UMFPACK2 library for fast solution of linear systems.

This is the last UMFPACK-library that was shipped as pure Fortran
source. Newer UMFPACK libraries are written in  and will be included
in the next FeatFlow-release.