# makefile fuer feat2dtest fuer sparc
#
OO=o
#
   FEATFLOW=XXFFXX
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libXXLIBXX
#
OBJ= $(OO)/feat2dtest.o\
     $(OO)/ii010.o\
     $(OO)/ir010.o\
     $(OO)/is010.o\
     $(OO)/xii01.o\
     $(OO)/xir01.o\
     $(OO)/xis01.o
#
COMOPT = XXCOXX
ARFLAGS = XXARXX
LDFLAGS =  $(FEATFLOWLIB)/libfeat2d.a  \
XX77XX
#
feat2dtest :$(OBJ)
	f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/feat2dtest.o: feat2dtest.f
	f77 -c $(COMOPT) feat2dtest.f -o $@
$(OO)/ii010.o: ii010.f
	f77 -c $(COMOPT) ii010.f -o $@
$(OO)/xii01.o: xii01.f
	f77 -c $(COMOPT) xii01.f -o $@
$(OO)/ir010.o: ir010.f
	f77 -c $(COMOPT) ir010.f -o $@
$(OO)/xir01.o: xir01.f
	f77 -c $(COMOPT) xir01.f -o $@
$(OO)/is010.o: is010.f
	f77 -c $(COMOPT) is010.f -o $@
$(OO)/xis01.o: xis01.f
	f77 -c $(COMOPT) xis01.f -o $@
