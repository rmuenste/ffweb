# makefile fuer tr2to3 fuer sparc
#
OO=o
#
   FEATFLOW=XXFFXX
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libXXLIBXX
#
OBJ= $(OO)/parq2d.o\
     $(OO)/rdparm.o\
     $(OO)/tr2to3.o\
     $(OO)/util.o
#
COMOPT = XXCOXX
ARFLAGS = XXARXX
LDFLAGS =   $(FEATFLOWLIB)/libfeat2d.a \
XX77XX
#
tr2to3 :  $(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/rdparm.o: rdparm.f
	f77 -c $(COMOPT) rdparm.f -o $@
$(OO)/tr2to3.o: tr2to3.f
	f77 -c $(COMOPT) tr2to3.f -o $@
$(OO)/util.o: util.f
	f77 -c $(COMOPT) util.f -o $@
