#!/bin/csh

set FEATFLOW = XXFFXX
echo "FEATFLOW Example"
echo "  "
echo "  "
echo "Processing:   2D, stationary"
echo "  "
cd $FEATFLOW/application/workspace
links.example
cd $FEATFLOW/application/example/input_files/o
rm *.o
#
cp $FEATFLOW/application/example/\#pre/c2d.tri $FEATFLOW/application/example/\#adc/c2d0.tri
cd $FEATFLOW/application/example/input_files
make -f trigen2d.m
mv $FEATFLOW/application/example/input_files/trigen2d $FEATFLOW/application/example/trigen2d
cd $FEATFLOW/application/example
cp \#data/trigen2d.dat_0 \#data/trigen2d.dat
trigen2d
cp \#data/trigen2d.dat_1 \#data/trigen2d.dat
trigen2d
cd $FEATFLOW/application/example/input_files
cp indat2d.f_stat indat2d.f
make -f cc2d.m
mv $FEATFLOW/application/example/input_files/cc2d $FEATFLOW/application/example/cc2d
cd $FEATFLOW/application/example
cc2d

echo " "
echo "======================================"
echo "   "
echo "Processing:   2D, non stationary"
echo "  "

cd $FEATFLOW/application/example/input_files
cp indat2d.f_non indat2d.f
make -f pp2d.m
mv $FEATFLOW/application/example/input_files/pp2d $FEATFLOW/application/example/pp2d
cd $FEATFLOW/application/example
pp2d

echo " "
echo "======================================"
echo "   "
echo "Processing:   3D, stationary"
echo "  "


cd $FEATFLOW/application/example/input_files
make -f tr2to3.m
mv $FEATFLOW/application/example/input_files/tr2to3 $FEATFLOW/application/example/tr2to3
make -f trigen3d.m
mv $FEATFLOW/application/example/input_files/trigen3d $FEATFLOW/application/example/trigen3d
cd $FEATFLOW/application/example

cd $FEATFLOW/application/example/input_files
cp indat3d.f_stat indat3d.f
make -f cc3d.m
mv $FEATFLOW/application/example/input_files/cc3d $FEATFLOW/application/example/cc3d
cd $FEATFLOW/application/example
tr2to3
trigen3d
cc3d

echo " "
echo "======================================"
echo "   "
echo "Processing:   3D, non stationary"
echo "  "

 
cd $FEATFLOW/application/example/input_files
cp indat3d.f_non indat3d.f
make -f pp3d.m
mv $FEATFLOW/application/example/input_files/pp3d $FEATFLOW/application/example/pp3d
cd $FEATFLOW/application/example
pp3d

