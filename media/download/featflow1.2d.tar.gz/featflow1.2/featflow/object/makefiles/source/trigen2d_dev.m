# makefile fuer trigen2d fuer sparc
#
OO=o
#
   FEATFLOW=XXFFXX
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libXXLIBXX
#
OBJ= $(OO)/avstr.o\
     $(OO)/bdrchk.o\
     $(OO)/cref1.o\
     $(OO)/cref2.o\
     $(OO)/cref3.o\
     $(OO)/cref4.o\
     $(OO)/cref5.o\
     $(OO)/cref6.o\
     $(OO)/owsc1.o\
     $(OO)/parq2d.o\
     $(OO)/rdparm.o\
     $(OO)/trigen2d.o\
     $(OO)/xcor.o
#
COMOPT = XXCOXX
ARFLAGS = XXARXX
LDFLAGS =   $(FEATFLOWLIB)/libfeat2d.a \
XX77XX
#
trigen2d :$(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/avstr.o: avstr.f
	f77 -c $(COMOPT) avstr.f -o $@
$(OO)/bdrchk.o: bdrchk.f
	f77 -c $(COMOPT) bdrchk.f -o $@
$(OO)/cref1.o: cref1.f
	f77 -c $(COMOPT) cref1.f -o $@
$(OO)/cref2.o: cref2.f
	f77 -c $(COMOPT) cref2.f -o $@
$(OO)/cref3.o: cref3.f
	f77 -c $(COMOPT) cref3.f -o $@
$(OO)/cref4.o: cref4.f
	f77 -c $(COMOPT) cref4.f -o $@
$(OO)/cref5.o: cref5.f
	f77 -c $(COMOPT) cref5.f -o $@
$(OO)/cref6.o: cref6.f
	f77 -c $(COMOPT) cref6.f -o $@
$(OO)/owsc1.o: owsc1.f
	f77 -c $(COMOPT) owsc1.f -o $@
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/rdparm.o: rdparm.f
	f77 -c $(COMOPT) rdparm.f -o $@
$(OO)/trigen2d.o: trigen2d.f
	f77 -c $(COMOPT) trigen2d.f -o $@
$(OO)/xcor.o: xcor.f
	f77 -c $(COMOPT) xcor.f -o $@
