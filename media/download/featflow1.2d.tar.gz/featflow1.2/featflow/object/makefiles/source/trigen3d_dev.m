# makefile fuer trigen3d fuer sparc
#
OO=o
#
   FEATFLOW=XXFFXX
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libXXLIBXX
#
OBJ= $(OO)/parq3d.o\
     $(OO)/trigen3d.o\
     $(OO)/util.o
#
COMOPT = XXCOXX
ARFLAGS = XXARXX
LDFLAGS =  $(FEATFLOWLIB)/libfeat3d.a \
$(FEATFLOWLIB)/libfeat2d.a \
XX77XX
#
trigen3d :  $(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/parq3d.o: parq3d.f
	f77 -c $(COMOPT) parq3d.f -o $@
$(OO)/trigen3d.o: trigen3d.f
	f77 -c $(COMOPT) trigen3d.f -o $@
$(OO)/util.o: util.f
	f77 -c $(COMOPT) util.f -o $@
