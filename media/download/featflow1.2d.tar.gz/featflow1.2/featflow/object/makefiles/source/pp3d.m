# makefile fuer pp3d fuer sparc
#
OO=o
#
   FEATFLOW=XXFFXX
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libXXLIBXX
    SRCPP3D=$(FEATFLOW)/source/pp3d/src
#
OBJ= $(OO)/indat3d.o\
     $(OO)/parq3d.o\
     $(OO)/pp3d.o
#
COMOPT = XXCOXX
ARFLAGS = XXARXX
LDFLAGS =  $(FEATFLOWLIB)/libpp3d.a \
$(FEATFLOWLIB)/libpp3dmg.a \
$(FEATFLOWLIB)/libfeat3d.a \
$(FEATFLOWLIB)/libfeat2d.a  \
XX77XX
#
pp3d :    $(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/indat3d.o: indat3d.f
	f77 -c $(COMOPT) indat3d.f -o $@
$(OO)/parq3d.o: parq3d.f
	f77 -c $(COMOPT) parq3d.f -o $@
$(OO)/pp3d.o: $(SRCPP3D)/pp3d.f pp3d.inc
	f77 -c $(COMOPT) $(SRCPP3D)/pp3d.f -o $@
