# makefile fuer feat3dtest fuer sparc
#
OO=o
#
   FEATFLOW=/home/cerberus5/featflow/sources/featflow1.2_new/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
#
OBJ= $(OO)/feat3dtest.o\
     $(OO)/parq.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:1024/64/1
ARFLAGS = rv
LDFLAGS =  $(FEATFLOWLIB)/libfeat3d.a \
$(FEATFLOWLIB)/libfeat2d.a \
-lF77 -xlic_lib=sunperf
#
feat3dtest :$(OBJ)
	    f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/feat3dtest.o: feat3dtest.f
	f77 -c $(COMOPT) feat3dtest.f -o $@
$(OO)/parq.o: parq.f
	f77 -c $(COMOPT) parq.f -o $@
