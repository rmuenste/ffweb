# makefile fuer cc2d fuer sparc
#
OO=o
#
   FEATFLOW=/home/people/cbecker/tmp/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libgen
    SRCCC2D=$(FEATFLOW)/source/cc2d/src
#
OBJ= $(OO)/indat2d.o\
     $(OO)/parq2d.o\
     $(OO)/cc2d.o
#
COMOPT =  
ARFLAGS = rv
LDFLAGS = $(FEATFLOWLIB)/libcc2d.a \
$(FEATFLOWLIB)/libcc2dmg.a \
$(FEATFLOWLIB)/libfeat2d.a \
-lF77 $(FEATFLOWLIB)/libblas.a
#
cc2d :    $(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/indat2d.o: indat2d.f
	f77 -c $(COMOPT) indat2d.f -o $@
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/cc2d.o: $(SRCCC2D)/cc2d.f cc2d.inc
	f77 -c $(COMOPT) $(SRCCC2D)/cc2d.f -o $@
