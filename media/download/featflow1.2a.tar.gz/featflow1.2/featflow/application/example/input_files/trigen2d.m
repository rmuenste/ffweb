# makefile fuer trigen2d fuer sparc
#
OO=o
#
   FEATFLOW=/home/people/cbecker/tmp/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libgen
    SRCTRIGEN2D=$(FEATFLOW)/source/trigen2d/src
#
OBJ= $(OO)/parq2d.o\
     $(OO)/trigen2d.o
#
COMOPT = 
ARFLAGS = rv
LDFLAGS =  $(FEATFLOWLIB)/libtrigen2d.a \
$(FEATFLOWLIB)/libfeat2d.a \
-lF77 $(FEATFLOWLIB)/libblas.a
#
trigen2d :$(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/trigen2d.o: $(SRCTRIGEN2D)/trigen2d.f trigen2d.inc
	f77 -c $(COMOPT) $(SRCTRIGEN2D)/trigen2d.f -o $@
