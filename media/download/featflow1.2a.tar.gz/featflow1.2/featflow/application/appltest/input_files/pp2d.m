# makefile fuer pp2d fuer ibm-pwr2
#
OO=o
#
   FEATFLOW=/net/blue/ture/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libgen
    SRCPP2D=$(FEATFLOW)/source/pp2d/src
#
OBJ= $(OO)/indat2d.o\
     $(OO)/parq2d.o\
     $(OO)/pp2d.o
#
COMOPT = -qarch=pwr2 -qtune=pwr2 -O3 
ARFLAGS = rv
LDFLAGS =  \
/usr/lib/libesslp2.a \
/usr/lib/libblas.a \
$(FEATFLOWLIB)/libpp2d.a \
$(FEATFLOWLIB)/libpp2dmg.a \
$(FEATFLOWLIB)/libfeat2d.a
#
pp2d :    $(OBJ)
	  f77 $(COMOPT) -bmaxdata:0x40000000 $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/indat2d.o: indat2d.f
	f77 -c $(COMOPT) indat2d.f -o $@
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/pp2d.o: $(SRCPP2D)/pp2d.f pp2d.inc
	f77 -c $(COMOPT) $(SRCPP2D)/pp2d.f -o $@
