# makefile fuer bouss_powerlaw fuer ultra
#
OO=o
#
   FEATFLOW=/home/people/featflow/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
#
OBJ= $(OO)/avs2d.o\
$(OO)/bmul.o\
$(OO)/bndry.o\
$(OO)/bouss.o\
$(OO)/coeff.o\
$(OO)/dfkt.o\
$(OO)/error.o\
$(OO)/fpost.o\
$(OO)/gupwd.o\
$(OO)/hwahl.o\
$(OO)/indat2d.o\
$(OO)/init1.o\
$(OO)/matmul.o\
$(OO)/mgrout.o\
$(OO)/mgcort.o\
$(OO)/nsdef.o\
$(OO)/optcnl.o\
$(OO)/oralB.o\
$(OO)/parq2d.o\
$(OO)/projma.o\
$(OO)/prostp.o\
$(OO)/rdparm.o\
$(OO)/supwdgn.o\
$(OO)/tupwdg.o\
$(OO)/trsort.o\
$(OO)/tcalc.o\
$(OO)/tdef.o\
$(OO)/tdfkt.o\
$(OO)/trand.o\
$(OO)/util.o\
$(OO)/xmrout.o\
$(OO)/zvalue1.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:1024/64/1 
ARFLAGS = rv
LDFLAGS = $(FEATFLOWLIB)/libfeat2d.a \
-lF77 -xlic_lib=sunperf
#
bouss_powerlaw :$(OBJ)
	f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@
#
$(OO)/avs2d.o: avs2d.f
	f77 -c $(COMOPT) avs2d.f -o $@
$(OO)/bmul.o: bmul.f
	f77 -c $(COMOPT) bmul.f -o $@
$(OO)/bndry.o: bndry.f
	f77 -c $(COMOPT) bndry.f -o $@
$(OO)/bouss.o: bouss.f
	f77 -c $(COMOPT) bouss.f -o $@
$(OO)/coeff.o: coeff.f
	f77 -c $(COMOPT) coeff.f -o $@
$(OO)/dfkt.o: dfkt.f
	f77 -c $(COMOPT) dfkt.f -o $@
$(OO)/error.o: error.f
	f77 -c $(COMOPT) error.f -o $@
$(OO)/fpost.o: fpost.f
	f77 -c $(COMOPT) fpost.f -o $@
$(OO)/gupwd.o: gupwd.f
	f77 -c $(COMOPT) gupwd.f -o $@
$(OO)/hwahl.o: hwahl.f
	f77 -c $(COMOPT) hwahl.f -o $@
$(OO)/indat2d.o: indat2d.f
	f77 -c $(COMOPT) indat2d.f -o $@
$(OO)/init1.o: init1.f bouss.inc
	f77 -c $(COMOPT) init1.f -o $@
$(OO)/matmul.o: matmul.f
	f77 -c $(COMOPT) matmul.f -o $@
$(OO)/mgrout.o: mgrout.f
	f77 -c $(COMOPT) mgrout.f -o $@
$(OO)/mgcort.o: mgcort.f
	f77 -c $(COMOPT) mgcort.f -o $@
$(OO)/nsdef.o: nsdef.f
	f77 -c $(COMOPT) nsdef.f -o $@
$(OO)/optcnl.o: optcnl.f
	f77 -c $(COMOPT) optcnl.f -o $@
$(OO)/oralB.o: oralB.f
	f77 -c $(COMOPT) oralB.f -o $@
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/projma.o: projma.f
	f77 -c $(COMOPT) projma.f -o $@
$(OO)/prostp.o: prostp.f
	f77 -c $(COMOPT) prostp.f -o $@
$(OO)/rdparm.o: rdparm.f
	f77 -c $(COMOPT) rdparm.f -o $@
$(OO)/supwdgn.o: supwdgn.f
	f77 -c $(COMOPT) supwdgn.f -o $@
$(OO)/tupwdg.o: tupwdg.f
	f77 -c $(COMOPT) tupwdg.f -o $@
$(OO)/trsort.o: trsort.f
	f77 -c $(COMOPT) trsort.f -o $@
$(OO)/tcalc.o: tcalc.f common.inc dwork.inc
	f77 -c $(COMOPT) tcalc.f -o $@
$(OO)/tdef.o: tdef.f common.inc
	f77 -c $(COMOPT) tdef.f -o $@
$(OO)/tdfkt.o: tdfkt.f
	f77 -c $(COMOPT) tdfkt.f -o $@
$(OO)/trand.o: trand.f common.inc dwork.inc
	f77 -c $(COMOPT) trand.f -o $@
$(OO)/util.o: util.f bouss.inc
	f77 -c $(COMOPT) util.f -o $@
$(OO)/xmrout.o: xmrout.f
	f77 -c $(COMOPT) xmrout.f -o $@
$(OO)/zvalue1.o: zvalue1.f
	f77 -c $(COMOPT) zvalue1.f -o $@
