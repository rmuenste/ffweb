# makefile fuer tr2to3 fuer sparc
#
OO=o
#
   FEATFLOW=/home/people/featflow/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
#
OBJ= $(OO)/parq2d.o\
     $(OO)/rdparm.o\
     $(OO)/tr2to3.o\
     $(OO)/util.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:1024/64/1 
ARFLAGS = rv
LDFLAGS = $(FEATFLOWLIB)/libfeat2d.a \
-lF77 -xlic_lib=sunperf
#
tr2to3 :  $(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/rdparm.o: rdparm.f
	f77 -c $(COMOPT) rdparm.f -o $@
$(OO)/tr2to3.o: tr2to3.f
	f77 -c $(COMOPT) tr2to3.f -o $@
$(OO)/util.o: util.f
	f77 -c $(COMOPT) util.f -o $@
