# makefile fuer cc3d fuer sparc
#
OO=o
#
   FEATFLOW=/home/atlas2/featflow/featflow_ultra60/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
#
OBJ= $(OO)/avs3d.o\
$(OO)/bmul.o\
$(OO)/bndry.o\
$(OO)/cc3d.o\
$(OO)/coeff.o\
$(OO)/dfkt.o\
$(OO)/error.o\
$(OO)/fpost.o\
$(OO)/gupwd.o\
$(OO)/indat3d.o\
$(OO)/init1.o\
$(OO)/matmul.o\
$(OO)/mgrout.o\
$(OO)/mgstp.o\
$(OO)/nsdef.o\
$(OO)/optcnl.o\
$(OO)/parq3d.o\
$(OO)/rdparm.o\
$(OO)/supwdg.o\
$(OO)/util.o\
$(OO)/vanca.o\
$(OO)/xmrout.o\
$(OO)/zvalue1.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:2048/64/1
ARFLAGS = rv
LDFLAGS = $(FEATFLOWLIB)/libfeat3d.a \
$(FEATFLOWLIB)/libfeat2d.a \
-lF77 -xlic_lib=sunperf
#
cc3d_movbc :$(OBJ)
	f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/avs3d.o: avs3d.f
	f77 -c $(COMOPT) avs3d.f -o $@
$(OO)/bmul.o: bmul.f
	f77 -c $(COMOPT) bmul.f -o $@
$(OO)/bndry.o: bndry.f
	f77 -c $(COMOPT) bndry.f -o $@
$(OO)/cc3d.o: cc3d.f
	f77 -c $(COMOPT) cc3d.f -o $@
$(OO)/coeff.o: coeff.f
	f77 -c $(COMOPT) coeff.f -o $@
$(OO)/dfkt.o: dfkt.f
	f77 -c $(COMOPT) dfkt.f -o $@
$(OO)/error.o: error.f
	f77 -c $(COMOPT) error.f -o $@
$(OO)/fpost.o: fpost.f
	f77 -c $(COMOPT) fpost.f -o $@
$(OO)/gupwd.o: gupwd.f
	f77 -c $(COMOPT) gupwd.f -o $@
$(OO)/indat3d.o: indat3d.f
	f77 -c $(COMOPT) indat3d.f -o $@
$(OO)/init1.o: init1.f
	f77 -c $(COMOPT) init1.f -o $@
$(OO)/matmul.o: matmul.f
	f77 -c $(COMOPT) matmul.f -o $@
$(OO)/mgrout.o: mgrout.f
	f77 -c $(COMOPT) mgrout.f -o $@
$(OO)/mgstp.o: mgstp.f
	f77 -c $(COMOPT) mgstp.f -o $@
$(OO)/optcnl.o: optcnl.f
	f77 -c $(COMOPT) optcnl.f -o $@
$(OO)/parq3d.o: parq3d.f
	f77 -c $(COMOPT) parq3d.f -o $@
$(OO)/rdparm.o: rdparm.f
	f77 -c $(COMOPT) rdparm.f -o $@
$(OO)/supwdg.o: supwdg.f
	f77 -c $(COMOPT) supwdg.f -o $@
$(OO)/nsdef.o: nsdef.f
	f77 -c $(COMOPT) nsdef.f -o $@
$(OO)/util.o: util.f
	f77 -c $(COMOPT) util.f -o $@
$(OO)/vanca.o: vanca.f
	f77 -c $(COMOPT) vanca.f -o $@
$(OO)/xmrout.o: xmrout.f
	f77 -c $(COMOPT) xmrout.f -o $@
$(OO)/zvalue1.o: zvalue1.f
	f77 -c $(COMOPT) zvalue1.f -o $@
