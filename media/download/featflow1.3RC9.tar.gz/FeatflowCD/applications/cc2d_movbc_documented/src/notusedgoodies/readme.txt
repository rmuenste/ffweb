This directory contains various files with additional routines
which are not yet part of this cc2d_movbc package, but have been
found useful.
They cover an extended way for treating triangulation structures,
introduce new arrays and give a structured way of dealing with
geometrical aspects that are not part of FeatFlow yet, e.g.
more that one point per edge...

Be aware that these routines might be buggy and a matter of change!

Michael K�ster, September 2005
