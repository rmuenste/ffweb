#include "Task.h"
#include "Daten.h"
#include "unistd.h"				  // for unlink
#ifndef USE_KCC
#include <memory>				  // for set_new_handler
#endif

//#define MAX_PROC  128

class	CProcessApp {
public:
    CProcessApp(const char* mFile);
    virtual 	  ~CProcessApp() {}

    virtual void   Run();
    void           ReadData(CInput& Daten);
    void           CheckParams();
    void	   InitTasks();

protected:
    const char*    File;
    Daten          Param;
};
