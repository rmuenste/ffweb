#ifndef ERRORCODES_H

#define ERRORCODES_H

// Define error codes when program aborts
#define FILE_OPEN_ERROR                 201		  // CInput & COutput
#define FILE_READ_ERROR                 202		  // CInput & COutput
#define FILE_WRITE_ERROR                203		  // CInput & COutput
#define ILLEGAL_INPUT_ERROR             206
#define ILLEGAL_PARTITION_ERROR         207
#define GMV_EXPORT_ERROR                208
#define ILLEGAL_COEFF_CASE_ERROR        209
#define BUILD_PROJ_MATRIX_ERROR         210		  // CCoarseGrid
#define UPWIND_ERROR                    211		  // CCoarseGrid
#define BETA_TEST_ERROR                 212		  // CCoarseGrid &
#define ILLEGAL_BOUNDARY_INFO_ERROR     213		  // Task
#define VIRTUAL_MEMORY_EXHAUSTED_ERROR  214
#define FACE_WITHOUT_ELEMENTS           215
#define DETERMINANT_ZERO                216
#define DERIVATES_NOT_AVAILABLE         217
#define IA_NOT_FOUND                    218
#define DIVERGENCE                      219	          // ParMultiGrid_3D

#endif
