#ifndef FEATDOMAINBOUND_H

#define FEATDOMAINBOUND_H

#include <LinLib.h>
#include <math.h>
#include "ParGrid.h"
#include "Const.h"

#define EPS  1e-6

class FeatDomainBound:public ParGrid
{
 protected:
  bIntArraylist_base    *SendBound;
  bIntArraylist_base    *RecvBound;
  bDVectorlist_base     *SendBoundData;
  bDVectorlist_base     *RecvBoundData;

  bIntArraylist_base    *SendNeumannBound;
  bIntArraylist_base    *RecvNeumannBound;
  bDVectorlist_base     *SendNeumannBoundData;
  bDVectorlist_base     *RecvNeumannBoundData;

  bIntArraylist_base    *MSendBound[MAXARRAY];
  bIntArraylist_base    *MRecvBound[MAXARRAY];
  bDVectorlist_base     *MSendBoundData[MAXARRAY];
  bDVectorlist_base     *MRecvBoundData[MAXARRAY];

  bIntArraylist_base    *MSendNeumannBound[MAXARRAY];
  bIntArraylist_base    *MRecvNeumannBound[MAXARRAY];
  bDVectorlist_base     *MSendNeumannBoundData[MAXARRAY];
  bDVectorlist_base     *MRecvNeumannBoundData[MAXARRAY];

  bIntArraylist_base    *SendElemBound;
  bIntArraylist_base    *RecvElemBound;
  bIntArraylist_base    *SendFaceBound;
  bIntArraylist_base    *RecvFaceBound;
  bDVectorlist_base     *SendElemBoundData;
  bDVectorlist_base     *RecvElemBoundData;

  bIntArraylist_base    *MSendElemBound[MAXARRAY];
  bIntArraylist_base    *MRecvElemBound[MAXARRAY];
  bIntArraylist_base    *MSendFaceBound[MAXARRAY];
  bIntArraylist_base    *MRecvFaceBound[MAXARRAY];
  bDVectorlist_base     *MSendElemBoundData[MAXARRAY];
  bDVectorlist_base     *MRecvElemBoundData[MAXARRAY];

  blistlist_base        *SPInfo;
  coord_base_3D         *SPCoord;

 public:
  FeatDomainBound(VOID);
  ~FeatDomainBound(VOID);

  void  InitDomainBound(VOID);
  void  InitDomainElemBound(VOID);
  void  InitDomainNeumannBound(VOID);

  void  SetBound(DoubleCompactMatrix* LA);
  void  SetBoundRightU(DoubleVector* u, double T);
  void  SetBoundRightF(DoubleVector* f, double T);
#ifdef INCLUDE_TEMPERATURE
  void  SetBoundRightBouss(DoubleVector* b);
#endif
  void  SetLumpBound(MultiVector* Lump);

  void  SetBoundValues(DoubleVector* x);
  void  GetBoundValuesMult(DoubleVector* x);
  void  SetElemBoundValues(DoubleVector* x);
  void  GetElemBoundValues(DoubleVector* x);
  void  HalfBoundValues(DoubleVector* x,DoubleVector* x2);
  void  SetNeumannBoundValues(DoubleVector* x);
  void  GetNeumannBoundValuesMult(DoubleVector* x);
  void  HalfNeumannBoundValues(DoubleVector* x,DoubleVector* x2);
  void  SetSPValues(DoubleVector* x,DoubleVector* x2);

  int FindElem(int elem,int face,double& p,int level);


  DoubleArray2D*  GetBoundInfo(IntArray *arr);
  void            SetBoundInfo(DoubleArray2D *arr,int neigh);
  void            SetNeumannBoundInfo(DoubleArray2D *arr,int neigh);

  void            GetElemBoundInfo();
  DoubleArray2D*  GetElemBoundInfo(IntArray *arr,IntArray *arr2);
  void            SetElemBoundInfo(DoubleArray2D *arr,int neigh);

  DoubleArray2D*  GetSPInfo();
  void            SetSPInfo(DoubleArray2D *arr,int neigh);
  DoubleArray2D*  GetSPVector(DoubleVector *v1,DoubleVector *v2,int myproc);
  void            SetSPVector(DoubleArray2D *arr,int neigh,DOUBLE& temp);

  void            SetLocalBound(DoubleCompactMatrix* LA,DoubleVector* LB,
                                DoubleVector* LX);
  void            SetHarmonicBound(DoubleCompactMatrix* LA,DoubleVector* LB,
                                   DoubleVector* LX,DoubleVector* BOUND);

  void            SetBoundData(DoubleVector *recv,DoubleVector *set);
  IntArray       *GetRealBound(VOID) {return RealBound;}

  void            AppendBoundNode(int pnode1,int pnode2,int nnode,int info);
  void            AppendBoundNode(int pnode1,int pnode2,
                                  int pnode3,int pnode4,int nnode,int info);
  void            AppendMidBoundNode(int pnode1,int pnode2,
                                     int pnode3,int pnode4,int nnode,int info);

  void            PrintSendData();
  void            PrintRecvData();
};

#endif




