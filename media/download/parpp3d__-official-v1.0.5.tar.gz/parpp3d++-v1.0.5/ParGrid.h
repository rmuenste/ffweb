
#ifndef PARGRIDH

#define PARGRIDH

#include <SquareGrid_3D.h>
#include <ParFiniteElement_3D.h>
#include <ParTrilinearElement_3D.h>
#include <ParRotatedElement_3D.h>
#include <ParNonParamElement_3D.h>
#include <ParNonParamMeanElement_3D.h>
#include <math.h>
#include <ParCompactMatrix.h>
#include <ParMultiGrid_3D.h>
#include "CCoarseGrid.h"
#include "PostGrid.h"
#include "String.h"
#include "blist.h"
#include "Daten.h"
#include "Errorcodes.h"			  // for error codes

#define UPWIND      1
#define STREAMLINE  2

extern Output StdOut;


class ParGrid:public ParMultiGrid_3D
{
protected:
    double 	DTime;
    UNSIGNED      Coeff,CoeffRhs;
    DoubleArray3D	    *DBAS;
    IntArray	    *KDFL;
    IntArray	    *KDFG;

    Daten *Param;
		  
    // Globale Daten
    ParFiniteElement_3D *RotElement;
    ParFiniteElement_3D *MassRotElement;
    FiniteElement_3D 	*ConElement; 
    DoubleVector	*f; 
    MultiCompactMatrix 	*C, *M, *A; 
    MultiRectMatrix 	*B1, *B2, *B3; 
    MultiVector         *LumpM, *PureLumpM; 
    DoubleVector        *vstart1, *vstart2, *vstart3; 
    DoubleVector        *Sol1, *Sol2, *Sol3, *CN1, *CN2, *CN3, *P, *CP, *Conc;  

    Output 		*ErrorFile;
    IntArray	   	*RealBound;
    node_base           *myBase;
    node_base           *myMidBase;
    node_base           *myMidNeighBase;
    elem_base           *myElemBase;
    blist_base          *real_nodeBase;
    blist_base          *konreal_nodeBase;
    blist_base          *InfoList;
    blist_base          *real_midnodeBase;
    node_base           *konBase;
    int			 NumCoarseElements;
  
    IntArray	   	*MRealBound[MAXARRAY];
    node_base           *MmyBase[MAXARRAY];
    elem_base           *MmyElemBase[MAXARRAY];
    blist_base          *Mreal_nodeBase[MAXARRAY];
    blist_base          *Mkonreal_nodeBase[MAXARRAY];
    blist_base          *MInfoList[MAXARRAY];

    IntArray            *MFaceInfo[MAXARRAY];
    IntArray            *FaceInfo;
    IntArray            *MElemInfo[MAXARRAY];
    IntArray            *ElemInfo;

  
    FILE		*MyProtFile;  
    // Coarse Grid
    CCoarseGrid         *CoarseGrid;
    // PostGrid
    PostGrid            *GlobalGrid;

public:
    ParGrid(void):CoarseGrid(NULL) {}
    ~ParGrid(void) {}

    IntArray  *GetBoundInfo() {return RealBound;}
  
    double    Solution(double X, double Y, double Z, double T);
    double    SolutionDX(double X, double Y, double Z);
    double    SolutionDY(double X, double Y, double Z);
    double    SolutionDZ(double X, double Y, double Z);
    double    CoeffBX(double X, double Y, double Z) {return 0;}
    double    CoeffBY(double X, double Y, double Z) {return 0;}
    double    CoeffBZ(double X, double Y, double Z) {return 0;}
    double    RightSideCoeff(double X,double Y, double Z, int IB, int BFIRST);
    double    StiffCoeff(double X, double Y, double Z, int IA, int IB, int BFIRST);

    void      SetMultiBound(MultiCompactMatrix* A, DoubleVector* LB, DoubleVector* LX, double T);
    void      SetMidMultiBound(MultiCompactMatrix* A, DoubleVector* LB, DoubleVector* LX, double T);
    void      SetMultiBound(MultiCompactMatrix* A);
    void      SetBoundDefekt(DoubleVector *b);

    void      CopyBoundaryData(DoubleVector *LB);

    void      CreateBoundInfo();
  
    void      ReadCoarseGrid(const char* name);

    void      PrintCoarseNeigh(void);
    void      PrintCoarseCoord(void);
    void      PrintCoarseElem(void);

    int       GetMakroInfo(unsigned mnum, MComTool *MyCom);
};

#endif


