#include "FeatDomainBound.h"

//#define CONTROL_MSG

FeatDomainBound::FeatDomainBound()
{
  SendBound=0;
  RecvBound=0;
  SendBoundData=0;
  RecvBoundData=0;
}

VOID FeatDomainBound::InitDomainBound(VOID)
{
  myBase->build_array(SendBoundData);
  myBase->build_array(RecvBoundData);
  
#ifdef CONTROL_MSG
  SendBoundData->print_list();
  RecvBoundData->print_list();	
#endif
}

VOID FeatDomainBound::InitDomainNeumannBound(VOID)
{
  myBase->build_neumann_array(SendNeumannBoundData);
  myBase->build_neumann_array(RecvNeumannBoundData);
  
#ifdef CONTROL_MSG
  SendNeumannBoundData->print_list();
  RecvNeumannBoundData->print_list();	
#endif
}

VOID FeatDomainBound::InitDomainElemBound(VOID)
{
    if (Debug) {
      protocol << "DEBUG(" << MyProcID << "): Entering FeatDomainBound::InitDomainElemBound.\n";
      protocol.mFlush();
    }

  myElemBase->build_array(SendElemBoundData);
  myElemBase->build_array(RecvElemBoundData);
  
#ifdef CONTROL_MSG
  SendElemBoundData->print_list();
  RecvElemBoundData->print_list();	
#endif

    if (Debug) {
      protocol << "DEBUG(" << MyProcID << "):  Leaving FeatDomainBound::InitDomainElemBound.\n";
      protocol.mFlush();
    }
}

FeatDomainBound::~FeatDomainBound(VOID)
{
//  if(SendBoundData)
//      delete SendBoundData;
//  if(RecvBoundData)
//      delete RecvBoundData;
}


void FeatDomainBound::AppendBoundNode(int pnode1,int pnode2,int nnode,int info)
{
  blist *temp;
  blink *link1,*link2;
  
  for(temp=myBase->get_neighlist()->get_first();temp;
			      temp=myBase->get_neighlist()->get_next(temp))
  {
    if(temp->base->find(pnode1,pnode2))
    {
      link1=temp->base->find_node(pnode1);
      link2=temp->base->find_node(pnode2);
      if(link1->type==REAL_BOUND && link2->type==REAL_BOUND)
      {
	if(link1->numneigh==1 || link2->numneigh==1)
	  {
//	    Prot<<"Add Boundnode (REAL_BOUND 1) n1="<<pnode1<<" n2="<<pnode2<<" node="<<nnode<<" neigh="<<temp->neigh<<" !!\n";
	    InfoList->append(nnode,REAL_BOUND,1);
	    temp->base->append(nnode,REAL_BOUND,1);
	  }
//	else if(link1->numneigh==7 || link2->numneigh==7 
//		|| link1->numneigh==3 || link2->numneigh==3)
	else
	  {
//	    Prot<<"Add Boundnode (REAL_BOUND 3) n1="<<pnode1<<" n2="<<pnode2<<" node="<<nnode<<" neigh="<<temp->neigh<<" !!\n";
	    InfoList->append(nnode,REAL_BOUND,3);
	    temp->base->append(nnode,REAL_BOUND,3);
	  }

      } else {
	if(link1->numneigh==1 || link2->numneigh==1)
	  {
	    InfoList->append(nnode,ART_BOUND,1);
	    temp->base->append(nnode,ART_BOUND,1);
//	  } else if(link1->numneigh==7 || link2->numneigh==7 
//		    || link1->numneigh==3 || link2->numneigh==3) {
	  } else {
	    InfoList->append(nnode,ART_BOUND,3);
	    temp->base->append(nnode,ART_BOUND,3);
	  }
//	Prot<<"Add Boundnode (ART_BOUND) n1="<<pnode1<<" n2="<<pnode2<<" node="<<nnode<<" neigh="<<temp->neigh<<" !!\n";
      }
    }
  }
  if(info!=0)
  {
    real_nodeBase->append(nnode,REAL_BOUND);
  }
}

void FeatDomainBound::AppendBoundNode(int pnode1,int pnode2,
				      int pnode3,int pnode4,int nnode,int info)
{
  blist *temp,*tempneigh;
  
  if(info==0)
  {
//    Prot<<"AppendMidBoundNode: pnode1="<<pnode1<<" pnode2="<<pnode2<<" pnode3="<<pnode3<<" pnode4="<<pnode4<<"\n";
    if(ActiveLevel==0 || ActiveLevel==1) {
      tempneigh=myMidNeighBase->findmid(pnode1,pnode2,pnode3,pnode4);
      if(tempneigh) {
	temp=myBase->find_neighlist(tempneigh->neigh);
	temp->base->append(nnode,ART_BOUND,pnode1,pnode2,pnode3,pnode4);
	InfoList->append(nnode,ART_BOUND,1);
	//      Prot<<"Add Boundnode (ART_BOUND) n1="<<pnode1<<" n2="<<pnode2<<" n3="<<pnode3<<" n4="<<pnode4<<" node="<<nnode<<" neigh="<<temp->neigh<<" !!\n";
      }
    } else {
      temp=myBase->find(pnode1,pnode2,pnode3,pnode4);
      if(temp) {
	temp->base->append(nnode,ART_BOUND,1);
	InfoList->append(nnode,ART_BOUND,1);
      }
    }
  } else {
    if(ActiveLevel==0 || ActiveLevel==1) {
      tempneigh=myMidNeighBase->findmid(pnode1,pnode2,pnode3,pnode4);
      if(tempneigh) {
	temp=myBase->find_neighlist(tempneigh->neigh);
	temp->base->append(nnode,ART_BOUND,pnode1,pnode2,pnode3,pnode4);
	InfoList->append(nnode,ART_BOUND,1);
      }
    } else {
      temp=myBase->find(pnode1,pnode2,pnode3,pnode4);
      if(temp) {
	temp->base->append(nnode,ART_BOUND,1);
	InfoList->append(nnode,ART_BOUND,1);
      }
    }
    real_nodeBase->append(nnode,REAL_BOUND);

//      Prot<<"Add Boundnode (REAL_BOUND) n1="<<pnode1<<" n2="<<pnode2<<" n3="<<pnode3<<" n4="<<pnode4<<" node="<<nnode<<" !!\n";
  }
}

void FeatDomainBound::AppendMidBoundNode(int pnode1,int pnode2,
					 int pnode3,int pnode4,int nnode,int info)
{
  blist *temp,*tempneigh;

//  Prot<<"AppendMidBoundNode: "<<pnode1<<" "<<pnode2<<" "<<pnode3<<" "<<pnode4<<" info: "<<info<<"\n";

  if(info==0)
  {
//    Prot<<"AppendMidBoundNode: pnode1="<<pnode1<<" pnode2="<<pnode2<<" pnode3="<<pnode3<<" pnode4="<<pnode4<<"\n";
    temp=myBase->find(pnode1,pnode2,pnode3,pnode4);
    if(temp)
    {
//    Prot<<"Add Midpoint (ART_BOUND) n1="<<pnode1<<" n2="<<pnode2<<" n3="<<pnode3<<" n4="<<pnode4<<" node="<<nnode<<" neigh="<<temp->neigh<<" !!\n";
      //  Prot<<"AppendMidBoundNode: Add Midpoint="<<nnode<<"\n";
      //Prot<<"   node="<<pnode1<<" X="<<(*VertCoord)(1,pnode1)<<" Y="<<(*VertCoord)(2,pnode1)<<" Z="<<(*VertCoord)(3,pnode1)<<"\n";
      //Prot<<"   node="<<pnode2<<" X="<<(*VertCoord)(1,pnode2)<<" Y="<<(*VertCoord)(2,pnode2)<<" Z="<<(*VertCoord)(3,pnode2)<<"\n";
      //Prot<<"   node="<<pnode3<<" X="<<(*VertCoord)(1,pnode3)<<" Y="<<(*VertCoord)(2,pnode3)<<" Z="<<(*VertCoord)(3,pnode3)<<"\n";
      //Prot<<"   node="<<pnode4<<" X="<<(*VertCoord)(1,pnode4)<<" Y="<<(*VertCoord)(2,pnode4)<<" Z="<<(*VertCoord)(3,pnode4)<<"\n";

      if(ActiveLevel==0) {
	tempneigh=myMidNeighBase->findmid(pnode1,pnode2,pnode3,pnode4);
	if(tempneigh) {
	  temp=myMidBase->find_neighlist(tempneigh->neigh);
	  temp->base->append(nnode,ART_BOUND,pnode1,pnode2,pnode3,pnode4);
	}
      } else {
	temp=myMidBase->find_neighlist(temp->neigh);
	temp->base->append(nnode,ART_BOUND,pnode1,pnode2,pnode3,pnode4);
      }
    } else {
      //Prot<<"AppendMidBoundNode: can't find nodes "<<pnode1<<" "<<pnode2<<" "<<pnode3<<" "<<pnode4<<"\n";
      //Prot<<"AppendMidBoundNode: can't find nodes\n";
      //Prot<<"   node="<<pnode1<<" X="<<(*VertCoord)(1,pnode1)<<" Y="<<(*VertCoord)(2,pnode1)<<" Z="<<(*VertCoord)(3,pnode1)<<"\n";
      //Prot<<"   node="<<pnode2<<" X="<<(*VertCoord)(1,pnode2)<<" Y="<<(*VertCoord)(2,pnode2)<<" Z="<<(*VertCoord)(3,pnode2)<<"\n";
      //Prot<<"   node="<<pnode3<<" X="<<(*VertCoord)(1,pnode3)<<" Y="<<(*VertCoord)(2,pnode3)<<" Z="<<(*VertCoord)(3,pnode3)<<"\n";
      //Prot<<"   node="<<pnode4<<" X="<<(*VertCoord)(1,pnode4)<<" Y="<<(*VertCoord)(2,pnode4)<<" Z="<<(*VertCoord)(3,pnode4)<<"\n";
    }
  } else {
    temp=myBase->find(pnode1,pnode2,pnode3,pnode4);
    if(temp)
    {
      //Prot<<"!! Info!=0 !! Add Midpoint (ART_BOUND) n1="<<pnode1<<" n2="<<pnode2<<" n3="<<pnode3<<" n4="<<pnode4<<" node="<<nnode<<" !!\n";
      if(ActiveLevel==0) {
	tempneigh=myMidNeighBase->findmid(pnode1,pnode2,pnode3,pnode4);
	if(tempneigh) {
	  temp=myMidBase->find_neighlist(tempneigh->neigh);
	  temp->base->append(nnode,ART_BOUND,pnode1,pnode2,pnode3,pnode4);
	} else {
          real_midnodeBase->append(nnode,REAL_BOUND,pnode1,pnode2,pnode3,pnode4);
	}
      } else {
	temp=myMidBase->find_neighlist(temp->neigh);
	temp->base->append(nnode,ART_BOUND,pnode1,pnode2,pnode3,pnode4);
      }
    } else {
      //Prot<<"!! Info!=0 !! AppendMidBoundNode: can't find nodes\n";
      //Prot<<"   node="<<pnode1<<" X="<<(*VertCoord)(1,pnode1)<<" Y="<<(*VertCoord)(2,pnode1)<<" Z="<<(*VertCoord)(3,pnode1)<<"\n";
      //Prot<<"   node="<<pnode2<<" X="<<(*VertCoord)(1,pnode2)<<" Y="<<(*VertCoord)(2,pnode2)<<" Z="<<(*VertCoord)(3,pnode2)<<"\n";
      //Prot<<"   node="<<pnode3<<" X="<<(*VertCoord)(1,pnode3)<<" Y="<<(*VertCoord)(2,pnode3)<<" Z="<<(*VertCoord)(3,pnode3)<<"\n";
      //Prot<<"   node="<<pnode4<<" X="<<(*VertCoord)(1,pnode4)<<" Y="<<(*VertCoord)(2,pnode4)<<" Z="<<(*VertCoord)(3,pnode4)<<"\n";
      real_midnodeBase->append(nnode,REAL_BOUND,pnode1,pnode2,pnode3,pnode4);
    }
  }
}

DoubleArray2D* FeatDomainBound::GetBoundInfo(IntArray *arr)
{
  DoubleArray2D *temp;
  blink *link;
  int i;
	
  if(arr)
  {
    if(Param->ElemType==1)
    {
      temp=new DoubleArray2D(3,arr->GetLen());
      for(i=1;i<=arr->GetLen();i++)
      {
	(*temp)(1,i)=(*VertCoord)(1,(*arr)(i));
	(*temp)(2,i)=(*VertCoord)(2,(*arr)(i));
	(*temp)(3,i)=(*VertCoord)(3,(*arr)(i));
      }
#ifdef CONTROL_MSG		
      Prot<<"GetBoundInfo : temp=\n"<<*temp<<"\n\n";
#endif
    } else if(Param->ElemType==2) {
      temp=new DoubleArray2D(3,arr->GetLen());
      for(i=1;i<=arr->GetLen();i++)
      {
	link=myBase->find_node((*arr)(i));
	if(link==NULL)
	{
	  Prot<<"\nlink==NULL\n";
	  protocol << progname << " (process " << MyProcID << "):\n"
		   << "  Program aborted in FeatDomainBound::GetBoundInfo\n";
	  MPI_Finalize();
	  exit(0);
	}
	(*temp)(1,i)=
	  0.25*((*VertCoord)(1,link->node1)+(*VertCoord)(1,link->node2)
		+(*VertCoord)(1,link->node3)+(*VertCoord)(1,link->node4));
	(*temp)(2,i)=
	  0.25*((*VertCoord)(2,link->node1)+(*VertCoord)(2,link->node2)
		+(*VertCoord)(2,link->node3)+(*VertCoord)(2,link->node4));
	(*temp)(3,i)=
	  0.25*((*VertCoord)(3,link->node1)+(*VertCoord)(3,link->node2)
		+(*VertCoord)(3,link->node3)+(*VertCoord)(3,link->node4));
      }
#ifdef CONTROL_MSG		
      Prot<<"GetBoundInfo MidCoord: temp=\n"<<*temp<<"\n\n";
#endif
    }
    return temp;
  }
	
  return NULL;
}

void FeatDomainBound::SetBoundInfo(DoubleArray2D *arr,int neigh)
{
  IntArray *target;
  DoubleArray2D *temp_coord;
  long i,j,len;
  int temp;
  DOUBLE X,Y,Z;
  blink *link;
	
  IntArray_blink *temp_link;
	
  for(temp_link=RecvBound->get_first();temp_link;temp_link=RecvBound->get_next(temp_link))
      if(temp_link->neigh==neigh)
	  break;
			
  if(temp_link==NULL)
      return;
		
  target=temp_link->ptr;
  len=target->GetLen();

#ifdef CONTROL_MSG
  if(arr)
      Prot<<"SetBoundInfo : neigh="<<neigh<<" arr=\n"<<*arr<<"\n target=\n"<<*target<<"\n\n";
  else
      Prot<<"SetBoundInfo : neigh"<<neigh<<" arr==NULL !!\n\n";
#endif	
	
  if(Param->ElemType==1)
  {
    if(len==arr->GetCols())
    {
      for(i=1;i<len;i++)
      {
	for(j=i+1;j<=len;j++)
	{
	  if(fabs((*arr)(1,i)-(*VertCoord)(1,(*target)(j)))<EPS)
	     if(fabs((*arr)(2,i)-(*VertCoord)(2,(*target)(j)))<EPS)
	       if(fabs((*arr)(3,i)-(*VertCoord)(3,(*target)(j)))<EPS) {
		 temp=(*target)(i);(*target)(i)=(*target)(j);(*target)(j)=temp;
	       }
	}
      }
    }
  } else if(Param->ElemType==2) {
    temp_coord=new DoubleArray2D(3,len);
    for(i=1;i<=len;i++)
    {
      link=myBase->find_node((*target)(i));
      (*temp_coord)(1,i)=0.25*((*VertCoord)(1,link->node1)
			       +(*VertCoord)(1,link->node2)
			       +(*VertCoord)(1,link->node3)
			       +(*VertCoord)(1,link->node4));
      (*temp_coord)(2,i)=0.25*((*VertCoord)(2,link->node1)
			       +(*VertCoord)(2,link->node2)
			       +(*VertCoord)(2,link->node3)
			       +(*VertCoord)(2,link->node4));
      (*temp_coord)(3,i)=0.25*((*VertCoord)(3,link->node1)
			       +(*VertCoord)(3,link->node2)
			       +(*VertCoord)(3,link->node3)
			       +(*VertCoord)(3,link->node4));      
    }

    int flag;
    if(len==arr->GetCols())
    {
      for(i=1;i<len;i++)
      {
	if(fabs((*temp_coord)(1,i)-(*arr)(1,i))>EPS || fabs((*temp_coord)(2,i)-(*arr)(2,i))>EPS || fabs((*temp_coord)(3,i)-(*arr)(3,i))>EPS) {
	  flag=0;
	  for(j=i+1;j<=len;j++)
	    {
	      X=(*temp_coord)(1,j);
	      Y=(*temp_coord)(2,j);
	      Z=(*temp_coord)(3,j);

	      if(fabs((*arr)(1,i)-X)<1e-4)
		if(fabs((*arr)(2,i)-Y)<1e-4)
		  if(fabs((*arr)(3,i)-Z)<1e-4) {
		    temp=(*target)(i);(*target)(i)=(*target)(j);(*target)(j)=temp;
		    (*temp_coord)(1,j)=(*temp_coord)(1,i);
		    (*temp_coord)(2,j)=(*temp_coord)(2,i);
		    (*temp_coord)(3,j)=(*temp_coord)(3,i);
		    flag=1;
		    break;
		  }
	    }
	  if(flag==0) {
	    Prot<<"MyProcID="<<MyProcID<<" didn't found corres. element: i="<<i<<" X="<<(*arr)(1,i)<<" Y="<<(*arr)(2,i)<<" Z="<<(*arr)(3,i)<<"\n";
	    Prot.Flush();
	  }
	}
      }
    } else {
      Prot<<"\n\n!!! SetBoundInfo : Arrays have different length neigh="<<neigh<<" len="<<len<<" len(neigh)="<<arr->GetCols()<<" !!!!!\n\n";
      Prot.Flush();
      Err<<"\n\nMyprocID="<<MyProcID<<" !!! SetBoundInfo : Arrays have different length neigh="<<neigh<<" len="<<len<<" len(neigh)="<<arr->GetCols()<<" !!!!!\n\n";
      Err.Flush();
    }
		

    // verify
//      for(i=1; i <= len; i++) {
//  	link=myBase->find_node((*target)(i));
//  	(*temp_coord)(1,i)=0.25*((*VertCoord)(1,link->node1)
//  				 +(*VertCoord)(1,link->node2)
//  				 +(*VertCoord)(1,link->node3)
//  				 +(*VertCoord)(1,link->node4));
//  	(*temp_coord)(2,i)=0.25*((*VertCoord)(2,link->node1)
//  				 +(*VertCoord)(2,link->node2)
//  				 +(*VertCoord)(2,link->node3)
//  				 +(*VertCoord)(2,link->node4));
//  	(*temp_coord)(3,i)=0.25*((*VertCoord)(3,link->node1)
//  				 +(*VertCoord)(3,link->node2)
//  				 +(*VertCoord)(3,link->node3)
//  				 +(*VertCoord)(3,link->node4));      
//      }
    
//      //    Prot<<"neigh="<<neigh<<"\n";
//      for(i=1; i <= len; i++)
//      {
//  	if(fabs((*temp_coord)(1,i)-(*arr)(1,i))>1e-4 ||
//  	   fabs((*temp_coord)(2,i)-(*arr)(2,i))>1e-4 ||
//  	   fabs((*temp_coord)(3,i)-(*arr)(3,i))>1e-4) {
//              Prot<<"MyProcID="<<MyProcID<<" ERROR(midpoint) neigh="<<neigh<<"   ("<<i<<")own  X="<<(*temp_coord)(1,i)<<" Y="<<(*temp_coord)(2,i)<<" Z="<<(*temp_coord)(3,i)<<"\n   ("<<i<<")recv X="<<(*arr)(1,i)<<" Y="<<(*arr)(2,i)<<" Z="<<(*arr)(3,i)<<"\n\n";
//              Prot.Flush();
//  	}
//      }

    delete temp_coord;
  }
}


DoubleArray2D* FeatDomainBound::GetElemBoundInfo(IntArray *arr,IntArray *arr2)
{
  DoubleArray2D *temp;
  elemlink *link;
  int i;
	
  if(arr)
  {
    temp=new DoubleArray2D(3,arr->GetLen());
    for(i=1;i<=arr->GetLen();i++)
    {
      link=myElemBase->find_node((*arr)(i),(*arr2)(i));
//      Prot<<"elem="<<(*arr)(i)<<" face="<<(*arr2)(i)<<"\n";

      if(link==NULL)
      {
	Err<<"\n!! GetElemBoundInfo !! \n link==NULL node="<<(*arr)(i)<<"\n";
	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Program aborted in FeatDomainBound::GetElemBoundInfo\n";
	MPI_Finalize();
	exit(0);
      }
      (*temp)(1,i)=
	0.25*((*VertCoord)(1,link->node1)+(*VertCoord)(1,link->node2)
	      +(*VertCoord)(1,link->node3)+(*VertCoord)(1,link->node4));
      (*temp)(2,i)=
	0.25*((*VertCoord)(2,link->node1)+(*VertCoord)(2,link->node2)
	      +(*VertCoord)(2,link->node3)+(*VertCoord)(2,link->node4));
      (*temp)(3,i)=
	0.25*((*VertCoord)(3,link->node1)+(*VertCoord)(3,link->node2)
	      +(*VertCoord)(3,link->node3)+(*VertCoord)(3,link->node4));

      //      Prot<<i<<" X="<<(*temp)(1,i)<<" Y="<<(*temp)(2,i)<<" Z="<<(*temp)(3,i)<<"\n";
    }
#ifdef CONTROL_MSG		
    Prot<<"GetElemBoundInfo MidCoord: temp=\n"<<*temp<<"\n\n";
#endif
    return temp;
  }
  
  return NULL;
}

void FeatDomainBound::SetElemBoundInfo(DoubleArray2D *arr,int neigh)
{
  IntArray *target,*target2;
  DoubleArray2D *temp_coord;
  long i,j,len;
  int temp;
  DOUBLE X,Y,Z;
  elemlink *link;

  IntArray_blink *temp_link,*temp_link2;
	
  for(temp_link=RecvElemBound->get_first();temp_link;
		temp_link=RecvElemBound->get_next(temp_link))
      if(temp_link->neigh==neigh)
	  break;
  for(temp_link2=RecvFaceBound->get_first();temp_link2;
		temp_link2=RecvFaceBound->get_next(temp_link2))
      if(temp_link2->neigh==neigh)
	  break;
			
  if(temp_link==NULL || temp_link2==NULL)
      return;
  
  target=temp_link->ptr;
  target2=temp_link2->ptr;
  len=target->GetLen();
  
#ifdef CONTROL_MSG
  if(arr)
      Prot<<"SetElemBoundInfo : neigh="<<neigh<<" arr=\n"<<*arr<<"\n target=\n"<<*target<<"\n\n";
  else
      Prot<<"SetElemBoundInfo : neigh"<<neigh<<" arr==NULL !!\n\n";
#endif	
	
  temp_coord=new DoubleArray2D(3,len);
  for(i=1;i<=len;i++)
  {
    link=myElemBase->find_node((*target)(i),(*target2)(i));
    (*temp_coord)(1,i)=0.25*((*VertCoord)(1,link->node1)
			     +(*VertCoord)(1,link->node2)
			     +(*VertCoord)(1,link->node3)
			     +(*VertCoord)(1,link->node4));
    (*temp_coord)(2,i)=0.25*((*VertCoord)(2,link->node1)
			     +(*VertCoord)(2,link->node2)
			     +(*VertCoord)(2,link->node3)
			     +(*VertCoord)(2,link->node4));
    (*temp_coord)(3,i)=0.25*((*VertCoord)(3,link->node1)
			     +(*VertCoord)(3,link->node2)
			     +(*VertCoord)(3,link->node3)
			     +(*VertCoord)(3,link->node4));      
  }
  
  if(len==arr->GetCols())
  {
    for(i=1;i<len;i++)
    {
      for(j=i+1;j<=len;j++)
      {
	X=(*temp_coord)(1,j);
	Y=(*temp_coord)(2,j);
	Z=(*temp_coord)(3,j);
	
	if(fabs((*arr)(1,i)-X)<EPS)
	  if(fabs((*arr)(2,i)-Y)<EPS)
	    if(fabs((*arr)(3,i)-Z)<EPS) {
	      temp=(*target)(i);(*target)(i)=(*target)(j);(*target)(j)=temp;
	      temp=(*target2)(i);(*target2)(i)=(*target2)(j);(*target2)(j)=temp;
	      (*temp_coord)(1,j)=(*temp_coord)(1,i);
	      (*temp_coord)(2,j)=(*temp_coord)(2,i);
	      (*temp_coord)(3,j)=(*temp_coord)(3,i);
	      break;
	    }
      }
    }

    // verify
//      for(i=1; i <= len; i++)
//      {
//  	link=myElemBase->find_node((*target)(i),(*target2)(i));
//  	(*temp_coord)(1,i)=0.25*((*VertCoord)(1,link->node1)
//  				 +(*VertCoord)(1,link->node2)
//  				 +(*VertCoord)(1,link->node3)
//  				 +(*VertCoord)(1,link->node4));
//  	(*temp_coord)(2,i)=0.25*((*VertCoord)(2,link->node1)
//  				 +(*VertCoord)(2,link->node2)
//  				 +(*VertCoord)(2,link->node3)
//  				 +(*VertCoord)(2,link->node4));
//  	(*temp_coord)(3,i)=0.25*((*VertCoord)(3,link->node1)
//  				 +(*VertCoord)(3,link->node2)
//  				 +(*VertCoord)(3,link->node3)
//  				 +(*VertCoord)(3,link->node4));      
//      }
    
//      //    Prot<<"neigh="<<neigh<<"\n";
//      for(i=1; i <= len; i++)
//      {
//  	if(fabs((*temp_coord)(1,i)-(*arr)(1,i))>1e-7 ||
//  	   fabs((*temp_coord)(2,i)-(*arr)(2,i))>1e-7 ||
//  	   fabs((*temp_coord)(3,i)-(*arr)(3,i))>1e-7) {
//              Err<<"myProcID="<<MyProcID<<" ERROR(elem) neigh="<<neigh<<"   ("<<i<<")own  X="<<(*temp_coord)(1,i)<<" Y="<<(*temp_coord)(2,i)<<" Z="<<(*temp_coord)(3,i)<<"\n   ("<<i<<")recv X="<<(*arr)(1,i)<<" Y="<<(*arr)(2,i)<<" Z="<<(*arr)(3,i)<<"\n\n";
//              Err.Flush();
//  	}
//      }

//      Prot<<"\n !!! SetElemBoundInfo !!!! neigh="<<neigh<<"\n";	
//      for(i=1;i<=len;i++) {
//  	Prot<<i<<" elem("<<i<<")="<<(*target)(i);
//  	link=myElemBase->find_node((*target)(i),(*target2)(i));
//  	X=0.25*((*VertCoord)(1,link->node1)
//  		+(*VertCoord)(1,link->node2)
//  		+(*VertCoord)(1,link->node3)
//  		+(*VertCoord)(1,link->node4));
//  	Y=0.25*((*VertCoord)(2,link->node1)
//  		+(*VertCoord)(2,link->node2)
//  		+(*VertCoord)(2,link->node3)
//  		+(*VertCoord)(2,link->node4));
//  	Z=0.25*((*VertCoord)(3,link->node1)
//  		+(*VertCoord)(3,link->node2)
//  		+(*VertCoord)(3,link->node3)
//  		+(*VertCoord)(3,link->node4));      
//  	Prot<<" X="<<X<<" Y="<<Y<<" Z="<<Z<<"\n";
//      }
//      Prot<<"\n";

  } else {
    Prot<<"\n\n!!! SetElemBoundInfo : Arrays have different length neigh="<<neigh<<" !!!!!\n\n";
    Prot.Flush();
  }
  delete temp_coord;
}

DoubleArray2D* FeatDomainBound::GetSPVector(DoubleVector *v1,DoubleVector *v2,int myproc)
{
	
  DoubleArray2D *temp;
  int i,len;
  blist* temp_list;
  	
  len=0;
  for(temp_list=myBase->get_neighlist()->get_first();temp_list;
						     temp_list=myBase->get_neighlist()->get_next(temp_list))
  {
    blink *temp_node;
    for(temp_node=temp_list->base->get_first();temp_node;temp_node=temp_list->base->get_next(temp_node))
	len++;
//  		len+=temp_list->base->get_len();
  }
	
  if(len)
  {
    temp=new DoubleArray2D(2,len);
    i=1;
  	
    for(temp_list=myBase->get_neighlist()->get_first();temp_list;
						       temp_list=myBase->get_neighlist()->get_next(temp_list))
    {
      blink *temp_node;
      for(temp_node=temp_list->base->get_first();temp_node;
						 temp_node=temp_list->base->get_next(temp_node))
      {
	(*temp)(1,i)=(*v1)(temp_node->node);
	(*temp)(2,i++)=(*v2)(temp_node->node);
      }
    }
    return temp;
  }
	
  return NULL;
}

void FeatDomainBound::SetSPVector(DoubleArray2D *arr,int neigh,DOUBLE& temp)
{
  blist *temp_link;
	
  for(temp_link=SPInfo->get_first();temp_link;temp_link=SPInfo->get_next(temp_link))
      if(temp_link->neigh==neigh)
	  break;
			
  if(temp_link==NULL)
  {
    Prot<<"!!!!!!!!! SetSPVector unknown neighbour :"<<neigh<<"\n";
    return;
  }
  	
  blink* node;
  		
  for(node=temp_link->base->get_first();node;node=temp_link->base->get_next(node))
  {
    temp+=(*arr)(1,node->node)*(*arr)(2,node->node);
  }
}

DoubleArray2D* FeatDomainBound::GetSPInfo()
{
  DoubleArray2D *temp;
  int i,len;
  blist* temp_list;
  blink *link;
  	
  len=0;
  for(temp_list=myBase->get_neighlist()->get_first();temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
  {
    len+=temp_list->base->get_len();
  }
	
  if(len)
  {
    temp=new DoubleArray2D(3,len);
    i=1;
  	
    if(Param->ElemType==1)
    {
      for(temp_list=myBase->get_neighlist()->get_first();temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
      {
	blink *temp_node;
	for(temp_node=temp_list->base->get_first();temp_node;temp_node=temp_list->base->get_next(temp_node))
	{
	  (*temp)(1,i)=(*VertCoord)(1,temp_node->node);
	  (*temp)(2,i)=(*VertCoord)(2,temp_node->node);
	  (*temp)(3,i++)=(*VertCoord)(3,temp_node->node);
	}
      }
    } else if(Param->ElemType==2) {
      for(temp_list=myBase->get_neighlist()->get_first();temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
      {
	blink *temp_node;
	for(temp_node=temp_list->base->get_first();temp_node;temp_node=temp_list->base->get_next(temp_node))
	{
	  link=myBase->find_node(temp_node->node);
	  if(link==NULL)
	  {
	      Err<<"GetSPInfo link==NULL\n";
	      protocol << progname << " (process " << MyProcID << "):\n"
		       << "  Program aborted in FeatDomainBound::GetSPInfo\n";
	      MPI_Finalize();
	      exit(0);
	  }
	  (*temp)(1,i)=
	    0.25*((*VertCoord)(1,link->node1)+(*VertCoord)(1,link->node2)
		  +(*VertCoord)(1,link->node3)+(*VertCoord)(1,link->node4));
	  (*temp)(2,i)=
	    0.25*((*VertCoord)(2,link->node1)+(*VertCoord)(2,link->node2)
		  +(*VertCoord)(2,link->node3)+(*VertCoord)(2,link->node4));
	  (*temp)(3,i++)=
	    0.25*((*VertCoord)(3,link->node1)+(*VertCoord)(3,link->node2)
		+(*VertCoord)(3,link->node3)+(*VertCoord)(3,link->node4));
	}
      }
    }
#ifdef CONTROL_MSG		
    Prot<<"GetSPInfo : temp=\n"<<*temp<<"\n\n";
#endif
		
    return temp;
  }
	
  return NULL;
}

void FeatDomainBound::SetSPInfo(DoubleArray2D *arr,int neigh)
{
  int i;
	
  if(SPInfo==NULL)
  {
    SPInfo=new blistlist_base();
    SPCoord=new coord_base_3D();
  }
	
  blist *temp_link;
	
  for(temp_link=SPInfo->get_first();temp_link;temp_link=SPInfo->get_next(temp_link))
      if(temp_link->neigh==neigh)
	  break;
			
  if(temp_link==NULL)
  {
    blist_base *base=new blist_base();
    temp_link=new blist(base);
    temp_link->neigh=neigh;	
    SPInfo->append(temp_link);
  }
  
  for(i=1;i<=arr->GetCols();i++)
  {
    coord_link_3D* coord;
  		
    for(coord=SPCoord->get_first();coord;coord=SPCoord->get_next(coord))
    {
      if(fabs((*arr)(1,i)-coord->x)<EPS && fabs((*arr)(2,i)-coord->y)<EPS
	 && fabs((*arr)(3,i)-coord->z)<EPS)
      {
#ifdef CONTROL_MSG
	Prot<<"array x="<<(*arr)(1,i)<<" y="<<(*arr)(2,i)<<" z="<<(*arr)(3,i)<<"  coord x="<<coord->x<<" y="<<coord->y<<" z="<<coord->z<<"\n";
#endif
	break;
      }
    }
    if(coord==NULL)
    {
      temp_link->base->append(i,neigh);
      SPCoord->append((*arr)(1,i),(*arr)(2,i),(*arr)(3,i));
    }
  }
	
}


void FeatDomainBound::SetNeumannBoundInfo(DoubleArray2D *arr,int neigh)
{
  IntArray *target;
  DoubleArray2D *temp_coord;
  long i,j,len;
  int temp;
  DOUBLE X,Y,Z;
  blink *link;
	
  IntArray_blink *temp_link;
	
  for(temp_link=RecvNeumannBound->get_first();temp_link;temp_link=RecvNeumannBound->get_next(temp_link))
      if(temp_link->neigh==neigh)
	  break;
			
  if(temp_link==NULL)
      return;
		
  target=temp_link->ptr;
  len=target->GetLen();

#ifdef CONTROL_MSG
  if(arr)
      Prot<<"RecvNeumannBoundInfo : neigh="<<neigh<<" arr=\n"<<*arr<<"\n\n";
  else
      Prot<<"RecvNeumannBoundInfo : neigh"<<neigh<<" arr==NULL !!\n\n";
#endif	

  if(Param->ElemType==1)
  {
    if(len==arr->GetCols())
    {
      for(i=1;i<len;i++)
      {
	for(j=i+1;j<=len;j++)
	{
	  if(fabs((*arr)(1,i)-(*VertCoord)(1,(*target)(j)))<EPS
	     && fabs((*arr)(2,i)-(*VertCoord)(2,(*target)(j)))<EPS
	     && fabs((*arr)(3,i)-(*VertCoord)(3,(*target)(j)))<EPS)
	  {
	    temp=(*target)(i);(*target)(i)=(*target)(j);(*target)(j)=temp;
	  }
	}
      }		
    } else {
      Prot<<"\n\n!!! RecvNeumannBoundInfo : different length len="<<len<<" arr->Cols="<<arr->GetCols()<<" from neigh: "<<neigh<<" !!!!!\n\n";
    }
  } else if(Param->ElemType==2) {
    temp_coord=new DoubleArray2D(3,len);
    for(i=1;i<=len;i++)
    {
      link=myBase->find_node((*target)(i));
      (*temp_coord)(1,i)=0.25*((*VertCoord)(1,link->node1)
			       +(*VertCoord)(1,link->node2)
			       +(*VertCoord)(1,link->node3)
			       +(*VertCoord)(1,link->node4));
      (*temp_coord)(2,i)=0.25*((*VertCoord)(2,link->node1)
			       +(*VertCoord)(2,link->node2)
			       +(*VertCoord)(2,link->node3)
			       +(*VertCoord)(2,link->node4));
      (*temp_coord)(3,i)=0.25*((*VertCoord)(3,link->node1)
			       +(*VertCoord)(3,link->node2)
			       +(*VertCoord)(3,link->node3)
			       +(*VertCoord)(3,link->node4));      
    }

    if(len==arr->GetCols())
    {
      for(i=1;i<len;i++)
      {
	for(j=i+1;j<=len;j++)
	{
	  X=(*temp_coord)(1,j);
	  Y=(*temp_coord)(2,j);
	  Z=(*temp_coord)(3,j);

	  if(fabs((*arr)(1,i)-X)<EPS && fabs((*arr)(2,i)-Y)<EPS
	     && fabs((*arr)(3,i)-Z)<EPS)
	  {
	    temp=(*target)(i);(*target)(i)=(*target)(j);(*target)(j)=temp;
	  }
	}
      }
    } else {
      Prot<<"\n\n!!! RecvNeumannBoundInfo : different length len="<<len<<" arr->Cols="<<arr->GetCols()<<" from neigh: "<<neigh<<" !!!!!\n\n";
    }
    delete temp_coord;
  }		
}

VOID FeatDomainBound::PrintSendData()
{
  SendBoundData->print_list();
}

VOID FeatDomainBound::PrintRecvData()
{
  RecvBoundData->print_list();
}


VOID FeatDomainBound::GetElemBoundInfo()
{
  int i,j,IAREA,neigh;
  blink *temp;
  myElemBase=new elem_base();

  for(i=1;i<=NumElements;i++)
  {
    for(j=1;j<=6;j++)
    {
      if((*NeighElem)(j,i)==0)
      {
	IAREA=(*MidFaces)(j,i);
	temp=myBase->find_node(IAREA,neigh);
	if(temp)
	{
	  myElemBase->insertelem(i,neigh,j,temp->node1,
				 temp->node2,temp->node3,temp->node4);
	}
      }
    }
  }
  //  myElemBase->printElems();
}

int FeatDomainBound::FindElem(int elem,int face,double& p,int level)
{
  RecvFaceBound=MRecvFaceBound[level];
  RecvElemBound=MRecvElemBound[level];
  RecvElemBoundData=MRecvElemBoundData[level];
  IntArray *Ptr,*Ptr2;
  DoubleVector *Data;
  DVector_blink *temp_vectlist;
  IntArray_blink *temp_elemlist,*temp_facelist;
  int i,len;
  
  for(temp_elemlist=RecvElemBound->get_first(),
	temp_facelist=RecvFaceBound->get_first(),
	temp_vectlist=RecvElemBoundData->get_first();
      temp_elemlist;
      temp_elemlist=RecvElemBound->get_next(temp_elemlist),
	temp_facelist=RecvFaceBound->get_next(temp_facelist),
	temp_vectlist=RecvElemBoundData->get_next(temp_vectlist))
  {
    Ptr=temp_elemlist->ptr;
    len=Ptr->GetLen();
    Ptr2=temp_facelist->ptr;
    Data=temp_vectlist->ptr;

    for(i=1;i<=len;i++)
    {
      if((*Ptr)(i)==elem && (*Ptr2)(i)==face)
      {
	p=(*Data)(i);
	return true;
      }
    }
    
  }
  return false;
}

