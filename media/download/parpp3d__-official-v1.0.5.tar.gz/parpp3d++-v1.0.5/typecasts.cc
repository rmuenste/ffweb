#include "typecasts.h"

const std::string int_to_string (const int n) {
// Usage:
//   int_to_string(number) if you just want to convert an integer to a 
//   string without character fill in.
    return int_to_string(n, "", 0);
}


const std::string int_to_string (const int n, const unsigned int digits) {
// Usage:
//   int_to_string(number, 0) if you don't want no fills with zeros.
//   int_to_string(number, x) if you don't want x fills with zeros.
    return int_to_string(n, " ", digits);
}


const std::string int_to_string (const int n, const char* character, unsigned int digits) {
// Usage:
//   int_to_string(number, 0) if you don't want no fills with 'character'.
//   int_to_string(number, x) if you don't want x fills with 'character'.
    unsigned int absN = abs(n);
    std::string  s;

    // Determine the number of decimals of n
    unsigned int n_digits;
    absN > 0 ? n_digits = int(log10(float(absN))) + 1 : n_digits = 1;

    // Prevent that some digits of 'n' are omitted because 'digits' was
    // chosen too small.
    if (digits < n_digits) {
        digits = n_digits;
    }
//      if (digits <= 0) {                            // May happen when n = 0
//          digits = 1;
//      }

    for (unsigned int i = digits - n_digits; i > 1; i--)
	s += character;

    if (digits > n_digits)
	if (n < 0)
	    s += "-";
	else
	    s += character;

    // Add to s a character by specifying its ascii code
    for (unsigned int i = n_digits;  i > 0;  i--) {
	s += '0' + ( absN % int(pow(10.0, double(i))) ) / int(pow(10.0, double(i-1)));
    }

    return s;
}


const std::string double_to_string (const double n, const char* efg, const unsigned int after_digits) {
// Usage:
//   double_to_string(number, format, x) if you want x decimals after the dot.
//                                       format means one of the format flags printf knows: e, f, g
    double       absN = fabs(n);
    int          before_digits = 1;
    char         sign[2];
    static char  format[128];
    static char  text[128];
    std::string  s;

    // Do we use printf format '%f'?
    if (strncmp(efg, "f", 1) == 0) {
	// Determine the number of digits before comma
	(absN > 0) ? 
	    before_digits = int(float(log10(absN))) + 1 :
	    before_digits = 1;
    }

    // Display a zero if n is negative, but don't show a plus if positive.
    // Therefore we can't use "%+s" in sprintf.
    if (n < 0)
	strncpy (sign, "-", 2);
    else
	strncpy (sign, " ", 2);

    sprintf (format, "%s%%%d.%d%s", sign, before_digits, after_digits, efg);

    // Size of text in Bytes:
    // 1            : sign, 
    // before_digits: # digits before comma
    // 1            : comma
    // after_digits : # digits after comma
    // 5            : e�300
    sprintf (text, format, absN);
    s += text;

    return s;
}

const std::string timeval_to_string(const double timevalue) {
    int hours, min, sec, millisec;

    hours    = (int)(timevalue / 3600); 
    min      = (int)((timevalue - hours * 3600) / 60); 
    sec      = (int)((timevalue - hours * 3600 - min * 60)); 
    millisec = (int)((timevalue - hours * 3600 - min * 60 - sec) * 10);

    return
	int_to_string(hours, " ", 3) + "h " +
	int_to_string(min, "0", 2) + "m " +
	int_to_string(sec, "0", 2) + "." + int_to_string(millisec, "0", 1) + "s";
}

const std::string norm_to_string(const double n, const char* efg, const unsigned int after_digits, double scale) {
    // Should never be true since scale is supposed to be the degree of freedom.
    if (fabs(scale) < 1e-10) {
	scale = 1.0;
    }
    return double_to_string(n / sqrt(scale), efg, after_digits);
}

//  const std::string pnorm_to_string(const double n, const char* efg, const unsigned int after_digits) {
//      return double_to_string(n / ConstGlobalDOF, efg, after_digits);
//  }
