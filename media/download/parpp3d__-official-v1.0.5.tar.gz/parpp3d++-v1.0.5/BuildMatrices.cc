#include "Task.h"

extern DateTime ClockMVMult;
extern double TMVMult, TMVMultCom;				  // time spent in matrix vector multiplication routines

void Task::Build_B(MultiRectMatrix& B1, MultiRectMatrix& B2, MultiRectMatrix& B3,
		   MultiCompactMatrix& A)
{
    int ILD, IEL, IAT, IAREA, IVT1, IVT2, IVT3, IVT4, IADJ, IVE, IVT, ILEV, IMID;
    double P1X, P1Y, P1Z, P2X, P2Y, P2Z, P3X, P3Y, P3Z, P4X, P4Y, P4Z, DNX, DNY, DNZ;
    double AX1, AX2, AX3, AX4, AY1, AY2, AY3, AY4, AZ1, AZ2, AZ3, AZ4, AX, AY, AZ, DHN;
    double PXC, PYC, PZC, PXA, PYA, PZA, DNAR1, DNAR2, DFAC;
    DoubleRectMatrix *B, *BT, *BTT;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::Build_B.\n";
	protocol.mFlush();
    }

    for (ILEV = 1; ILEV <= TotalLevel; ILEV++) {
	SetLevel(ILEV);
	B1[ILEV] = new DoubleRectMatrix(2 * A[ILEV]->GetNumDiag(), A[ILEV]->GetNumDiag());
	B2[ILEV] = new DoubleRectMatrix(2 * A[ILEV]->GetNumDiag(), A[ILEV]->GetNumDiag());
	B3[ILEV] = new DoubleRectMatrix(2 * A[ILEV]->GetNumDiag(), A[ILEV]->GetNumDiag());

	B   = B1[ILEV];
	BT  = B2[ILEV];
	BTT = B3[ILEV];
	ILD = 0;
	for(IEL = 1; IEL <= NumElements; IEL++) {
	    PXC = 0.;
	    PYC = 0.;
	    PZC = 0.;

	    for (IVE = 1; IVE <= 8; IVE++) {
		IVT  = (*VertElem)(IVE,IEL);
		PXC += (*VertCoord)(1,IVT);
		PYC += (*VertCoord)(2,IVT);
		PZC += (*VertCoord)(3,IVT);
	    }

	    PXC *= 0.125;
	    PYC *= 0.125;
	    PZC *= 0.125;

	    for (IAT = 1; IAT <= 6; IAT++) {
		IADJ = (*NeighElem)(IAT,IEL);
		if (!(IADJ > 0  &&  IADJ < IEL)) {
		    IAREA = (*MidFaces)(IAT,IEL);

		    if (IAT == 1) {
			IVT1 = (*VertElem)(1,IEL);
			IVT2 = (*VertElem)(2,IEL);
			IVT3 = (*VertElem)(3,IEL);
			IVT4 = (*VertElem)(4,IEL);
		    }
		    if (IAT == 2) {
			IVT1 = (*VertElem)(1,IEL);
			IVT2 = (*VertElem)(2,IEL);
			IVT3 = (*VertElem)(6,IEL);
			IVT4 = (*VertElem)(5,IEL);
		    }
		    if (IAT == 3) {
			IVT1 = (*VertElem)(2,IEL);
			IVT2 = (*VertElem)(3,IEL);
			IVT3 = (*VertElem)(6,IEL);
			IVT4 = (*VertElem)(7,IEL);
		    }
		    if (IAT == 4) {
			IVT1 = (*VertElem)(3,IEL);
			IVT2 = (*VertElem)(4,IEL);
			IVT3 = (*VertElem)(8,IEL);
			IVT4 = (*VertElem)(7,IEL);
		    }
		    if (IAT == 5) {
			IVT1 = (*VertElem)(4,IEL);
			IVT2 = (*VertElem)(1,IEL);
			IVT3 = (*VertElem)(5,IEL);
			IVT4 = (*VertElem)(8,IEL);
		    }
		    if (IAT == 6) {
			IVT1 = (*VertElem)(5,IEL);
			IVT2 = (*VertElem)(6,IEL);
			IVT3 = (*VertElem)(7,IEL);
			IVT4 = (*VertElem)(8,IEL);
		    }

		    P1X = (*VertCoord)(1,IVT1);
		    P1Y = (*VertCoord)(2,IVT1);
		    P1Z = (*VertCoord)(3,IVT1);
		    P2X = (*VertCoord)(1,IVT2);
		    P2Y = (*VertCoord)(2,IVT2);
		    P2Z = (*VertCoord)(3,IVT2);
		    P3X = (*VertCoord)(1,IVT3);
		    P3Y = (*VertCoord)(2,IVT3);
		    P3Z = (*VertCoord)(3,IVT3);
		    P4X = (*VertCoord)(1,IVT4);
		    P4Y = (*VertCoord)(2,IVT4);
		    P4Z = (*VertCoord)(3,IVT4);

		    PXA = (P1X + P2X + P3X + P4X) * 0.25;
		    PYA = (P1Y + P2Y + P3Y + P4Y) * 0.25;
		    PZA = (P1Z + P2Z + P3Z + P4Z) * 0.25;

		    AX2 = P2X - P1X;
		    AY2 = P2Y - P1Y;
		    AZ2 = P2Z - P1Z;
		    AY3 = P3Y - P1Y;
		    AX3 = P3X - P1X;
		    AZ3 = P3Z - P1Z;
		    AY4 = P4Y - P1Y;
		    AX4 = P4X - P1X;
		    AZ4 = P4Z - P1Z;

		    AX = PXC - PXA;
		    AY = PYC - PYA;
		    AZ = PZC - PZA;

		    DNX = (AY3 * AZ2) - (AZ3 * AY2);
		    DNY = (AZ3 * AX2) - (AX3 * AZ2);
		    DNZ = (AX3 * AY2) - (AY3 * AX2);
		    DNAR1 = sqrt(DNX * DNX + DNY * DNY + DNZ * DNZ);

		    DNX = (AY4 * AZ3) - (AZ4 * AY3);
		    DNY = (AZ4 * AX3) - (AX4 * AZ3);
		    DNZ = (AX4 * AY3) - (AY4 * AX3);
		    DNAR2 = sqrt(DNX * DNX + DNY * DNY + DNZ * DNZ);

		    DFAC = 0.5 * (DNAR1 + DNAR2) / DNAR2;
		    DNX =DFAC * DNX;
		    DNY =DFAC * DNY;
		    DNZ =DFAC * DNZ;

		    DHN = DNX * AX + DNY * AY + DNZ * AZ;
		    if (DHN < 0.) {
			DNX = -DNX;
			DNY = -DNY;
			DNZ = -DNZ;
		    }

		    ILD++;
		    B->Diag(IAREA) = BT->Diag(IAREA) = BTT->Diag(IAREA) = ILD;
		    B->Col(ILD)    = BT->Col(ILD) = BTT->Col(ILD) = IEL;
		    B->Data(ILD)   = DNX;
		    BT->Data(ILD)  = DNY;
		    BTT->Data(ILD) = DNZ;

		    if (IADJ > 0) {
			ILD++;
			B->Col(ILD)    = BT->Col(ILD) = BTT->Col(ILD) = IADJ;
			B->Data(ILD)   = -DNX;
			BT->Data(ILD)  = -DNY;
			BTT->Data(ILD) = -DNZ;
		    }
		}
	    }
	} // end for(IEL = 1; IEL <= NumElements; IEL++)

	B->Diag(TotNumFaces+1) = BT->Diag(TotNumFaces+1) = BTT->Diag(TotNumFaces+1) = ILD+1;
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Leaving Task::Build_B.\n";
	protocol.mFlush();
    }

    return;
}

void Task::B_Mult(DoubleVector& p,DoubleVector& f1,DoubleVector& f2,
		  DoubleVector& f3,
		  double a1,double a2)
{
    int ILD,IEL,IAT,IAREA,IVT1,IVT2,IVT3,IVT4,IADJ,IVE,IVT;
    double P1X,P1Y,P1Z,P2X,P2Y,P2Z,P3X,P3Y,P3Z,P4X,P4Y,P4Z,DNX,DNY,DNZ;
    double AX1,AX2,AX3,AX4,AY1,AY2,AY3,AY4,AZ1,AZ2,AZ3,AZ4,AX,AY,AZ,DHN,DPDIFF;
    double PXC,PYC,PZC,PXA,PYA,PZA,DNAR1,DNAR2,DFAC,ptemp;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::B_Mult.\n";
	protocol.mFlush();
    }

    SetElemBoundValues(&p);
    CommunicateElem();

    for(IEL = 1;IEL<=NumElements;IEL++)
    {
	PXC = 0.;
	PYC = 0.;
	PZC = 0.;

	for(IVE=1;IVE<=8;IVE++) {
	    IVT = (*VertElem)(IVE,IEL);
	    PXC+=(*VertCoord)(1,IVT);
	    PYC+=(*VertCoord)(2,IVT);
	    PZC+=(*VertCoord)(3,IVT);
	}

	PXC*=0.125;
	PYC*=0.125;
	PZC*=0.125;

	for(IAT = 1;IAT<=6;IAT++)
	{
	    IADJ = (*NeighElem)(IAT,IEL);
	    if (!(IADJ>0 && IADJ<IEL))
	    {
		IAREA = (*MidFaces)(IAT,IEL);

		if (IAT == 1)
		{
		    IVT1 = (*VertElem)(1,IEL);
		    IVT2 = (*VertElem)(2,IEL);
		    IVT3 = (*VertElem)(3,IEL);
		    IVT4 = (*VertElem)(4,IEL);
		}
		if (IAT == 2)
		{
		    IVT1 = (*VertElem)(1,IEL);
		    IVT2 = (*VertElem)(2,IEL);
		    IVT3 = (*VertElem)(6,IEL);
		    IVT4 = (*VertElem)(5,IEL);
		}
		if (IAT == 3)
		{
		    IVT1 = (*VertElem)(2,IEL);
		    IVT2 = (*VertElem)(3,IEL);
		    IVT3 = (*VertElem)(6,IEL);
		    IVT4 = (*VertElem)(7,IEL);
		}
		if (IAT == 4)
		{
		    IVT1 = (*VertElem)(3,IEL);
		    IVT2 = (*VertElem)(4,IEL);
		    IVT3 = (*VertElem)(8,IEL);
		    IVT4 = (*VertElem)(7,IEL);
		}
		if (IAT == 5)
		{
		    IVT1 = (*VertElem)(4,IEL);
		    IVT2 = (*VertElem)(1,IEL);
		    IVT3 = (*VertElem)(5,IEL);
		    IVT4 = (*VertElem)(8,IEL);
		}
		if (IAT == 6)
		{
		    IVT1 = (*VertElem)(5,IEL);
		    IVT2 = (*VertElem)(6,IEL);
		    IVT3 = (*VertElem)(7,IEL);
		    IVT4 = (*VertElem)(8,IEL);
		}

		P1X = (*VertCoord)(1,IVT1);
		P1Y = (*VertCoord)(2,IVT1);
		P1Z = (*VertCoord)(3,IVT1);
		P2X = (*VertCoord)(1,IVT2);
		P2Y = (*VertCoord)(2,IVT2);
		P2Z = (*VertCoord)(3,IVT2);
		P3X = (*VertCoord)(1,IVT3);
		P3Y = (*VertCoord)(2,IVT3);
		P3Z = (*VertCoord)(3,IVT3);
		P4X = (*VertCoord)(1,IVT4);
		P4Y = (*VertCoord)(2,IVT4);
		P4Z = (*VertCoord)(3,IVT4);

		PXA = (P1X+P2X+P3X+P4X)*0.25;
		PYA = (P1Y+P2Y+P3Y+P4Y)*0.25;
		PZA = (P1Z+P2Z+P3Z+P4Z)*0.25;

		AX2 = P2X-P1X;
		AY2 = P2Y-P1Y;
		AZ2 = P2Z-P1Z;
		AY3 = P3Y-P1Y;
		AX3 = P3X-P1X;
		AZ3 = P3Z-P1Z;
		AY4 = P4Y-P1Y;
		AX4 = P4X-P1X;
		AZ4 = P4Z-P1Z;

		AX  = PXC-PXA;
		AY  = PYC-PYA;
		AZ  = PZC-PZA;

		DNX = (AY3*AZ2)-(AZ3*AY2);
		DNY = (AZ3*AX2)-(AX3*AZ2);
		DNZ = (AX3*AY2)-(AY3*AX2);
		DNAR1 = sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

		DNX = (AY4*AZ3)-(AZ4*AY3);
		DNY = (AZ4*AX3)-(AX4*AZ3);
		DNZ = (AX4*AY3)-(AY4*AX3);
		DNAR2 = sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

		DFAC = 0.5*(DNAR1+DNAR2)/DNAR2;
		DNX  = DFAC*DNX;
		DNY  = DFAC*DNY;
		DNZ  = DFAC*DNZ;

		DHN = DNX*AX+DNY*AY+DNZ*AZ;
		if (DHN<0.) {
		    DNX = -DNX;
		    DNY = -DNY;
		    DNZ = -DNZ;
		}

		if (IADJ>0)
		{
		    DPDIFF = p(IEL)-p(IADJ);
		    f1(IAREA) = a2*f1(IAREA)+a1*DNX*DPDIFF;
		    f2(IAREA) = a2*f2(IAREA)+a1*DNY*DPDIFF;
		    f3(IAREA) = a2*f3(IAREA)+a1*DNZ*DPDIFF;
		} else {
		    if (FindElem(IEL,IAT,ptemp,ActiveLevel) == true)
		    {
//		      Prot<<"FindElem !! IEL="<<IEL<<" IAT="<<IAT<<" ptemp="<<ptemp<<"\n";
			DPDIFF=p(IEL)-ptemp;
			f1(IAREA)=a2*f1(IAREA)+a1*DNX*DPDIFF;
			f2(IAREA)=a2*f2(IAREA)+a1*DNY*DPDIFF;
			f3(IAREA)=a2*f3(IAREA)+a1*DNZ*DPDIFF;
		    } else {
//		      Prot<<"Boundary IAREA="<<IAREA<<"\n";
			f1(IAREA)=a2*f1(IAREA)+a1*DNX*p(IEL);
			f2(IAREA)=a2*f2(IAREA)+a1*DNY*p(IEL);
			f3(IAREA)=a2*f3(IAREA)+a1*DNZ*p(IEL);
		    }
		}
	    }
	}
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::B_Mult.\n";
	protocol.mFlush();
    }

    return;
} // end B_Mult

void Task::BT_Mult(DoubleVector& u1,DoubleVector& u2,DoubleVector& u3,
		   DoubleVector& p,
		   double a1)
// Compute  p = a1 * B^{T} * u
{
    int    ILD, IEL, IAT, IAREA, IVT1, IVT2, IVT3, IVT4, IADJ, IVE, IVT;
    double P1X, P1Y, P1Z, P2X, P2Y, P2Z, P3X, P3Y, P3Z, P4X, P4Y, P4Z, DNX, DNY, DNZ;
    double AX1, AX2, AX3, AX4, AY1, AY2, AY3, AY4, AZ1, AZ2, AZ3, AZ4, AX, AY, AZ, DHN;
    double PXC, PYC, PZC, PXA, PYA, PZA, DNAR1, DNAR2, DFAC;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::BT_Mult.\n";
	protocol.mFlush();
    }

    for (IEL = 1; IEL <= NumElements; IEL++) {
	PXC = 0.;
	PYC = 0.;
	PZC = 0.;

	for (IVE = 1; IVE <= 8; IVE++) {
	    IVT = (*VertElem)(IVE, IEL);
	    PXC += (*VertCoord)(1, IVT);
	    PYC += (*VertCoord)(2, IVT);
	    PZC += (*VertCoord)(3, IVT);
	}

	PXC *= 0.125;
	PYC *= 0.125;
	PZC *= 0.125;

	p(IEL)=0;
	for (IAT = 1; IAT <= 6; IAT++)
	{
	    if (IAT == 1)
	    {
		IVT1 = (*VertElem)(1,IEL);
		IVT2 = (*VertElem)(2,IEL);
		IVT3 = (*VertElem)(3,IEL);
		IVT4 = (*VertElem)(4,IEL);
	    }
	    if (IAT == 2)
	    {
		IVT1 = (*VertElem)(1,IEL);
		IVT2 = (*VertElem)(2,IEL);
		IVT3 = (*VertElem)(6,IEL);
		IVT4 = (*VertElem)(5,IEL);
	    }
	    if (IAT == 3)
	    {
		IVT1 = (*VertElem)(2,IEL);
		IVT2 = (*VertElem)(3,IEL);
		IVT3 = (*VertElem)(6,IEL);
		IVT4 = (*VertElem)(7,IEL);
	    }
	    if (IAT == 4)
	    {
		IVT1 = (*VertElem)(3,IEL);
		IVT2 = (*VertElem)(4,IEL);
		IVT3 = (*VertElem)(8,IEL);
		IVT4 = (*VertElem)(7,IEL);
	    }
	    if (IAT == 5)
	    {
		IVT1 = (*VertElem)(4,IEL);
		IVT2 = (*VertElem)(1,IEL);
		IVT3 = (*VertElem)(5,IEL);
		IVT4 = (*VertElem)(8,IEL);
	    }
	    if (IAT == 6)
	    {
		IVT1 = (*VertElem)(5,IEL);
		IVT2 = (*VertElem)(6,IEL);
		IVT3 = (*VertElem)(7,IEL);
		IVT4 = (*VertElem)(8,IEL);
	    }
	    P1X=(*VertCoord)(1,IVT1);
	    P1Y=(*VertCoord)(2,IVT1);
	    P1Z=(*VertCoord)(3,IVT1);
	    P2X=(*VertCoord)(1,IVT2);
	    P2Y=(*VertCoord)(2,IVT2);
	    P2Z=(*VertCoord)(3,IVT2);
	    P3X=(*VertCoord)(1,IVT3);
	    P3Y=(*VertCoord)(2,IVT3);
	    P3Z=(*VertCoord)(3,IVT3);
	    P4X=(*VertCoord)(1,IVT4);
	    P4Y=(*VertCoord)(2,IVT4);
	    P4Z=(*VertCoord)(3,IVT4);

	    PXA=(P1X+P2X+P3X+P4X)*0.25;
	    PYA=(P1Y+P2Y+P3Y+P4Y)*0.25;
	    PZA=(P1Z+P2Z+P3Z+P4Z)*0.25;

	    AX2=P2X-P1X;
	    AY2=P2Y-P1Y;
	    AZ2=P2Z-P1Z;
	    AY3=P3Y-P1Y;
	    AX3=P3X-P1X;
	    AZ3=P3Z-P1Z;
	    AY4=P4Y-P1Y;
	    AX4=P4X-P1X;
	    AZ4=P4Z-P1Z;

	    AX =PXC-PXA;
	    AY =PYC-PYA;
	    AZ =PZC-PZA;

	    DNX=(AY3*AZ2)-(AZ3*AY2);
	    DNY=(AZ3*AX2)-(AX3*AZ2);
	    DNZ=(AX3*AY2)-(AY3*AX2);
	    DNAR1=sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

	    DNX=(AY4*AZ3)-(AZ4*AY3);
	    DNY=(AZ4*AX3)-(AX4*AZ3);
	    DNZ=(AX4*AY3)-(AY4*AX3);
	    DNAR2=sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

	    DFAC=0.5*(DNAR1+DNAR2)/DNAR2;
	    DNX =DFAC*DNX;
	    DNY =DFAC*DNY;
	    DNZ =DFAC*DNZ;

	    DHN=DNX*AX+DNY*AY+DNZ*AZ;
	    if (DHN < 0.) {
		DNX=-DNX;
		DNY=-DNY;
		DNZ=-DNZ;
	    }

	    IAREA=(*MidFaces)(IAT,IEL);

	    p(IEL) += a1 * (DNX * u1(IAREA) + DNY * u2(IAREA) + DNZ * u3(IAREA));
	}
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::BT_Mult.\n";
	protocol.mFlush();
    }

    return;
} // end BT_Mult

MultiCompactMatrix* Task::GetProjMatrix()
{
    int NC,IEL,IAT,IADJ,IEQ,BSORT,IHELP,ICOL;
    MultiCompactMatrix *C=new MultiCompactMatrix(MaxLevel);

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::GetProjMatrix.\n";
	protocol.mFlush();
    }

    for(int ILEV=1;ILEV<=TotalLevel;ILEV++) {
	SetLevel(ILEV);
	DoubleCompactMatrix *mat=new DoubleCompactMatrix(7*NumElements,NumElements);
	(*C)[ILEV]=mat;

	NC=0;
	mat->Diag(1)=1;

	for(IEL=1;IEL<=NumElements;IEL++)
	{
	    NC++;
	    mat->Col(NC)=IEL;
	    for(IAT=1;IAT<=6;IAT++)
	    {
		IADJ=(*NeighElem)(IAT,IEL);
		if (IADJ!=0)
		{
		    NC++;
		    mat->Col(NC)=IADJ;
		}
	    }
	    mat->Diag(IEL+1)=NC+1;
	}

	for(IEQ=1;IEQ<=NumElements;IEQ++)
	{
	    do {
		BSORT=true;
		for(ICOL=mat->Diag(IEQ)+1;ICOL<=mat->Diag(IEQ+1)-2;ICOL++)
		{
		    if (mat->Col(ICOL)>mat->Col(ICOL+1))
		    {
			IHELP=mat->Col(ICOL);
			mat->Col(ICOL)=mat->Col(ICOL+1);
			mat->Col(ICOL+1)=IHELP;
			BSORT=false;
		    }
		}
	    } while(BSORT==false);
	}
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::GetProjMatrix.\n";
	protocol.mFlush();
    }

    return C;
} // end GetProjMatrix

void Task::BuildProjMatrix(MultiCompactMatrix& mat,MultiVector& Mvect,
			   MultiRectMatrix& B,MultiRectMatrix& BT,MultiRectMatrix& BTT)
{
    int IEL,IAT,IAREA,IADJ,INP,ILD1,ILD2,ILDB1,ILDC,INPR,ILDB2;
    double DH1,DH2;
    DoubleCompactMatrix *C;
    DoubleRectMatrix *B1,*B2,*B3;
    DoubleVector *M;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::BuildProjMatrix.\n";
	protocol.mFlush();
    }

    for(int ILEV=1;ILEV<=TotalLevel;ILEV++) {
	SetLevel(ILEV);
	C=mat[ILEV];
	M=Mvect[ILEV];
	B1=B[ILEV];
	B2=BT[ILEV];
	B3=BTT[ILEV];
	*C=0;

	for(IEL=1;IEL<=NumElements;IEL++)
	{
	    for(IAT=1;IAT<=6;IAT++)
	    {
		IAREA=(*MidFaces)(IAT,IEL);
		if (IAREA==0)
		    protocol << progname << " (process " << MyProcID << "):\n"
			     <<" Error(1) IAREA==0 IEL="<<IEL<<" IAT="<<IAT<<"\n";
		IADJ=(*NeighElem)(IAT,IEL);
		//	INPR=(*InfoVertEdge)(IAREA+NumVertices);
		INPR=GetNeuNodeType(IAREA);

		if (IADJ!=0 || INPR==NEUMANN_BOUND)
		{
		    ILD1=C->Diag(IEL);
		    ILD2=C->Diag(IEL+1)-1;

		    for(ILDB1=B1->Diag(IAREA);ILDB1<=B1->Diag(IAREA+1)-1;ILDB1++)
		    {
			if (B1->Col(ILDB1)==IEL)
			    break;
		    }
		    if (ILDB1 > B1->Diag(IAREA+1)-1)
		    {
			protocol << progname << " (process " << MyProcID << "):\n"
				 <<" Error in B1 IEL="<<IEL<<" IAREA="<<IAREA<<" IAT="<<IAT<<" level="<<ILEV<<"\n"
				 << progname << " (process " << MyProcID << "):\n"
				 << "  Program aborted in Task::BuildProjMatrix\n";
			MPI_Finalize();
			exit(0);
		    }
		    DH1=pow(B1->Data(ILDB1),2.0)+pow(B2->Data(ILDB1),2.0)+pow(B3->Data(ILDB1),2);
		    C->Data(ILD1)+=DH1/(*M)(IAREA);

		    if (IADJ!=0)
		    {
			for(ILDB2=B1->Diag(IAREA);ILDB2<=B1->Diag(IAREA+1)-1;ILDB2++)
			{
			    if (B1->Col(ILDB2)==IADJ)
				break;
			}
			if (ILDB2 > B1->Diag(IAREA+1)-1)
			{
			    protocol << progname << " (process " << MyProcID << "):\n"
				     <<"Error in B2\n"
				     << progname << " (process " << MyProcID << "):\n"
				     << "  Program aborted in Task::BuildProjMatrix\n";
			    MPI_Finalize();
			    exit(0);
			}
			for(ILDC=ILD1+1;ILDC<=ILD2;ILDC++)
			{
			    if (C->Col(ILDC)==IADJ)
				break;
			}
			if (ILDC > ILD2)
			{
			    protocol << progname << " (process " << MyProcID << "):\n"
				     <<"Error in C\n"
				     << progname << " (process " << MyProcID << "):\n"
				     << "  Program aborted in Task::BuildProjMatrix\n";
			    MPI_Finalize();
			    exit(0);
			}
			DH2=B1->Data(ILDB1)*B1->Data(ILDB2)+B2->Data(ILDB1)*B2->Data(ILDB2)
			    +B3->Data(ILDB1)*B3->Data(ILDB2);
			C->Data(ILDC)=DH2/(*M)(IAREA);
		    }
		}
	    }
	}
	// for Parallel computing
	myElemBase=MmyElemBase[ILEV];
	SetCElemInfo(M);
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::BuildProjMatrix.\n";
	protocol.mFlush();
    }

    return;
} // end BuildProjMatrix

MultiVector *Task::GetLumpedMassMat(MultiCompactMatrix& M)
{
    int IEQ;
    double DMH;
    MultiVector  *multi=new MultiVector(MaxLevel);

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::GetLumpedMassMat.\n";
	protocol.mFlush();
    }

    for(int ILEV=1;ILEV<=TotalLevel;ILEV++) {
	DoubleVector *vect=new DoubleVector(M[ILEV]->GetNumDiag());
	(*multi)[ILEV]=vect;

	for(IEQ=1;IEQ<=M[ILEV]->GetNumDiag();IEQ++)
	{
//	DMH=0;
//	for(int ICOL=M[ILEV]->Diag(IEQ);ICOL<=M[ILEV]->Diag(IEQ+1)-1;ICOL++)
//	  DMH+=M[ILEV]->Data(ICOL);
//	(*vect)(IEQ)=DMH;
	    (*vect)(IEQ)=M[ILEV]->Data(M[ILEV]->Diag(IEQ));
	}
	SetLevel(ILEV);
	SetBoundValues(vect);
	Communicate();
	GetBoundValuesMult(vect);
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::GetLumpedMassMat.\n";
	protocol.mFlush();
    }

    return multi;
} // end GetLumpedMassMat

MultiVector *Task::GetPureLumpedMassMat(MultiCompactMatrix& M)
{
    int IEQ;
    double DMH;
    MultiVector  *multi=new MultiVector(MaxLevel);

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::GetPureLumpedMassMat.\n";
	protocol.mFlush();
    }

    for(int ILEV=1;ILEV<=TotalLevel;ILEV++) {
	DoubleVector *vect=new DoubleVector(M[ILEV]->GetNumDiag());
	(*multi)[ILEV]=vect;

	for(IEQ=1;IEQ<=M[ILEV]->GetNumDiag();IEQ++)
	{
	    DMH=0;
//	for(int ICOL=M[ILEV]->Diag(IEQ);ICOL<=M[ILEV]->Diag(IEQ+1)-1;ICOL++)
//	  DMH+=M[ILEV]->Data(ICOL);
//	(*vect)(IEQ)=DMH;
	    (*vect)(IEQ)=M[ILEV]->Data(M[ILEV]->Diag(IEQ));
	}
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::GetPureLumpedMassMat.\n";
	protocol.mFlush();
    }

    return multi;
} // end GetPureLumpedMassMat

void Task::SetCElemInfo(DoubleVector *M)
{
    elemlist* temp_list;
    double P1X,P1Y,P1Z;
    double P2X,P2Y,P2Z;
    double P3X,P3Y,P3Z;
    double P4X,P4Y,P4Z,DNX,DNY,DNZ;
//      double AX1,AY1,AZ1;
    double AX2,AY2,AZ2;
    double AX3,AY3,AZ3;
    double AX4,AY4,AZ4;
    double AX,AY,AZ,DHN;
    double PXC,PYC,PZC,PXA,PYA,PZA,DNAR1,DNAR2,DFAC;
    int IEL,IVT,IAT,IVT1,IVT2,IVT3,IVT4,IVE;
    double ptemp;

    DoubleVector *temp=new DoubleVector(NumElements);

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::SetCElemInfo.\n";
	protocol.mFlush();
    }

    for(temp_list=myElemBase->get_neighlist()->get_first();temp_list;
	temp_list=myElemBase->get_neighlist()->get_next(temp_list))
    {
	elemlink *temp_node;
	for(temp_node=temp_list->base->get_first();temp_node;
	    temp_node=temp_list->base->get_next(temp_node))
	{
	    PXC=0.;
	    PYC=0.;
	    PZC=0.;

	    for(IVE=1;IVE<=8;IVE++) {
		IVT=(*VertElem)(IVE,temp_node->elem);
		PXC+=(*VertCoord)(1,IVT);
		PYC+=(*VertCoord)(2,IVT);
		PZC+=(*VertCoord)(3,IVT);
	    }

	    PXC*=0.125;
	    PYC*=0.125;
	    PZC*=0.125;

	    IAT=temp_node->face;
	    IEL=temp_node->elem;

	    if (IAT == 1)
	    {
		IVT1 = (*VertElem)(1,IEL);
		IVT2 = (*VertElem)(2,IEL);
		IVT3 = (*VertElem)(3,IEL);
		IVT4 = (*VertElem)(4,IEL);
	    }
	    if (IAT == 2)
	    {
		IVT1 = (*VertElem)(1,IEL);
		IVT2 = (*VertElem)(2,IEL);
		IVT3 = (*VertElem)(6,IEL);
		IVT4 = (*VertElem)(5,IEL);
	    }
	    if (IAT == 3)
	    {
		IVT1 = (*VertElem)(2,IEL);
		IVT2 = (*VertElem)(3,IEL);
		IVT3 = (*VertElem)(6,IEL);
		IVT4 = (*VertElem)(7,IEL);
	    }
	    if (IAT == 4)
	    {
		IVT1 = (*VertElem)(3,IEL);
		IVT2 = (*VertElem)(4,IEL);
		IVT3 = (*VertElem)(8,IEL);
		IVT4 = (*VertElem)(7,IEL);
	    }
	    if (IAT == 5)
	    {
		IVT1 = (*VertElem)(4,IEL);
		IVT2 = (*VertElem)(1,IEL);
		IVT3 = (*VertElem)(5,IEL);
		IVT4 = (*VertElem)(8,IEL);
	    }
	    if (IAT == 6)
	    {
		IVT1 = (*VertElem)(5,IEL);
		IVT2 = (*VertElem)(6,IEL);
		IVT3 = (*VertElem)(7,IEL);
		IVT4 = (*VertElem)(8,IEL);
	    }

	    P1X=(*VertCoord)(1,IVT1);
	    P1Y=(*VertCoord)(2,IVT1);
	    P1Z=(*VertCoord)(3,IVT1);
	    P2X=(*VertCoord)(1,IVT2);
	    P2Y=(*VertCoord)(2,IVT2);
	    P2Z=(*VertCoord)(3,IVT2);
	    P3X=(*VertCoord)(1,IVT3);
	    P3Y=(*VertCoord)(2,IVT3);
	    P3Z=(*VertCoord)(3,IVT3);
	    P4X=(*VertCoord)(1,IVT4);
	    P4Y=(*VertCoord)(2,IVT4);
	    P4Z=(*VertCoord)(3,IVT4);

	    PXA=(P1X+P2X+P3X+P4X)*0.25;
	    PYA=(P1Y+P2Y+P3Y+P4Y)*0.25;
	    PZA=(P1Z+P2Z+P3Z+P4Z)*0.25;

	    AX2=P2X-P1X;
	    AY2=P2Y-P1Y;
	    AZ2=P2Z-P1Z;
	    AY3=P3Y-P1Y;
	    AX3=P3X-P1X;
	    AZ3=P3Z-P1Z;
	    AY4=P4Y-P1Y;
	    AX4=P4X-P1X;
	    AZ4=P4Z-P1Z;

	    AX =PXC-PXA;
	    AY =PYC-PYA;
	    AZ =PZC-PZA;

	    DNX=(AY3*AZ2)-(AZ3*AY2);
	    DNY=(AZ3*AX2)-(AX3*AZ2);
	    DNZ=(AX3*AY2)-(AY3*AX2);
	    DNAR1=sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

	    DNX=(AY4*AZ3)-(AZ4*AY3);
	    DNY=(AZ4*AX3)-(AX4*AZ3);
	    DNZ=(AX4*AY3)-(AY4*AX3);
	    DNAR2=sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

	    DFAC=0.5*(DNAR1+DNAR2)/DNAR2;
	    DNX =DFAC*DNX;
	    DNY =DFAC*DNY;
	    DNZ =DFAC*DNZ;

	    DHN=DNX*AX+DNY*AY+DNZ*AZ;
	    if (DHN < 0) {
		DNX=-DNX;
		DNY=-DNY;
		DNZ=-DNZ;
	    }
	    temp_node->normal=(DNX*DNX+DNY*DNY+DNZ*DNZ)/(*M)((*MidFaces)(temp_node->face,temp_node->elem));

	    (*temp)(temp_node->elem)=temp_node->normal;
	}
    }

    SetElemBoundValues(temp);
    CommunicateElem();

    elemlist* list;
    for(list=myElemBase->get_neighlist()->get_first();
	list;
	list=myElemBase->get_neighlist()->get_next(list))
    {
	elemlink *node;
	for(node=list->base->get_first();node;
	    node=list->base->get_next(node))
	{
	    if (FindElem(node->elem,node->face,ptemp,ActiveLevel)==true)
	    {
		node->normalneigh=ptemp;
	    } else {
		Prot<<"SetCElemInfo: Didnot find elem="<<node->elem<<" face="<<node->face<<"\n";
	    }
	}
    }

    delete temp;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::SetCElemInfo.\n";
	protocol.mFlush();
    }

    return;
} // end SetCElemInfo


void Task::CVectMult(DoubleCompactMatrix *C, DoubleVector& x, DoubleVector& f, double& T)
// f = C * x
// T holds communication time
{
    ClockMVMult.SetTime();

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::CVectMult.\n";
	protocol.mFlush();
    }

    double ptemp;
    myElemBase = MmyElemBase[ActiveLevel];

//  if (Debug) {
//    	protocol << "DEBUG(" << MyProcID << "): Entering Task::CVectMult.\n";
//     	protocol.mFlush();
//  }

    T = 0;
    DateTime ComTime;
    SetElemBoundValues(&x);
    CommunicateElem();
    T += ComTime.GetTimeDiff();

    // f = C * x
    C->VectMult(x, f);

    elemlist* list;
    for (list = myElemBase->get_neighlist()->get_first();
	list;
	list = myElemBase->get_neighlist()->get_next(list)) {
	elemlink *node;
	for (node = list->base->get_first(); node;
	    node = list->base->get_next(node))
	{
	    if (FindElem(node->elem, node->face, ptemp, ActiveLevel) == true)
	    {
//  	        Prot<<"CVectMult : elem="<<node->elem<<" face="<<node->face<<" normal="<<node->normal<<"\n";
		f(node->elem) += node->normal * x(node->elem);
		f(node->elem) -= node->normal * ptemp;
	    } else {
		Prot<<"Didnot find elem="<<node->elem<<" face="<<node->face<<"\n";
	    }
	}
    }

    TMVMult += ClockMVMult.GetTimeDiff();
    TMVMultCom += T;

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CVectMult.\n";
//  	protocol.mFlush();
//      }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CVectMult.\n";
	protocol.mFlush();
    }

    return;
}

//  elemlist* list;
//  for(list=myElemBase->get_neighlist()->get_first(),
//          temp_vectlist=RecvElemBoundData->get_first();list;
//      list=myElemBase->get_neighlist()->get_next(list),
//          temp_vectlist=RecvElemBoundData->get_next(temp_vectlist))
//  {
//      elemlink *node;
//      Data=temp_vectlist->ptr;
//      for(i=1,node=list->base->get_first();node;
//          node=list->base->get_next(node),i++)
//      {
//          if (FindElem(node->elem,node->face,ptemp,ActiveLevel)==true)
//          {
//              f(node->elem)+=node->normal*x(node->elem);
//              f(node->elem)-=node->normal*ptemp;
//          } else {
//              Prot<<"Didnot find elem="<<node->elem<<" face="<<node->face<<"\n";
//          }
//      }
//  }


void Task::TestGrid()
{
    int ILD,IEL,IAT,IAREA,IVT1,IVT2,IVT3,IVT4,IADJ,IVE,IVT;
    double P1X,P1Y,P1Z,P2X,P2Y,P2Z,P3X,P3Y,P3Z,P4X,P4Y,P4Z,DNX,DNY,DNZ;
    double AX1,AX2,AX3,AX4,AY1,AY2,AY3,AY4,AZ1,AZ2,AZ3,AZ4,AX,AY,AZ,DHN;
    double PXC,PYC,PZC,PXA,PYA,PZA,DNAR1,DNAR2,DFAC,DNX1,DNY1,DNZ1,DNX2,DNY2,DNZ2;

    if (Debug) {
 	protocol << "DEBUG(" << MyProcID << "): Entering Task::TestGrid.\n";
 	protocol.mFlush();
    }

    for(IEL=1;IEL<=NumElements;IEL++) {
 	PXC = 0.;
 	PYC = 0.;
 	PZC = 0.;

 	for(IVE=1;IVE<=8;IVE++) {
 	    IVT=(*VertElem)(IVE,IEL);
 	    PXC+=(*VertCoord)(1,IVT);
 	    PYC+=(*VertCoord)(2,IVT);
 	    PZC+=(*VertCoord)(3,IVT);
 	}

 	PXC*=0.125;
 	PYC*=0.125;
 	PZC*=0.125;

 	for(IAT=1;IAT<=6;IAT++) {
 	    if (IAT == 1) {
 		IVT1 = (*VertElem)(1,IEL);
 		IVT2 = (*VertElem)(2,IEL);
 		IVT3 = (*VertElem)(3,IEL);
 		IVT4 = (*VertElem)(4,IEL);
 	    }
 	    if (IAT == 2) {
 		IVT1 = (*VertElem)(1,IEL);
 		IVT2 = (*VertElem)(2,IEL);
 		IVT3 = (*VertElem)(6,IEL);
 		IVT4 = (*VertElem)(5,IEL);
 	    }
 	    if (IAT == 3) {
 		IVT1 = (*VertElem)(2,IEL);
 		IVT2 = (*VertElem)(3,IEL);
 		IVT3 = (*VertElem)(6,IEL);
 		IVT4 = (*VertElem)(7,IEL);
 	    }
 	    if (IAT == 4) {
 		IVT1 = (*VertElem)(3,IEL);
 		IVT2 = (*VertElem)(4,IEL);
 		IVT3 = (*VertElem)(8,IEL);
 		IVT4 = (*VertElem)(7,IEL);
 	    }
 	    if (IAT == 5) {
 		IVT1 = (*VertElem)(4,IEL);
 		IVT2 = (*VertElem)(1,IEL);
 		IVT3 = (*VertElem)(5,IEL);
 		IVT4 = (*VertElem)(8,IEL);
 	    }
 	    if (IAT == 6) {
 		IVT1 = (*VertElem)(5,IEL);
 		IVT2 = (*VertElem)(6,IEL);
 		IVT3 = (*VertElem)(7,IEL);
 		IVT4 = (*VertElem)(8,IEL);
 	    }
 	    P1X=(*VertCoord)(1,IVT1);
 	    P1Y=(*VertCoord)(2,IVT1);
 	    P1Z=(*VertCoord)(3,IVT1);
 	    P2X=(*VertCoord)(1,IVT2);
 	    P2Y=(*VertCoord)(2,IVT2);
 	    P2Z=(*VertCoord)(3,IVT2);
 	    P3X=(*VertCoord)(1,IVT3);
 	    P3Y=(*VertCoord)(2,IVT3);
 	    P3Z=(*VertCoord)(3,IVT3);
 	    P4X=(*VertCoord)(1,IVT4);
 	    P4Y=(*VertCoord)(2,IVT4);
 	    P4Z=(*VertCoord)(3,IVT4);


 	    PXA=(P1X+P2X+P3X+P4X)*0.25;
 	    PYA=(P1Y+P2Y+P3Y+P4Y)*0.25;
 	    PZA=(P1Z+P2Z+P3Z+P4Z)*0.25;

 	    AX2=P2X-P1X;
 	    AY2=P2Y-P1Y;
 	    AZ2=P2Z-P1Z;
 	    AY3=P3Y-P1Y;
 	    AX3=P3X-P1X;
 	    AZ3=P3Z-P1Z;
 	    AY4=P4Y-P1Y;
 	    AX4=P4X-P1X;
 	    AZ4=P4Z-P1Z;

 	    AX =PXC-PXA;
 	    AY =PYC-PYA;
 	    AZ =PZC-PZA;


 	    DNX1=(AY3*AZ2)-(AZ3*AY2);
 	    DNY1=(AZ3*AX2)-(AX3*AZ2);
 	    DNZ1=(AX3*AY2)-(AY3*AX2);
 	    DNAR1=sqrt(DNX1*DNX1+DNY1*DNY1+DNZ1*DNZ1);

 	    if (DNAR1<1e-12) {
 		Prot<<"Error in element "<<IEL<<"\n";
 		Prot<<" P1=("<<P1X<<","<<P1Y<<","<<P1Z<<")\n";
 		Prot<<" P2=("<<P2X<<","<<P2Y<<","<<P2Z<<")\n";
 		Prot<<" P3=("<<P3X<<","<<P3Y<<","<<P3Z<<")\n";
 		Prot<<" P4=("<<P4X<<","<<P4Y<<","<<P4Z<<")\n";
 	    }

 	    DNX2=(AY4*AZ3)-(AZ4*AY3);
 	    DNY2=(AZ4*AX3)-(AX4*AZ3);
 	    DNZ2=(AX4*AY3)-(AY4*AX3);
 	    DNAR2=sqrt(DNX2*DNX2+DNY2*DNY2+DNZ2*DNZ2);

 	    if (DNAR2<1e-12) {
 		Prot<<"Error in element "<<IEL<<"\n";
 		Prot<<" P1=("<<P1X<<","<<P1Y<<","<<P1Z<<")\n";
 		Prot<<" P2=("<<P2X<<","<<P2Y<<","<<P2Z<<")\n";
 		Prot<<" P3=("<<P3X<<","<<P3Y<<","<<P3Z<<")\n";
 		Prot<<" P4=("<<P4X<<","<<P4Y<<","<<P4Z<<")\n";
 	    }
 	}
    }

    if (Debug) {
 	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::TestGrid.\n";
 	protocol.mFlush();
    }

    return;
}
