#ifndef TYPECASTSH

#define TYPECASTSH

#include <string>

// Uncomment next line on:
//   alice, 
// Use it on  
//   linux, 
#ifndef ALPHA_LINUX
#include <cstdio>
#endif

#include <math.h>

extern double GlobalDOF;
extern double ConstGlobalDOF;

const std::string int_to_string    (const int n);
const std::string int_to_string    (const int n, const unsigned int digits);
const std::string int_to_string    (const int n, const char* character, unsigned int digits);
const std::string double_to_string (const double n, const char* efg, const unsigned int after_digits);
const std::string timeval_to_string(const double timevalue);
const std::string norm_to_string   (const double n, const char* efg, const unsigned int after_digits, double scale);

#endif
