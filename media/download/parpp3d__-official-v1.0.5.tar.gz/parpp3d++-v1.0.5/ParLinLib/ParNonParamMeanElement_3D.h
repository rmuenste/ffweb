#ifndef PARNONPARAMMEANELEMENT3DH

#define PARNONPARAMMEANELEMENT3DH

#include "ParFiniteElement_3D.h"
#include "Const.h"

class ParNonParamMeanElement_3D:public ParFiniteElement_3D
{
protected:
  double F1(double X,double Y,double Z,double CA1,double CB1,double CC1,
	    double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
	    double CD1,double CD2,double CD3,double CD4,double CD5,double CD6,
	    double CE1,double CE2,double CE3,double CE4,double CE5,double CE6);
  double F2(double X,double Y,double Z,double CA1,double CB1,double CC1,
	    double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
	    double CD1,double CD2,double D3,double CD4,double CD5,double CD6,
	    double CE1,double CE2,double CE3,double CE4,double CE5,double CE6);
  double F3(double X,double Y,double Z,double CA1,double CB1,double CC1,
	    double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
	    double CD1,double CD2,double D3,double CD4,double CD5,double CD6,
	    double CE1,double CE2,double CE3,double CE4,double CE5,double CE6);
  double F4(double X,double Y,double Z,double CA1,double CB1,double CC1,
	    double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
	    double CD1,double CD2,double D3,double CD4,double CD5,double CD6,
	    double CE1,double CE2,double CE3,double CE4,double CE5,double CE6);
  double F5(double X,double Y,double Z,double CA1,double CB1,double CC1,
	    double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
	    double CD1,double CD2,double D3,double CD4,double CD5,double CD6,
	    double CE1,double CE2,double CE3,double CE4,double CE5,double CE6);
  double F6(double X,double Y,double Z,double CA1,double CB1,double CC1,
	    double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
	    double CD1,double CD2,double D3,double CD4,double CD5,double CD6,
	    double CE1,double CE2,double CE3,double CE4,double CE5,double CE6);
  void Invert(DoubleArray2D& A,DoubleArray& F,DoubleArray& CKH,int IPAR);
  void Exchange(int NDIM,int N,DoubleArray2D& A,DoubleArray2D& B,
		DoubleArray& MERKX,DoubleArray& MERKY,int& IFEHL);
  DoubleArray2D *COB;
public:
  ParNonParamMeanElement_3D(SquareGrid_3D *NGrid):ParFiniteElement_3D(NGrid) 
  {IDFL=NumFaceElem;NDIM=1;COB=new DoubleArray2D(27,10);}
  ~ParNonParamMeanElement_3D(VOID) {}
		
  VOID PreCalc(DOUBLE X1,DOUBLE X2,DOUBLE X3);
  VOID GetValue(DOUBLE X1,DOUBLE X2,DOUBLE X3);
  UNSIGNED GetDOF(VOID);
  UNSIGNED GetTotalDOF(VOID);
  UNSIGNED GetIEROW(VOID);
  int      GetElemType(void);
  VOID SetGlobalDOF(UNSIGNED IEL,UNSIGNED IPAR);
  VOID Restrict(DoubleVector *LD,DoubleVector *LB,
		IntArray2D *VertElem2,IntArray2D *VertElem1,
		IntArray2D *MidFaces2,IntArray2D *MidFaces1,
		IntArray2D *NeighElem2,IntArray2D *NeighElem1,
		UNSIGNED NumVertices2,UNSIGNED NumVertices1,
		UNSIGNED NumElements2,UNSIGNED NumElements1);
  VOID Prol(DoubleVector *LD,DoubleVector *LB,
	    IntArray2D *VertElem2,IntArray2D *VertElem1,
	    IntArray2D *MidFaces2,IntArray2D *MidFaces1,
	    IntArray2D *NeighElem2,IntArray2D *NeighElem1,
	    UNSIGNED NumVertices2,UNSIGNED NumVertices1,
	    UNSIGNED NumElements2,UNSIGNED NumElements1);
  VOID ParRestrict(DoubleVector *LD,DoubleVector *LB,
		   IntArray2D *VertElem2,IntArray2D *VertElem1,
		   IntArray2D *MidFaces2,IntArray2D *MidFaces1,
		   IntArray2D *NeighElem2,IntArray2D *NeighElem1,
		   UNSIGNED NumVertices2,UNSIGNED NumVertices1,
		   UNSIGNED NumElements2,UNSIGNED NumElements1,
		   ParMultiGrid_3D *Com);
  VOID ParProl(DoubleVector *LD,DoubleVector *LB,
	       IntArray2D *VertElem2,IntArray2D *VertElem1,
	       IntArray2D *MidFaces2,IntArray2D *MidFaces1,
	       IntArray2D *NeighElem2,IntArray2D *NeighElem1,
	       UNSIGNED NumVertices2,UNSIGNED NumVertices1,
	       UNSIGNED NumElements2,UNSIGNED NumElements1,
	       ParMultiGrid_3D *Com);
};

inline UNSIGNED ParNonParamMeanElement_3D::GetDOF(VOID)
{
  return IDFL;
}

inline UNSIGNED ParNonParamMeanElement_3D::GetTotalDOF(VOID)
{
  return Grid->TotNumFaces;
}

inline UNSIGNED ParNonParamMeanElement_3D::GetIEROW(VOID)
{
  return 12;
}

inline int ParNonParamMeanElement_3D::GetElemType(VOID)
{
  return NON_PARAM;
}

#endif
