#include "ParNonParamElement_3D.h"
#include "ParMultiGrid_3D.h"

extern double TProl,TProlCom,TRest,TRestCom;

#define Q8	0.125
#define NNVME	8

VOID ParNonParamElement_3D::SetGlobalDOF(UNSIGNED IEL,UNSIGNED IPAR)
{
  INTEGER IVE,NKE,IME,IKE,IEE,IAE;
  IntArray	JVG(NNVEA),JVL(NNVEA);
  
  for(IVE=1;IVE<=NumVertElem;IVE++) {
    JVG(IVE)=(*VertElem)(IVE,IEL);
    JVL(IVE)=IVE;
  }
  NKE=NumVertElem;
  if(TotNumFaces>0)
  {
    for(IAE=1;IAE<=NumFaceElem;IAE++) {
      JVG(NKE+IAE)=(*MidFaces)(IAE,IEL)+NumVertices;
      JVL(NKE+IAE)=NKE+IAE;
    }
    NKE+=NumFaceElem;
  }
 
  if(IPAR>=0)
      BubbleSort(JVG,JVL,NKE);
  
  for(IAE=1;IAE<=NumFaceElem;IAE++) {
    if(TotNumFaces>0)
	(*KDFG)(IAE)=JVG(NKE-NumFaceElem+IAE)-NumVertices;
  }
  if(IPAR==1) {
    for(IAE=1;IAE<=NumFaceElem;IAE++) {
      (*KDFL)(IAE)=JVL(NKE-NumFaceElem+IAE)-NumVertElem;
    }
  }
}

double ParNonParamElement_3D::F1(double X,double Y,double Z,double CA1,double CB1,double CC1,
			      double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
			      double CD1,double CD2,double CD3,double CD4,double CD5,double CD6,
			      double CE1,double CE2,double CE3,double CE4,double CE5,double CE6)
{
  return 1.0;
}

double ParNonParamElement_3D::F2(double X,double Y,double Z,double CA1,double CB1,double CC1,
			      double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
			      double CD1,double CD2,double CD3,double CD4,double CD5,double CD6,
			      double CE1,double CE2,double CE3,double CE4,double CE5,double CE6)
{
  return CA1*X  +CB1*Y +CC1*Z; 
}

double ParNonParamElement_3D::F3(double X,double Y,double Z,double CA1,double CB1,double CC1,
			      double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
			      double CD1,double CD2,double CD3,double CD4,double CD5,double CD6,
			      double CE1,double CE2,double CE3,double CE4,double CE5,double CE6)
{
  return CA2*X  +CB2*Y +CC2*Z;  
}

double ParNonParamElement_3D::F4(double X,double Y,double Z,double CA1,double CB1,double CC1,
			      double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
			      double CD1,double CD2,double CD3,double CD4,double CD5,double CD6,
			      double CE1,double CE2,double CE3,double CE4,double CE5,double CE6)
{
  return CA3*X  +CB3*Y +CC3*Z;
}

double ParNonParamElement_3D::F5(double X,double Y,double Z,double CA1,double CB1,double CC1,
			      double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
			      double CD1,double CD2,double CD3,double CD4,double CD5,double CD6,
			      double CE1,double CE2,double CE3,double CE4,double CE5,double CE6)
{
  return CD1*X*X+CD2*Y*Y+CD3*Z*Z+CD4*X*Y+CD5*X*Z+CD6*Y*Z; 
}

double ParNonParamElement_3D::F6(double X,double Y,double Z,double CA1,double CB1,double CC1,
			      double CA2,double CB2,double CC2,double CA3,double CB3,double CC3,
			      double CD1,double CD2,double CD3,double CD4,double CD5,double CD6,
			      double CE1,double CE2,double CE3,double CE4,double CE5,double CE6)
{
  return  CE1*X*X+CE2*Y*Y+CE3*Z*Z+CE4*X*Y+CE5*X*Z+CE6*Y*Z; 
}

void ParNonParamElement_3D::Invert(DoubleArray2D& A,DoubleArray& F,DoubleArray& X,int IPAR)
{
  int NDIM=6,IA,IB,IFEHL;
  DoubleArray2D B(NDIM,NDIM);
  DoubleArray MERKX(NDIM),MERKY(NDIM);
  
  if(IPAR==0) {
    Exchange(NDIM,NDIM,A,B,MERKX,MERKY,IFEHL);
    for(IA=1;IA<=NDIM;IA++)
      for(IB=1;IB<=NDIM;IB++)
	A(IA,IB)=B(IA,IB);
  } else if(IPAR==1) {
    for(IA=1;IA<=NDIM;IA++) {
      X(IA)=0.0;
       for(IB=1;IB<=NDIM;IB++) {
	 X(IA)=X(IA)+A(IA,IB)*F(IB);
       }
    }
  }
}

void ParNonParamElement_3D::Exchange(int NDIM,int N,DoubleArray2D& A,DoubleArray2D& B,
				  DoubleArray& MERKX,DoubleArray& MERKY,int& IFEHL)
{
  int I,L,IX,IY,K,J,INDX,INDY,M;
  double PIVOT,HILF;

  IFEHL=1;
  for(I=1;I<=N;I++) {
    MERKX(I)=0;
    MERKY(I)=0;
    for(L=1;L<=N;L++)
      B(I,L)=A(I,L);
  }

  for(I=1;I<=N;I++) {
    PIVOT=0.0;
    for(IX=1;IX<=N;IX++) {
      // MERKX(IX)==0
      if(fabs(MERKX(IX) - 0.0) < FLOAT_EPS) {
	for(IY=1;IY<=N;IY++) {
	  // MERKY(IY)==0
	  if(fabs(MERKY(IY) - 0.0) < FLOAT_EPS) {
	    if(fabs(B(IX,IY))>fabs(PIVOT)) {
	      PIVOT=B(IX,IY);
	      INDX=IX;
	      INDY=IY;
	    }
	  }
	}
      }
    }

    if(fabs(PIVOT)<=0.0)
      return;
    MERKX(INDX)=INDY;
    MERKY(INDY)=INDX;
    B(INDX,INDY)=1.0/PIVOT;
    for(L=1;L<=N;L++) {
      if(L!=INDX) {
	for(M=1;M<=N;M++) {
	  if(M!=INDY)
	    B(L,M)=B(L,M)-B(L,INDY)*B(INDX,M)/PIVOT;
	}
      }
    }

    for(IX=1;IX<=N;IX++) {
      if(IX!=INDX)
	B(IX,INDY)=B(IX,INDY)/PIVOT;
    }
    for(IY=1;IY<=N;IY++) {
      if(IY!=INDY)
	B(INDX,IY)=-B(INDX,IY)/PIVOT;
    }
  }

  for(I=2;I<=N;I++) {
    IX=I-1;
    // MERKX(IX)!=IX
    if(fabs(MERKX(IX) - IX) > FLOAT_EPS) {
      for(J=1;J<=N;J++) {
	IY=J;
	// MERKX(IY)==IX
	if(fabs(MERKX(IY) - IX) < FLOAT_EPS)
	  break;
      }
      for(K=1;K<=N;K++) {
	HILF=B(IX,K);
	B(IX,K)=B(IY,K);
	B(IY,K)=HILF;
      }
      MERKX(IY)=MERKX(IX);
    }
    MERKX(IX)=IX;
  }

  for(I=2;I<=N;I++) {
    IX=I-1;
    // MERKY(IX)!=IX
    if(fabs(MERKY(IX) - IX) > FLOAT_EPS) {
      for(J=1;J<=N;J++) {
	IY=J;
	// MERKY(IY)==IX
	if(fabs(MERKY(IY) - IX) < FLOAT_EPS)
	  break;
      }
      
      for(K=1;K<=N;K++) {
	HILF=B(K,IX);
	B(K,IX)=B(K,IY);
	B(K,IY)=HILF;
      }
      MERKY(IY)=MERKY(IX);
    }
    MERKY(IX)=IX;
  }
  
  IFEHL=0;
}

void ParNonParamElement_3D::PreCalc(DOUBLE X1,DOUBLE X2,DOUBLE X3)
{
 //   Point-oriented element

  DOUBLE XJ1;
  DoubleArray2D	DHELP(6,4);
  int IDFL1,IA,IK1,IK2,IK;
  double CA1,CA2,CA3,CB1,CB2,CB3,CC1,CC2,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6;
  
  if(DETJ>0 && DETJ<1e-70) {
	protocol << progname << " (process " << MyProcID << "):\n"
	       << "  Program aborted in ParNonParamElement_3D::PreCalc.\n"
	       << "  Element has vanishing area DETJ="<<DETJ<<" !!!\n";
        MPI_Abort(MPI_COMM_WORLD, DETERMINANT_ZERO);
  }
  if((*BDER)(5) || (*BDER)(6) || (*BDER)(7) || (*BDER)(8)) {
	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Program aborted in ParNonParamElement_3D::PreCalc.\n"
		 << "  Desired derivates not available !!!\n";
        MPI_Abort(MPI_COMM_WORLD, DERIVATES_NOT_AVAILABLE);
  }

  //  PARAMETER (NNBAS=27,NNDER=10,NNCUBP=36,NNVE=8,NNAE=6)
  //  PARAMETER (NNDIM=3,NNCOF=10)
  double Q3=1e0/3e0;
  double Q7=-0.5625e0;
  double Q9=0.5208333e0;
  DoubleArray   DXM(6),DYM(6),DZM(6),F(6),CKH(6);
  DoubleArray2D A(6,6),CK(6,6);
  DoubleArray   P1X(6),P1Y(6),P1Z(6);
  DoubleArray P2X(6),P2Y(6),P2Z(6);
  DoubleArray P3X(6),P3Y(6),P3Z(6);
  DoubleArray P4X(6),P4Y(6),P4Z(6);
  DoubleArray P5X(6),P5Y(6),P5Z(6);
  DoubleArray P6X(6),P6Y(6),P6Z(6);
  DoubleArray P7X(6),P7Y(6),P7Z(6);
  DoubleArray P8X(6),P8Y(6),P8Z(6);
  DoubleArray PP1(6),PP2(6),PP3(6),PP4(6),PP5(6);
  DoubleArray PS1(6),PS2(6),PQ1(6),PQ2(6),PQ3(6);

  DXM(1)=0.25*((*DX)(1)+(*DX)(2)+(*DX)(3)+(*DX)(4));
  DYM(1)=0.25*((*DY)(1)+(*DY)(2)+(*DY)(3)+(*DY)(4));
  DZM(1)=0.25*((*DZ)(1)+(*DZ)(2)+(*DZ)(3)+(*DZ)(4));

  DXM(2)=0.25*((*DX)(1)+(*DX)(2)+(*DX)(6)+(*DX)(5));
  DYM(2)=0.25*((*DY)(1)+(*DY)(2)+(*DY)(6)+(*DY)(5));
  DZM(2)=0.25*((*DZ)(1)+(*DZ)(2)+(*DZ)(6)+(*DZ)(5));

  DXM(3)=0.25*((*DX)(2)+(*DX)(3)+(*DX)(7)+(*DX)(6));
  DYM(3)=0.25*((*DY)(2)+(*DY)(3)+(*DY)(7)+(*DY)(6));
  DZM(3)=0.25*((*DZ)(2)+(*DZ)(3)+(*DZ)(7)+(*DZ)(6));

  DXM(4)=0.25*((*DX)(3)+(*DX)(7)+(*DX)(8)+(*DX)(4));
  DYM(4)=0.25*((*DY)(3)+(*DY)(7)+(*DY)(8)+(*DY)(4));
  DZM(4)=0.25*((*DZ)(3)+(*DZ)(7)+(*DZ)(8)+(*DZ)(4));

  DXM(5)=0.25*((*DX)(1)+(*DX)(4)+(*DX)(8)+(*DX)(5));
  DYM(5)=0.25*((*DY)(1)+(*DY)(4)+(*DY)(8)+(*DY)(5));
  DZM(5)=0.25*((*DZ)(1)+(*DZ)(4)+(*DZ)(8)+(*DZ)(5));

  DXM(6)=0.25*((*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8));
  DYM(6)=0.25*((*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8));
  DZM(6)=0.25*((*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8));

  
  CA1=(DXM(1)-DXM(6))/sqrt(pow(DXM(1)-DXM(6),2)+pow(DYM(1)-DYM(6),2)+
			   pow(DZM(1)-DZM(6),2));
  CB1=(DYM(1)-DYM(6))/sqrt(pow(DXM(1)-DXM(6),2)+pow(DYM(1)-DYM(6),2)+
			   pow(DZM(1)-DZM(6),2));
  CC1=(DZM(1)-DZM(6))/sqrt(pow(DXM(1)-DXM(6),2)+pow(DYM(1)-DYM(6),2)+
			   pow(DZM(1)-DZM(6),2));
  CA2=(DXM(2)-DXM(4))/sqrt(pow(DXM(2)-DXM(4),2)+pow(DYM(2)-DYM(4),2)+
			   pow(DZM(2)-DZM(4),2));
  CB2=(DYM(2)-DYM(4))/sqrt(pow(DXM(2)-DXM(4),2)+pow(DYM(2)-DYM(4),2)+
			   pow(DZM(2)-DZM(4),2));
  CC2=(DZM(2)-DZM(4))/sqrt(pow(DXM(2)-DXM(4),2)+pow(DYM(2)-DYM(4),2)+
			   pow(DZM(2)-DZM(4),2));
  CA3=(DXM(3)-DXM(5))/sqrt(pow(DXM(3)-DXM(5),2)+pow(DYM(3)-DYM(5),2)+
			   pow(DZM(3)-DZM(5),2));
  CB3=(DYM(3)-DYM(5))/sqrt(pow(DXM(3)-DXM(5),2)+pow(DYM(3)-DYM(5),2)+
			   pow(DZM(3)-DZM(5),2));
  CC3=(DZM(3)-DZM(5))/sqrt(pow(DXM(3)-DXM(5),2)+pow(DYM(3)-DYM(5),2)+
			   pow(DZM(3)-DZM(5),2));
  CD1=pow(CA1,2)-pow(CA2,2);
  CD2=pow(CB1,2)-pow(CB2,2);
  CD3=pow(CC1,2)-pow(CC2,2);
  CD4=2.0*CA1*CB1-2.0*CA2*CB2;
  CD5=2.0*CA1*CC1-2.0*CA2*CC2;
  CD6=2.0*CB1*CC1-2.0*CB2*CC2;
  CE1=pow(CA2,2)-pow(CA3,2);
  CE2=pow(CB2,2)-pow(CB3,2);
  CE3=pow(CC2,2)-pow(CC3,2);
  CE4=2.0*CA2*CB2-2.0*CA3*CB3;
  CE5=2.0*CA2*CC2-2.0*CA3*CC3;
  CE6=2.0*CB2*CC2-2.0*CB3*CC3;


  for(IA=1;IA<=6;IA++) {
       A(IA,1)=F1(DXM(IA),DYM(IA),DZM(IA),CA1,CB1,CC1,CA2,CB2,CC2,
		  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6);      
       A(IA,2)=F2(DXM(IA),DYM(IA),DZM(IA),CA1,CB1,CC1,CA2,CB2,CC2,
		  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6);       
       A(IA,3)=F3(DXM(IA),DYM(IA),DZM(IA),CA1,CB1,CC1,CA2,CB2,CC2,
		  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6);       
       A(IA,4)=F4(DXM(IA),DYM(IA),DZM(IA),CA1,CB1,CC1,CA2,CB2,CC2,
		  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6);       
       A(IA,5)=F5(DXM(IA),DYM(IA),DZM(IA),CA1,CB1,CC1,CA2,CB2,CC2,
		  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6);
       A(IA,6)=F6(DXM(IA),DYM(IA),DZM(IA),CA1,CB1,CC1,CA2,CB2,CC2,
		  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6);       
  }

  Invert(A,F,CKH,0);       

  for(IK1=1;IK1<=6;IK1++)
    for(IK2=1;IK2<=6;IK2++)
      CK(IK1,IK2)=A(IK2,IK1);
  
  for(IK=1;IK<=6;IK++) {
    (*COB)(IK,1)=CK(IK,6)*CE1+CK(IK,5)*CD1;
    (*COB)(IK,2)=CK(IK,6)*CE2+CK(IK,5)*CD2;
    (*COB)(IK,3)=CK(IK,6)*CE3+CK(IK,5)*CD3;
    (*COB)(IK,4)=CK(IK,6)*CE4+CK(IK,5)*CD4;
    (*COB)(IK,5)=CK(IK,6)*CE5+CK(IK,5)*CD5;
    (*COB)(IK,6)=CK(IK,6)*CE6+CK(IK,5)*CD6;
    (*COB)(IK,7)=CK(IK,4)*CA3+CK(IK,3)*CA2+CK(IK,2)*CA1;
    (*COB)(IK,8)=CK(IK,4)*CB3+CK(IK,3)*CB2+CK(IK,2)*CB1;
    (*COB)(IK,9)=CK(IK,4)*CC3+CK(IK,3)*CC2+CK(IK,2)*CC1;
    (*COB)(IK,10)=CK(IK,1);
  }

//    // Mean-value element
//      DOUBLE XJ1;
//    DoubleArray2D	DHELP(6,4);
//    int IDFL1,IA,IK1,IK2,IK;
//    double CA1,CA2,CA3,CB1,CB2,CB3,CC1,CC2,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6;
  
//    if(DETJ>0 && DETJ<1e-70) {
//      Err<<"NonParamElement_3D: Element has vanishing area DETJ="<<DETJ<<" !!!\n";
//      exit(1);
//    }
//    if((*BDER)(5) || (*BDER)(6) || (*BDER)(7) || (*BDER)(8)) {
//      Err<<"NonParamElement_3D: Desired derivates not available !!!\n";
//      exit(1);
//    }

//    //  PARAMETER (NNBAS=27,NNDER=10,NNCUBP=36,NNVE=8,NNAE=6)
//    //  PARAMETER (NNDIM=3,NNCOF=10)
//    double Q3=1e0/3e0;
//    double Q7=-0.5625e0;
//    double Q9=0.5208333e0;
//    DoubleArray   DXM(6),DYM(6),DZM(6),F(6),CKH(6);
//    DoubleArray2D A(6,6),CK(6,6);
//    DoubleArray   P1X(6),P1Y(6),P1Z(6);
//    DoubleArray P2X(6),P2Y(6),P2Z(6);
//    DoubleArray P3X(6),P3Y(6),P3Z(6);
//    DoubleArray P4X(6),P4Y(6),P4Z(6);
//    DoubleArray P5X(6),P5Y(6),P5Z(6);
//    DoubleArray P6X(6),P6Y(6),P6Z(6);
//    DoubleArray P7X(6),P7Y(6),P7Z(6);
//    DoubleArray P8X(6),P8Y(6),P8Z(6);
//    DoubleArray PP1(6),PP2(6),PP3(6),PP4(6),PP5(6);
//    DoubleArray PS1(6),PS2(6),PQ1(6),PQ2(6),PQ3(6);

//    DXM(1)=0.25*((*DX)(1)+(*DX)(2)+(*DX)(3)+(*DX)(4));
//    DYM(1)=0.25*((*DY)(1)+(*DY)(2)+(*DY)(3)+(*DY)(4));
//    DZM(1)=0.25*((*DZ)(1)+(*DZ)(2)+(*DZ)(3)+(*DZ)(4));

//    DXM(2)=0.25*((*DX)(1)+(*DX)(2)+(*DX)(6)+(*DX)(5));
//    DYM(2)=0.25*((*DY)(1)+(*DY)(2)+(*DY)(6)+(*DY)(5));
//    DZM(2)=0.25*((*DZ)(1)+(*DZ)(2)+(*DZ)(6)+(*DZ)(5));

//    DXM(3)=0.25*((*DX)(2)+(*DX)(3)+(*DX)(7)+(*DX)(6));
//    DYM(3)=0.25*((*DY)(2)+(*DY)(3)+(*DY)(7)+(*DY)(6));
//    DZM(3)=0.25*((*DZ)(2)+(*DZ)(3)+(*DZ)(7)+(*DZ)(6));

//    DXM(4)=0.25*((*DX)(3)+(*DX)(7)+(*DX)(8)+(*DX)(4));
//    DYM(4)=0.25*((*DY)(3)+(*DY)(7)+(*DY)(8)+(*DY)(4));
//    DZM(4)=0.25*((*DZ)(3)+(*DZ)(7)+(*DZ)(8)+(*DZ)(4));

//    DXM(5)=0.25*((*DX)(1)+(*DX)(4)+(*DX)(8)+(*DX)(5));
//    DYM(5)=0.25*((*DY)(1)+(*DY)(4)+(*DY)(8)+(*DY)(5));
//    DZM(5)=0.25*((*DZ)(1)+(*DZ)(4)+(*DZ)(8)+(*DZ)(5));

//    DXM(6)=0.25*((*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8));
//    DYM(6)=0.25*((*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8));
//    DZM(6)=0.25*((*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8));

  
//    CA1=(DXM(1)-DXM(6))/sqrt(pow(DXM(1)-DXM(6),2)+pow(DYM(1)-DYM(6),2)+
//  			   pow(DZM(1)-DZM(6),2));
//    CB1=(DYM(1)-DYM(6))/sqrt(pow(DXM(1)-DXM(6),2)+pow(DYM(1)-DYM(6),2)+
//  			   pow(DZM(1)-DZM(6),2));
//    CC1=(DZM(1)-DZM(6))/sqrt(pow(DXM(1)-DXM(6),2)+pow(DYM(1)-DYM(6),2)+
//  			   pow(DZM(1)-DZM(6),2));
//    CA2=(DXM(2)-DXM(4))/sqrt(pow(DXM(2)-DXM(4),2)+pow(DYM(2)-DYM(4),2)+
//  			   pow(DZM(2)-DZM(4),2));
//    CB2=(DYM(2)-DYM(4))/sqrt(pow(DXM(2)-DXM(4),2)+pow(DYM(2)-DYM(4),2)+
//  			   pow(DZM(2)-DZM(4),2));
//    CC2=(DZM(2)-DZM(4))/sqrt(pow(DXM(2)-DXM(4),2)+pow(DYM(2)-DYM(4),2)+
//  			   pow(DZM(2)-DZM(4),2));
//    CA3=(DXM(3)-DXM(5))/sqrt(pow(DXM(3)-DXM(5),2)+pow(DYM(3)-DYM(5),2)+
//  			   pow(DZM(3)-DZM(5),2));
//    CB3=(DYM(3)-DYM(5))/sqrt(pow(DXM(3)-DXM(5),2)+pow(DYM(3)-DYM(5),2)+
//  			   pow(DZM(3)-DZM(5),2));
//    CC3=(DZM(3)-DZM(5))/sqrt(pow(DXM(3)-DXM(5),2)+pow(DYM(3)-DYM(5),2)+
//  			   pow(DZM(3)-DZM(5),2));
//    CD1=pow(CA1,2)-pow(CA2,2);
//    CD2=pow(CB1,2)-pow(CB2,2);
//    CD3=pow(CC1,2)-pow(CC2,2);
//    CD4=2.0*CA1*CB1-2.0*CA2*CB2;
//    CD5=2.0*CA1*CC1-2.0*CA2*CC2;
//    CD6=2.0*CB1*CC1-2.0*CB2*CC2;
//    CE1=pow(CA2,2)-pow(CA3,2);
//    CE2=pow(CB2,2)-pow(CB3,2);
//    CE3=pow(CC2,2)-pow(CC3,2);
//    CE4=2.0*CA2*CB2-2.0*CA3*CB3;
//    CE5=2.0*CA2*CC2-2.0*CA3*CC3;
//    CE6=2.0*CB2*CC2-2.0*CB3*CC3;

//    P1X(1)=Q3*((*DX)(1)+(*DX)(2)+(*DX)(3));
//    P1Y(1)=Q3*((*DY)(1)+(*DY)(2)+(*DY)(3));
//    P1Z(1)=Q3*((*DZ)(1)+(*DZ)(2)+(*DZ)(3));
//    P2X(1)=0.6*(*DX)(1)+0.2*(*DX)(2)+0.2*(*DX)(3);
//    P2Y(1)=0.6*(*DY)(1)+0.2*(*DY)(2)+0.2*(*DY)(3);
//    P2Z(1)=0.6*(*DZ)(1)+0.2*(*DZ)(2)+0.2*(*DZ)(3);
//    P3X(1)=0.2*(*DX)(1)+0.6*(*DX)(2)+0.2*(*DX)(3);
//    P3Y(1)=0.2*(*DY)(1)+0.6*(*DY)(2)+0.2*(*DY)(3);
//    P3Z(1)=0.2*(*DZ)(1)+0.6*(*DZ)(2)+0.2*(*DZ)(3);
//    P4X(1)=0.2*(*DX)(1)+0.2*(*DX)(2)+0.6*(*DX)(3);
//    P4Y(1)=0.2*(*DY)(1)+0.2*(*DY)(2)+0.6*(*DY)(3);
//    P4Z(1)=0.2*(*DZ)(1)+0.2*(*DZ)(2)+0.6*(*DZ)(3);
//    P5X(1)=Q3*((*DX)(1)+(*DX)(3)+(*DX)(4));
//    P5Y(1)=Q3*((*DY)(1)+(*DY)(3)+(*DY)(4));
//    P5Z(1)=Q3*((*DZ)(1)+(*DZ)(3)+(*DZ)(4));
//    P6X(1)=0.6*(*DX)(1)+0.2*(*DX)(3)+0.2*(*DX)(4);
//    P6Y(1)=0.6*(*DY)(1)+0.2*(*DY)(3)+0.2*(*DY)(4);
//    P6Z(1)=0.6*(*DZ)(1)+0.2*(*DZ)(3)+0.2*(*DZ)(4);
//    P7X(1)=0.2*(*DX)(1)+0.6*(*DX)(3)+0.2*(*DX)(4);
//    P7Y(1)=0.2*(*DY)(1)+0.6*(*DY)(3)+0.2*(*DY)(4);
//    P7Z(1)=0.2*(*DZ)(1)+0.6*(*DZ)(3)+0.2*(*DZ)(4);
//    P8X(1)=0.2*(*DX)(1)+0.2*(*DX)(3)+0.6*(*DX)(4);
//    P8Y(1)=0.2*(*DY)(1)+0.2*(*DY)(3)+0.6*(*DY)(4);
//    P8Z(1)=0.2*(*DZ)(1)+0.2*(*DZ)(3)+0.6*(*DZ)(4);
//    // ***  das sind die 8 Kubaturpunkte auf der ersten flaeche
//    PP1(1)=sqrt(pow((*DX)(1)-(*DX)(2),2)+pow((*DY)(1)-(*DY)(2),2)+
//  	      pow((*DZ)(1)-(*DZ)(2),2));
//    PP2(1)=sqrt(pow((*DX)(2)-(*DX)(3),2)+pow((*DY)(2)-(*DY)(3),2)+
//  	      pow((*DZ)(2)-(*DZ)(3),2));
//    PP3(1)=sqrt(pow((*DX)(1)-(*DX)(3),2)+pow((*DY)(1)-(*DY)(3),2)+
//  	      pow((*DZ)(1)-(*DZ)(3),2));
//    PP4(1)=sqrt(pow((*DX)(3)-(*DX)(4),2)+pow((*DY)(3)-(*DY)(4),2)+
//  	      pow((*DZ)(3)-(*DZ)(4),2));
//    PP5(1)=sqrt(pow((*DX)(1)-(*DX)(4),2)+pow((*DY)(1)-(*DY)(4),2)+
//  	      pow((*DZ)(1)-(*DZ)(4),2));
//    PS1(1)=(PP1(1)+PP2(1)+PP3(1))/2.0;
//    PS2(1)=(PP3(1)+PP4(1)+PP5(1))/2.0;
//    PQ1(1)=sqrt(PS1(1)*(PS1(1)-PP1(1))*(PS1(1)-PP2(1))*(PS1(1)-PP3(1)));
//    PQ2(1)=sqrt(PS2(1)*(PS2(1)-PP3(1))*(PS2(1)-PP4(1))*(PS2(1)-PP5(1)));
//    PQ3(1)=PQ1(1)+PQ2(1);

//    P1X(2)=Q3*((*DX)(1)+(*DX)(2)+(*DX)(6));
//    P1Y(2)=Q3*((*DY)(1)+(*DY)(2)+(*DY)(6));
//    P1Z(2)=Q3*((*DZ)(1)+(*DZ)(2)+(*DZ)(6));
//    P2X(2)=0.6*(*DX)(1)+0.2*(*DX)(2)+0.2*(*DX)(6);
//    P2Y(2)=0.6*(*DY)(1)+0.2*(*DY)(2)+0.2*(*DY)(6);
//    P2Z(2)=0.6*(*DZ)(1)+0.2*(*DZ)(2)+0.2*(*DZ)(6);
//    P3X(2)=0.2*(*DX)(1)+0.6*(*DX)(2)+0.2*(*DX)(6);
//    P3Y(2)=0.2*(*DY)(1)+0.6*(*DY)(2)+0.2*(*DY)(6);
//    P3Z(2)=0.2*(*DZ)(1)+0.6*(*DZ)(2)+0.2*(*DZ)(6);
//    P4X(2)=0.2*(*DX)(1)+0.2*(*DX)(2)+0.6*(*DX)(6);
//    P4Y(2)=0.2*(*DY)(1)+0.2*(*DY)(2)+0.6*(*DY)(6);
//    P4Z(2)=0.2*(*DZ)(1)+0.2*(*DZ)(2)+0.6*(*DZ)(6);
//    P5X(2)=Q3*((*DX)(1)+(*DX)(6)+(*DX)(5));
//    P5Y(2)=Q3*((*DY)(1)+(*DY)(6)+(*DY)(5));
//    P5Z(2)=Q3*((*DZ)(1)+(*DZ)(6)+(*DZ)(5));
//    P6X(2)=0.6*(*DX)(1)+0.2*(*DX)(6)+0.2*(*DX)(5);
//    P6Y(2)=0.6*(*DY)(1)+0.2*(*DY)(6)+0.2*(*DY)(5);
//    P6Z(2)=0.6*(*DZ)(1)+0.2*(*DZ)(6)+0.2*(*DZ)(5);
//    P7X(2)=0.2*(*DX)(1)+0.6*(*DX)(6)+0.2*(*DX)(5);
//    P7Y(2)=0.2*(*DY)(1)+0.6*(*DY)(6)+0.2*(*DY)(5);
//    P7Z(2)=0.2*(*DZ)(1)+0.6*(*DZ)(6)+0.2*(*DZ)(5);
//    P8X(2)=0.2*(*DX)(1)+0.2*(*DX)(6)+0.6*(*DX)(5);
//    P8Y(2)=0.2*(*DY)(1)+0.2*(*DY)(6)+0.6*(*DY)(5);
//    P8Z(2)=0.2*(*DZ)(1)+0.2*(*DZ)(6)+0.6*(*DZ)(5);
//    // ***  das sind die 8 Kubaturpunkte auf der zweiten flaeche
//    PP1(2)=sqrt(pow((*DX)(1)-(*DX)(2),2)+pow((*DY)(1)-(*DY)(2),2)+
//  	      pow((*DZ)(1)-(*DZ)(2),2));
//    PP2(2)=sqrt(pow((*DX)(2)-(*DX)(6),2)+pow((*DY)(2)-(*DY)(6),2)+
//  	      pow((*DZ)(2)-(*DZ)(6),2));
//    PP3(2)=sqrt(pow((*DX)(1)-(*DX)(6),2)+pow((*DY)(1)-(*DY)(6),2)+
//  	      pow((*DZ)(1)-(*DZ)(6),2));
//    PP4(2)=sqrt(pow((*DX)(5)-(*DX)(6),2)+pow((*DY)(5)-(*DY)(6),2)+
//  	      pow((*DZ)(5)-(*DZ)(6),2));
//    PP5(2)=sqrt(pow((*DX)(1)-(*DX)(5),2)+pow((*DY)(1)-(*DY)(5),2)+
//  	      pow((*DZ)(1)-(*DZ)(5),2));
//    PS1(2)=(PP1(2)+PP2(2)+PP3(2))/2.0;
//    PS2(2)=(PP3(2)+PP4(2)+PP5(2))/2.0;
//    PQ1(2)=sqrt(PS1(2)*(PS1(2)-PP1(2))*(PS1(2)-PP2(2))*(PS1(2)-PP3(2)));
//    PQ2(2)=sqrt(PS2(2)*(PS2(2)-PP3(2))*(PS2(2)-PP4(2))*(PS2(2)-PP5(2)));
//    PQ3(2)=PQ1(2)+PQ2(2);

//    P1X(3)=Q3*((*DX)(2)+(*DX)(3)+(*DX)(7));
//    P1Y(3)=Q3*((*DY)(2)+(*DY)(3)+(*DY)(7));
//    P1Z(3)=Q3*((*DZ)(2)+(*DZ)(3)+(*DZ)(7));
//    P2X(3)=0.6*(*DX)(2)+0.2*(*DX)(3)+0.2*(*DX)(7);
//    P2Y(3)=0.6*(*DY)(2)+0.2*(*DY)(3)+0.2*(*DY)(7);
//    P2Z(3)=0.6*(*DZ)(2)+0.2*(*DZ)(3)+0.2*(*DZ)(7);
//    P3X(3)=0.2*(*DX)(2)+0.6*(*DX)(3)+0.2*(*DX)(7);
//    P3Y(3)=0.2*(*DY)(2)+0.6*(*DY)(3)+0.2*(*DY)(7);
//    P3Z(3)=0.2*(*DZ)(2)+0.6*(*DZ)(3)+0.2*(*DZ)(7);
//    P4X(3)=0.2*(*DX)(2)+0.2*(*DX)(3)+0.6*(*DX)(7);
//    P4Y(3)=0.2*(*DY)(2)+0.2*(*DY)(3)+0.6*(*DY)(7);
//    P4Z(3)=0.2*(*DZ)(2)+0.2*(*DZ)(3)+0.6*(*DZ)(7);
//    P5X(3)=Q3*((*DX)(2)+(*DX)(7)+(*DX)(6));
//    P5Y(3)=Q3*((*DY)(2)+(*DY)(7)+(*DY)(6));
//    P5Z(3)=Q3*((*DZ)(2)+(*DZ)(7)+(*DZ)(6));
//    P6X(3)=0.6*(*DX)(2)+0.2*(*DX)(7)+0.2*(*DX)(6);
//    P6Y(3)=0.6*(*DY)(2)+0.2*(*DY)(7)+0.2*(*DY)(6);
//    P6Z(3)=0.6*(*DZ)(2)+0.2*(*DZ)(7)+0.2*(*DZ)(6);
//    P7X(3)=0.2*(*DX)(2)+0.6*(*DX)(7)+0.2*(*DX)(6);
//    P7Y(3)=0.2*(*DY)(2)+0.6*(*DY)(7)+0.2*(*DY)(6);
//    P7Z(3)=0.2*(*DZ)(2)+0.6*(*DZ)(7)+0.2*(*DZ)(6);
//    P8X(3)=0.2*(*DX)(2)+0.2*(*DX)(7)+0.6*(*DX)(6);
//    P8Y(3)=0.2*(*DY)(2)+0.2*(*DY)(7)+0.6*(*DY)(6);
//    P8Z(3)=0.2*(*DZ)(2)+0.2*(*DZ)(7)+0.6*(*DZ)(6);
//    // ***  das sind die 8 Kubaturpunkte auf der dritten flaeche
//    PP1(3)=sqrt(pow((*DX)(2)-(*DX)(3),2)+pow((*DY)(2)-(*DY)(3),2)+
//  	      pow((*DZ)(2)-(*DZ)(3),2));
//    PP2(3)=sqrt(pow((*DX)(3)-(*DX)(7),2)+pow((*DY)(3)-(*DY)(7),2)+
//  	      pow((*DZ)(3)-(*DZ)(7),2));
//    PP3(3)=sqrt(pow((*DX)(2)-(*DX)(7),2)+pow((*DY)(2)-(*DY)(7),2)+
//  	      pow((*DZ)(2)-(*DZ)(7),2));
//    PP4(3)=sqrt(pow((*DX)(7)-(*DX)(6),2)+pow((*DY)(7)-(*DY)(6),2)+
//  	      pow((*DZ)(7)-(*DZ)(6),2));
//    PP5(3)=sqrt(pow((*DX)(2)-(*DX)(6),2)+pow((*DY)(2)-(*DY)(6),2)+
//  	      pow((*DZ)(2)-(*DZ)(6),2));
//    PS1(3)=(PP1(3)+PP2(3)+PP3(3))/2.0;
//    PS2(3)=(PP3(3)+PP4(3)+PP5(3))/2.0;
//    PQ1(3)=sqrt(PS1(3)*(PS1(3)-PP1(3))*(PS1(3)-PP2(3))*(PS1(3)-PP3(3)));
//    PQ2(3)=sqrt(PS2(3)*(PS2(3)-PP3(3))*(PS2(3)-PP4(3))*(PS2(3)-PP5(3)));
//    PQ3(3)=PQ1(3)+PQ2(3);

//    P1X(4)=Q3*((*DX)(3)+(*DX)(4)+(*DX)(8));
//    P1Y(4)=Q3*((*DY)(3)+(*DY)(4)+(*DY)(8));
//    P1Z(4)=Q3*((*DZ)(3)+(*DZ)(4)+(*DZ)(8));
//    P2X(4)=0.6*(*DX)(3)+0.2*(*DX)(4)+0.2*(*DX)(8);
//    P2Y(4)=0.6*(*DY)(3)+0.2*(*DY)(4)+0.2*(*DY)(8);
//    P2Z(4)=0.6*(*DZ)(3)+0.2*(*DZ)(4)+0.2*(*DZ)(8);
//    P3X(4)=0.2*(*DX)(3)+0.6*(*DX)(4)+0.2*(*DX)(8);
//    P3Y(4)=0.2*(*DY)(3)+0.6*(*DY)(4)+0.2*(*DY)(8);
//    P3Z(4)=0.2*(*DZ)(3)+0.6*(*DZ)(4)+0.2*(*DZ)(8);
//    P4X(4)=0.2*(*DX)(3)+0.2*(*DX)(4)+0.6*(*DX)(8);
//    P4Y(4)=0.2*(*DY)(3)+0.2*(*DY)(4)+0.6*(*DY)(8);
//    P4Z(4)=0.2*(*DZ)(3)+0.2*(*DZ)(4)+0.6*(*DZ)(8);
//    P5X(4)=Q3*((*DX)(3)+(*DX)(8)+(*DX)(7));
//    P5Y(4)=Q3*((*DY)(3)+(*DY)(8)+(*DY)(7));
//    P5Z(4)=Q3*((*DZ)(3)+(*DZ)(8)+(*DZ)(7));
//    P6X(4)=0.6*(*DX)(3)+0.2*(*DX)(8)+0.2*(*DX)(7);
//    P6Y(4)=0.6*(*DY)(3)+0.2*(*DY)(8)+0.2*(*DY)(7);
//    P6Z(4)=0.6*(*DZ)(3)+0.2*(*DZ)(8)+0.2*(*DZ)(7);
//    P7X(4)=0.2*(*DX)(3)+0.6*(*DX)(8)+0.2*(*DX)(7);
//    P7Y(4)=0.2*(*DY)(3)+0.6*(*DY)(8)+0.2*(*DY)(7);
//    P7Z(4)=0.2*(*DZ)(3)+0.6*(*DZ)(8)+0.2*(*DZ)(7);
//    P8X(4)=0.2*(*DX)(3)+0.2*(*DX)(8)+0.6*(*DX)(7);
//    P8Y(4)=0.2*(*DY)(3)+0.2*(*DY)(8)+0.6*(*DY)(7);
//    P8Z(4)=0.2*(*DZ)(3)+0.2*(*DZ)(8)+0.6*(*DZ)(7);
//    // ***  das sind die 8 Kubaturpunkte auf der vierten flaeche
//    PP1(4)=sqrt(pow((*DX)(3)-(*DX)(4),2)+pow((*DY)(3)-(*DY)(4),2)+
//  	      pow((*DZ)(3)-(*DZ)(4),2));
//    PP2(4)=sqrt(pow((*DX)(4)-(*DX)(8),2)+pow((*DY)(4)-(*DY)(8),2)+
//  	      pow((*DZ)(4)-(*DZ)(8),2));
//    PP3(4)=sqrt(pow((*DX)(3)-(*DX)(8),2)+pow((*DY)(3)-(*DY)(8),2)+
//  	      pow((*DZ)(3)-(*DZ)(8),2));
//    PP4(4)=sqrt(pow((*DX)(7)-(*DX)(8),2)+pow((*DY)(7)-(*DY)(8),2)+
//  	      pow((*DZ)(7)-(*DZ)(8),2));
//    PP5(4)=sqrt(pow((*DX)(3)-(*DX)(7),2)+pow((*DY)(3)-(*DY)(7),2)+
//  	      pow((*DZ)(3)-(*DZ)(7),2));
//    PS1(4)=(PP1(4)+PP2(4)+PP3(4))/2.0;
//    PS2(4)=(PP3(4)+PP4(4)+PP5(4))/2.0;
//    PQ1(4)=sqrt(PS1(4)*(PS1(4)-PP1(4))*(PS1(4)-PP2(4))*(PS1(4)-PP3(4)));
//    PQ2(4)=sqrt(PS2(4)*(PS2(4)-PP3(4))*(PS2(4)-PP4(4))*(PS2(4)-PP5(4)));
//    PQ3(4)=PQ1(4)+PQ2(4);

//    P1X(5)=Q3*((*DX)(1)+(*DX)(4)+(*DX)(8));
//    P1Y(5)=Q3*((*DY)(1)+(*DY)(4)+(*DY)(8));
//    P1Z(5)=Q3*((*DZ)(1)+(*DZ)(4)+(*DZ)(8));
//    P2X(5)=0.6*(*DX)(1)+0.2*(*DX)(4)+0.2*(*DX)(8);
//    P2Y(5)=0.6*(*DY)(1)+0.2*(*DY)(4)+0.2*(*DY)(8);
//    P2Z(5)=0.6*(*DZ)(1)+0.2*(*DZ)(4)+0.2*(*DZ)(8);
//    P3X(5)=0.2*(*DX)(1)+0.6*(*DX)(4)+0.2*(*DX)(8);
//    P3Y(5)=0.2*(*DY)(1)+0.6*(*DY)(4)+0.2*(*DY)(8);
//    P3Z(5)=0.2*(*DZ)(1)+0.6*(*DZ)(4)+0.2*(*DZ)(8);
//    P4X(5)=0.2*(*DX)(1)+0.2*(*DX)(4)+0.6*(*DX)(8);
//    P4Y(5)=0.2*(*DY)(1)+0.2*(*DY)(4)+0.6*(*DY)(8);
//    P4Z(5)=0.2*(*DZ)(1)+0.2*(*DZ)(4)+0.6*(*DZ)(8);
//    P5X(5)=Q3*((*DX)(1)+(*DX)(5)+(*DX)(8));
//    P5Y(5)=Q3*((*DY)(1)+(*DY)(5)+(*DY)(8));
//    P5Z(5)=Q3*((*DZ)(1)+(*DZ)(5)+(*DZ)(8));
//    P6X(5)=0.6*(*DX)(1)+0.2*(*DX)(5)+0.2*(*DX)(8);
//    P6Y(5)=0.6*(*DY)(1)+0.2*(*DY)(5)+0.2*(*DY)(8);
//    P6Z(5)=0.6*(*DZ)(1)+0.2*(*DZ)(5)+0.2*(*DZ)(8);
//    P7X(5)=0.2*(*DX)(1)+0.6*(*DX)(5)+0.2*(*DX)(8);
//    P7Y(5)=0.2*(*DY)(1)+0.6*(*DY)(5)+0.2*(*DY)(8);
//    P7Z(5)=0.2*(*DZ)(1)+0.6*(*DZ)(5)+0.2*(*DZ)(8);
//    P8X(5)=0.2*(*DX)(1)+0.2*(*DX)(5)+0.6*(*DX)(8);
//    P8Y(5)=0.2*(*DY)(1)+0.2*(*DY)(5)+0.6*(*DY)(8);
//    P8Z(5)=0.2*(*DZ)(1)+0.2*(*DZ)(5)+0.6*(*DZ)(8);
//    // ***  das sind die 8 Kubaturpunkte auf der fuenften flaeche
//    PP1(5)=sqrt(pow((*DX)(1)-(*DX)(4),2)+pow((*DY)(1)-(*DY)(4),2)+
//  	      pow((*DZ)(1)-(*DZ)(4),2));
//    PP2(5)=sqrt(pow((*DX)(4)-(*DX)(8),2)+pow((*DY)(4)-(*DY)(8),2)+
//  	      pow((*DZ)(4)-(*DZ)(8),2));
//    PP3(5)=sqrt(pow((*DX)(1)-(*DX)(8),2)+pow((*DY)(1)-(*DY)(8),2)+
//  	      pow((*DZ)(1)-(*DZ)(8),2));
//    PP4(5)=sqrt(pow((*DX)(1)-(*DX)(5),2)+pow((*DY)(1)-(*DY)(5),2)+
//  	      pow((*DZ)(1)-(*DZ)(5),2));
//    PP5(5)=sqrt(pow((*DX)(5)-(*DX)(8),2)+pow((*DY)(5)-(*DY)(8),2)+
//  	      pow((*DZ)(5)-(*DZ)(8),2));
//    PS1(5)=(PP1(5)+PP2(5)+PP3(5))/2.0;
//    PS2(5)=(PP3(5)+PP4(5)+PP5(5))/2.0;
//    PQ1(5)=sqrt(PS1(5)*(PS1(5)-PP1(5))*(PS1(5)-PP2(5))*(PS1(5)-PP3(5)));
//    PQ2(5)=sqrt(PS2(5)*(PS2(5)-PP3(5))*(PS2(5)-PP4(5))*(PS2(5)-PP5(5)));
//    PQ3(5)=PQ1(5)+PQ2(5);

//    P1X(6)=Q3*((*DX)(5)+(*DX)(6)+(*DX)(7));
//    P1Y(6)=Q3*((*DY)(5)+(*DY)(6)+(*DY)(7));
//    P1Z(6)=Q3*((*DZ)(5)+(*DZ)(6)+(*DZ)(7));
//    P2X(6)=0.6*(*DX)(5)+0.2*(*DX)(6)+0.2*(*DX)(7);
//    P2Y(6)=0.6*(*DY)(5)+0.2*(*DY)(6)+0.2*(*DY)(7);
//    P2Z(6)=0.6*(*DZ)(5)+0.2*(*DZ)(6)+0.2*(*DZ)(7);
//    P3X(6)=0.2*(*DX)(5)+0.6*(*DX)(6)+0.2*(*DX)(7);
//    P3Y(6)=0.2*(*DY)(5)+0.6*(*DY)(6)+0.2*(*DY)(7);
//    P3Z(6)=0.2*(*DZ)(5)+0.6*(*DZ)(6)+0.2*(*DZ)(7);
//    P4X(6)=0.2*(*DX)(5)+0.2*(*DX)(6)+0.6*(*DX)(7);
//    P4Y(6)=0.2*(*DY)(5)+0.2*(*DY)(6)+0.6*(*DY)(7);
//    P4Z(6)=0.2*(*DZ)(5)+0.2*(*DZ)(6)+0.6*(*DZ)(7);
//    P5X(6)=Q3*((*DX)(5)+(*DX)(7)+(*DX)(8));
//    P5Y(6)=Q3*((*DY)(5)+(*DY)(7)+(*DY)(8));
//    P5Z(6)=Q3*((*DZ)(5)+(*DZ)(7)+(*DZ)(8));
//    P6X(6)=0.6*(*DX)(5)+0.2*(*DX)(7)+0.2*(*DX)(8);
//    P6Y(6)=0.6*(*DY)(5)+0.2*(*DY)(7)+0.2*(*DY)(8);
//    P6Z(6)=0.6*(*DZ)(5)+0.2*(*DZ)(7)+0.2*(*DZ)(8);
//    P7X(6)=0.2*(*DX)(5)+0.6*(*DX)(7)+0.2*(*DX)(8);
//    P7Y(6)=0.2*(*DY)(5)+0.6*(*DY)(7)+0.2*(*DY)(8);
//    P7Z(6)=0.2*(*DZ)(5)+0.6*(*DZ)(7)+0.2*(*DZ)(8);
//    P8X(6)=0.2*(*DX)(5)+0.2*(*DX)(7)+0.6*(*DX)(8);
//    P8Y(6)=0.2*(*DY)(5)+0.2*(*DY)(7)+0.6*(*DY)(8);
//    P8Z(6)=0.2*(*DZ)(5)+0.2*(*DZ)(7)+0.6*(*DZ)(8);
//    // ***  das sind die 8 Kubaturpunkte auf der sechsten flaeche
//    PP1(6)=sqrt(pow((*DX)(5)-(*DX)(6),2)+pow((*DY)(5)-(*DY)(6),2)+
//  	      pow((*DZ)(5)-(*DZ)(6),2));
//    PP2(6)=sqrt(pow((*DX)(6)-(*DX)(7),2)+pow((*DY)(6)-(*DY)(7),2)+
//  	      pow((*DZ)(6)-(*DZ)(7),2));
//    PP3(6)=sqrt(pow((*DX)(5)-(*DX)(7),2)+pow((*DY)(5)-(*DY)(7),2)+
//  	      pow((*DZ)(5)-(*DZ)(7),2));
//    PP4(6)=sqrt(pow((*DX)(7)-(*DX)(8),2)+pow((*DY)(7)-(*DY)(8),2)+
//  	      pow((*DZ)(7)-(*DZ)(8),2));
//    PP5(6)=sqrt(pow((*DX)(5)-(*DX)(8),2)+pow((*DY)(5)-(*DY)(8),2)+
//  	      pow((*DZ)(5)-(*DZ)(8),2));
//    PS1(6)=(PP1(6)+PP2(6)+PP3(6))/2.0;
//    PS2(6)=(PP3(6)+PP4(6)+PP5(6))/2.0;
//    PQ1(6)=sqrt(PS1(6)*(PS1(6)-PP1(6))*(PS1(6)-PP2(6))*(PS1(6)-PP3(6)));
//    PQ2(6)=sqrt(PS2(6)*(PS2(6)-PP3(6))*(PS2(6)-PP4(6))*(PS2(6)-PP5(6)));
//    PQ3(6)=PQ1(6)+PQ2(6);

//    // ************************************************************************

//    for(IA=1;IA<=6;IA++) {
//      A(IA,1)=(PQ1(IA)/PQ3(IA))*(Q7*F1(P1X(IA),P1Y(IA),P1Z(IA),
//  				     CA1,CB1,CC1,CA2,CB2,CC2,
//  				     CA3,CB3,CC3,CD1,CD2,CD3,
//  				     CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6)+
//  			       Q9*F1(P2X(IA),P2Y(IA),P2Z(IA),
//  				     CA1,CB1,CC1,CA2,CB2,CC2,       
//  				     CA3,CB3,CC3,CD1,CD2,CD3,
//  				     CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6)+
//  			       Q9*F1(P3X(IA),P3Y(IA),P3Z(IA),
//  				     CA1,CB1,CC1,CA2,CB2,CC2,       
//  				     CA3,CB3,CC3,CD1,CD2,CD3,
//  				     CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6)+
//  			       Q9*F1(P4X(IA),P4Y(IA),P4Z(IA),
//  				     CA1,CB1,CC1,CA2,CB2,CC2,       
//  				     CA3,CB3,CC3,CD1,CD2,CD3,
//  				     CD4,CD5,CD6,CE1,CE2,CE3,CE4,CE5,CE6))+
//        (PQ2(IA)/PQ3(IA))*(Q7*F1(P5X(IA),P5Y(IA),P5Z(IA),
//  			       CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,
//  			       CE3,CE4,CE5,CE6)+
//  			 Q9*F1(P6X(IA),P6Y(IA),P6Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,
//  			       CE4,CE5,CE6)+
//  			 Q9*F1(P7X(IA),P7Y(IA),P7Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,
//  			       CE4,CE5,CE6)+
//  			 Q9*F1(P8X(IA),P8Y(IA),P8Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,
//  			       CE4,CE5,CE6));

//      A(IA,2)=(PQ1(IA)/PQ3(IA))*(Q7*F2(P1X(IA),P1Y(IA),P1Z(IA),
//  				     CA1,CB1,CC1,CA2,CB2,CC2,
//  				     CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  				     CE2,CE3,CE4,CE5,CE6)+
//  			       Q9*F2(P2X(IA),P2Y(IA),P2Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				     CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  				     CE2,CE3,CE4,CE5,CE6)+
//  			       Q9*F2(P3X(IA),P3Y(IA),P3Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				     CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  				     CE2,CE3,CE4,CE5,CE6)+
//  			       Q9*F2(P4X(IA),P4Y(IA),P4Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				     CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,CE2,CE3,
//  				     CE4,CE5,CE6))+
//        (PQ2(IA)/PQ3(IA))*(Q7*F2(P5X(IA),P5Y(IA),P5Z(IA),
//  			       CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  			       CE2,CE3,CE4,CE5,CE6)+
//  			 Q9*F2(P6X(IA),P6Y(IA),P6Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  			       CE2,CE3,CE4,CE5,CE6)+
//  			 Q9*F2(P7X(IA),P7Y(IA),P7Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  			       CE2,CE3,CE4,CE5,CE6)+
//  			 Q9*F2(P8X(IA),P8Y(IA),P8Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  			       CE2,CE3,CE4,CE5,CE6));
      
//        A(IA,3)=(PQ1(IA)/PQ3(IA))*(Q7*F3(P1X(IA),P1Y(IA),P1Z(IA),
//  				       CA1,CB1,CC1,CA2,CB2,CC2,
//  				       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  				       CE2,CE3,CE4,CE5,CE6)+
//  				 Q9*F3(P2X(IA),P2Y(IA),P2Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  				       CE2,CE3,CE4,CE5,CE6)+
//  				 Q9*F3(P3X(IA),P3Y(IA),P3Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  				       CE2,CE3,CE4,CE5,CE6)+
//  				 Q9*F3(P4X(IA),P4Y(IA),P4Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  				       CE2,CE3,CE4,CE5,CE6))+
//        (PQ2(IA)/PQ3(IA))*(Q7*F3(P5X(IA),P5Y(IA),P5Z(IA),
//  			       CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  			       CE2,CE3,CE4,CE5,CE6)+
//  			 Q9*F3(P6X(IA),P6Y(IA),P6Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  			       CE2,CE3,CE4,CE5,CE6)+
//  			 Q9*F3(P7X(IA),P7Y(IA),P7Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  			       CE2,CE3,CE4,CE5,CE6)+
//  			 Q9*F3(P8X(IA),P8Y(IA),P8Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,CE1,
//  			       CE2,CE3,CE4,CE5,CE6));
    
//      A(IA,4)=(PQ1(IA)/PQ3(IA))*(Q7*F4(P1X(IA),P1Y(IA),P1Z(IA),
//  				     CA1,CB1,CC1,CA2,CB2,CC2,
//  				     CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				     CE1,CE2,CE3,CE4,CE5,CE6)+
//  			       Q9*F4(P2X(IA),P2Y(IA),P2Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				     CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				     CE1,CE2,CE3,CE4,CE5,CE6)+
//  			       Q9*F4(P3X(IA),P3Y(IA),P3Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				     CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				     CE1,CE2,CE3,CE4,CE5,CE6)+
//  			       Q9*F4(P4X(IA),P4Y(IA),P4Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				     CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				     CE1,CE2,CE3,CE4,CE5,CE6))+
//        (PQ2(IA)/PQ3(IA))*(Q7*F4(P5X(IA),P5Y(IA),P5Z(IA),
//  			       CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  			       CE1,CE2,CE3,CE4,CE5,CE6)+
//  			 Q9*F4(P6X(IA),P6Y(IA),P6Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  			       CE1,CE2,CE3,CE4,CE5,CE6)+
//  			 Q9*F4(P7X(IA),P7Y(IA),P7Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  			       CE1,CE2,CE3,CE4,CE5,CE6)+
//  			 Q9*F4(P8X(IA),P8Y(IA),P8Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  			       CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  			       CE1,CE2,CE3,CE4,CE5,CE6));

//         A(IA,5)=(PQ1(IA)/PQ3(IA))*(Q7*F5(P1X(IA),P1Y(IA),P1Z(IA),
//  					CA1,CB1,CC1,CA2,CB2,CC2,
//  					CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  					CE1,CE2,CE3,CE4,CE5,CE6)+
//  				  Q9*F5(P2X(IA),P2Y(IA),P2Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  					CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  					CE1,CE2,CE3,CE4,CE5,CE6)+
//  				  Q9*F5(P3X(IA),P3Y(IA),P3Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  					CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  					CE1,CE2,CE3,CE4,CE5,CE6)+
//  				  Q9*F5(P4X(IA),P4Y(IA),P4Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  					CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  					CE1,CE2,CE3,CE4,CE5,CE6))+
//  	 (PQ2(IA)/PQ3(IA))*(Q7*F5(P5X(IA),P5Y(IA),P5Z(IA),
//  				  CA1,CB1,CC1,CA2,CB2,CC2,       
//  				  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				  CE1,CE2,CE3,CE4,CE5,CE6)+
//  			    Q9*F5(P6X(IA),P6Y(IA),P6Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				  CE1,CE2,CE3,CE4,CE5,CE6)+
//  			    Q9*F5(P7X(IA),P7Y(IA),P7Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				  CE1,CE2,CE3,CE4,CE5,CE6)+
//  			    Q9*F5(P8X(IA),P8Y(IA),P8Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				  CE1,CE2,CE3,CE4,CE5,CE6));

//         A(IA,6)=(PQ1(IA)/PQ3(IA))*(Q7*F6(P1X(IA),P1Y(IA),P1Z(IA),
//  					CA1,CB1,CC1,CA2,CB2,CC2,
//  					CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  					CE1,CE2,CE3,CE4,CE5,CE6)+
//  				  Q9*F6(P2X(IA),P2Y(IA),P2Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  					CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  					CE1,CE2,CE3,CE4,CE5,CE6)+
//  				  Q9*F6(P3X(IA),P3Y(IA),P3Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  					CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  					CE1,CE2,CE3,CE4,CE5,CE6)+
//  				  Q9*F6(P4X(IA),P4Y(IA),P4Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  					CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  					CE1,CE2,CE3,CE4,CE5,CE6))+
//  	 (PQ2(IA)/PQ3(IA))*(Q7*F6(P5X(IA),P5Y(IA),P5Z(IA),
//  				  CA1,CB1,CC1,CA2,CB2,CC2,       
//  				  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				  CE1,CE2,CE3,CE4,CE5,CE6)+
//  			    Q9*F6(P6X(IA),P6Y(IA),P6Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				  CE1,CE2,CE3,CE4,CE5,CE6)+
//  			    Q9*F6(P7X(IA),P7Y(IA),P7Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				  CE1,CE2,CE3,CE4,CE5,CE6)+
//  			    Q9*F6(P8X(IA),P8Y(IA),P8Z(IA),CA1,CB1,CC1,CA2,CB2,CC2,       
//  				  CA3,CB3,CC3,CD1,CD2,CD3,CD4,CD5,CD6,
//  				  CE1,CE2,CE3,CE4,CE5,CE6));

//    }

//    Invert(A,F,CKH,0);       

//    for(IK1=1;IK1<=6;IK1++)
//      for(IK2=1;IK2<=6;IK2++)
//        CK(IK1,IK2)=A(IK2,IK1);
  
//    for(IK=1;IK<=6;IK++) {
//      (*COB)(IK,1)=CK(IK,6)*CE1+CK(IK,5)*CD1;
//      (*COB)(IK,2)=CK(IK,6)*CE2+CK(IK,5)*CD2;
//      (*COB)(IK,3)=CK(IK,6)*CE3+CK(IK,5)*CD3;
//      (*COB)(IK,4)=CK(IK,6)*CE4+CK(IK,5)*CD4;
//      (*COB)(IK,5)=CK(IK,6)*CE5+CK(IK,5)*CD5;
//      (*COB)(IK,6)=CK(IK,6)*CE6+CK(IK,5)*CD6;
//      (*COB)(IK,7)=CK(IK,4)*CA3+CK(IK,3)*CA2+CK(IK,2)*CA1;
//      (*COB)(IK,8)=CK(IK,4)*CB3+CK(IK,3)*CB2+CK(IK,2)*CB1;
//      (*COB)(IK,9)=CK(IK,4)*CC3+CK(IK,3)*CC2+CK(IK,2)*CC1;
//      (*COB)(IK,10)=CK(IK,1);
//    }
}

void ParNonParamElement_3D::GetValue(DOUBLE X1,DOUBLE X2,DOUBLE X3)
{
  if(DETJ>0 && DETJ<1e-70) {
	protocol << progname << " (process " << MyProcID << "):\n"
	       << "  Program aborted in ParNonParamElement_3D::GetValue.\n"
	       << "  Element has vanishing area DETJ="<<DETJ<<" !!!\n";
        MPI_Abort(MPI_COMM_WORLD, DETERMINANT_ZERO);
  }
  if((*BDER)(5) || (*BDER)(6) || (*BDER)(7) || (*BDER)(8)) {
	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Program aborted in ParNonParamElement_3D::GetValue.\n"
		 << "  Desired derivates not available !!!\n";
        MPI_Abort(MPI_COMM_WORLD, DERIVATES_NOT_AVAILABLE);
  }
  
  if((*BDER)(1)) {

    // *** Function values
    (*DBAS)(1,1,1)= (*COB)(1,1)*pow(X1,2)+(*COB)(1,2)*pow(X2,2)+(*COB)(1,3)*pow(X3,2)
      +(*COB)(1,4)*X1*X2+(*COB)(1,5)*X1*X3+(*COB)(1,6)*X2*X3
      +(*COB)(1,7)*X1+(*COB)(1,8)*X2+(*COB)(1,9)*X3+(*COB)(1,10);
    (*DBAS)(1,2,1)= (*COB)(2,1)*pow(X1,2)+(*COB)(2,2)*pow(X2,2)+(*COB)(2,3)*pow(X3,2)
      +(*COB)(2,4)*X1*X2+(*COB)(2,5)*X1*X3+(*COB)(2,6)*X2*X3
      +(*COB)(2,7)*X1+(*COB)(2,8)*X2+(*COB)(2,9)*X3+(*COB)(2,10);
    (*DBAS)(1,3,1)= (*COB)(3,1)*pow(X1,2)+(*COB)(3,2)*pow(X2,2)+(*COB)(3,3)*pow(X3,2)
      +(*COB)(3,4)*X1*X2+(*COB)(3,5)*X1*X3+(*COB)(3,6)*X2*X3
      +(*COB)(3,7)*X1+(*COB)(3,8)*X2+(*COB)(3,9)*X3+(*COB)(3,10);
    (*DBAS)(1,4,1)= (*COB)(4,1)*pow(X1,2)+(*COB)(4,2)*pow(X2,2)+(*COB)(4,3)*pow(X3,2)
      +(*COB)(4,4)*X1*X2+(*COB)(4,5)*X1*X3+(*COB)(4,6)*X2*X3
      +(*COB)(4,7)*X1+(*COB)(4,8)*X2+(*COB)(4,9)*X3+(*COB)(4,10);
    (*DBAS)(1,5,1)= (*COB)(5,1)*pow(X1,2)+(*COB)(5,2)*pow(X2,2)+(*COB)(5,3)*pow(X3,2)
      +(*COB)(5,4)*X1*X2+(*COB)(5,5)*X1*X3+(*COB)(5,6)*X2*X3
      +(*COB)(5,7)*X1+(*COB)(5,8)*X2+(*COB)(5,9)*X3+(*COB)(5,10);
    (*DBAS)(1,6,1)= (*COB)(6,1)*pow(X1,2)+(*COB)(6,2)*pow(X2,2)+(*COB)(6,3)*pow(X3,2)
      +(*COB)(6,4)*X1*X2+(*COB)(6,5)*X1*X3+(*COB)(6,6)*X2*X3
      +(*COB)(6,7)*X1+(*COB)(6,8)*X2+(*COB)(6,9)*X3+(*COB)(6,10);
  }
  
  if((*BDER)(2)) {
    (*DBAS)(1,1,2)= 2.0*(*COB)(1,1)*X1+(*COB)(1,4)*X2+(*COB)(1,5)*X3+(*COB)(1,7);
    (*DBAS)(1,2,2)= 2.0*(*COB)(2,1)*X1+(*COB)(2,4)*X2+(*COB)(2,5)*X3+(*COB)(2,7);
    (*DBAS)(1,3,2)= 2.0*(*COB)(3,1)*X1+(*COB)(3,4)*X2+(*COB)(3,5)*X3+(*COB)(3,7);
    (*DBAS)(1,4,2)= 2.0*(*COB)(4,1)*X1+(*COB)(4,4)*X2+(*COB)(4,5)*X3+(*COB)(4,7);
    (*DBAS)(1,5,2)= 2.0*(*COB)(5,1)*X1+(*COB)(5,4)*X2+(*COB)(5,5)*X3+(*COB)(5,7);
    (*DBAS)(1,6,2)= 2.0*(*COB)(6,1)*X1+(*COB)(6,4)*X2+(*COB)(6,5)*X3+(*COB)(6,7);
  }
  if((*BDER)(3)) {
    (*DBAS)(1,1,3)= 2.0*(*COB)(1,2)*X2+(*COB)(1,4)*X1+(*COB)(1,6)*X3+(*COB)(1,8);
    (*DBAS)(1,2,3)= 2.0*(*COB)(2,2)*X2+(*COB)(2,4)*X1+(*COB)(2,6)*X3+(*COB)(2,8);
    (*DBAS)(1,3,3)= 2.0*(*COB)(3,2)*X2+(*COB)(3,4)*X1+(*COB)(3,6)*X3+(*COB)(3,8);
    (*DBAS)(1,4,3)= 2.0*(*COB)(4,2)*X2+(*COB)(4,4)*X1+(*COB)(4,6)*X3+(*COB)(4,8);
    (*DBAS)(1,5,3)= 2.0*(*COB)(5,2)*X2+(*COB)(5,4)*X1+(*COB)(5,6)*X3+(*COB)(5,8);
    (*DBAS)(1,6,3)= 2.0*(*COB)(6,2)*X2+(*COB)(6,4)*X1+(*COB)(6,6)*X3+(*COB)(6,8);
  }

  if((*BDER)(4)) {
    (*DBAS)(1,1,4)= 2.0*(*COB)(1,3)*X3+(*COB)(1,5)*X1+(*COB)(1,6)*X2+(*COB)(1,9);
    (*DBAS)(1,2,4)= 2.0*(*COB)(2,3)*X3+(*COB)(2,5)*X1+(*COB)(2,6)*X2+(*COB)(2,9);
    (*DBAS)(1,3,4)= 2.0*(*COB)(3,3)*X3+(*COB)(3,5)*X1+(*COB)(3,6)*X2+(*COB)(3,9);
    (*DBAS)(1,4,4)= 2.0*(*COB)(4,3)*X3+(*COB)(4,5)*X1+(*COB)(4,6)*X2+(*COB)(4,9);
    (*DBAS)(1,5,4)= 2.0*(*COB)(5,3)*X3+(*COB)(5,5)*X1+(*COB)(5,6)*X2+(*COB)(5,9);
    (*DBAS)(1,6,4)= 2.0*(*COB)(6,3)*X3+(*COB)(6,5)*X1+(*COB)(6,6)*X2+(*COB)(6,9);
  }
}

VOID ParNonParamElement_3D::Restrict(DoubleVector *LD,DoubleVector *LB,
				 IntArray2D *VertElem2,IntArray2D *VertElem1,
				 IntArray2D *MidFaces2,IntArray2D *MidFaces1,
				 IntArray2D *NeighElem2,IntArray2D *NeighElem1,
				 UNSIGNED NumVertices2,UNSIGNED NumVertices1,
				 UNSIGNED NumElements2,UNSIGNED NumElements1)
{
//  VertElem2,NeighElem2 and NumElements2:  fine grid information
//  NumVertices1: coarse grid information

  int IELH1,IELH2,IELH3,IELH4,IELH5,IELH6,IELH7,IELH8,IEL1;
  int IA1,IA2,IA3,IA4,IA5,IA6;
	
  double DY1,DY2,DY3,DY4,DY5,DY6,DY7,DY8,DY9,DY10,DY11,DY12;
  double DY13,DY14,DY15,DY16,DY17,DY18,DY19,DY20,DY21,DY22,DY23,DY24;
  double DY25,DY26,DY27,DY28,DY29,DY30,DY31,DY32,DY33,DY34,DY35,DY36;
  double A1,A2,A3,A4,A5,A6,A7;

  A1= 11.0/24.0;
  A2= 7.0/48.0;
  A3=-5.0/48.0;
  A4=-1.0/24.0;
  A5= 11.0/24.0;
  A6= 1.0/12.0;
  A7=-1.0/24.0;

  *LB=0;
	
  for(IEL1=1;IEL1<=NumElements1;IEL1++)
  {
    IA1=(*MidFaces1)(1,IEL1);
    IA2=(*MidFaces1)(2,IEL1);
    IA3=(*MidFaces1)(3,IEL1);
    IA4=(*MidFaces1)(4,IEL1);
    IA5=(*MidFaces1)(5,IEL1);
    IA6=(*MidFaces1)(6,IEL1);
 
    IELH1=IEL1;
    IELH2=(*NeighElem2)(3,IELH1);
    IELH3=(*NeighElem2)(3,IELH2);
    IELH4=(*NeighElem2)(3,IELH3);
    IELH5=(*NeighElem2)(6,IELH1);
    IELH6=(*NeighElem2)(3,IELH5);
    IELH7=(*NeighElem2)(3,IELH6);
    IELH8=(*NeighElem2)(3,IELH7);
 
    DY1= (*LD)((*MidFaces2)(1,IELH1));
    DY2= (*LD)((*MidFaces2)(1,IELH2));
    DY3= (*LD)((*MidFaces2)(1,IELH3));
    DY4= (*LD)((*MidFaces2)(1,IELH4));
    DY5= (*LD)((*MidFaces2)(2,IELH1));
    DY6= (*LD)((*MidFaces2)(5,IELH2));
    DY7= (*LD)((*MidFaces2)(5,IELH6));
    DY8= (*LD)((*MidFaces2)(2,IELH5));
    DY9= (*LD)((*MidFaces2)(2,IELH2));
    DY10=(*LD)((*MidFaces2)(5,IELH3));
    DY11=(*LD)((*MidFaces2)(5,IELH7));
    DY12=(*LD)((*MidFaces2)(2,IELH6));
    DY13=(*LD)((*MidFaces2)(2,IELH3));
    DY14=(*LD)((*MidFaces2)(5,IELH4));
    DY15=(*LD)((*MidFaces2)(5,IELH8));
    DY16=(*LD)((*MidFaces2)(2,IELH7));
    DY17=(*LD)((*MidFaces2)(2,IELH4));
    DY18=(*LD)((*MidFaces2)(5,IELH1));
    DY19=(*LD)((*MidFaces2)(5,IELH5));
    DY20=(*LD)((*MidFaces2)(2,IELH8));
    DY21=(*LD)((*MidFaces2)(1,IELH5));
    DY22=(*LD)((*MidFaces2)(1,IELH6));
    DY23=(*LD)((*MidFaces2)(1,IELH7));
    DY24=(*LD)((*MidFaces2)(1,IELH8));
    DY25=(*LD)((*MidFaces2)(3,IELH1));
    DY26=(*LD)((*MidFaces2)(3,IELH2));
    DY27=(*LD)((*MidFaces2)(3,IELH3));
    DY28=(*LD)((*MidFaces2)(3,IELH4));
    DY29=(*LD)((*MidFaces2)(6,IELH1));
    DY30=(*LD)((*MidFaces2)(6,IELH2));
    DY31=(*LD)((*MidFaces2)(6,IELH3));
    DY32=(*LD)((*MidFaces2)(6,IELH4));
    DY33=(*LD)((*MidFaces2)(3,IELH5));
    DY34=(*LD)((*MidFaces2)(3,IELH6));
    DY35=(*LD)((*MidFaces2)(3,IELH7));
    DY36=(*LD)((*MidFaces2)(3,IELH8));
 
    if((*NeighElem1)(1,IEL1)!=0) {
      (*LB)(IA1)= (*LB)(IA1)
	+A1*(DY1+DY2+DY3+DY4)
	+A2*(DY5+DY6+DY9+DY10+DY13+DY14+DY17+DY18)
	+A3*(DY7+DY8+DY11+DY12+DY15+DY16+DY19+DY20)
	+A4*(DY21+DY22+DY23+DY24)
	+A5*(DY25+DY26+DY27+DY28)
	+A6*(DY29+DY30+DY31+DY32)
	+A7*(DY33+DY34+DY35+DY36);   
    }
 
 
    if((*NeighElem1)(2,IEL1)!=0) {
      (*LB)(IA2)= (*LB)(IA2)
	+A1*(DY5+DY6+DY7+DY8)
	+A2*(DY1+DY2+DY9+DY12+DY21+DY22+DY18+DY19)
	+A3*(DY3+DY4+DY10+DY11+DY23+DY24+DY17+DY20)
	+A4*(DY13+DY14+DY15+DY16)
	+A5*(DY25+DY29+DY30+DY33)
	+A6*(DY26+DY28+DY34+DY36)
	+A7*(DY27+DY31+DY32+DY35);    
    }
 
 
    if((*NeighElem1)(3,IEL1)!=0) {
      (*LB)(IA3)= (*LB)(IA3)
	+A1*(DY9+DY10+DY11+DY12)
	+A2*(DY2+DY3+DY6+DY7+DY22+DY23+DY13+DY16)
	+A3*(DY1+DY4+DY5+DY8+DY21+DY24+DY14+DY15)
	+A4*(DY17+DY18+DY19+DY20)
	+A5*(DY26+DY30+DY31+DY34)
	+A6*(DY25+DY27+DY33+DY35)
	+A7*(DY28+DY29+DY32+DY36);     
    }
 
 
    if((*NeighElem1)(4,IEL1)!=0) {
      (*LB)(IA4)= (*LB)(IA4)
	+A1*(DY13+DY14+DY15+DY16)
	+A2*(DY3+DY4+DY10+DY11+DY23+DY24+DY17+DY20)
	+A3*(DY1+DY2+DY9+DY12+DY21+DY22+DY18+DY19)
	+A4*(DY5+DY6+DY7+DY8)
	+A5*(DY27+DY31+DY32+DY35)  
	+A6*(DY26+DY28+DY34+DY36)
	+A7*(DY25+DY29+DY30+DY33);
    }
 
 
    if((*NeighElem1)(5,IEL1)!=0) {
      (*LB)(IA5)= (*LB)(IA5)
	+A1*(DY17+DY18+DY19+DY20)
	+A2*(DY1+DY4+DY5+DY8+DY21+DY24+DY14+DY15)
	+A3*(DY2+DY3+DY6+DY7+DY22+DY23+DY13+DY16)
	+A4*(DY9+DY10+DY11+DY12)
	+A5*(DY28+DY29+DY32+DY36)     
	+A6*(DY25+DY27+DY33+DY35)
	+A7*(DY26+DY30+DY31+DY34);
    }
 
 
    if((*NeighElem1)(6,IEL1)!=0) {
      (*LB)(IA6)= (*LB)(IA6)
	+A1*(DY21+DY22+DY23+DY24)
	+A2*(DY7+DY8+DY11+DY12+DY15+DY16+DY19+DY20)
	+A3*(DY5+DY6+DY9+DY10+DY13+DY14+DY17+DY18)
	+A4*(DY1+DY2+DY3+DY4)
	+A5*(DY33+DY34+DY35+DY36)     
	+A6*(DY29+DY30+DY31+DY32)
	+A7*(DY25+DY26+DY27+DY28);
    }
  }
}

VOID ParNonParamElement_3D::ParRestrict(DoubleVector *LD,DoubleVector *LB,
       			    IntArray2D *VertElem2,IntArray2D *VertElem1,
	       		    IntArray2D *MidFaces2,IntArray2D *MidFaces1,
		       	    IntArray2D *NeighElem2,IntArray2D *NeighElem1,
			    UNSIGNED NumVertices2,UNSIGNED NumVertices1,
	       		    UNSIGNED NumElements2,UNSIGNED NumElements1,
	       		    ParMultiGrid_3D *Com)
{
//  VertElem2,NeighElem2 and NumElements2:  fine grid information
//  NumVertices1: coarse grid information

  int IELH1,IELH2,IELH3,IELH4,IELH5,IELH6,IELH7,IELH8,IEL1;
  int IA1,IA2,IA3,IA4,IA5,IA6;
	
  double DY1,DY2,DY3,DY4,DY5,DY6,DY7,DY8,DY9,DY10,DY11,DY12;
  double DY13,DY14,DY15,DY16,DY17,DY18,DY19,DY20,DY21,DY22,DY23,DY24;
  double DY25,DY26,DY27,DY28,DY29,DY30,DY31,DY32,DY33,DY34,DY35,DY36;
  double A1,A2,A3,A4,A5,A6,A7;

#ifdef CLOCK_MEASURE
  double T1=0,T2=0;

  DateTime Clock;
  DateTime ClockHelp;
	
  Clock.SetTime();
#endif

  A1= 11.0/24.0;
  A2= 7.0/48.0;
  A3=-5.0/48.0;
  A4=-1.0/24.0;
  A5= 11.0/24.0;
  A6= 1.0/12.0;
  A7=-1.0/24.0;

  *LB=0;
	
  for(IEL1=1;IEL1<=NumElements1;IEL1++)
  {
    IA1=(*MidFaces1)(1,IEL1);
    IA2=(*MidFaces1)(2,IEL1);
    IA3=(*MidFaces1)(3,IEL1);
    IA4=(*MidFaces1)(4,IEL1);
    IA5=(*MidFaces1)(5,IEL1);
    IA6=(*MidFaces1)(6,IEL1);
 
    IELH1=IEL1;
    IELH2=(*NeighElem2)(3,IELH1);
    IELH3=(*NeighElem2)(3,IELH2);
    IELH4=(*NeighElem2)(3,IELH3);
    IELH5=(*NeighElem2)(6,IELH1);
    IELH6=(*NeighElem2)(3,IELH5);
    IELH7=(*NeighElem2)(3,IELH6);
    IELH8=(*NeighElem2)(3,IELH7);

 
    DY1= (*LD)((*MidFaces2)(1,IELH1));
    DY2= (*LD)((*MidFaces2)(1,IELH2));
    DY3= (*LD)((*MidFaces2)(1,IELH3));
    DY4= (*LD)((*MidFaces2)(1,IELH4));
    DY5= (*LD)((*MidFaces2)(2,IELH1));
    DY6= (*LD)((*MidFaces2)(5,IELH2));
    DY7= (*LD)((*MidFaces2)(5,IELH6));
    DY8= (*LD)((*MidFaces2)(2,IELH5));
    DY9= (*LD)((*MidFaces2)(2,IELH2));
    DY10=(*LD)((*MidFaces2)(5,IELH3));
    DY11=(*LD)((*MidFaces2)(5,IELH7));
    DY12=(*LD)((*MidFaces2)(2,IELH6));
    DY13=(*LD)((*MidFaces2)(2,IELH3));
    DY14=(*LD)((*MidFaces2)(5,IELH4));
    DY15=(*LD)((*MidFaces2)(5,IELH8));
    DY16=(*LD)((*MidFaces2)(2,IELH7));
    DY17=(*LD)((*MidFaces2)(2,IELH4));
    DY18=(*LD)((*MidFaces2)(5,IELH1));
    DY19=(*LD)((*MidFaces2)(5,IELH5));
    DY20=(*LD)((*MidFaces2)(2,IELH8));
    DY21=(*LD)((*MidFaces2)(1,IELH5));
    DY22=(*LD)((*MidFaces2)(1,IELH6));
    DY23=(*LD)((*MidFaces2)(1,IELH7));
    DY24=(*LD)((*MidFaces2)(1,IELH8));
    DY25=(*LD)((*MidFaces2)(3,IELH1));
    DY26=(*LD)((*MidFaces2)(3,IELH2));
    DY27=(*LD)((*MidFaces2)(3,IELH3));
    DY28=(*LD)((*MidFaces2)(3,IELH4));
    DY29=(*LD)((*MidFaces2)(6,IELH1));
    DY30=(*LD)((*MidFaces2)(6,IELH2));
    DY31=(*LD)((*MidFaces2)(6,IELH3));
    DY32=(*LD)((*MidFaces2)(6,IELH4));
    DY33=(*LD)((*MidFaces2)(3,IELH5));
    DY34=(*LD)((*MidFaces2)(3,IELH6));
    DY35=(*LD)((*MidFaces2)(3,IELH7));
    DY36=(*LD)((*MidFaces2)(3,IELH8));

    if((*NeighElem1)(1,IEL1)!=0 || Com->GetNodeType(IA1)==ART_BOUND) {
      (*LB)(IA1)= (*LB)(IA1)
	+A1*(DY1+DY2+DY3+DY4)
	+A2*(DY5+DY6+DY9+DY10+DY13+DY14+DY17+DY18)
	+A3*(DY7+DY8+DY11+DY12+DY15+DY16+DY19+DY20)
	+A4*(DY21+DY22+DY23+DY24)
	+A5*(DY25+DY26+DY27+DY28)
	+A6*(DY29+DY30+DY31+DY32)
	+A7*(DY33+DY34+DY35+DY36);   
    }
 
 
    if((*NeighElem1)(2,IEL1)!=0 || Com->GetNodeType(IA2)==ART_BOUND) {
      (*LB)(IA2)= (*LB)(IA2)
	+A1*(DY5+DY6+DY7+DY8)
	+A2*(DY1+DY2+DY9+DY12+DY21+DY22+DY18+DY19)
	+A3*(DY3+DY4+DY10+DY11+DY23+DY24+DY17+DY20)
	+A4*(DY13+DY14+DY15+DY16)
	+A5*(DY25+DY29+DY30+DY33)
	+A6*(DY26+DY28+DY34+DY36)
	+A7*(DY27+DY31+DY32+DY35);    
    }
 
 
    if((*NeighElem1)(3,IEL1)!=0 || Com->GetNodeType(IA3)==ART_BOUND) {
      (*LB)(IA3)= (*LB)(IA3)
	+A1*(DY9+DY10+DY11+DY12)
	+A2*(DY2+DY3+DY6+DY7+DY22+DY23+DY13+DY16)
	+A3*(DY1+DY4+DY5+DY8+DY21+DY24+DY14+DY15)
	+A4*(DY17+DY18+DY19+DY20)
	+A5*(DY26+DY30+DY31+DY34)
	+A6*(DY25+DY27+DY33+DY35)
	+A7*(DY28+DY29+DY32+DY36);     
    }
 
 
    if((*NeighElem1)(4,IEL1)!=0 || Com->GetNodeType(IA4)==ART_BOUND) {
      (*LB)(IA4)= (*LB)(IA4)
	+A1*(DY13+DY14+DY15+DY16)
	+A2*(DY3+DY4+DY10+DY11+DY23+DY24+DY17+DY20)
	+A3*(DY1+DY2+DY9+DY12+DY21+DY22+DY18+DY19)
	+A4*(DY5+DY6+DY7+DY8)
	+A5*(DY27+DY31+DY32+DY35)  
	+A6*(DY26+DY28+DY34+DY36)
	+A7*(DY25+DY29+DY30+DY33);
    }
 
 
    if((*NeighElem1)(5,IEL1)!=0 || Com->GetNodeType(IA5)==ART_BOUND) {
      (*LB)(IA5)= (*LB)(IA5)
	+A1*(DY17+DY18+DY19+DY20)
	+A2*(DY1+DY4+DY5+DY8+DY21+DY24+DY14+DY15)
	+A3*(DY2+DY3+DY6+DY7+DY22+DY23+DY13+DY16)
	+A4*(DY9+DY10+DY11+DY12)
	+A5*(DY28+DY29+DY32+DY36)     
	+A6*(DY25+DY27+DY33+DY35)
	+A7*(DY26+DY30+DY31+DY34);
    }
 
 
    if((*NeighElem1)(6,IEL1)!=0 || Com->GetNodeType(IA6)==ART_BOUND) {
      (*LB)(IA6)= (*LB)(IA6)
	+A1*(DY21+DY22+DY23+DY24)
	+A2*(DY7+DY8+DY11+DY12+DY15+DY16+DY19+DY20)
	+A3*(DY5+DY6+DY9+DY10+DY13+DY14+DY17+DY18)
	+A4*(DY1+DY2+DY3+DY4)
	+A5*(DY33+DY34+DY35+DY36)     
	+A6*(DY29+DY30+DY31+DY32)
	+A7*(DY25+DY26+DY27+DY28);
    }

    if((*NeighElem1)(1,IEL1)==0 && Com->GetNodeType(IA1)==REAL_BOUND) {
      (*LB)(IA1)= 2.0*((*LB)(IA1)
	      +A1*(DY1+DY2+DY3+DY4)
	      +A2*(DY5+DY6+DY9+DY10+DY13+DY14+DY17+DY18)
	      +A3*(DY7+DY8+DY11+DY12+DY15+DY16+DY19+DY20)
	      +A4*(DY21+DY22+DY23+DY24)
	      +A5*(DY25+DY26+DY27+DY28)
	      +A6*(DY29+DY30+DY31+DY32)
	      +A7*(DY33+DY34+DY35+DY36));
      }
    
    
    if((*NeighElem1)(2,IEL1)==0 && Com->GetNodeType(IA2)==REAL_BOUND) {
      (*LB)(IA2)= 2.0*((*LB)(IA2)
	      +A1*(DY5+DY6+DY7+DY8)
	      +A2*(DY1+DY2+DY9+DY12+DY21+DY22+DY18+DY19)
	      +A3*(DY3+DY4+DY10+DY11+DY23+DY24+DY17+DY20)
	      +A4*(DY13+DY14+DY15+DY16)
	      +A5*(DY25+DY29+DY30+DY33)
	      +A6*(DY26+DY28+DY34+DY36)
	      +A7*(DY27+DY31+DY32+DY35));
      }
    
    
    if((*NeighElem1)(3,IEL1)==0 && Com->GetNodeType(IA3)==REAL_BOUND) {
      (*LB)(IA3)= 2.0*((*LB)(IA3)
	      +A1*(DY9+DY10+DY11+DY12)
	      +A2*(DY2+DY3+DY6+DY7+DY22+DY23+DY13+DY16)
	      +A3*(DY1+DY4+DY5+DY8+DY21+DY24+DY14+DY15)
	      +A4*(DY17+DY18+DY19+DY20)
	      +A5*(DY26+DY30+DY31+DY34)
	      +A6*(DY25+DY27+DY33+DY35)
	      +A7*(DY28+DY29+DY32+DY36));
      }
    
    
    if((*NeighElem1)(4,IEL1)==0  && Com->GetNodeType(IA4)==REAL_BOUND) {
      (*LB)(IA4)= 2.0*((*LB)(IA4)
	      +A1*(DY13+DY14+DY15+DY16)
	      +A2*(DY3+DY4+DY10+DY11+DY23+DY24+DY17+DY20)
	      +A3*(DY1+DY2+DY9+DY12+DY21+DY22+DY18+DY19)
	      +A4*(DY5+DY6+DY7+DY8)
	      +A5*(DY27+DY31+DY32+DY35)  
	      +A6*(DY26+DY28+DY34+DY36)
	      +A7*(DY25+DY29+DY30+DY33));
      }
    
    
    if((*NeighElem1)(5,IEL1)==0  && Com->GetNodeType(IA5)==REAL_BOUND) {
      (*LB)(IA5)= 2.0*((*LB)(IA5)
	      +A1*(DY17+DY18+DY19+DY20)
	      +A2*(DY1+DY4+DY5+DY8+DY21+DY24+DY14+DY15)
	      +A3*(DY2+DY3+DY6+DY7+DY22+DY23+DY13+DY16)
	      +A4*(DY9+DY10+DY11+DY12)
	      +A5*(DY28+DY29+DY32+DY36)     
	      +A6*(DY25+DY27+DY33+DY35)
	      +A7*(DY26+DY30+DY31+DY34));
      }
    
    
    if((*NeighElem1)(6,IEL1)==0  && Com->GetNodeType(IA6)==REAL_BOUND) {
      (*LB)(IA6)= 2.0*((*LB)(IA6)
	      +A1*(DY21+DY22+DY23+DY24)
	      +A2*(DY7+DY8+DY11+DY12+DY15+DY16+DY19+DY20)
	      +A3*(DY5+DY6+DY9+DY10+DY13+DY14+DY17+DY18)
	      +A4*(DY1+DY2+DY3+DY4)
	      +A5*(DY33+DY34+DY35+DY36)     
	      +A6*(DY29+DY30+DY31+DY32)
	      +A7*(DY25+DY26+DY27+DY28));
      }
  }

#ifdef CLOCK_MEASURE
  T1+=Clock.GetTimeDiff();

  ClockHelp.SetTime();
#endif
  Com->CommunicateProlRest(LB);
#ifdef CLOCK_MEASURE
  T2+=ClockHelp.GetTimeDiff();

  TRest += (T1 + T2); 
  TRestCom += T2; 
#endif
}


VOID ParNonParamElement_3D::Prol(DoubleVector *LD,DoubleVector *LB,
			     IntArray2D *VertElem2,IntArray2D *VertElem1,
			     IntArray2D *MidFaces2,IntArray2D *MidFaces1,
			     IntArray2D *NeighElem2,IntArray2D *NeighElem1,
			     UNSIGNED NumVertices2,UNSIGNED NumVertices1,
			     UNSIGNED NumElements2,UNSIGNED NumElements1)
{
//  VertElem2,NeighElem2 and NumElements2:  fine grid information
//  NumVertices1: coarse grid information

  int IEL1,IELH1,IELH2,IELH3,IELH4,IELH5,IELH6,IELH7,IELH8;
  double DY1,DY2,DY3,DY4,DY5,DY6;
  double A1,A2,A3,A4,A5,A6,A7;
	
  A1= 11.0/24.0;
  A2= 7.0/48.0;
  A3=-5.0/48.0;
  A4=-1.0/24.0;
  A5= 11.0/24.0;
  A6= 1.0/12.0;
  A7=-1.0/24.0;

  *LB=0;

  for(IEL1=1;IEL1<=NumElements1;IEL1++)
  {
    DY1=(*LD)((*MidFaces1)(1,IEL1));
    DY2=(*LD)((*MidFaces1)(2,IEL1));
    DY3=(*LD)((*MidFaces1)(3,IEL1));
    DY4=(*LD)((*MidFaces1)(4,IEL1));
    DY5=(*LD)((*MidFaces1)(5,IEL1));
    DY6=(*LD)((*MidFaces1)(6,IEL1));

    IELH1=IEL1;
    IELH2=(*NeighElem2)(3,IELH1);
    IELH3=(*NeighElem2)(3,IELH2);
    IELH4=(*NeighElem2)(3,IELH3);
    IELH5=(*NeighElem2)(6,IELH1);
    IELH6=(*NeighElem2)(3,IELH5);
    IELH7=(*NeighElem2)(3,IELH6);
    IELH8=(*NeighElem2)(3,IELH7);

    if((*NeighElem1)(1,IEL1)!=0) { 
      (*LB)((*MidFaces2)(1,IELH1))=(*LB)((*MidFaces2)(1,IELH1))+
	A1*DY1+A2*DY2+A3*DY3+A3*DY4+A2*DY5+A4*DY6;
      (*LB)((*MidFaces2)(1,IELH2))=(*LB)((*MidFaces2)(1,IELH2))+
	A1*DY1+A2*DY2+A2*DY3+A3*DY4+A3*DY5+A4*DY6;
      (*LB)((*MidFaces2)(1,IELH3))=(*LB)((*MidFaces2)(1,IELH3))+
	A1*DY1+A3*DY2+A2*DY3+A2*DY4+A3*DY5+A4*DY6;
      (*LB)((*MidFaces2)(1,IELH4))=(*LB)((*MidFaces2)(1,IELH4))+
	A1*DY1+A3*DY2+A3*DY3+A2*DY4+A2*DY5+A4*DY6;
    }


    if((*NeighElem1)(2,IEL1)!=0) { 
      (*LB)((*MidFaces2)(2,IELH1))=(*LB)((*MidFaces2)(2,IELH1))+
	A2*DY1+A1*DY2+A3*DY3+A4*DY4+A2*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH2))=(*LB)((*MidFaces2)(5,IELH2))+
	A2*DY1+A1*DY2+A2*DY3+A4*DY4+A3*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH6))=(*LB)((*MidFaces2)(5,IELH6))+
	A3*DY1+A1*DY2+A2*DY3+A4*DY4+A3*DY5+A2*DY6;
      (*LB)((*MidFaces2)(2,IELH5))=(*LB)((*MidFaces2)(2,IELH5))+
	A3*DY1+A1*DY2+A3*DY3+A4*DY4+A2*DY5+A2*DY6;
    }


    if((*NeighElem1)(3,IEL1)!=0) { 
      (*LB)((*MidFaces2)(2,IELH2))=(*LB)((*MidFaces2)(2,IELH2))+
	A2*DY1+A2*DY2+A1*DY3+A3*DY4+A4*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH3))=(*LB)((*MidFaces2)(5,IELH3))+
	A2*DY1+A3*DY2+A1*DY3+A2*DY4+A4*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH7))=(*LB)((*MidFaces2)(5,IELH7))+
	A3*DY1+A3*DY2+A1*DY3+A2*DY4+A4*DY5+A2*DY6;
      (*LB)((*MidFaces2)(2,IELH6))=(*LB)((*MidFaces2)(2,IELH6))+
	A3*DY1+A2*DY2+A1*DY3+A3*DY4+A4*DY5+A2*DY6;
    }


    if((*NeighElem1)(4,IEL1)!=0) { 
      (*LB)((*MidFaces2)(2,IELH3))=(*LB)((*MidFaces2)(2,IELH3))+
	A2*DY1+A4*DY2+A2*DY3+A1*DY4+A3*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH4))=(*LB)((*MidFaces2)(5,IELH4))+
	A2*DY1+A4*DY2+A3*DY3+A1*DY4+A2*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH8))=(*LB)((*MidFaces2)(5,IELH8))+
	A3*DY1+A4*DY2+A3*DY3+A1*DY4+A2*DY5+A2*DY6;
      (*LB)((*MidFaces2)(2,IELH7))=(*LB)((*MidFaces2)(2,IELH7))+
	A3*DY1+A4*DY2+A2*DY3+A1*DY4+A3*DY5+A2*DY6;
    }


    if((*NeighElem1)(5,IEL1)!=0) { 
      (*LB)((*MidFaces2)(2,IELH4))=(*LB)((*MidFaces2)(2,IELH4))+
	A2*DY1+A3*DY2+A4*DY3+A2*DY4+A1*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH1))=(*LB)((*MidFaces2)(5,IELH1))+
	A2*DY1+A2*DY2+A4*DY3+A3*DY4+A1*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH5))=(*LB)((*MidFaces2)(5,IELH5))+
	A3*DY1+A2*DY2+A4*DY3+A3*DY4+A1*DY5+A2*DY6;
      (*LB)((*MidFaces2)(2,IELH8))=(*LB)((*MidFaces2)(2,IELH8))+
	A3*DY1+A3*DY2+A4*DY3+A2*DY4+A1*DY5+A2*DY6;
    }


    if((*NeighElem1)(6,IEL1)!=0) { 
      (*LB)((*MidFaces2)(1,IELH5))=(*LB)((*MidFaces2)(1,IELH5))+
	A4*DY1+A2*DY2+A3*DY3+A3*DY4+A2*DY5+A1*DY6;
      (*LB)((*MidFaces2)(1,IELH6))=(*LB)((*MidFaces2)(1,IELH6))+
	A4*DY1+A2*DY2+A2*DY3+A3*DY4+A3*DY5+A1*DY6;
      (*LB)((*MidFaces2)(1,IELH7))=(*LB)((*MidFaces2)(1,IELH7))+
	A4*DY1+A3*DY2+A2*DY3+A2*DY4+A3*DY5+A1*DY6;
      (*LB)((*MidFaces2)(1,IELH8))=(*LB)((*MidFaces2)(1,IELH8))+
	A4*DY1+A3*DY2+A3*DY3+A2*DY4+A2*DY5+A1*DY6;
    }


    (*LB)((*MidFaces2)(3,IELH1))=A5*DY1+A5*DY2+A6*DY3+A7*DY4+A6*DY5+A7*DY6;
    (*LB)((*MidFaces2)(3,IELH2))=A5*DY1+A6*DY2+A5*DY3+A6*DY4+A7*DY5+A7*DY6;
    (*LB)((*MidFaces2)(3,IELH3))=A5*DY1+A7*DY2+A6*DY3+A5*DY4+A6*DY5+A7*DY6;
    (*LB)((*MidFaces2)(3,IELH4))=A5*DY1+A6*DY2+A7*DY3+A6*DY4+A5*DY5+A7*DY6;

    (*LB)((*MidFaces2)(6,IELH1))=A6*DY1+A5*DY2+A7*DY3+A7*DY4+A5*DY5+A6*DY6;
    (*LB)((*MidFaces2)(6,IELH2))=A6*DY1+A5*DY2+A5*DY3+A7*DY4+A7*DY5+A6*DY6;
    (*LB)((*MidFaces2)(6,IELH3))=A6*DY1+A7*DY2+A5*DY3+A5*DY4+A7*DY5+A6*DY6;
    (*LB)((*MidFaces2)(6,IELH4))=A6*DY1+A7*DY2+A7*DY3+A5*DY4+A5*DY5+A6*DY6;

    (*LB)((*MidFaces2)(3,IELH5))=A7*DY1+A5*DY2+A6*DY3+A7*DY4+A6*DY5+A5*DY6;
    (*LB)((*MidFaces2)(3,IELH6))=A7*DY1+A6*DY2+A5*DY3+A6*DY4+A7*DY5+A5*DY6;
    (*LB)((*MidFaces2)(3,IELH7))=A7*DY1+A7*DY2+A6*DY3+A5*DY4+A6*DY5+A5*DY6;
    (*LB)((*MidFaces2)(3,IELH8))=A7*DY1+A6*DY2+A7*DY3+A6*DY4+A5*DY5+A5*DY6;
  }
}

VOID ParNonParamElement_3D::ParProl(DoubleVector *LD,DoubleVector *LB,
				IntArray2D *VertElem2,IntArray2D *VertElem1,
				IntArray2D *MidFaces2,IntArray2D *MidFaces1,
				IntArray2D *NeighElem2,IntArray2D *NeighElem1,
				UNSIGNED NumVertices2,UNSIGNED NumVertices1,
				UNSIGNED NumElements2,UNSIGNED NumElements1,
				ParMultiGrid_3D *Com)
{
//  VertElem2,NeighElem2 and NumElements2:  fine grid information
//  NumVertices1: coarse grid information

  int IEL1,IELH1,IELH2,IELH3,IELH4,IELH5,IELH6,IELH7,IELH8;
  double DY1,DY2,DY3,DY4,DY5,DY6;
  double A1,A2,A3,A4,A5,A6,A7;

#ifdef CLOCK_MEASURE
  double T1=0,T2=0;
  DateTime Clock;
  DateTime ClockHelp;

  Clock.SetTime();
#endif
	
  A1= 11.0/24.0;
  A2= 7.0/48.0;
  A3=-5.0/48.0;
  A4=-1.0/24.0;
  A5= 11.0/24.0;
  A6= 1.0/12.0;
  A7=-1.0/24.0;

  *LB=0;

  for(IEL1=1;IEL1<=NumElements1;IEL1++)
  {
    DY1=(*LD)((*MidFaces1)(1,IEL1));
    DY2=(*LD)((*MidFaces1)(2,IEL1));
    DY3=(*LD)((*MidFaces1)(3,IEL1));
    DY4=(*LD)((*MidFaces1)(4,IEL1));
    DY5=(*LD)((*MidFaces1)(5,IEL1));
    DY6=(*LD)((*MidFaces1)(6,IEL1));

    IELH1=IEL1;
    IELH2=(*NeighElem2)(3,IELH1);
    IELH3=(*NeighElem2)(3,IELH2);
    IELH4=(*NeighElem2)(3,IELH3);
    IELH5=(*NeighElem2)(6,IELH1);
    IELH6=(*NeighElem2)(3,IELH5);
    IELH7=(*NeighElem2)(3,IELH6);
    IELH8=(*NeighElem2)(3,IELH7);

    if((*NeighElem1)(1,IEL1)!=0 
       || Com->GetNodeType((*MidFaces2)(1,IELH1))==ART_BOUND) 
      (*LB)((*MidFaces2)(1,IELH1))=(*LB)((*MidFaces2)(1,IELH1))+
	A1*DY1+A2*DY2+A3*DY3+A3*DY4+A2*DY5+A4*DY6;

    if((*NeighElem1)(1,IEL1)!=0 
       || Com->GetNodeType((*MidFaces2)(1,IELH2))==ART_BOUND) 
      (*LB)((*MidFaces2)(1,IELH2))=(*LB)((*MidFaces2)(1,IELH2))+
	A1*DY1+A2*DY2+A2*DY3+A3*DY4+A3*DY5+A4*DY6;

    if((*NeighElem1)(1,IEL1)!=0 
       || Com->GetNodeType((*MidFaces2)(1,IELH3))==ART_BOUND) 
      (*LB)((*MidFaces2)(1,IELH3))=(*LB)((*MidFaces2)(1,IELH3))+
	A1*DY1+A3*DY2+A2*DY3+A2*DY4+A3*DY5+A4*DY6;

    if((*NeighElem1)(1,IEL1)!=0 
       || Com->GetNodeType((*MidFaces2)(1,IELH4))==ART_BOUND) 
      (*LB)((*MidFaces2)(1,IELH4))=(*LB)((*MidFaces2)(1,IELH4))+
	A1*DY1+A3*DY2+A3*DY3+A2*DY4+A2*DY5+A4*DY6;


    if((*NeighElem1)(2,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(2,IELH1))==ART_BOUND) 
      (*LB)((*MidFaces2)(2,IELH1))=(*LB)((*MidFaces2)(2,IELH1))+
	A2*DY1+A1*DY2+A3*DY3+A4*DY4+A2*DY5+A3*DY6;

    if((*NeighElem1)(2,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(5,IELH2))==ART_BOUND) 
      (*LB)((*MidFaces2)(5,IELH2))=(*LB)((*MidFaces2)(5,IELH2))+
	A2*DY1+A1*DY2+A2*DY3+A4*DY4+A3*DY5+A3*DY6;

    if((*NeighElem1)(2,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(5,IELH6))==ART_BOUND) 
      (*LB)((*MidFaces2)(5,IELH6))=(*LB)((*MidFaces2)(5,IELH6))+
	A3*DY1+A1*DY2+A2*DY3+A4*DY4+A3*DY5+A2*DY6;

    if((*NeighElem1)(2,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(2,IELH5))==ART_BOUND) 
      (*LB)((*MidFaces2)(2,IELH5))=(*LB)((*MidFaces2)(2,IELH5))+
	A3*DY1+A1*DY2+A3*DY3+A4*DY4+A2*DY5+A2*DY6;


    if((*NeighElem1)(3,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(2,IELH2))==ART_BOUND)  
      (*LB)((*MidFaces2)(2,IELH2))=(*LB)((*MidFaces2)(2,IELH2))+
	A2*DY1+A2*DY2+A1*DY3+A3*DY4+A4*DY5+A3*DY6;

    if((*NeighElem1)(3,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(5,IELH3))==ART_BOUND)  
      (*LB)((*MidFaces2)(5,IELH3))=(*LB)((*MidFaces2)(5,IELH3))+
	A2*DY1+A3*DY2+A1*DY3+A2*DY4+A4*DY5+A3*DY6;

    if((*NeighElem1)(3,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(5,IELH7))==ART_BOUND)  
      (*LB)((*MidFaces2)(5,IELH7))=(*LB)((*MidFaces2)(5,IELH7))+
	A3*DY1+A3*DY2+A1*DY3+A2*DY4+A4*DY5+A2*DY6;

    if((*NeighElem1)(3,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(2,IELH6))==ART_BOUND)  
      (*LB)((*MidFaces2)(2,IELH6))=(*LB)((*MidFaces2)(2,IELH6))+
	A3*DY1+A2*DY2+A1*DY3+A3*DY4+A4*DY5+A2*DY6;


    if((*NeighElem1)(4,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(2,IELH3))==ART_BOUND)  
      (*LB)((*MidFaces2)(2,IELH3))=(*LB)((*MidFaces2)(2,IELH3))+
	A2*DY1+A4*DY2+A2*DY3+A1*DY4+A3*DY5+A3*DY6;

    if((*NeighElem1)(4,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(5,IELH4))==ART_BOUND)  
      (*LB)((*MidFaces2)(5,IELH4))=(*LB)((*MidFaces2)(5,IELH4))+
	A2*DY1+A4*DY2+A3*DY3+A1*DY4+A2*DY5+A3*DY6;

    if((*NeighElem1)(4,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(5,IELH8))==ART_BOUND)  
      (*LB)((*MidFaces2)(5,IELH8))=(*LB)((*MidFaces2)(5,IELH8))+
	A3*DY1+A4*DY2+A3*DY3+A1*DY4+A2*DY5+A2*DY6;

    if((*NeighElem1)(4,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(2,IELH7))==ART_BOUND)  
      (*LB)((*MidFaces2)(2,IELH7))=(*LB)((*MidFaces2)(2,IELH7))+
	A3*DY1+A4*DY2+A2*DY3+A1*DY4+A3*DY5+A2*DY6;


    if((*NeighElem1)(5,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(2,IELH4))==ART_BOUND)  
      (*LB)((*MidFaces2)(2,IELH4))=(*LB)((*MidFaces2)(2,IELH4))+
	A2*DY1+A3*DY2+A4*DY3+A2*DY4+A1*DY5+A3*DY6;

    if((*NeighElem1)(5,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(5,IELH1))==ART_BOUND)  
      (*LB)((*MidFaces2)(5,IELH1))=(*LB)((*MidFaces2)(5,IELH1))+
	A2*DY1+A2*DY2+A4*DY3+A3*DY4+A1*DY5+A3*DY6;

    if((*NeighElem1)(5,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(5,IELH5))==ART_BOUND)  
      (*LB)((*MidFaces2)(5,IELH5))=(*LB)((*MidFaces2)(5,IELH5))+
	A3*DY1+A2*DY2+A4*DY3+A3*DY4+A1*DY5+A2*DY6;

    if((*NeighElem1)(5,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(2,IELH8))==ART_BOUND)  
      (*LB)((*MidFaces2)(2,IELH8))=(*LB)((*MidFaces2)(2,IELH8))+
	A3*DY1+A3*DY2+A4*DY3+A2*DY4+A1*DY5+A2*DY6;


    if((*NeighElem1)(6,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(1,IELH5))==ART_BOUND)  
      (*LB)((*MidFaces2)(1,IELH5))=(*LB)((*MidFaces2)(1,IELH5))+
	A4*DY1+A2*DY2+A3*DY3+A3*DY4+A2*DY5+A1*DY6;

    if((*NeighElem1)(6,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(1,IELH6))==ART_BOUND)  
      (*LB)((*MidFaces2)(1,IELH6))=(*LB)((*MidFaces2)(1,IELH6))+
	A4*DY1+A2*DY2+A2*DY3+A3*DY4+A3*DY5+A1*DY6;

    if((*NeighElem1)(6,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(1,IELH7))==ART_BOUND)  
      (*LB)((*MidFaces2)(1,IELH7))=(*LB)((*MidFaces2)(1,IELH7))+
	A4*DY1+A3*DY2+A2*DY3+A2*DY4+A3*DY5+A1*DY6;

    if((*NeighElem1)(6,IEL1)!=0
       || Com->GetNodeType((*MidFaces2)(1,IELH8))==ART_BOUND)  
      (*LB)((*MidFaces2)(1,IELH8))=(*LB)((*MidFaces2)(1,IELH8))+
	A4*DY1+A3*DY2+A3*DY3+A2*DY4+A2*DY5+A1*DY6;

    (*LB)((*MidFaces2)(3,IELH1))=A5*DY1+A5*DY2+A6*DY3+A7*DY4+A6*DY5+A7*DY6;
    (*LB)((*MidFaces2)(3,IELH2))=A5*DY1+A6*DY2+A5*DY3+A6*DY4+A7*DY5+A7*DY6;
    (*LB)((*MidFaces2)(3,IELH3))=A5*DY1+A7*DY2+A6*DY3+A5*DY4+A6*DY5+A7*DY6;
    (*LB)((*MidFaces2)(3,IELH4))=A5*DY1+A6*DY2+A7*DY3+A6*DY4+A5*DY5+A7*DY6;

    (*LB)((*MidFaces2)(6,IELH1))=A6*DY1+A5*DY2+A7*DY3+A7*DY4+A5*DY5+A6*DY6;
    (*LB)((*MidFaces2)(6,IELH2))=A6*DY1+A5*DY2+A5*DY3+A7*DY4+A7*DY5+A6*DY6;
    (*LB)((*MidFaces2)(6,IELH3))=A6*DY1+A7*DY2+A5*DY3+A5*DY4+A7*DY5+A6*DY6;
    (*LB)((*MidFaces2)(6,IELH4))=A6*DY1+A7*DY2+A7*DY3+A5*DY4+A5*DY5+A6*DY6;

    (*LB)((*MidFaces2)(3,IELH5))=A7*DY1+A5*DY2+A6*DY3+A7*DY4+A6*DY5+A5*DY6;
    (*LB)((*MidFaces2)(3,IELH6))=A7*DY1+A6*DY2+A5*DY3+A6*DY4+A7*DY5+A5*DY6;
    (*LB)((*MidFaces2)(3,IELH7))=A7*DY1+A7*DY2+A6*DY3+A5*DY4+A6*DY5+A5*DY6;
    (*LB)((*MidFaces2)(3,IELH8))=A7*DY1+A6*DY2+A7*DY3+A6*DY4+A5*DY5+A5*DY6;

    if((*NeighElem1)(1,IEL1)==0 
       && Com->GetNodeType((*MidFaces2)(1,IELH1))==REAL_BOUND)  
      (*LB)((*MidFaces2)(1,IELH1))=(*LB)((*MidFaces2)(1,IELH1))+2.0*
	(A1*DY1+A2*DY2+A3*DY3+A3*DY4+A2*DY5+A4*DY6);

    if((*NeighElem1)(1,IEL1)==0 
       && Com->GetNodeType((*MidFaces2)(1,IELH2))==REAL_BOUND)  
      (*LB)((*MidFaces2)(1,IELH2))=(*LB)((*MidFaces2)(1,IELH2))+2.0*
	(A1*DY1+A2*DY2+A2*DY3+A3*DY4+A3*DY5+A4*DY6);

    if((*NeighElem1)(1,IEL1)==0 
       && Com->GetNodeType((*MidFaces2)(1,IELH3))==REAL_BOUND)  
      (*LB)((*MidFaces2)(1,IELH3))=(*LB)((*MidFaces2)(1,IELH3))+2.0*
	(A1*DY1+A3*DY2+A2*DY3+A2*DY4+A3*DY5+A4*DY6);

    if((*NeighElem1)(1,IEL1)==0 
       && Com->GetNodeType((*MidFaces2)(1,IELH4))==REAL_BOUND)  
      (*LB)((*MidFaces2)(1,IELH4))=(*LB)((*MidFaces2)(1,IELH4))+2.0*
	(A1*DY1+A3*DY2+A3*DY3+A2*DY4+A2*DY5+A4*DY6);

    
    if((*NeighElem1)(2,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(2,IELH1))==REAL_BOUND)  
      (*LB)((*MidFaces2)(2,IELH1))=(*LB)((*MidFaces2)(2,IELH1))+2.0*
	(A2*DY1+A1*DY2+A3*DY3+A4*DY4+A2*DY5+A3*DY6);

    if((*NeighElem1)(2,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(5,IELH2))==REAL_BOUND)  
      (*LB)((*MidFaces2)(5,IELH2))=(*LB)((*MidFaces2)(5,IELH2))+2.0*
	(A2*DY1+A1*DY2+A2*DY3+A4*DY4+A3*DY5+A3*DY6);
    
    if((*NeighElem1)(2,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(5,IELH6))==REAL_BOUND)  
      (*LB)((*MidFaces2)(5,IELH6))=(*LB)((*MidFaces2)(5,IELH6))+2.0*
	(A3*DY1+A1*DY2+A2*DY3+A4*DY4+A3*DY5+A2*DY6);
    
    if((*NeighElem1)(2,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(2,IELH5))==REAL_BOUND)  
      (*LB)((*MidFaces2)(2,IELH5))=(*LB)((*MidFaces2)(2,IELH5))+2.0*
	(A3*DY1+A1*DY2+A3*DY3+A4*DY4+A2*DY5+A2*DY6);
    

    if((*NeighElem1)(3,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(2,IELH2))==REAL_BOUND)  
      (*LB)((*MidFaces2)(2,IELH2))=(*LB)((*MidFaces2)(2,IELH2))+2.0*
	(A2*DY1+A2*DY2+A1*DY3+A3*DY4+A4*DY5+A3*DY6);

    if((*NeighElem1)(3,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(5,IELH3))==REAL_BOUND)  
      (*LB)((*MidFaces2)(5,IELH3))=(*LB)((*MidFaces2)(5,IELH3))+2.0*
	(A2*DY1+A3*DY2+A1*DY3+A2*DY4+A4*DY5+A3*DY6);

    if((*NeighElem1)(3,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(5,IELH7))==REAL_BOUND)  
    (*LB)((*MidFaces2)(5,IELH7))=(*LB)((*MidFaces2)(5,IELH7))+2.0*
      (A3*DY1+A3*DY2+A1*DY3+A2*DY4+A4*DY5+A2*DY6);

    if((*NeighElem1)(3,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(2,IELH6))==REAL_BOUND)  
      (*LB)((*MidFaces2)(2,IELH6))=(*LB)((*MidFaces2)(2,IELH6))+2.0*
	(A3*DY1+A2*DY2+A1*DY3+A3*DY4+A4*DY5+A2*DY6);


    if((*NeighElem1)(4,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(2,IELH3))==REAL_BOUND)  
      (*LB)((*MidFaces2)(2,IELH3))=(*LB)((*MidFaces2)(2,IELH3))+2.0*
	(A2*DY1+A4*DY2+A2*DY3+A1*DY4+A3*DY5+A3*DY6);
    
    if((*NeighElem1)(4,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(5,IELH4))==REAL_BOUND)  
      (*LB)((*MidFaces2)(5,IELH4))=(*LB)((*MidFaces2)(5,IELH4))+2.0*
	(A2*DY1+A4*DY2+A3*DY3+A1*DY4+A2*DY5+A3*DY6);
    
    if((*NeighElem1)(4,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(5,IELH8))==REAL_BOUND)  
      (*LB)((*MidFaces2)(5,IELH8))=(*LB)((*MidFaces2)(5,IELH8))+2.0*
	(A3*DY1+A4*DY2+A3*DY3+A1*DY4+A2*DY5+A2*DY6);
    
    if((*NeighElem1)(4,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(2,IELH7))==REAL_BOUND)  
      (*LB)((*MidFaces2)(2,IELH7))=(*LB)((*MidFaces2)(2,IELH7))+2.0*
	(A3*DY1+A4*DY2+A2*DY3+A1*DY4+A3*DY5+A2*DY6);
    

    if((*NeighElem1)(5,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(2,IELH4))==REAL_BOUND)  
      (*LB)((*MidFaces2)(2,IELH4))=(*LB)((*MidFaces2)(2,IELH4))+2.0*
	(A2*DY1+A3*DY2+A4*DY3+A2*DY4+A1*DY5+A3*DY6);

    if((*NeighElem1)(5,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(5,IELH1))==REAL_BOUND)  
      (*LB)((*MidFaces2)(5,IELH1))=(*LB)((*MidFaces2)(5,IELH1))+2.0*
	(A2*DY1+A2*DY2+A4*DY3+A3*DY4+A1*DY5+A3*DY6);

    if((*NeighElem1)(5,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(5,IELH5))==REAL_BOUND)  
      (*LB)((*MidFaces2)(5,IELH5))=(*LB)((*MidFaces2)(5,IELH5))+2.0*
	(A3*DY1+A2*DY2+A4*DY3+A3*DY4+A1*DY5+A2*DY6);

    if((*NeighElem1)(5,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(2,IELH8))==REAL_BOUND)  
      (*LB)((*MidFaces2)(2,IELH8))=(*LB)((*MidFaces2)(2,IELH8))+2.0*
	(A3*DY1+A3*DY2+A4*DY3+A2*DY4+A1*DY5+A2*DY6);
   

    if((*NeighElem1)(6,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(1,IELH5))==REAL_BOUND)  
      (*LB)((*MidFaces2)(1,IELH5))=(*LB)((*MidFaces2)(1,IELH5))+2.0*
	(A4*DY1+A2*DY2+A3*DY3+A3*DY4+A2*DY5+A1*DY6);

    if((*NeighElem1)(6,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(1,IELH6))==REAL_BOUND)  
      (*LB)((*MidFaces2)(1,IELH6))=(*LB)((*MidFaces2)(1,IELH6))+2.0*
	(A4*DY1+A2*DY2+A2*DY3+A3*DY4+A3*DY5+A1*DY6);

    if((*NeighElem1)(6,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(1,IELH7))==REAL_BOUND)  
      (*LB)((*MidFaces2)(1,IELH7))=(*LB)((*MidFaces2)(1,IELH7))+2.0*
	(A4*DY1+A3*DY2+A2*DY3+A2*DY4+A3*DY5+A1*DY6);

    if((*NeighElem1)(6,IEL1)==0
       && Com->GetNodeType((*MidFaces2)(1,IELH8))==REAL_BOUND)  
      (*LB)((*MidFaces2)(1,IELH8))=(*LB)((*MidFaces2)(1,IELH8))+2.0*
	(A4*DY1+A3*DY2+A3*DY3+A2*DY4+A2*DY5+A1*DY6);

  }
#ifdef CLOCK_MEASURE
  T1 += Clock.GetTimeDiff(); 

  ClockHelp.SetTime();
#endif
  Com->CommunicateProlRest(LB);
#ifdef CLOCK_MEASURE
  T2 += ClockHelp.GetTimeDiff(); 

  TProl += T1 + T2; 
  TProlCom += T2; 
#endif
}
