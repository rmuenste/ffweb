#include "Task.h"
#include "ParVector.h"

extern double TNorm,TNormCom;

//#define CLOCK_MEASURE

double ParVector::ScalProd(DoubleVector& v2, Task *MyTask)
{
    double temp = 0;
    DoubleVector tempv(v2.GetLen()), tempv2(v2.GetLen());

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering ParVector::ScalProd.\n";
	protocol.mFlush();
    }

    if (GetLen() != v2.GetLen()) {
#ifdef DEBUG
// ********** Error : different vectors **********
	Err << "ParVector: different vector sizes !!  Name:" << GetName() << "\n";
#endif
	MPI_Finalize();
	exit(0);
    }

    tempv  = v2;
    tempv2 = *this;

#ifdef CLOCK_MEASURE
    DateTime Clock, ClockHelp;
    Clock.SetTime();
    ClockHelp.SetTime();
#endif

    MyTask->SetSPValues(&tempv2, &tempv);

#ifdef CLOCK_MEASURE
    TNormCom += ClockHelp.GetTimeDiff();
#endif

    for (unsigned int index = 1; index <= GetLen(); index++)
	temp += tempv2(index) * tempv(index);

#ifdef CLOCK_MEASURE
    ClockHelp.SetTime();
#endif
    MyTask->CommunicateSP(temp);
#ifdef CLOCK_MEASURE
    TNormCom += ClockHelp.GetTimeDiff();
    TNorm += Clock.GetTimeDiff();
#endif

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving ParVector::ScalProd.\n";
	protocol.mFlush();
    }

    return temp;
}

double ParVector::ConstScalProd(DoubleVector& v2,Task *MyTask)
{
    double temp = 0;
    DoubleVector tempv(v2), tempv2(*this);

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering ParVector::ConstScalProd.\n";
	protocol.mFlush();
    }

    if (GetLen() != v2.GetLen()) {
#ifdef DEBUG
// ********** Error : different vectors **********
	Err << "ParVector: different vector sizes !!  Name:" << GetName() << "\n";
#endif
	MPI_Finalize();
	exit(0);
    }

    for (unsigned int index = 1; index <= GetLen(); index++)
	temp += tempv2(index) * tempv(index);

    MyTask->CommunicateSP(temp);

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving ParVector::ConstScalProd.\n";
	protocol.mFlush();
    }

    return temp;
}

ParVector& ParVector::operator=(ParVector& aParVector)
{
  unsigned int size=aParVector.GetLen();

  if (GetLen() >= size) {
    for (unsigned int index = 1; index <= size; index++)
	(*this)(index) = aParVector(index);
  }
  return *this;
}

ParVector& ParVector::operator=(double aNumber)
{
  for (unsigned int index = 1; index <= GetLen(); index++) {
    (*this)(index) = aNumber;
  }
  return *this;
}
