#ifndef PARROTATED_BILINEARELEMENT3DH

#define PARROTATED_BILINEARELEMENT3DH

#include "ParFiniteElement_3D.h"
#include "Const.h"

class ParRotatedElement_3D:public ParFiniteElement_3D
{
public:
  ParRotatedElement_3D(SquareGrid_3D *NGrid):ParFiniteElement_3D(NGrid) 
                       {IDFL=NumFaceElem;}
  ~ParRotatedElement_3D(VOID) {}
		
  VOID GetValue(DOUBLE XI1,DOUBLE XI2,DOUBLE XI3);
  UNSIGNED GetDOF(VOID);
  UNSIGNED GetTotalDOF(VOID);
  UNSIGNED GetIEROW(VOID);
  int      GetElemType(void);
  VOID SetGlobalDOF(UNSIGNED IEL,UNSIGNED IPAR);
  VOID Restrict(DoubleVector *LD,DoubleVector *LB,
		IntArray2D *VertElem2,IntArray2D *VertElem1,
		IntArray2D *MidFaces2,IntArray2D *MidFaces1,
		IntArray2D *NeighElem2,IntArray2D *NeighElem1,
		UNSIGNED NumVertices2,UNSIGNED NumVertices1,
		UNSIGNED NumElements2,UNSIGNED NumElements1);
  VOID Prol(DoubleVector *LD,DoubleVector *LB,
	    IntArray2D *VertElem2,IntArray2D *VertElem1,
	    IntArray2D *MidFaces2,IntArray2D *MidFaces1,
	    IntArray2D *NeighElem2,IntArray2D *NeighElem1,
	    UNSIGNED NumVertices2,UNSIGNED NumVertices1,
	    UNSIGNED NumElements2,UNSIGNED NumElements1);
  VOID ParRestrict(DoubleVector *LD,DoubleVector *LB,
		   IntArray2D *VertElem2,IntArray2D *VertElem1,
		   IntArray2D *MidFaces2,IntArray2D *MidFaces1,
		   IntArray2D *NeighElem2,IntArray2D *NeighElem1,
		   UNSIGNED NumVertices2,UNSIGNED NumVertices1,
		   UNSIGNED NumElements2,UNSIGNED NumElements1,
		   ParMultiGrid_3D *Com);
  VOID ParProl(DoubleVector *LD,DoubleVector *LB,
	       IntArray2D *VertElem2,IntArray2D *VertElem1,
	       IntArray2D *MidFaces2,IntArray2D *MidFaces1,
	       IntArray2D *NeighElem2,IntArray2D *NeighElem1,
	       UNSIGNED NumVertices2,UNSIGNED NumVertices1,
	       UNSIGNED NumElements2,UNSIGNED NumElements1,
	       ParMultiGrid_3D *Com);
};

inline UNSIGNED ParRotatedElement_3D::GetDOF(VOID)
{
  return IDFL;
}

inline UNSIGNED ParRotatedElement_3D::GetTotalDOF(VOID)
{
  return Grid->TotNumFaces;
}

inline UNSIGNED ParRotatedElement_3D::GetIEROW(VOID)
{
  return 12;
}

inline int ParRotatedElement_3D::GetElemType(VOID)
{
  return PARAM;
}

#endif
