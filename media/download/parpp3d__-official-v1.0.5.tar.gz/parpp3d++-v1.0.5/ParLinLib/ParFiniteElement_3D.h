#ifndef PARFINITEELEMENT3DH

#define PARFINITEELEMENT3DH

#include "FiniteElement_3D.h"

class ParMultiGrid_3D;

class ParFiniteElement_3D: public FiniteElement_3D
{
 public:
  ParFiniteElement_3D(SquareGrid_3D* NGrid):FiniteElement_3D(NGrid) {}
  virtual ~ParFiniteElement_3D(VOID) {}
  

  virtual VOID ParRestrict(DoubleVector *LD,DoubleVector *LB,
			   IntArray2D *VertElem2,IntArray2D *VertElem1,
			   IntArray2D *MidEdges2,IntArray2D *MidEdges1,
			   IntArray2D *NeighElem2,IntArray2D *NeighElem1,
			   UNSIGNED NumVertices2,UNSIGNED NumVertices1,
			   UNSIGNED NumElements2,UNSIGNED NumElements1,
			   ParMultiGrid_3D *Com)=0;
  virtual VOID ParProl(DoubleVector *LD,DoubleVector *LB,
		       IntArray2D *VertElem2,IntArray2D *VertElem1,
		       IntArray2D *MidEdges2,IntArray2D *MidEdges1,
		       IntArray2D *NeighElem2,IntArray2D *NeighElem1,
		       UNSIGNED NumVertices2,UNSIGNED NumVertices1,
		       UNSIGNED NumElements2,UNSIGNED NumElements1,
		       ParMultiGrid_3D *Com_3D)=0;
  
};

#endif
