#ifndef MG_INFO_H

#define MG_INFO_H

typedef struct MG_Info
{
    double       defect;
    double       defectReduction;
    double       relChange;
    double       convRate;
    unsigned int steps;
    double       omega;
} MG_Info;

#endif
