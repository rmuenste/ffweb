#include "ParMultiGrid_3D.h"
#include "ParCompactMatrix.h"

extern std::string progname;
extern double TSmooth;				  // time spent in smoothing routines
extern double TDefect;				  // time spent computing defect
extern double TRest;				  // time spent in restriction routines
extern double TProl;				  // time spent in prolongation routines
extern double TCoarse;				  // time needed for solving coarse grid problem
extern double TNorm;				  // time needed for calculating norms
extern double TEvalue;				  // ?
extern double TSmoothCom, TDefectCom, TRestCom,
              TProlCom, TCoarseCom, TNormCom;	  // communication time needed

ParMultiGrid_3D::ParMultiGrid_3D()
{
    for (int i = 1; i <= MAXMULTI; i++) {
        MVertCoord[i]      = 0;
        MMidCoord[i]       = 0;
        MVertElem[i]       = 0;
        MMidEdges[i]       = 0;
        MNeighElem[i]      = 0;
        MElemVert[i]       = 0;
        MElemEdge[i]       = 0;
        MInfoVertEdge[i]   = 0;
        MInfoVertBound[i]  = 0;
        MVertBound[i]      = 0;
        MElemBound[i]      = 0;
        MPosBoundEntry[i]  = 0;
        MVertParamBound[i] = 0;
        MMidParamBound[i]  = 0;

        MMidFaceCoord[i]  = 0;
        MMidEdges[i]      = 0;
        MMidFaces[i]      = 0;
        MElemMeetEdge[i]  = 0;
        MElemMeetFace[i]  = 0;
        MVertMeetEdge[i]  = 0;
        MFaceMeetEdge[i]  = 0;
        MVertMeetFace[i]  = 0;
        MEdgeMeetFace[i]  = 0;
        MElemMeetVert[i]  = 0;
        MFaceMeetVert[i]  = 0;
        MMidFacesBound[i] = 0;
    }
}

void ParMultiGrid_3D::SetTotalLevel(unsigned int P_TotalLevel)
{
  if (P_TotalLevel < 1)
      TotalLevel = 1;
  else if (P_TotalLevel > MAXMULTI)
      TotalLevel = MAXMULTI;
  else
      TotalLevel = P_TotalLevel;

  MinLevel = 1;
  MaxLevel = TotalLevel;
}

ParMultiGrid_3D::~ParMultiGrid_3D(void)
{
  int i;

  for (i = 1;i <= TotalLevel-1;i++) {
    if (MVertCoord[i])
        delete MVertCoord[i];
    if (MMidCoord[i])
        delete MMidCoord[i];
    if (MVertElem[i])
        delete MVertElem[i];
    if (MMidEdges[i])
        delete MMidEdges[i];
    if (MNeighElem[i])
        delete MNeighElem[i];
    if (MElemVert[i])
        delete MElemVert[i];
    if (MElemEdge[i])
        delete MElemEdge[i];
    if (MInfoVertEdge[i])
        delete MInfoVertEdge[i];
    if (MInfoVertBound[i])
        delete MInfoVertBound[i];
    if (MVertBound[i])
        delete MVertBound[i];
    if (MElemBound[i])
        delete MElemBound[i];
    if (MPosBoundEntry[i])
        delete MPosBoundEntry[i];
    if (MVertParamBound[i])
        delete MVertParamBound[i];
    if (MMidParamBound[i])
        delete MMidParamBound[i];

    if (MMidFaceCoord[i])
        delete MMidFaceCoord[i];
    if (MMidEdges[i])
        delete MMidEdges[i];
    if (MMidFaces[i])
        delete MMidFaces[i];
    if (MElemMeetEdge[i])
        delete MElemMeetEdge[i];
    if (MElemMeetFace[i])
        delete MElemMeetFace[i];
    if (MVertMeetEdge[i])
        delete MVertMeetEdge[i];
    if (MFaceMeetEdge[i])
        delete MFaceMeetEdge[i];
    if (MVertMeetFace[i])
        delete MVertMeetFace[i];
    if (MEdgeMeetFace[i])
        delete MEdgeMeetFace[i];
    if (MElemMeetVert[i])
        delete MElemMeetVert[i];
    if (MFaceMeetVert[i])
        delete MFaceMeetVert[i];
    if (MMidFacesBound[i])
        delete MMidFacesBound[i];
  }
}

void ParMultiGrid_3D::SetLevel(unsigned int ILEV)
{
    NumElements   = MNumElements[ILEV];
    NumVertices   = MNumVertices[ILEV];
    NumEdges      = MNumEdges[ILEV];
    NumVertElem   = MNumVertElem[ILEV];
    NumElemVert   = MNumElemVert[ILEV];
    NumVertBound  = MNumVertBound[ILEV];

    TotNumEdges   = MTotNumEdges[ILEV];
    TotNumFaces   = MTotNumFaces[ILEV];
    NumEdgeElem   = MNumEdgeElem[ILEV];
    NumFaceElem   = MNumFaceElem[ILEV];
    NumElemEdge   = MNumElemEdge[ILEV];
    NumEdgeVert   = MNumEdgeVert[ILEV];
    NumFaceVert   = MNumFaceVert[ILEV];
    NumFaceEdge   = MNumFaceEdge[ILEV];
    NumEdgesBound = MNumEdgesBound[ILEV];
    NumFacesBound = MNumFacesBound[ILEV];

    VertCoord     = MVertCoord[ILEV];
    MidCoord      = MMidCoord[ILEV];
    VertElem      = MVertElem[ILEV];
    MidEdges      = MMidEdges[ILEV];
    NeighElem     = MNeighElem[ILEV];
    ElemVert      = MElemVert[ILEV];
    ElemEdge      = MElemEdge[ILEV];
    InfoVertEdge  = MInfoVertEdge[ILEV];
    InfoVertBound = MInfoVertBound[ILEV];
    VertBound     = MVertBound[ILEV];
    ElemBound     = MElemBound[ILEV];
    PosBoundEntry = MPosBoundEntry[ILEV];

    MidFaceCoord  = MMidFaceCoord[ILEV];
    MidEdges      = MMidEdges[ILEV];
    MidFaces      = MMidFaces[ILEV];
    ElemMeetEdge  = MElemMeetEdge[ILEV];
    ElemMeetFace  = MElemMeetFace[ILEV];
    VertMeetEdge  = MVertMeetEdge[ILEV];
    FaceMeetEdge  = MFaceMeetEdge[ILEV];
    VertMeetFace  = MVertMeetFace[ILEV];
    EdgeMeetFace  = MEdgeMeetFace[ILEV];
    ElemMeetVert  = MElemMeetVert[ILEV];
    FaceMeetVert  = MFaceMeetVert[ILEV];
    MidFacesBound = MMidFacesBound[ILEV];

    ActiveLevel = ILEV;
}


void ParMultiGrid_3D::AssembleMatrices(FiniteElement_3D& Elem, MultiCompactMatrix* A,
                                       unsigned int BCON, IntArray2D& KAB,
                                       unsigned int KABN, unsigned int ICUB,
                                       unsigned int ISYMM, unsigned int ICLEAR,
                                       unsigned int ILINT)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::AssembleMatrices.\n";
        protocol.mFlush();
    }

    for (int ILEV = MinLevel; ILEV <= MaxLevel; ILEV++) {
        NumElements  = MNumElements[ILEV];
        NumVertices  = MNumVertices[ILEV];
        NumEdges     = MNumEdges[ILEV];
        NumVertElem  = MNumVertElem[ILEV];
        NumElemVert  = MNumElemVert[ILEV];
        NumVertBound = MNumVertBound[ILEV];

        TotNumEdges   = MTotNumEdges[ILEV];
        TotNumFaces   = MTotNumFaces[ILEV];
        NumEdgeElem   = MNumEdgeElem[ILEV];
        NumFaceElem   = MNumFaceElem[ILEV];
        NumElemEdge   = MNumElemEdge[ILEV];
        NumEdgeVert   = MNumEdgeVert[ILEV];
        NumFaceVert   = MNumFaceVert[ILEV];
        NumFaceEdge   = MNumFaceEdge[ILEV];
        NumEdgesBound = MNumEdgesBound[ILEV];
        NumFacesBound = MNumFacesBound[ILEV];

        VertCoord     = MVertCoord[ILEV];
        MidCoord      = MMidCoord[ILEV];
        VertElem      = MVertElem[ILEV];
        MidEdges      = MMidEdges[ILEV];
        NeighElem     = MNeighElem[ILEV];
        ElemVert      = MElemVert[ILEV];
        ElemEdge      = MElemEdge[ILEV];
        InfoVertEdge  = MInfoVertEdge[ILEV];
        InfoVertBound = MInfoVertBound[ILEV];
        VertBound     = MVertBound[ILEV];
        ElemBound     = MElemBound[ILEV];
        PosBoundEntry = MPosBoundEntry[ILEV];

        MidFaceCoord  = MMidFaceCoord[ILEV];
        MidEdges      = MMidEdges[ILEV];
        MidFaces      = MMidFaces[ILEV];
        ElemMeetEdge  = MElemMeetEdge[ILEV];
        ElemMeetFace  = MElemMeetFace[ILEV];
        VertMeetEdge  = MVertMeetEdge[ILEV];
        FaceMeetEdge  = MFaceMeetEdge[ILEV];
        VertMeetFace  = MVertMeetFace[ILEV];
        EdgeMeetFace  = MEdgeMeetFace[ILEV];
        ElemMeetVert  = MElemMeetVert[ILEV];
        FaceMeetVert  = MFaceMeetVert[ILEV];
        MidFacesBound = MMidFacesBound[ILEV];

        Elem.CalcStiffMatrix((*A)[ILEV], BCON, KAB, KABN, ICUB, ISYMM, ICLEAR, ILINT);

//      if (ICLEAR == TRUE)
            MNumEquations[ILEV] = Elem.GetNumEquations();
    } // end for loop

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::AssembleMatrices.\n";
        protocol.mFlush();
    }

    return;
}

void ParMultiGrid_3D::AssembleTopMatrix(FiniteElement_3D& Elem,
                                        DoubleCompactMatrix*& A,
                                        unsigned int BCON, IntArray2D& KAB,
                                        unsigned int KABN, unsigned int ICUB,
                                        unsigned int ISYMM, unsigned int ICLEAR,
                                        unsigned int ILINT)
{
  NumElements = MNumElements[MaxLevel];
  NumVertices = MNumVertices[MaxLevel];
  NumEdges = MNumEdges[MaxLevel];
  NumVertElem = MNumVertElem[MaxLevel];
  NumElemVert = MNumElemVert[MaxLevel];
  NumVertBound = MNumVertBound[MaxLevel];

  TotNumEdges = MTotNumEdges[MaxLevel];
  TotNumFaces = MTotNumFaces[MaxLevel];
  NumEdgeElem = MNumEdgeElem[MaxLevel];
  NumFaceElem = MNumFaceElem[MaxLevel];
  NumElemEdge = MNumElemEdge[MaxLevel];
  NumEdgeVert = MNumEdgeVert[MaxLevel];
  NumFaceVert = MNumFaceVert[MaxLevel];
  NumFaceEdge = MNumFaceEdge[MaxLevel];
  NumEdgesBound = MNumEdgesBound[MaxLevel];
  NumFacesBound = MNumFacesBound[MaxLevel];

  VertCoord = MVertCoord[MaxLevel];
  MidCoord = MMidCoord[MaxLevel];
  VertElem = MVertElem[MaxLevel];
  MidEdges = MMidEdges[MaxLevel];
  NeighElem = MNeighElem[MaxLevel];
  ElemVert = MElemVert[MaxLevel];
  ElemEdge = MElemEdge[MaxLevel];
  InfoVertEdge = MInfoVertEdge[MaxLevel];
  InfoVertBound = MInfoVertBound[MaxLevel];
  VertBound = MVertBound[MaxLevel];
  ElemBound = MElemBound[MaxLevel];
  PosBoundEntry = MPosBoundEntry[MaxLevel];

  MidFaceCoord = MMidFaceCoord[MaxLevel];
  MidEdges = MMidEdges[MaxLevel];
  MidFaces = MMidFaces[MaxLevel];
  ElemMeetEdge = MElemMeetEdge[MaxLevel];
  ElemMeetFace = MElemMeetFace[MaxLevel];
  VertMeetEdge = MVertMeetEdge[MaxLevel];
  FaceMeetEdge = MFaceMeetEdge[MaxLevel];
  VertMeetFace = MVertMeetFace[MaxLevel];
  EdgeMeetFace = MEdgeMeetFace[MaxLevel];
  ElemMeetVert = MElemMeetVert[MaxLevel];
  FaceMeetVert = MFaceMeetVert[MaxLevel];
  MidFacesBound = MMidFacesBound[MaxLevel];

  Elem.CalcStiffMatrix(A, BCON, KAB, KABN, ICUB, ISYMM, ICLEAR, ILINT);

  if (ICLEAR == TRUE)
      MNumEquations[MaxLevel]=Elem.GetNumEquations();
}


void ParMultiGrid_3D::AssembleRightHandSide(FiniteElement_3D& Elem, MultiVector f,
                                            unsigned int BCON, IntArray& KB,
                                            unsigned int KBN, unsigned int ICUB,
                                            unsigned int ICLEAR, unsigned int ILINT)
{
  for (int ILEV = MinLevel;ILEV <= MaxLevel;ILEV++) {
    NumElements = MNumElements[ILEV];
    NumVertices = MNumVertices[ILEV];
    NumEdges = MNumEdges[ILEV];
    NumVertElem = MNumVertElem[ILEV];
    NumElemVert = MNumElemVert[ILEV];
    NumVertBound = MNumVertBound[ILEV];

    TotNumEdges = MTotNumEdges[ILEV];
    TotNumFaces = MTotNumFaces[ILEV];
    NumEdgeElem = MNumEdgeElem[ILEV];
    NumFaceElem = MNumFaceElem[ILEV];
    NumElemEdge = MNumElemEdge[ILEV];
    NumEdgeVert = MNumEdgeVert[ILEV];
    NumFaceVert = MNumFaceVert[ILEV];
    NumFaceEdge = MNumFaceEdge[ILEV];
    NumEdgesBound = MNumEdgesBound[ILEV];
    NumFacesBound = MNumFacesBound[ILEV];

    VertCoord = MVertCoord[ILEV];
    MidCoord = MMidCoord[ILEV];
    VertElem = MVertElem[ILEV];
    MidEdges = MMidEdges[ILEV];
    NeighElem = MNeighElem[ILEV];
    ElemVert = MElemVert[ILEV];
    ElemEdge = MElemEdge[ILEV];
    InfoVertEdge = MInfoVertEdge[ILEV];
    InfoVertBound = MInfoVertBound[ILEV];
    VertBound = MVertBound[ILEV];
    ElemBound = MElemBound[ILEV];
    PosBoundEntry = MPosBoundEntry[ILEV];

    MidFaceCoord = MMidFaceCoord[ILEV];
    MidEdges = MMidEdges[ILEV];
    MidFaces = MMidFaces[ILEV];
    ElemMeetEdge = MElemMeetEdge[ILEV];
    ElemMeetFace = MElemMeetFace[ILEV];
    VertMeetEdge = MVertMeetEdge[ILEV];
    FaceMeetEdge = MFaceMeetEdge[ILEV];
    VertMeetFace = MVertMeetFace[ILEV];
    EdgeMeetFace = MEdgeMeetFace[ILEV];
    ElemMeetVert = MElemMeetVert[ILEV];
    FaceMeetVert = MFaceMeetVert[ILEV];
    MidFacesBound = MMidFacesBound[ILEV];

    Elem.CalcRightSide(f[ILEV], BCON, KB, KBN, ICUB, ICLEAR, ILINT);
  }
}

void ParMultiGrid_3D::CalcRightSide(FiniteElement_3D& Elem, DoubleVector*& LB,
                                    unsigned int BCON, IntArray& KB,
                                    unsigned int KBN, unsigned int ICUB, unsigned int ICLEAR,
                                    unsigned int ILINT)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::CalcRightSide.\n";
        protocol.mFlush();
    }

    NumElements   = MNumElements[MaxLevel];
    NumVertices   = MNumVertices[MaxLevel];
    NumEdges      = MNumEdges[MaxLevel];
    NumVertElem   = MNumVertElem[MaxLevel];
    NumElemVert   = MNumElemVert[MaxLevel];
    NumVertBound  = MNumVertBound[MaxLevel];

    TotNumEdges   = MTotNumEdges[MaxLevel];
    TotNumFaces   = MTotNumFaces[MaxLevel];
    NumEdgeElem   = MNumEdgeElem[MaxLevel];
    NumFaceElem   = MNumFaceElem[MaxLevel];
    NumElemEdge   = MNumElemEdge[MaxLevel];
    NumEdgeVert   = MNumEdgeVert[MaxLevel];
    NumFaceVert   = MNumFaceVert[MaxLevel];
    NumFaceEdge   = MNumFaceEdge[MaxLevel];
    NumEdgesBound = MNumEdgesBound[MaxLevel];
    NumFacesBound = MNumFacesBound[MaxLevel];

    VertCoord     = MVertCoord[MaxLevel];
    MidCoord      = MMidCoord[MaxLevel];
    VertElem      = MVertElem[MaxLevel];
    MidEdges      = MMidEdges[MaxLevel];
    NeighElem     = MNeighElem[MaxLevel];
    ElemVert      = MElemVert[MaxLevel];
    ElemEdge      = MElemEdge[MaxLevel];
    InfoVertEdge  = MInfoVertEdge[MaxLevel];
    InfoVertBound = MInfoVertBound[MaxLevel];
    VertBound     = MVertBound[MaxLevel];
    ElemBound     = MElemBound[MaxLevel];
    PosBoundEntry = MPosBoundEntry[MaxLevel];

    MidFaceCoord  = MMidFaceCoord[MaxLevel];
    MidEdges      = MMidEdges[MaxLevel];
    MidFaces      = MMidFaces[MaxLevel];
    ElemMeetEdge  = MElemMeetEdge[MaxLevel];
    ElemMeetFace  = MElemMeetFace[MaxLevel];
    VertMeetEdge  = MVertMeetEdge[MaxLevel];
    FaceMeetEdge  = MFaceMeetEdge[MaxLevel];
    VertMeetFace  = MVertMeetFace[MaxLevel];
    EdgeMeetFace  = MEdgeMeetFace[MaxLevel];
    ElemMeetVert  = MElemMeetVert[MaxLevel];
    FaceMeetVert  = MFaceMeetVert[MaxLevel];
    MidFacesBound = MMidFacesBound[MaxLevel];

    Elem.CalcRightSide(LB, BCON, KB, KBN, ICUB, ICLEAR, ILINT);

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::CalcRightSide.\n";
        protocol.mFlush();
    }

    return;
}


DoubleVector* ParMultiGrid_3D::GetRightSideVector(FiniteElement_3D& Elem)
{
  NumElements  = MNumElements[MaxLevel];
  NumVertices  = MNumVertices[MaxLevel];
  NumEdges     = MNumEdges[MaxLevel];
  NumVertElem  = MNumVertElem[MaxLevel];
  NumElemVert  = MNumElemVert[MaxLevel];
  NumVertBound = MNumVertBound[MaxLevel];

  VertCoord     = MVertCoord[MaxLevel];
  MidCoord      = MMidCoord[MaxLevel];
  VertElem      = MVertElem[MaxLevel];
  MidEdges      = MMidEdges[MaxLevel];
  NeighElem     = MNeighElem[MaxLevel];
  ElemVert      = MElemVert[MaxLevel];
  ElemEdge      = MElemEdge[MaxLevel];
  InfoVertEdge  = MInfoVertEdge[MaxLevel];
  InfoVertBound = MInfoVertBound[MaxLevel];
  VertBound     = MVertBound[MaxLevel];
  ElemBound     = MElemBound[MaxLevel];
  PosBoundEntry = MPosBoundEntry[MaxLevel];

  return Elem.GetRightSideVector();
}


// for stepsize control

// sx1=(A*x1, y)
// sx2=(A*x2, y)
double ParMultiGrid_3D::StepControl(DoubleCompactMatrix *A, DoubleVector& x,
                                    DoubleVector& d, DoubleVector& f,
				    double AMin, double AMax)
{
    double aux1, aux2, alpha, returnValue;

    // AMin == AMax  &&  AMin == 1.0
    if (fabs(AMin - AMax) < FLOAT_EPS  &&  fabs(AMin - 1.0) < FLOAT_EPS) {
	returnValue = 1.0;
    } else {
	ParVector *aux = new ParVector(x.GetLen());

	((ParCompactMatrix*)A)->ParVectMult(x, *aux, (Task*)this);
	aux1 = aux->ScalProd(d, (Task*)this);
	((ParCompactMatrix*)A)->ParVectMult(d, *aux, (Task*)this);
	aux2 = aux->ScalProd(d, (Task*)this);

	alpha = ((ParVector&)f).ScalProd(d, (Task*)this);

	delete aux;

	if (fabs(aux2) > 1e-20) {
	    returnValue = (alpha - aux1) / aux2;
	    if (returnValue < AMin)
		returnValue = AMin;
	    if (returnValue > AMax)
		returnValue = AMax;
	} else {
	    returnValue = 1.0;
	}
    }

    return returnValue;
}

double ParMultiGrid_3D::ConstStepControl(DoubleCompactMatrix *A, DoubleVector& x,
					 DoubleVector& d, DoubleVector& f,
					 double AMin, double AMax)
{
    double aux1, aux2, alpha, t, returnValue;

    // AMin == AMax  &&  AMin == 1.0
    if (fabs(AMin - AMax) < FLOAT_EPS  &&  fabs(AMin - 1.0) < FLOAT_EPS) {
	returnValue = 1.0;
    } else {
	ParVector *aux = new ParVector(x.GetLen());

	CVectMult(A, x, *aux, t);
	aux1 = aux->ConstScalProd(d, (Task*)this);
	CVectMult(A, d, *aux, t);
	aux2 = aux->ConstScalProd(d, (Task*)this);

	alpha=((ParVector&)f).ConstScalProd(d, (Task*)this);

	delete aux;

	if (fabs(aux2) > 1e-20) {
	    returnValue = (alpha - aux1) / aux2;
	    if (returnValue < AMin)
		returnValue = AMin;
	    if (returnValue > AMax)
		returnValue = AMax;
	} else {
	    returnValue = 1.0;
	}
    }

    return returnValue;
}


MG_Info ParMultiGrid_3D::MultiDriver(ParFiniteElement_3D& Elem, MultiCompactMatrix* A,
                                     DoubleVector *LX1, DoubleVector *LB1, double l2normX,
                                     unsigned int MinIterations, unsigned int MaxIterations,
                                     double EpsUChange, double EpsUDefect, double DampU,
                                     double AMin, double AMax)
// Solve within 'MaxIterations' fixpoint iterations the equation
//          A * LX1 = LB1
// with multigrid method where the
// * the relative change of LX1 must be less than EpsUChange        and
// * the defect LB1 - A * LX1 must be less than EpsUDefect          and
// * the final defect must be less than initial defect times DampU
{
    double       defectInitial, defectOld;
    double       alpha;
    MG_Info      mgInfo = { -100, -100, -100, -100, 0, -100 };
    unsigned int ITE = 0;
    int          flag;
//      MemInfo Space;
//      Space.GetFreeSpace();

#ifdef CLOCK_MEASURE
    DateTime ClockSingleOperation;
    DateTime ClockMG;
    DateTime ClockHelp;
    double   TAll = 0;
#endif

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::MultiDriver.\n";
        protocol.mFlush();
    }

    if (MaxLevel < MinLevel  ||  MinLevel <= 0  ||  MaxLevel > MAXMULTI) {
        Err << "Wrong Parameter MaxLevel or MinLevel !!\n";
        return mgInfo;
    }

    if (LX1 == 0)
        LX1 = new DoubleVector(MNumEquations[MaxLevel]);

    if (LB1 == 0)
        LB1 = new DoubleVector(MNumEquations[MaxLevel]);

    if (LX1->GetLen() < MNumEquations[MaxLevel]  ||  LB1->GetLen() < MNumEquations[MaxLevel]) {
        delete LX1; delete LB1;
        LX1 = new DoubleVector(MNumEquations[MaxLevel]);
        LB1 = new DoubleVector(MNumEquations[MaxLevel]);
        Prot << "MultiGrid: new vectors LX1 and LB1 !!\n";
    }

    // Allocate a family of vectors for ...
    DoubleVector *LX[MAXARRAY];                   // ... the current solution
    DoubleVector *LB[MAXARRAY];                   // ... the current right hand side
    DoubleVector *LD[MAXARRAY];                   // ... the current defect

    // Allocate memory for each member of a family
    for (ActiveLevel = MinLevel;  ActiveLevel < MaxLevel;  ActiveLevel++) {
        LX[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
        LB[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
        LD[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
    }

    // Initializing phase
    LX[MaxLevel] = LX1;
    LB[MaxLevel] = LB1;
    LD[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);


    // only one level?
    if (MinLevel == MaxLevel) {
        (*LX[MaxLevel]) = (*LB[MaxLevel]);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        CommunicateExact(LX[MaxLevel]);
#ifdef CLOCK_MEASURE
        TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

    } else {
        // multilevel
        unsigned int KITO[MAXMULTI], KIT[MAXMULTI];

#ifdef CLOCK_MEASURE
        ClockMG.SetTime();
#endif
	// F-, V- or W-cycle
        KITO[MaxLevel] = 1;
        for (ActiveLevel = MinLevel + 1;  ActiveLevel < MaxLevel;  ActiveLevel++) {
            if (Cycle == 0)
                KITO[ActiveLevel] = 2;
            else
                KITO[ActiveLevel] = Cycle;
        }
//          ActiveLevel = MaxLevel;

//  #ifdef CLOCK_MEASURE
//  	ClockSingleOperation.SetTime();
//  #endif

//          if (PreSmSteps > 0)
//              PreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps, AMin, AMax);
//  #ifdef CLOCK_MEASURE
//  	TSmooth += ClockSingleOperation.GetTimeDiff();
//          ClockSingleOperation.SetTime();
//  #endif

//          // Calculate initial defect: LD = LB - A * LX in 3 steps
//          // Step 1: LD = A * LX;
//          (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);

//  #ifdef CLOCK_MEASURE
//          ClockHelp.SetTime();
//  #endif
//          SetBoundValues(LD[MaxLevel]);
//          Communicate();
//          GetBoundValuesMult(LD[MaxLevel]);
//  #ifdef CLOCK_MEASURE
//          TDefectCom += ClockHelp.GetTimeDiff();
//  #endif
//          // Step 2: LD = - A * LX;
//          (*LD[MaxLevel]) *= -1;

//          // Step 3: LD = - A * LX + LB;
//          (*LD[MaxLevel]) += (*LB[MaxLevel]);
//          // ... done

//  #ifdef CLOCK_MEASURE
//          TDefect += ClockSingleOperation.GetTimeDiff();
//          ClockHelp.SetTime();
//  #endif
//          ActiveLevel--;

#ifdef CLOCK_MEASURE
	ClockHelp.SetTime();
#endif

        // Compute l2 norm of defect
        mgInfo.defect = l2norm(LB1);
        defectInitial = defectOld = mgInfo.defect;

#ifdef CLOCK_MEASURE
        TNorm += ClockHelp.GetTimeDiff();
#endif

        // Start iteration
        for (ITE = 1;  ITE <= MaxIterations;  ITE++) {
            for (ActiveLevel = MinLevel;  ActiveLevel <= MaxLevel;  ActiveLevel++)
                KIT[ActiveLevel] = KITO[ActiveLevel];

            ActiveLevel = MaxLevel;
            do {
                // Descend to coarsest level (= MinLevel),
                // i.e. pre-smooth and restrict.
                while (ActiveLevel != MinLevel) {
                    // Pre-Smoothing
//  #ifdef CLOCK_MEASURE
//  		    ClockSingleOperation.SetTime();
//  #endif
                    if (PreSmSteps > 0)
                        PreSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PreSmSteps, AMin, AMax);

#ifdef CLOCK_MEASURE
//  		    TSmooth += ClockSingleOperation.GetTimeDiff();
                    ClockSingleOperation.SetTime();
#endif

                    // Calculate defect LD = LB - A * LX in three steps
                    // Step 1: LD = A * LX
                    (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel], *LD[ActiveLevel]);

#ifdef CLOCK_MEASURE
                    ClockHelp.SetTime();
#endif
                    SetBoundValues(LD[ActiveLevel]);
                    Communicate();
                    GetBoundValuesMult(LD[ActiveLevel]);
#ifdef CLOCK_MEASURE
                    TDefectCom += ClockHelp.GetTimeDiff();
#endif

                    // Step 2: LD = -A * LX
                    (*LD[ActiveLevel]) *= -1;

                    // Step 3: LD = LB - A * LX
                    (*LD[ActiveLevel]) += (*LB[ActiveLevel]);
                    // .. done

#ifdef CLOCK_MEASURE
                    TDefect += ClockSingleOperation.GetTimeDiff();
#endif
                    ActiveLevel--;

                    // Restriction of defect
                    Elem.ParRestrict(LD[ActiveLevel+1],           LB[ActiveLevel],
                                     MVertElem[ActiveLevel+1],    MVertElem[ActiveLevel],
                                     MMidFaces[ActiveLevel+1],    MMidFaces[ActiveLevel],
                                     MNeighElem[ActiveLevel+1],   MNeighElem[ActiveLevel],
                                     MNumVertices[ActiveLevel+1], MNumVertices[ActiveLevel],
                                     MNumElements[ActiveLevel+1], MNumElements[ActiveLevel],
                                     this);

                    // Choose zero as initial vector on lower level
                    (*LX[ActiveLevel]) = 0;
                    CopyBoundaryData(LB[ActiveLevel]);
                } // end while(ActiveLevel != MinLevel)

                // Exact solution on lowest level
                (*LX[MinLevel]) = (*LB[MinLevel]);

#ifdef CLOCK_MEASURE
                ClockSingleOperation.SetTime();
#endif
		CommunicateExact(LX[MinLevel]);
#ifdef CLOCK_MEASURE
                TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

                // Ascend to finest level (= MaxLevel),
                // i.e. prolongate and post-smooth.
                while (ActiveLevel != MaxLevel) {
                    ActiveLevel++;
                    Elem.ParProl(LX[ActiveLevel - 1],       LD[ActiveLevel],
                                 MVertElem[ActiveLevel],    MVertElem[ActiveLevel - 1],
                                 MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel - 1],
                                 MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel - 1],
                                 MNumVertices[ActiveLevel], MNumVertices[ActiveLevel - 1],
                                 MNumElements[ActiveLevel], MNumElements[ActiveLevel - 1],
                                 this);
                    CopyBoundaryData(LD[ActiveLevel]);

                    // Update solution: LX = LX + alpha * LD
                    alpha = StepControl((*A)[ActiveLevel], *LX[ActiveLevel],
                                         *LD[ActiveLevel], *LB[ActiveLevel],
					 AMin, AMax);
//                  protocol << "     alpha = " << double_to_string(alpha, "e", 3)
//                           << " on level " << int_to_string(ActiveLevel) << "\n";
		    if (! isnan(alpha))	{	       // NaN can happen when right side is zero,
			(*LD[ActiveLevel]) *= alpha;   // thus defect is zero
		    }
                    (*LX[ActiveLevel]) += (*LD[ActiveLevel]);
//  #ifdef CLOCK_MEASURE
//                      ClockSingleOperation.SetTime();
//  #endif
                    if (PostSmSteps > 0)
                        PostSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PostSmSteps, AMin, AMax);
//  #ifdef CLOCK_MEASURE
//  		    TSmooth += ClockSingleOperation.GetTimeDiff();
//  #endif

                    KIT[ActiveLevel] = KIT[ActiveLevel] - 1;
                    if (KIT[ActiveLevel] == 0) {
                        if (Cycle == 0)
                            KIT[ActiveLevel] = 1;
                        else
                            KIT[ActiveLevel] = KITO[ActiveLevel];
                    } else {
                        break;
                    }
                }
            } while (ActiveLevel != MaxLevel);

//  #ifdef CLOCK_MEASURE
//  	    ClockSingleOperation.SetTime();
//  #endif
//  	    // Smooth on finest level
//              if (PreSmSteps > 0)
//                  PreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps, AMin, AMax);
//  #ifdef CLOCK_MEASURE
//  	    TSmooth += ClockSingleOperation.GetTimeDiff();
//  #endif
#ifdef CLOCK_MEASURE
            ClockSingleOperation.SetTime();
#endif

            // Calculate new defect LD = LB - A * LX in three steps
            // Step 1: LD = A * LX
            (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);

#ifdef CLOCK_MEASURE
            ClockHelp.SetTime();
#endif
            SetBoundValues(LD[MaxLevel]);
            Communicate();
            GetBoundValuesMult(LD[MaxLevel]);
#ifdef CLOCK_MEASURE
            TDefectCom += ClockHelp.GetTimeDiff();
#endif

            // Step 2: LD = -A * LX
            (*LD[MaxLevel]) *= -1;

            // Step 3: LD = LB - A * LX
            (*LD[MaxLevel]) += (*LB[MaxLevel]);
            // .. done

#ifdef CLOCK_MEASURE
            TDefect += ClockSingleOperation.GetTimeDiff();
            ClockSingleOperation.SetTime();
#endif
            // Compute relative change of solution, i.e.
	    //   || x_{n+1} - x_{n} || / || x_{n} ||
	    // = || lx || / || x_{n} ||
	    if (fabs(l2normX) < 1e-16) {	  // l2normX == 0 ?
		mgInfo.relChange = 0;
	    } else {
		mgInfo.relChange = l2norm(LX[MaxLevel]) / l2normX;
	    }

            // Compute current defect of solution
            mgInfo.defect = l2norm(LD[MaxLevel]);

	    Prot << "     ParMultiGrid ITERATION " << ITE << "   !!RES!! = " << mgInfo.defect << "\n";

#ifdef CLOCK_MEASURE
            TNorm += ClockSingleOperation.GetTimeDiff();
#endif

	    // Here, we can actually control how accurate the equation is solved.
	    // There are many possibilities: Check, whether
            // (a) defect <= EpsUDefect
            // (b) defect <= defectInitial * DampU
            // (c) relChange <= EpsUChange

	    // Only (a)
//	    flag = StopCriterion(mgInfo.defect, EpsUDefect);
//  #ifdef MG_DEBUG
//    	    protocol << "MG_DEBUG: ITE: " << ITE << "\n"
//  		     << "MG_DEBUG: " << "        defect    ?<? EpsDefect\n"
//  		     << "MG_DEBUG: "
//  		     << mgInfo.defect << " ?<? " << EpsUDefect
//		     << "  (Iteration " << ITE << ")\n";
//  #endif

	    // Only (b)
	    flag = StopCriterion(mgInfo.defect, defectInitial * DampU);
#ifdef MG_DEBUG
  	    protocol << "MG_DEBUG: ITE: " << ITE << "\n"
		     << "MG_DEBUG: " << "        defect   ?<? defectInitial * DampU\n"
		     << "MG_DEBUG: "
		     << mgInfo.defect << " ?<? " << defectInitial * DampU 
		     << "  (Iteration " << ITE << ")\n";
#endif

	    // (a) + (b) + (c)
//              flag = StopCriterion(mgInfo.defect, defectInitial, mgInfo.relChange, EpsUDefect, DampU, EpsUChange);
//  #ifdef MG_DEBUG
//    	    protocol << "MG_DEBUG: ITE: " << ITE << "\n"
//  		     << "MG_DEBUG: " << "        defect    ?<? EpsDefect         defect   ?<? defectInitial * DampU      relChange  ?<? EpsChange\n"
//  		     << "MG_DEBUG: "
//  		     << mgInfo.defect << " ?<? " << EpsUDefect << "    "
//  		     << mgInfo.defect << " ?<? " << defectInitial * DampU << "   "
//  		     << mgInfo.relChange << " ?<? " << EpsUChange
//		     << "  (Iteration " << ITE << ")\n";
//  #endif

            if (flag == CRIT_TRUE  &&  ITE >= MinIterations)
                break;

            // Set values for the next iteration
            defectOld = mgInfo.defect;
        } // end for (ITE = 1;  ITE <= MaxIterations;  ITE++)
    }

#ifdef MG_DEBUG
    protocol << "MG_DEBUG: ----\n";
#endif
#ifdef CLOCK_MEASURE
    TAll += ClockMG.GetTimeDiff();
#endif

    if (defectInitial > 1e-20)
        mgInfo.defectReduction = mgInfo.defect / defectInitial;
    else
        mgInfo.defectReduction = 0;

    // If we reached the maximum number of allowed iterations, ITE will be one
    // more than MaxIterations. Hence, reset this value
    if (ITE > MaxIterations)
        ITE--;

    Prot << "MultiGrid ITERATIONS " << ITE
         << "  NORM OF RESIDUAL " << mgInfo.defect << "\n      "
         << "  !!RES!!/!!INITIAL RES!!" << mgInfo.defectReduction << "\n"
         << "  --> RATE OF CONVERGENCE " << pow(mgInfo.defectReduction, 1.0 / (double)(ITE)) << "\n";

    for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
        delete LX[ActiveLevel];
        delete LB[ActiveLevel];
        delete LD[ActiveLevel];
    }
    delete LD[MaxLevel];

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::MultiDriver.\n";
        protocol.mFlush();
    }

    mgInfo.convRate = pow(mgInfo.defectReduction, 1.0 / (double)(ITE));
    mgInfo.steps    = ITE;

    return mgInfo;
}


MG_Info ParMultiGrid_3D::MultiDriverSmooth(ParFiniteElement_3D& Elem, MultiCompactMatrix* A,
                                           DoubleVector *LX1, DoubleVector *LB1, double l2normX,
                                           unsigned int MaxIterations,
                                           double EpsUDefect,
                                           int StartLevel,
                                           double AMin, double AMax)
// Difference to ParMultiGrid_3D::MultiDriver:
// * use of parameter StartLevel instead of global value MaxLevel
// * use of MultiPre/PostSmooth instead of Pre/PostSmooth
{
    double       defectInitial, defectOld;
    double       alpha;
    MG_Info      mgInfo = { -100, -100, -100, -100, 0, -100 };
    unsigned int ITE = 0;
    int          flag;

#ifdef CLOCK_MEASURE
    DateTime ClockSingleOperation;
    DateTime ClockMG;
    DateTime ClockHelp;
    double   TAll = 0;
#endif

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::MultiDriverSmooth.\n";
        protocol.mFlush();
    }

    if (MaxLevel < MinLevel  ||  MinLevel <= 0  ||  MaxLevel > MAXMULTI) {
        Err << "Wrong Parameter MaxLevel or MinLevel !!\n";
        return mgInfo;
    }

    if (LX1 == 0)
        LX1 = new DoubleVector(MNumEquations[StartLevel]);

    if (LB1 == 0)
        LB1 = new DoubleVector(MNumEquations[StartLevel]);

    if (LX1->GetLen() < MNumEquations[StartLevel]  ||  LB1->GetLen() < MNumEquations[StartLevel]) {
        delete LX1; delete LB1;
        LX1 = new DoubleVector(MNumEquations[StartLevel]);
        LB1 = new DoubleVector(MNumEquations[StartLevel]);
        Prot << "MultiGrid: new vectors LX1 and LB1 !!\n";
    }

    // Allocate a family of vectors for ...
    DoubleVector *LX[MAXARRAY];                   // ... the current solution
    DoubleVector *LB[MAXARRAY];                   // ... the current right hand side
    DoubleVector *LD[MAXARRAY];                   // ... the current defect

    // Allocate memory for each member of a family
    for (ActiveLevel = MinLevel; ActiveLevel < StartLevel; ActiveLevel++) {
        LX[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
        LB[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
        LD[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
    }

    // Initializing phase
    LX[StartLevel] = LX1;
    LB[StartLevel] = LB1;
    LD[StartLevel] = new DoubleVector(MNumEquations[StartLevel]);

    // only one level?
    if (MinLevel == StartLevel) {
        (*LX[StartLevel]) = (*LB[StartLevel]);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        CommunicateExact(LX[StartLevel]);
#ifdef CLOCK_MEASURE
        TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

    } else {
        // multilevel
        unsigned int KITO[MAXMULTI], KIT[MAXMULTI];

#ifdef CLOCK_MEASURE
        ClockMG.SetTime();
#endif
        KITO[StartLevel] = 1;
        for (ActiveLevel = MinLevel + 1;  ActiveLevel < StartLevel;  ActiveLevel++) {
            if (Cycle == 0)
                KITO[ActiveLevel] = 2;
            else
                KITO[ActiveLevel] = Cycle;
        }
//          ActiveLevel = StartLevel;

//  //      Prot<<"before presmooth x=\n";
//  //      OutputVector(LX[StartLevel], StartLevel);
//  //      Prot<<"before presmooth b=\n";
//  //      OutputVector(LB[StartLevel], StartLevel);

//  //      ClockSingleOperation.SetTime();
//  //      if (PreSmSteps > 0)
//  //          PreSmooth(A, LX[StartLevel], LB[StartLevel], PreSmSteps, AMin, AMax);
//  //      TSmooth += ClockSingleOperation.GetTimeDiff();

//  //      Prot << "after presmooth x=\n";
//  //      OutputVector(LX[StartLevel], StartLevel);

//  #ifdef CLOCK_MEASURE
//          ClockSingleOperation.SetTime();
//  #endif

//          // Calculate initial defect: LD = LB - A * LX in 3 steps
//          // Step 1: LD = A * LX;
//          (*A)[StartLevel]->VectMult(*LX[StartLevel], *LD[StartLevel]);

//  #ifdef CLOCK_MEASURE
//          ClockHelp.SetTime();
//  #endif
//          SetBoundValues(LD[StartLevel]);
//          Communicate();
//          GetBoundValuesMult(LD[StartLevel]);
//  #ifdef CLOCK_MEASURE
//          TDefectCom += ClockHelp.GetTimeDiff();
//  #endif
//          // Step 2: LD = - A * LX;
//          (*LD[StartLevel]) *= -1;

//          // Step 3: LD = - A * LX + LB;
//          (*LD[StartLevel]) += (*LB[StartLevel]);
//          // ... done

//  //      Prot<<"defect d=\n";
//  //      OutputVector(LD[StartLevel], StartLevel);
//  //      Prot<<"x=\n"<<*LX[StartLevel]<<"\n";
//  //      Prot<<"b=\n"<<*LB[StartLevel]<<"\n";

//  #ifdef CLOCK_MEASURE
//          TDefect += ClockSingleOperation.GetTimeDiff();
//  #endif

//          ActiveLevel--;

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        // Compute l2 norm of defect
        mgInfo.defect = l2norm(LB1);
        defectInitial = defectOld = mgInfo.defect;
#ifdef CLOCK_MEASURE
        TNorm += ClockSingleOperation.GetTimeDiff();
#endif

        // Do at least one iteration!
//      // Test whether defect measured in l2 norm satisfies given tolerance (defectInitial < EpsUDefect)
//      flag = StopCriterion(FD, 1.0, 0.0, EPS, 1.0, 0.0);
//      if (flag == CRIT_FALSE) {


        // Start iteration
        for (ITE = 1;  ITE <= MaxIterations;  ITE++) {
            for (ActiveLevel = MinLevel;  ActiveLevel <= StartLevel; ActiveLevel++)
                KIT[ActiveLevel] = KITO[ActiveLevel];

            ActiveLevel = StartLevel;
            do {
                // Descend to coarsest level (= MinLevel),
                // i.e. pre-smooth and restrict.
                while (ActiveLevel != MinLevel) {
                    // Pre-Smoothing
//                  Prot << "before presmooth x = \n";
//                  OutputVector(LX[ActiveLevel], ActiveLevel);
//  #ifdef CLOCK_MEASURE
//  		    ClockSingleOperation.SetTime();
//  #endif
                    if (PreSmSteps > 0)
                        MultiPreSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PreSmSteps);
#ifdef CLOCK_MEASURE
//  		    TSmooth += ClockSingleOperation.GetTimeDiff();
                    ClockSingleOperation.SetTime();
#endif
//                  Prot << "After presmooth x = \n";
//                  OutputVector(LX[ActiveLevel], ActiveLevel);

                    // Calculate defect LD = LB - A * LX in three steps
                    // Step 1: LD = A * LX
                    (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel], *LD[ActiveLevel]);

#ifdef CLOCK_MEASURE
                    ClockHelp.SetTime();
#endif
                    SetBoundValues(LD[ActiveLevel]);
                    Communicate();
                    GetBoundValuesMult(LD[ActiveLevel]);
#ifdef CLOCK_MEASURE
                    TDefectCom += ClockHelp.GetTimeDiff();
#endif

                    // Step 2: LD = -A * LX
                    (*LD[ActiveLevel]) *= -1;

                    // Step 3: LD = LB - A * LX
                    (*LD[ActiveLevel]) += (*LB[ActiveLevel]);
                    // .. done

//                  Prot << "After defect x = \n";
//                  OutputVector(LD[ActiveLevel], ActiveLevel);

#ifdef CLOCK_MEASURE
                    TDefect += ClockSingleOperation.GetTimeDiff();
#endif

                    ActiveLevel--;

                    // Restriction of defect
                    Elem.ParRestrict(LD[ActiveLevel+1],           LB[ActiveLevel],
                                     MVertElem[ActiveLevel+1],    MVertElem[ActiveLevel],
                                     MMidFaces[ActiveLevel+1],    MMidFaces[ActiveLevel],
                                     MNeighElem[ActiveLevel+1],   MNeighElem[ActiveLevel],
                                     MNumVertices[ActiveLevel+1], MNumVertices[ActiveLevel],
                                     MNumElements[ActiveLevel+1], MNumElements[ActiveLevel],
                                     this);

//                  Prot << "After Restrict b = \n";
//                  OutputVector(LB[ActiveLevel], ActiveLevel);

                    // Choose zero as initial vector on lower level
                    (*LX[ActiveLevel]) = 0;
                    CopyBoundaryData(LB[ActiveLevel]);

//                  Prot << "After copy boundary b = \n";
//                  OutputVector(LB[ActiveLevel], ActiveLevel);
                } // end while(ActiveLevel != MinLevel)

                // Exact solution on lowest level
                (*LX[MinLevel]) = (*LB[MinLevel]);

#ifdef CLOCK_MEASURE
                ClockSingleOperation.SetTime();
#endif

//              OutputVector(LX[MinLevel], ActiveLevel);

                CommunicateExact(LX[MinLevel]);

//              Prot << "After solve exact x = \n";
//              OutputVector(LX[MinLevel], MinLevel);

#ifdef CLOCK_MEASURE
                TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

                // Ascend to finest level (= StartLevel),
                // i.e. prolongate and post-smooth.
                while (ActiveLevel != StartLevel) {
                    ActiveLevel++;

//                  *LX[ActiveLevel - 1] = 1.0;

                    Elem.ParProl(LX[ActiveLevel - 1],       LD[ActiveLevel],
                                 MVertElem[ActiveLevel],    MVertElem[ActiveLevel - 1],
                                 MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel - 1],
                                 MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel - 1],
                                 MNumVertices[ActiveLevel], MNumVertices[ActiveLevel - 1],
                                 MNumElements[ActiveLevel], MNumElements[ActiveLevel - 1],
                                 this);

//                  Prot << "After prol d = \n";
//                  OutputVector(LD[ActiveLevel], ActiveLevel);

                    CopyBoundaryData(LD[ActiveLevel]);

                    // Update solution: LX = LX + alpha * LD
                    alpha = StepControl((*A)[ActiveLevel], *LX[ActiveLevel],
                                         *LD[ActiveLevel], *LB[ActiveLevel],
					 AMin, AMax);
//                  protocol << "     alpha = " << double_to_string(alpha, "e", 3)
//                           << " on level " << int_to_string(ActiveLevel) << "\n";
		    if (! isnan(alpha))	{	       // NaN can happen when right side is zero,
			(*LD[ActiveLevel]) *= alpha;   // thus defect is zero
		    }
                    (*LX[ActiveLevel]) += (*LD[ActiveLevel]);

//  #ifdef CLOCK_MEASURE
//                      ClockSingleOperation.SetTime();
//  #endif
                    if (PostSmSteps > 0)
                        MultiPostSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PostSmSteps);
//  #ifdef CLOCK_MEASURE
//  		    TSmooth += ClockSingleOperation.GetTimeDiff();
//  #endif

                    KIT[ActiveLevel] = KIT[ActiveLevel] - 1;
                    if (KIT[ActiveLevel] == 0) {
                        if (Cycle == 0)
                            KIT[ActiveLevel] = 1;
                        else
                            KIT[ActiveLevel] = KITO[ActiveLevel];
                    } else {
                        break;
                    }
                }
            } while (ActiveLevel != StartLevel);

//  #ifdef CLOCK_MEASURE
//              ClockSingleOperation.SetTime();
//  #endif
//              if (PreSmSteps > 0)
//                  MultiPreSmooth(A, LX[StartLevel], LB[StartLevel], PreSmSteps);
//  #ifdef CLOCK_MEASURE
//              TSmooth += ClockSingleOperation.GetTimeDiff();
//  #endif

#ifdef CLOCK_MEASURE
            ClockSingleOperation.SetTime();
#endif

            // Calculate new defect LD = LB - A * LX in three steps
            // Step 1: LD = A * LX
            (*A)[StartLevel]->VectMult(*LX[StartLevel], *LD[StartLevel]);

#ifdef CLOCK_MEASURE
            ClockHelp.SetTime();
#endif
            SetBoundValues(LD[StartLevel]);
            Communicate();
            GetBoundValuesMult(LD[StartLevel]);
#ifdef CLOCK_MEASURE
            TDefectCom += ClockHelp.GetTimeDiff();
#endif

            // Step 2: LD = -A * LX
            (*LD[StartLevel]) *= -1;

            // Step 3: LD = LB - A * LX
            (*LD[StartLevel]) += (*LB[StartLevel]);
            // .. done

//          Prot << "Before norm d = \n";
//          OutputVector(LD[StartLevel], StartLevel);

//          Prot << "Before norm d = \n" << *LD[StartLevel] << "\n";

#ifdef CLOCK_MEASURE
            TDefect += ClockSingleOperation.GetTimeDiff();
            ClockSingleOperation.SetTime();
#endif
            // Compute relative change of solution
	    if (fabs(l2normX) < 1e-16) {	  // l2normX == 0 ?
		mgInfo.relChange = 0;
	    } else {
		mgInfo.relChange = l2norm(LX[MaxLevel]) / l2normX;
	    }

            // Compute current defect of solution
            mgInfo.defect = l2norm(LD[StartLevel]);

            Prot << "     ParMultiGrid ITERATION " << ITE << "   !!RES!! = " << mgInfo.defect << "\n";

#ifdef CLOCK_MEASURE
            TNorm += ClockSingleOperation.GetTimeDiff();
#endif

            // Check, whether
            // a) defect <= EpsUDefect
            flag = StopCriterion(mgInfo.defect, EpsUDefect);

            if (flag == CRIT_TRUE)
                break;

            // Set values for the next iteration
            defectOld = mgInfo.defect;
        } // end for (ITE = 1;  ITE <= MaxIterations;  ITE++)
//      } // end if (defect satisifes given tolerance)
    }

#ifdef CLOCK_MEASURE
    TAll += ClockMG.GetTimeDiff();
#endif

    if (defectInitial > 1e-20)
        mgInfo.defectReduction = mgInfo.defect / defectInitial;
    else
        mgInfo.defectReduction = 0;

    // If we reached the maximum number of allowed iterations, ITE will be one
    // more than MaxIterations. Hence, reset this value
    if (ITE > MaxIterations)
        ITE--;

    Prot << "MultiGrid ITERATIONS " << ITE
         << "  NORM OF RESIDUAL " << mgInfo.defect << "\n      "
         << "  !!RES!!/!!INITIAL RES!!" << mgInfo.defectReduction << "\n"
         << "  --> RATE OF CONVERGENCE " << pow(mgInfo.defectReduction, 1.0 / (double)(ITE)) << "\n";

    for (ActiveLevel = MinLevel;  ActiveLevel < StartLevel;  ActiveLevel++) {
        delete LX[ActiveLevel];
        delete LB[ActiveLevel];
        delete LD[ActiveLevel];
    }
    delete LD[StartLevel];

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::MultiDriverSmooth.\n";
        protocol.mFlush();
    }

    mgInfo.convRate = pow(mgInfo.defectReduction, 1.0 / (double)(ITE));
    mgInfo.steps    = ITE;

    return mgInfo;
}


MG_Info ParMultiGrid_3D::PrecondMultiLevel(ParFiniteElement_3D& Elem,
                                           MultiCompactMatrix* A,
                                           DoubleVector  *LX1,
                                           unsigned int MaxIterations,
                                           double EpsUDefect,
                                           double AMin, double AMax)
{
    double       defectInitial, defectOld;
    double       alpha;
    MG_Info      mgInfo = { -100, -100, -100, -100, 0, -100 };
    unsigned int ITE = 0;
    int          flag;
    double 	 l2normX;

//    double TMultiGrid = 0;

#ifdef CLOCK_MEASURE
    DateTime ClockSingleOperation;
    DateTime ClockMG;
    DateTime ClockHelp;
    double   TAll = 0;
#endif

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::PrecondMultiLevel.\n";
        protocol.mFlush();
    }

    if (MaxLevel < MinLevel  ||  MinLevel <= 0  ||  MaxLevel > MAXMULTI) {
        Err << "Wrong Parameter MaxLevel or MinLevel !!\n";
        return mgInfo;
    }

    if (LX1 == 0)
        LX1 = new DoubleVector(MNumEquations[MaxLevel]);

    if (LX1->GetLen() < MNumEquations[MaxLevel]) {
        delete LX1;
        LX1 = new DoubleVector(MNumEquations[MaxLevel]);
        Prot << "MultiGrid: new vectors LX1 !!\n";
    }

    // Allocate a family of vectors for ...
    DoubleVector *LX[MAXARRAY];                   // ... the current solution
    DoubleVector *LB[MAXARRAY];                   // ... the current right hand side
    DoubleVector *LD[MAXARRAY];                   // ... the current defect
//      DoubleVector *TMP;                            // and finally a vector to compute relative change of solution

    for (ActiveLevel = MinLevel;  ActiveLevel < MaxLevel;  ActiveLevel++) {
        LX[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
        LB[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
        LD[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
    }
     LX[MaxLevel] = LX1;
     LB[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);
    *LB[MaxLevel] = *LX1;
//  *LX[MaxLevel]=0;
     LD[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);
//       TMP          = new DoubleVector(MNumEquations[MaxLevel]);

     // only one level?
     if (MinLevel == MaxLevel) {
	 (*LX[MaxLevel]) = (*LB[MaxLevel]);

#ifdef CLOCK_MEASURE
	 ClockSingleOperation.SetTime();
#endif
	 CommunicateExact(LX[MaxLevel]);
#ifdef CLOCK_MEASURE
	 TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

     } else {
	 unsigned int KITO[MAXMULTI],
	     KIT[MAXMULTI];

#ifdef CLOCK_MEASURE
	 ClockMG.SetTime();
#endif
	 KITO[MaxLevel] = 1;
	 for (ActiveLevel = MinLevel + 1;  ActiveLevel < MaxLevel;  ActiveLevel++) {
	     if (Cycle == 0)
		 KITO[ActiveLevel] = 2;
	     else
		 KITO[ActiveLevel] = Cycle;
	 }
	 ActiveLevel = MaxLevel;

//  	 Prot << "before presmooth x = \n";
//  	 OutputVector(LX[MaxLevel], MaxLevel);
//  	 Prot << "before presmooth b = \n";
//  	 OutputVector(LB[MaxLevel], MaxLevel);

//  	 ClockSingleOperation.SetTime();
//  	 if (PreSmSteps > 0)
//  	     PreSmooth(A, LX[MaxLevel], LB[MaxLevel], LD[MaxLevel], PreSmSteps, AMin, AMax);
//  	 TSmooth += ClockSingleOperation.GetTimeDiff();

//  	 Prot << "after presmooth x = \n";
//  	 OutputVector(LX[MaxLevel], MaxLevel);

#ifdef CLOCK_MEASURE
	 ClockSingleOperation.SetTime();
#endif

	 // Calculate initial defect: LD = LB - A * LX in 3 steps
	 // Step 1: LD = A * LX;
	 (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);

#ifdef CLOCK_MEASURE
	 ClockHelp.SetTime();
#endif
	 SetBoundValues(LD[MaxLevel]);
	 Communicate();
	 GetBoundValuesMult(LD[MaxLevel]);
#ifdef CLOCK_MEASURE
	 TDefectCom += ClockHelp.GetTimeDiff();
#endif

	 // Step 2: LD = - A * LX;
	 (*LD[MaxLevel]) *= -1;

	 // Step 3: LD = - A * LX + LB;
	 (*LD[MaxLevel]) += (*LB[MaxLevel]);
	 // ... done

//  	 Prot << "defect d = \n";
//  	 OutputVector(LD[MaxLevel], MaxLevel);
//  	 Prot << "x = \n" << *LX[MaxLevel] << "\n";
//  	 Prot << "b = \n" << *LB[MaxLevel] << "\n";

#ifdef CLOCK_MEASURE
	 TDefect += ClockSingleOperation.GetTimeDiff();
#endif

	 ActiveLevel--;

#ifdef CLOCK_MEASURE
	 ClockSingleOperation.SetTime();
#endif
	 // Compute l2 norm of defect
	 mgInfo.defect = l2norm(LD[MaxLevel]);
	 defectInitial = defectOld = mgInfo.defect;
#ifdef CLOCK_MEASURE
	 TNorm += ClockSingleOperation.GetTimeDiff();
#endif


	 // Do at least one iteration!
//  	 if (defectOld > 1e-9) {
	 for (ITE = 1;  ITE <= MaxIterations;  ITE++) {
	     for (ActiveLevel = MinLevel;  ActiveLevel <= MaxLevel;  ActiveLevel++)
		 KIT[ActiveLevel] = KITO[ActiveLevel];

	     ActiveLevel = MaxLevel;

	     do {
		 // Descend to coarsest level (= MinLevel),
		 // i.e. pre-smooth and restrict.
		 while (ActiveLevel != MinLevel) {
		     // Pre-Smoothing
//  		     Prot << "before presmooth x = \n";
//  		     OutputVector(LX[ActiveLevel], ActiveLevel);

		     if (PreSmSteps > 0)
			 PreSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PreSmSteps, AMin, AMax);

//                      Prot << "After presmooth x = \n";
//                      OutputVector(LX[ActiveLevel], ActiveLevel);

#ifdef CLOCK_MEASURE
                        ClockSingleOperation.SetTime();
#endif

                        // Calculate defect LD = LB - A * LX in three steps
                        // Step 1: LD = A * LX
                        (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel], *LD[ActiveLevel]);

#ifdef CLOCK_MEASURE
                        ClockHelp.SetTime();
#endif
                        SetBoundValues(LD[ActiveLevel]);
                        Communicate();
                        GetBoundValuesMult(LD[ActiveLevel]);
#ifdef CLOCK_MEASURE
                        TDefectCom += ClockHelp.GetTimeDiff();
#endif

                        // Step 2: LD = -A * LX
                        (*LD[ActiveLevel]) *= -1;

                        // Step 3: LD = LB - A * LX
                        (*LD[ActiveLevel]) += (*LB[ActiveLevel]);
                        // .. done

//                      Prot << "After defect x = \n";
//                      OutputVector(LD[ActiveLevel], ActiveLevel);

#ifdef CLOCK_MEASURE
                        TDefect += ClockSingleOperation.GetTimeDiff();
#endif

                        ActiveLevel--;

                        // Restriction of defect
                        Elem.ParRestrict(LD[ActiveLevel+1],           LB[ActiveLevel],
                                         MVertElem[ActiveLevel+1],    MVertElem[ActiveLevel],
                                         MMidFaces[ActiveLevel+1],    MMidFaces[ActiveLevel],
                                         MNeighElem[ActiveLevel+1],   MNeighElem[ActiveLevel],
                                         MNumVertices[ActiveLevel+1], MNumVertices[ActiveLevel],
                                         MNumElements[ActiveLevel+1], MNumElements[ActiveLevel],
                                         this);

//                      Prot << "After Restrict b = \n";
//                      OutputVector(LB[ActiveLevel], ActiveLevel);

                        // Choose zero as initial vector on lower level
                        (*LX[ActiveLevel]) = 0;
                        CopyBoundaryData(LB[ActiveLevel]);

//                      Prot << "After copy boundary b = \n";
//                      OutputVector(LB[ActiveLevel], ActiveLevel);
                    } // end while(ActiveLevel != MinLevel)

                    // Exact solution on lowest level
                    (*LX[MinLevel]) = (*LB[MinLevel]);

#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
                    CommunicateExact(LX[MinLevel]);

//                  Prot << "After solve exact x = \n";
//                  OutputVector(LX[MinLevel], MinLevel);

#ifdef CLOCK_MEASURE
                    TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

                    // Ascend to finest level (= MaxLevel),
                    // i.e. prolongate and post-smooth.
                    while (ActiveLevel != MaxLevel) {
                        ActiveLevel++;

                        Elem.ParProl(LX[ActiveLevel-1],         LD[ActiveLevel],
                                     MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
                                     MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
                                     MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
                                     MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
                                     MNumElements[ActiveLevel], MNumElements[ActiveLevel-1],
                                     this);

//                      Prot << "After prol d = \n";
//                      OutputVector(LD[ActiveLevel], ActiveLevel);

                        CopyBoundaryData(LD[ActiveLevel]);

                        // Update solution: LX = LX + alpha * LD
                        alpha = StepControl((*A)[ActiveLevel], *LX[ActiveLevel],
                                             *LD[ActiveLevel], *LB[ActiveLevel],
					     AMin, AMax);
			if (! isnan(alpha))	{	       // NaN can happen when right side is zero,
			    (*LD[ActiveLevel]) *= alpha;   // thus defect is zero
			}
                        (*LX[ActiveLevel]) += (*LD[ActiveLevel]);

                        if (PostSmSteps > 0)
                            PostSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PostSmSteps, AMin, AMax);


                        KIT[ActiveLevel] = KIT[ActiveLevel] - 1;
                        if (KIT[ActiveLevel] == 0) {
                            if (Cycle == 0)
                                KIT[ActiveLevel] = 1;
                            else
                                KIT[ActiveLevel] = KITO[ActiveLevel];
                        } else {
                            break;
                        }
                    }
                } while (ActiveLevel != MaxLevel);

#ifdef CLOCK_MEASURE
                ClockSingleOperation.SetTime();
#endif
                if (PreSmSteps > 0)
                    PreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps, AMin, AMax);
#ifdef CLOCK_MEASURE
                TSmooth += ClockSingleOperation.GetTimeDiff();
#endif

#ifdef CLOCK_MEASURE
                ClockSingleOperation.SetTime();
#endif

                // Calculate new defect LD = LB - A * LX in three steps
                // Step 1: LD = A * LX
                (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);

#ifdef CLOCK_MEASURE
                ClockHelp.SetTime();
#endif
                SetBoundValues(LD[MaxLevel]);
                Communicate();
                GetBoundValuesMult(LD[MaxLevel]);
#ifdef CLOCK_MEASURE
                TDefectCom += ClockHelp.GetTimeDiff();
#endif

                // Step 2: LD = -A * LX
                (*LD[MaxLevel]) *= -1;

                // Step 3: LD = LB - A * LX
                (*LD[MaxLevel]) += (*LB[MaxLevel]);
                // .. done

//              Prot << "Before norm d = \n";
//              OutputVector(LD[MaxLevel], MaxLevel);

//              Prot << "Before norm d = \n" << *LD[MaxLevel] << "\n";

#ifdef CLOCK_MEASURE
                TDefect += ClockSingleOperation.GetTimeDiff();
                ClockSingleOperation.SetTime();
#endif

                // Compute relative change of solution
//              *TMP  = (*LX[MaxLevel]);
//              *TMP -= *LX1;
//              mgInfo.relChange  = l2norm(TMP) / l2norm(LX1);
		l2normX = l2norm(LX1);
		if (fabs(l2normX) < 1e-16) {	  // l2normX == 0 ?
		    mgInfo.relChange = 0;
		} else {
		    mgInfo.relChange = l2norm(LX[MaxLevel]) / l2normX;
		}

                // Compute current defect of solution
                mgInfo.defect = l2norm(LD[MaxLevel]);

                ProtAdd << "     ParMultiGrid ITERATION " << ITE << "   !!RES!! = " << mgInfo.defect << "\n";

#ifdef CLOCK_MEASURE
                TNorm += ClockSingleOperation.GetTimeDiff();
#endif

                // Check, whether
                // a) defect <= EpsUDefect
                flag = StopCriterion(mgInfo.defect, EpsUDefect);

                // Set values for the next iteration
                defectOld = mgInfo.defect;
            } // end for (ITE = 1;  ITE <= MaxIterations;  ITE++)
//      }
    }

#ifdef CLOCK_MEASURE
    TAll += ClockMG.GetTimeDiff();
#endif

    if (defectInitial > 1e-20)
        mgInfo.defectReduction = mgInfo.defect / defectInitial;
    else
        mgInfo.defectReduction = 0;

    // If we reached the maximum number of allowed iterations, ITE will be one
    // more than MaxIterations. Hence, reset this value
    if (ITE > MaxIterations)
        ITE--;

    Prot << "MultiGrid ITERATIONS " << ITE
         << "  NORM OF RESIDUAL " << mgInfo.defect << "\n      "
         << "  !!RES!!/!!INITIAL RES!!" << mgInfo.defectReduction << "\n"
         << "  --> RATE OF CONVERGENCE " << pow(mgInfo.defectReduction, 1.0 / (double)(ITE)) << "\n";

    for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
        delete LX[ActiveLevel];
        delete LB[ActiveLevel];
        delete LD[ActiveLevel];
    }
    delete LD[MaxLevel];
    delete LB[MaxLevel];
//  delete TMP;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::PrecondMultiLevel.\n";
        protocol.mFlush();
    }

    mgInfo.convRate = pow(mgInfo.defectReduction, 1.0 / (double)(ITE));
    mgInfo.steps    = ITE;

    return mgInfo;
}


MG_Info ParMultiGrid_3D::PrecondAddMultiLevel(ParFiniteElement_3D& Elem,
                                              MultiCompactMatrix* A,
                                              DoubleVector  *LX1,
                                              unsigned int MaxIterations,
                                              double EpsUDefect,
                                              double AMin, double AMax)
// I don't quite understand what is done in here (SB)
// Don't use it.
{
    double       defectInitial, defectOld;
    MG_Info      mgInfo = { -100, -100, -100, -100, 0, -100 };
    unsigned int ITE = 0;
    int          flag;

#ifdef CLOCK_MEASURE
    DateTime ClockSingleOperation;
    DateTime ClockMG;
    DateTime ClockHelp;
    double   TAll = 0;
#endif


    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::PrecondAddMultiLevel.\n";
        protocol.mFlush();
    }

    if (MaxLevel < MinLevel  ||  MinLevel <= 0  ||  MaxLevel > MAXMULTI) {
        Err << "Wrong Parameter MaxLevel or MinLevel !!\n";
        return mgInfo;
    }

    if (LX1 == 0)
        LX1 = new DoubleVector(MNumEquations[MaxLevel]);

    if (LX1->GetLen() < MNumEquations[MaxLevel]) {
        delete LX1;
        LX1 = new DoubleVector(MNumEquations[MaxLevel]);
        Prot << "MultiGrid: new vectors LX !!\n";
    }

    // Allocate a family of vectors for ...
    DoubleVector *LX[MAXARRAY];                   // ... the current solution
    DoubleVector *LB[MAXARRAY];                   // ... the current right hand side
    DoubleVector *LD[MAXARRAY];                   // ... the current defect
//      DoubleVector *TMP;                            // and finally a vector to compute relative change of solution

    for (ActiveLevel = MinLevel;  ActiveLevel < MaxLevel;  ActiveLevel++) {
        LX[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
        LB[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
        LD[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
    }
     LX[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);
    *LX[MaxLevel] = *LX1;
     LB[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);
    *LB[MaxLevel] = *LX1;
//      (*LX[MaxLevel]) = 0;
     LD[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);
//      TMP           = new DoubleVector(MNumEquations[MaxLevel]);

    // only one level?
    if (MinLevel == MaxLevel) {
        (*LX[MaxLevel]) = (*LB[MaxLevel]);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        CommunicateExact(LX[MaxLevel]);
#ifdef CLOCK_MEASURE
        TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

    } else {
        // multilevel
        unsigned int KITO[MAXMULTI], KIT[MAXMULTI];

#ifdef CLOCK_MEASURE
        ClockMG.SetTime();
#endif
        KITO[MaxLevel] = 1;
        for (ActiveLevel = MinLevel + 1; ActiveLevel < MaxLevel; ActiveLevel++) {
            if (Cycle == 0)
                KITO[ActiveLevel] = 2;
            else
                KITO[ActiveLevel] = Cycle;
        }
        ActiveLevel = MaxLevel;

//      Prot << "before presmooth x = \n";
//      OutputVector(LX[MaxLevel], MaxLevel);
//      Prot << "before presmooth b = \n";
//      OutputVector(LB[MaxLevel], MaxLevel);

//      ClockSingleOperation.SetTime();
//      if (PreSmSteps > 0)
//          PreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps, AMin, AMax);
//      TSmooth += ClockSingleOperation.GetTimeDiff();

//      Prot << "after presmooth x = \n";
//      OutputVector(LX[MaxLevel], MaxLevel);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif

        // Calculate initial defect: LD = LB - A * LX in 3 steps
        // Step 1: LD = A * LX;
        (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);

#ifdef CLOCK_MEASURE
        ClockHelp.SetTime();
#endif
        SetBoundValues(LD[MaxLevel]);
        Communicate();
        GetBoundValuesMult(LD[MaxLevel]);
#ifdef CLOCK_MEASURE
        TDefectCom += ClockHelp.GetTimeDiff();
#endif
        // Step 2: LD = - A * LX;
        (*LD[MaxLevel]) *= -1;

        // Step 3: LD = - A * LX + LB;
        (*LD[MaxLevel]) += (*LB[MaxLevel]);
        // ... done

        (*LB[MaxLevel]) = (*LD[MaxLevel]);

//      Prot << "defect d = \n";
//      OutputVector(LD[MaxLevel], MaxLevel);
//      Prot << "x = \n" << *LX[MaxLevel] << "\n";
//      Prot << "b = \n" << *LB[MaxLevel] << "\n";

#ifdef CLOCK_MEASURE
        TDefect += ClockSingleOperation.GetTimeDiff();
#endif

        ActiveLevel--;

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        // Compute l2 norm of defect
        mgInfo.defect = l2norm(LD[MaxLevel]);
        defectInitial = defectOld = mgInfo.defect;
#ifdef CLOCK_MEASURE
        TNorm += ClockSingleOperation.GetTimeDiff();
#endif

//      if (defectOld > 1e-9) {
            for (ITE = 1;  ITE <= MaxIterations;  ITE++) {
                ActiveLevel = MaxLevel;

                while (ActiveLevel != MinLevel) {
                    ActiveLevel--;

                    // Restriction of defect
                    Elem.ParRestrict(LD[ActiveLevel+1],           LB[ActiveLevel],
                                     MVertElem[ActiveLevel+1],    MVertElem[ActiveLevel],
                                     MMidFaces[ActiveLevel+1],    MMidFaces[ActiveLevel],
                                     MNeighElem[ActiveLevel+1],   MNeighElem[ActiveLevel],
                                     MNumVertices[ActiveLevel+1], MNumVertices[ActiveLevel],
                                     MNumElements[ActiveLevel+1], MNumElements[ActiveLevel],
                                     this);
                    CopyBoundaryData(LB[ActiveLevel]);
                }

                ActiveLevel = MaxLevel;

                while (ActiveLevel != MinLevel) {
//                  (*LX[ActiveLevel]) = 0;
                    if (PreSmSteps > 0)
                        PreSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PreSmSteps, AMin, AMax);
                    ActiveLevel--;
                }

                (*LX[MinLevel]) = (*LB[MinLevel]);
                CommunicateExact(LX[MinLevel]);

                ActiveLevel = MinLevel;

                // Ascend to finest level (= MaxLevel),
                // i.e. prolongate and ?
                while (ActiveLevel != MaxLevel) {
                    ActiveLevel++;
                    Elem.ParProl(LX[ActiveLevel-1],         LD[ActiveLevel],
                                 MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
                                 MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
                                 MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
                                 MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
                                 MNumElements[ActiveLevel], MNumElements[ActiveLevel-1],
                                 this);
                    CopyBoundaryData(LD[ActiveLevel]);
                    (*LX[ActiveLevel]) += (*LD[ActiveLevel]);
                }

                // Check, whether
                // a) defect <= EpsUDefect
                flag = StopCriterion(mgInfo.defect, EpsUDefect);

                // Set values for the next iteration
                defectOld = mgInfo.defect;
            } // end for (ITE = 1;  ITE <= MaxIterations;  ITE++)
//      }
    }

    *LX1 += (*LX[MaxLevel]);

#ifdef CLOCK_MEASURE
    TAll += ClockMG.GetTimeDiff();
#endif

    if (defectInitial > 1e-20)
        mgInfo.defectReduction = mgInfo.defect / defectInitial;
    else
        mgInfo.defectReduction = 0;

    // If we reached the maximum number of allowed iterations, ITE will be one
    // more than MaxIterations. Hence, reset this value
    if (ITE > MaxIterations)
        ITE--;

    for (ActiveLevel = MinLevel;ActiveLevel < MaxLevel;ActiveLevel++) {
        delete LX[ActiveLevel];
        delete LB[ActiveLevel];
        delete LD[ActiveLevel];
    }
    delete LX[MaxLevel];
    delete LB[MaxLevel];
    delete LD[MaxLevel];
//      delete TMP;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::PrecondAddMultiLevel.\n";
        protocol.mFlush();
    }

    mgInfo.convRate = pow(mgInfo.defectReduction, 1.0 / (double)(ITE));
    mgInfo.steps    = ITE;

    return mgInfo;
}


//  MG_Info ParMultiGrid_3D::NeumannMultiDriver(ParFiniteElement_3D& Elem,
//                                              MultiCompactMatrix* A,
//                                              DoubleVector  *LX1,
//                                              DoubleVector *LB1,
//                                              unsigned int MaxIterations, double EpsPDefect,
//                                              double AMin, double AMax)
//  {
//      double       defectInitial, defectOld;
//      MG_Info      mgInfo = { -100, -100, -100, -100, 0, -100 };
//      unsigned int ITE = 0;
//      double       l2normX;
//  #ifdef CLOCK_MEASURE
//      DateTime ClockSingleOperation;
//      DateTime ClockMG;
//      double TAll = 0;
//  //    double TMultiGrid = 0
//  #endif

//      if (Debug) {
//          protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::NeumannMultiDriver.\n";
//          protocol.mFlush();
//      }

//      if (MaxLevel < MinLevel  ||  MinLevel <= 0  ||  MaxLevel > MAXMULTI) {
//          Err << "Wrong Parameter MaxLevel or MinLevel !!\n";
//          return mgInfo;
//      }

//      if (LX1 == 0)
//          LX1 = new DoubleVector(MNumEquations[MaxLevel]);

//      if (LB1 == 0)
//          LB1 = new DoubleVector(MNumEquations[MaxLevel]);

//      if (LX1->GetLen() < MNumEquations[MaxLevel]  ||  LB1->GetLen() < MNumEquations[MaxLevel]) {
//          delete LX1; delete LB1;
//          LX1 = new DoubleVector(MNumEquations[MaxLevel]);
//          LB1 = new DoubleVector(MNumEquations[MaxLevel]);
//          Prot << "MultiGrid: new vectors LX1 and LB1 !!\n";
//      }

//      // Allocate a family of vectors for ...
//      DoubleVector *LX[MAXARRAY];                   // ... the current solution
//      DoubleVector *LB[MAXARRAY];                   // ... the current right hand side
//      DoubleVector *LD[MAXARRAY];                   // ... the current defect
//  //      DoubleVector *TMP;                            // and finally a vector to compute relative change of solution
//      // Allocate memory for each member of a family
//      for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
//          LX[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
//          LB[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
//          LD[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
//      }

//      // Initializing phase
//      LX[MaxLevel] = LX1;
//      LB[MaxLevel] = LB1;
//      LD[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);
//  //      TMP          = new DoubleVector(MNumEquations[MaxLevel]);

//  //  Prot<<"before filter LB[MaxLevel]=\n";
//  //  OutputVector(LB[MaxLevel], MaxLevel);
//  //  Prot<<"\n";

//      Filter(LB[MaxLevel]);

//  //  Prot<<"LB[MaxLevel]=\n";
//  //  OutputVector(LB[MaxLevel], MaxLevel);
//  //  Prot<<"\n";


//      // only one level?
//      if (MinLevel == MaxLevel) {
//          (*LX[MaxLevel]) = (*LB[MaxLevel]);
//  #ifdef CLOCK_MEASURE
//          ClockSingleOperation.SetTime();
//  #endif
//          CommunicateExact(LX[MaxLevel]);
//  #ifdef CLOCK_MEASURE
//          TEvalue += ClockSingleOperation.GetTimeDiff();
//  #endif

//      } else {
//          // multilevel
//          unsigned int KITO[MAXMULTI], KIT[MAXMULTI];

//  #ifdef CLOCK_MEASURE
//          ClockMG.SetTime();
//  #endif

//          KITO[MaxLevel] = 1;
//          for (ActiveLevel = MinLevel + 1; ActiveLevel < MaxLevel; ActiveLevel++) {
//              if (Cycle == 0)
//                  KITO[ActiveLevel] = 2;
//              else
//                  KITO[ActiveLevel] = Cycle;
//          }
//          ActiveLevel = MaxLevel;

//  //      ClockSingleOperation.SetTime();
//  //      if (PreSmSteps > 0)
//  //          PreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps, AMin, AMax);
//  //      TSmooth += ClockSingleOperation.GetTimeDiff();

//  //      Prot << "After Presmooth LX[MaxLevel] = \n";
//  //      OutputVector(LX[MaxLevel], MaxLevel);
//  //      Prot << "\n";

//  #ifdef CLOCK_MEASURE
//          ClockSingleOperation.SetTime();
//  #endif

//          // Calculate initial defect: LD = LB - A * LX in 3 steps
//          // Step 1: LD = A * LX;
//          (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);

//          SetNeumannBoundValues(LD[MaxLevel]);
//          CommunicateNeumann();
//          GetNeumannBoundValuesMult(LD[MaxLevel]);

//          // Step 2: LD = - A * LX;
//          (*LD[MaxLevel]) *= -1;

//          // Step 3: LD = - A * LX + LB;
//          (*LD[MaxLevel]) += (*LB[MaxLevel]);
//          // ... done

//  //      Prot << "Defect LD[MaxLevel] = \n";
//  //      OutputVector(LD[MaxLevel], MaxLevel);
//  //      Prot << "\n";

//  #ifdef CLOCK_MEASURE
//          TDefect += ClockSingleOperation.GetTimeDiff();
//  #endif

//          // Compute l2 norm of defect
//          mgInfo.defect = l2norm(LD[MaxLevel]);
//          defectInitial = defectOld = mgInfo.defect;

//          ActiveLevel--;

//          // Do at least one iteration!
//  //      if (mgInfo.defect > EpsPDefect) {
//          for (ITE = 1;  ITE <= MaxIterations;  ITE++) {
//              for (ActiveLevel = MinLevel; ActiveLevel <= MaxLevel; ActiveLevel++)
//                  KIT[ActiveLevel] = KITO[ActiveLevel];

//              ActiveLevel = MaxLevel;
//              do {
//                  // Descend to coarsest level (= MinLevel),
//                  // i.e. pre-smooth and restrict.
//                  while (ActiveLevel != MinLevel) {
//                      // Pre-Smoothing
//  #ifdef CLOCK_MEASURE
//                      ClockSingleOperation.SetTime();
//  #endif
//                      if (PreSmSteps > 0)
//                          PreSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PreSmSteps, AMin, AMax);
//  #ifdef CLOCK_MEASURE
//                      TSmooth += ClockSingleOperation.GetTimeDiff();
//  #endif

//  //                  Prot << "After Presmooth LX[" << ActiveLevel << "] = \n";
//  //                  OutputVector(LX[ActiveLevel], ActiveLevel);
//  //                  Prot << "\n";

//  #ifdef CLOCK_MEASURE
//                      ClockSingleOperation.SetTime();
//  #endif

//                      // Calculate defect LD = LB - A * LX in three steps
//                      // Step 1: LD = A * LX
//                      (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel], *LD[ActiveLevel]);

//                      SetNeumannBoundValues(LD[ActiveLevel]);
//                      CommunicateNeumann();
//                      GetNeumannBoundValuesMult(LD[ActiveLevel]);

//                      // Step 2: LD = -A * LX
//                      (*LD[ActiveLevel]) *= -1;

//                      // Step 3: LD = LB - A * LX
//                      (*LD[ActiveLevel]) += (*LB[ActiveLevel]);
//                      // .. done

//  //                  Prot << "Defect LD[" << ActiveLevel << "] = \n";
//  //                  OutputVector(LD[ActiveLevel], ActiveLevel);
//  //                  Prot << "\n";

//  #ifdef CLOCK_MEASURE
//                      TDefect += ClockSingleOperation.GetTimeDiff();
//  #endif

//                      ActiveLevel--;

//                      // Restriction of defect
//                      Elem.ParRestrict(LD[ActiveLevel+1],           LB[ActiveLevel],
//                                       MVertElem[ActiveLevel+1],    MVertElem[ActiveLevel],
//                                       MMidFaces[ActiveLevel+1],    MMidFaces[ActiveLevel],
//                                       MNeighElem[ActiveLevel+1],   MNeighElem[ActiveLevel],
//                                       MNumVertices[ActiveLevel+1], MNumVertices[ActiveLevel],
//                                       MNumElements[ActiveLevel+1], MNumElements[ActiveLevel],
//                                       this);

//  //                  Prot << "After Restrict LB[" << ActiveLevel << "] = \n";
//  //                  OutputVector(LB[ActiveLevel], ActiveLevel);
//  //                  Prot << "\n";

//                      // Choose zero as initial vector on lower level
//                      (*LX[ActiveLevel]) = 0;
//                  }

//                  // Exact solution on lowest level
//                  (*LX[MinLevel]) = (*LB[MinLevel]);
//  #ifdef CLOCK_MEASURE
//                  ClockSingleOperation.SetTime();
//  #endif
//                  CommunicateExact(LX[MinLevel]);

//  //              Prot << "After CommunicateExact LX[" << MinLevel << "] = \n";
//  //              OutputVector(LX[MinLevel], MinLevel);
//  //              Prot << "\n";
//  #ifdef CLOCK_MEASURE
//                  TEvalue += ClockSingleOperation.GetTimeDiff();
//  #endif

//                  // Ascend to finest level (= StartLevel),
//                  // i.e. prolongate and post-smooth.
//                  while (ActiveLevel != MaxLevel) {
//                      ActiveLevel++;
//                      Elem.ParProl(LX[ActiveLevel-1],         LD[ActiveLevel],
//                                   MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
//                                   MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
//                                   MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
//                                   MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
//                                   MNumElements[ActiveLevel], MNumElements[ActiveLevel-1],
//                                   this);

//  //                  Prot << "After Prol LD[" << ActiveLevel << "] = \n";
//  //                  OutputVector(LD[ActiveLevel], ActiveLevel);
//  //                  Prot << "\n";

//                      // Update solution: LX = LX + LD
//                      (*LX[ActiveLevel]) += (*LD[ActiveLevel]);

//                      if (PostSmSteps > 0)
//                          PostSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PostSmSteps, AMin, AMax);

//  //                  Prot << "After PostSmooth LX[" << ActiveLevel << "] = \n";
//  //                  OutputVector(LX[ActiveLevel], ActiveLevel);
//  //                  Prot << "\n";

//                      KIT[ActiveLevel] = KIT[ActiveLevel] - 1;
//                      if (KIT[ActiveLevel] == 0) {
//                          if (Cycle == 0)
//                              KIT[ActiveLevel] = 1;
//                          else
//                              KIT[ActiveLevel] = KITO[ActiveLevel];
//                      } else {
//                          break;
//                      }
//                  }
//              } while (ActiveLevel != MaxLevel);

//  #ifdef CLOCK_MEASURE
//              ClockSingleOperation.SetTime();
//  #endif
//              if (PreSmSteps > 0)
//                  PreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps, AMin, AMax);
//  #ifdef CLOCK_MEASURE
//              TSmooth += ClockSingleOperation.GetTimeDiff();
//  #endif

//  #ifdef CLOCK_MEASURE
//              ClockSingleOperation.SetTime();
//  #endif

//              // Calculate new defect LD = LB - A * LX in three steps
//              // Step 1: LD = A * LX
//              (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);

//              SetNeumannBoundValues(LD[MaxLevel]);
//              CommunicateNeumann();
//              GetNeumannBoundValuesMult(LD[MaxLevel]);

//              // Step 2: LD = -A * LX
//              (*LD[MaxLevel]) *= -1;

//              // Step 3: LD = LB - A * LX
//              (*LD[MaxLevel]) += (*LB[MaxLevel]);
//              // .. done

//  #ifdef CLOCK_MEASURE
//              TDefect += ClockSingleOperation.GetTimeDiff();
//  #endif

//  //          Prot << "Before l2 - norm LD[" << MaxLevel << "] = \n";
//  //          OutputVector(LD[MaxLevel], MaxLevel);
//  //          Prot << "\n";

//              // Compute relative change of solution
//  //              *TMP  = (*LX[MaxLevel]);
//  //              *TMP -= *LX1;
//  //              mgInfo.relChange  = l2norm(TMP) / l2norm(LX1);
//  	    l2normX = l2norm(LX1);
//  	    if (fabs(l2normX) < 1e-16) {	  // l2normX == 0 ?
//  		mgInfo.relChange = 0;
//  	    } else {
//  		mgInfo.relChange = l2norm(LX[MaxLevel]) / l2normX;
//  	    }

//              // Compute current defect of solution
//              mgInfo.defect = l2norm(LD[MaxLevel]);

//              // Check, whether
//              // a) defect <= EpsPDefect
//              if (mgInfo.defect <= EpsPDefect)
//                  break;

//              // Set values for the next iteration
//              defectOld = mgInfo.defect;
//          } // end for (ITE = 1;  ITE <= MaxIterations;  ITE++)
//  //      }
//      }

//  #ifdef CLOCK_MEASURE
//      TAll += ClockMG.GetTimeDiff();
//  #endif

//      if (defectInitial > 1e-20)
//          mgInfo.defectReduction = mgInfo.defect / defectInitial;
//      else
//          mgInfo.defectReduction = 0;

//      // If we reached the maximum number of allowed iterations, ITE will be one
//      // more than MaxIterations. Hence, reset this value
//      if (ITE > MaxIterations)
//          ITE--;

//      Prot << "ParMultiGrid ITERATIONS " << ITE
//           << "  NORM OF RESIDUAL " << mgInfo.defect << "\n      "
//           << "  !!RES!!/!!INITIAL RES!!" << mgInfo.defectReduction << "\n"
//           << "  --> RATE OF CONVERGENCE " << pow(mgInfo.defectReduction, 1.0 / (double)(ITE)) << "\n";

//      for (ActiveLevel = MinLevel;ActiveLevel < MaxLevel;ActiveLevel++) {
//          delete LX[ActiveLevel];
//          delete LB[ActiveLevel];
//          delete LD[ActiveLevel];
//      }
//      delete LD[MaxLevel];
//  //      delete TMP;

//      if (Debug) {
//          protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::NeumannMultiDriver.\n";
//          protocol.mFlush();
//      }

//      mgInfo.convRate = pow(mgInfo.defectReduction, 1.0 / (double)(ITE));
//      mgInfo.steps    = ITE;

//      return mgInfo;
//  }


MG_Info ParMultiGrid_3D::ProjMultiDriver(ParFiniteElement_3D& Elem, FiniteElement_3D& ConElem, MultiCompactMatrix* A,
                                         DoubleVector  *LX1, DoubleVector *LB1, double l2normX,
                                         unsigned int MinIterations, unsigned int MaxIterations,
					 unsigned int prolongationType,
					 double EpsPChange, double EpsPDefect, double DampP,
                                         double AMin, double AMax)
{
    double       defectInitial, defectOld;
    double       alpha, T;
    MG_Info      mgInfo = { -100, -100, -100, -100, 0, -100 };
    unsigned int ITE = 0;
    int          flag;

#ifdef CLOCK_MEASURE
    DateTime ClockSingleOperation, ClockHelp;
    DateTime ClockMG;
    double TAll = 0;
//    double TMultiGrid = 0;
#endif

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::ProjMultiDriver.\n";
        protocol.mFlush();
    }

    if (MaxLevel < MinLevel  ||  MinLevel <= 0  ||  MaxLevel > MAXMULTI) {
        Err << "Wrong Parameter MaxLevel or MinLevel !!\n";
        return mgInfo;
    }

    if (LX1 == 0)
        LX1 = new DoubleVector(MNumElements[MaxLevel]);

    if (LB1 == 0)
        LB1 = new DoubleVector(MNumElements[MaxLevel]);

    if (LX1->GetLen() < MNumElements[MaxLevel]  ||  LB1->GetLen() < MNumElements[MaxLevel]) {
        delete LX1; delete LB1;
        LX1 = new DoubleVector(MNumElements[MaxLevel]);
        LB1 = new DoubleVector(MNumElements[MaxLevel]);
        Prot << "MultiGrid: new vectors LX1 and LB1 !!\n";
    }

    // Allocate a family of vectors for ...
    DoubleVector *LX[MAXARRAY];                   // ... the current solution
    DoubleVector *LB[MAXARRAY];                   // ... the current right hand side
    DoubleVector *LD[MAXARRAY];                   // ... the current defect
//      DoubleVector *LT[MAXARRAY];
//      DoubleVector *LT2[MAXARRAY];
    DoubleVector *LD_noncon[MAXARRAY];            // ... the current defect (in nonconform representation)

    // Allocate memory for each member of a family
    for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
        LX[ActiveLevel]  = new DoubleVector(MNumElements[ActiveLevel]);
        LB[ActiveLevel]  = new DoubleVector(MNumElements[ActiveLevel]);
        LD[ActiveLevel]  = new DoubleVector(MNumElements[ActiveLevel]);
//      LT[ActiveLevel]  = new DoubleVector(MTotNumFaces[ActiveLevel]);
//      LT2[ActiveLevel] = new DoubleVector(MTotNumFaces[ActiveLevel]);
    }

    // Initializing phase
    LX[MaxLevel]  = LX1;
    LB[MaxLevel]  = LB1;
    LD[MaxLevel]  = new DoubleVector(MNumElements[MaxLevel]);
//  LT[MaxLevel]  = new DoubleVector(MTotNumFaces[MaxLevel]);
//  LT2[MaxLevel] = new DoubleVector(MTotNumFaces[MaxLevel]);

    if (prolongationType == 2) {
	for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
	    LD_noncon[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
	}
	LD_noncon[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);
    }


    // only one level?
    if (MinLevel == MaxLevel) {
        (*LX[MaxLevel]) = (*LB[MaxLevel]);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        CommunicateConstExact(LX[MaxLevel]);
#ifdef CLOCK_MEASURE
        TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

    } else {
        // multilevel
        unsigned int KITO[MAXMULTI], KIT[MAXMULTI];

#ifdef CLOCK_MEASURE
        ClockMG.SetTime();
#endif
        KITO[MaxLevel] = 1;
        for (ActiveLevel = MinLevel + 1;  ActiveLevel < MaxLevel;  ActiveLevel++) {
            if (Cycle == 0)
                KITO[ActiveLevel] = 2;
            else
                KITO[ActiveLevel] = Cycle;
        }
        ActiveLevel = MaxLevel;

//  	Prot << "before presmooth x = \n";
//  	OutputConstVector(LB[ActiveLevel], ActiveLevel);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        if (PreSmSteps > 0)
            ConstPreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps);
#ifdef CLOCK_MEASURE
        TSmooth += ClockSingleOperation.GetTimeDiff();
#endif

//      Prot << "after presmooth x = \n";
//      OutputConstVector(LX[MaxLevel], MaxLevel);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif

//      (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);
//      SetBoundValues(LD[MaxLevel]);
//      Communicate();
//      GetBoundValuesMult(LD[MaxLevel]);


	// Calculate defect LD = LB - A * LX in three steps
        // Step 1: LD = A * LX;
        CVectMult((*A)[MaxLevel], *LX[MaxLevel], *LD[MaxLevel], T);

        // Step 2: LD = - A * LX;
        (*LD[MaxLevel]) *= -1;

        // Step 3: LD = - A * LX + LB;
        (*LD[MaxLevel]) += (*LB[MaxLevel]);
        // ... done


//      Prot << "defect d = \n";
//	OutputConstVector(LD[MaxLevel], MaxLevel);
//      Prot << "x = \n" << *LX[MaxLevel] << "\n";
//      Prot << "b = \n" << *LB[MaxLevel] << "\n";

#ifdef CLOCK_MEASURE
        TDefect += ClockSingleOperation.GetTimeDiff();
        TDefectCom += T;
#endif

        ActiveLevel--;

#ifdef CLOCK_MEASURE
        ClockHelp.SetTime();
#endif
        // Compute l2 norm of defect
        mgInfo.defect = constl2norm(LD[MaxLevel]);
        defectInitial = defectOld = mgInfo.defect;

#ifdef CLOCK_MEASURE
        TNorm += ClockHelp.GetTimeDiff();
#endif

        for (ITE = 1;  ITE <= MaxIterations;  ITE++) {
            for (ActiveLevel = MinLevel;  ActiveLevel <= MaxLevel;  ActiveLevel++)
                KIT[ActiveLevel] = KITO[ActiveLevel];

            ActiveLevel = MaxLevel;
            do {
                // Descend to coarsest level (= MinLevel),
                // i.e. pre-smooth and restrict.
                while (ActiveLevel != MinLevel) {
                    // Pre-Smoothing
#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
//                  Prot << "before presmooth x = \n";
//                  OutputVector(LX[ActiveLevel], ActiveLevel);
                    if (PreSmSteps > 0)
                        ConstPreSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PreSmSteps);
#ifdef CLOCK_MEASURE
                    TSmooth += ClockSingleOperation.GetTimeDiff();
#endif

//                  Prot << "After presmooth x = \n";
//                  OutputVector(LX[ActiveLevel], ActiveLevel);

#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
//                  (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel], *LD[ActiveLevel]);
//                  SetBoundValues(LD[ActiveLevel]);
//                  Communicate();
//                  GetBoundValuesMult(LD[ActiveLevel]);

                    // Calculate defect LD = LB - A * LX in three steps
                    // Step 1: LD = A * LX
                    CVectMult((*A)[ActiveLevel], *LX[ActiveLevel], *LD[ActiveLevel], T);

                    // Step 2: LD = -A * LX
                    (*LD[ActiveLevel]) *= -1;

                    // Step 3: LD = LB - A * LX
                    (*LD[ActiveLevel]) += (*LB[ActiveLevel]);
                    // .. done

//                  Prot << "After defect x = \n";
//                  OutputConstVector(LD[ActiveLevel], ActiveLevel);

#ifdef CLOCK_MEASURE
                    TDefect += ClockSingleOperation.GetTimeDiff();
                    TDefectCom += T;
#endif

                    ActiveLevel--;

                    // Restriction of defect
#ifdef CLOCK_MEASURE
		    ClockSingleOperation.SetTime();
#endif
//                  ConToRot(LD[ActiveLevel + 1], LT[ActiveLevel + 1], ActiveLevel + 1);
//                  Elem.ParRestrict(LT[ActiveLevel + 1], LT2[ActiveLevel],
//                                   MVertElem[ActiveLevel + 1], MVertElem[ActiveLevel],
//                                   MMidFaces[ActiveLevel + 1], MMidFaces[ActiveLevel],
//                                   MNeighElem[ActiveLevel + 1], MNeighElem[ActiveLevel],
//                                   MNumVertices[ActiveLevel + 1], MNumVertices[ActiveLevel],
//                                   MNumElements[ActiveLevel + 1], MNumElements[ActiveLevel],
//                                   this);
//                  RotToCon(LT2[ActiveLevel], LB[ActiveLevel], ActiveLevel);

                    ConElem.Restrict(LD[ActiveLevel+1],           LB[ActiveLevel],
                                     MVertElem[ActiveLevel+1],    MVertElem[ActiveLevel],
                                     MMidFaces[ActiveLevel+1],    MMidFaces[ActiveLevel],
                                     MNeighElem[ActiveLevel+1],   MNeighElem[ActiveLevel],
                                     MNumVertices[ActiveLevel+1], MNumVertices[ActiveLevel],
                                     MNumElements[ActiveLevel+1], MNumElements[ActiveLevel]);

#ifdef CLOCK_MEASURE
		    TRest += ClockSingleOperation.GetTimeDiff();
#endif
//                  Prot << "After Restrict b = \n";
//                  OutputConstVector(LB[ActiveLevel], ActiveLevel);


                    // Choose zero as initial vector on lower level
                    (*LX[ActiveLevel]) = 0;
//                  CopyBoundaryData(LB[ActiveLevel]);

//                  Prot << "After copy boundary b = \n";
//                  OutputVector(LB[ActiveLevel], ActiveLevel);
                } // end while(ActiveLevel != MinLevel)


                // Exact solution on lowest level
                (*LX[MinLevel]) = (*LB[MinLevel]);

#ifdef CLOCK_MEASURE
                ClockSingleOperation.SetTime();
#endif
		// Process 1 collects the distributed data and 
		// solves the coarse grid problem = C^{-1} LX
                CommunicateConstExact(LX[MinLevel]);

//              Prot << "After solve exact x = \n";
//              OutputConstVector(LX[MinLevel], MinLevel);

#ifdef CLOCK_MEASURE
                TCoarse += ClockSingleOperation.GetTimeDiff();
#endif

                // Ascend to finest level (= MaxLevel),
                // i.e. prolongate and post-smooth.
                while (ActiveLevel != MaxLevel) {
                    ActiveLevel++;
#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
//                  ConToRot(LX[ActiveLevel - 1], LT2[ActiveLevel - 1], ActiveLevel - 1);
//                  Elem.ParProl(LT2[ActiveLevel - 1], LT[ActiveLevel],
//                               MVertElem[ActiveLevel], MVertElem[ActiveLevel - 1],
//                               MMidFaces[ActiveLevel], MMidFaces[ActiveLevel - 1],
//                               MNeighElem[ActiveLevel], MNeighElem[ActiveLevel - 1],
//                               MNumVertices[ActiveLevel], MNumVertices[ActiveLevel - 1],
//                               MNumElements[ActiveLevel], MNumElements[ActiveLevel - 1],
//                               this);
//                  RotToCon(LT[ActiveLevel], LD[ActiveLevel], ActiveLevel);

		    if (prolongationType == 2) {
			ConToRot(LX[ActiveLevel-1], LD_noncon[ActiveLevel-1], ActiveLevel-1);
			Elem.Prol(LD_noncon[ActiveLevel-1],  LD_noncon[ActiveLevel],
				  MVertElem[ActiveLevel],    MVertElem[ActiveLevel - 1],
				  MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel - 1],
				  MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel - 1],
				  MNumVertices[ActiveLevel], MNumVertices[ActiveLevel - 1],
				  MNumElements[ActiveLevel], MNumElements[ActiveLevel - 1]);
			RotToCon(LD_noncon[ActiveLevel], LD[ActiveLevel], ActiveLevel);
		    } else {
			ConElem.Prol(LX[ActiveLevel-1],         LD[ActiveLevel],
				     MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
				     MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
				     MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
				     MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
				     MNumElements[ActiveLevel], MNumElements[ActiveLevel-1]);
		    }

//                  Prot << "After prol d = \n";
//                  OutputVector(LD[ActiveLevel], ActiveLevel);

#ifdef CLOCK_MEASURE
		    TProl += ClockSingleOperation.GetTimeDiff();
#endif

//                  CopyBoundaryData(LD[ActiveLevel]);

                    // Update solution: LX = LX + alpha * LD
                    alpha = ConstStepControl((*A)[ActiveLevel], *LX[ActiveLevel],
                                              *LD[ActiveLevel], *LB[ActiveLevel],
					      AMin, AMax);
// 		    protocol << "     alpha = " << double_to_string(alpha, "e", 3)
// 			     << " on level " << int_to_string(ActiveLevel) << "\n";
		    if (! isnan(alpha))	{	       // NaN can happen when right side is zero,
			(*LD[ActiveLevel]) *= alpha;   // thus defect is zero
		    }
                    (*LX[ActiveLevel]) += (*LD[ActiveLevel]);

                    if (PostSmSteps > 0)
                        ConstPostSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PostSmSteps);

                    KIT[ActiveLevel] = KIT[ActiveLevel] - 1;
                    if (KIT[ActiveLevel] == 0) {
                        if (Cycle == 0)
                            KIT[ActiveLevel] = 1;
                        else
                            KIT[ActiveLevel] = KITO[ActiveLevel];
                    } else {
                        break;
                    }
                }
            } while (ActiveLevel != MaxLevel);

#ifdef CLOCK_MEASURE
            ClockSingleOperation.SetTime();
#endif
            if (PreSmSteps > 0)
                ConstPreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps);
#ifdef CLOCK_MEASURE
            TSmooth += ClockSingleOperation.GetTimeDiff();
            ClockSingleOperation.SetTime();
#endif

//          (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);
//          SetBoundValues(LD[MaxLevel]);
//          Communicate();
//          GetBoundValuesMult(LD[MaxLevel]);

            // Calculate new defect LD = LB - A * LX in three steps
            // Step 1: LD = A * LX
            CVectMult((*A)[MaxLevel], *LX[MaxLevel], *LD[MaxLevel], T);

            // Step 2: LD = -A * LX
            (*LD[MaxLevel]) *= -1;

            // Step 3: LD = LB - A * LX
            (*LD[MaxLevel]) += (*LB[MaxLevel]);
            // .. done

#ifdef CLOCK_MEASURE
            TDefect += ClockSingleOperation.GetTimeDiff();
            TDefectCom += T;
#endif

            // Compute relative change of solution, i.e.
	    //   || x_{n+1} - x_{n} || / || x_{n} ||
	    // = || x || / || x_{n} ||
	    if (fabs(l2normX) < 1e-16) {	  // l2normX == 0 ?
		mgInfo.relChange = 0;
	    } else {
		mgInfo.relChange = constl2norm(LX[MaxLevel]) / l2normX;
	    }

            // Compute current defect of solution
            mgInfo.defect = constl2norm(LD[MaxLevel]);

	    // Here, we can actually control how accurate the equation is solved.
	    // There are many possibilities: Check, whether
            // (a) defect <= EpsPDefect
            // (b) defect <= defectInitial * DampP
            // (c) relChange <= EpsPChange

	    // Only (a)
	    flag = StopCriterion(mgInfo.defect, EpsPDefect);
#ifdef MG_DEBUG
 	    protocol << "MG_DEBUG: "
 		     << "        defect    ?<? EpsDefect\nMG_DEBUG: "
 		     << mgInfo.defect << " ?<? " << EpsPDefect
		     << "  (Iteration " << ITE << ")\n";
#endif

	    // Only (b)
//  	    flag = StopCriterion(mgInfo.defect, defectInitial * DampP);
//  #ifdef MG_DEBUG
//   	    protocol << "MG_DEBUG: "
//    		     << "        defect    ?<? defectInitial * DampP\n"
//    		     << mgInfo.defect << " ?<? " << defectInitial * DampP
//		     << "  (Iteration " << ITE << ")\n";
//  #endif

	    // (a) + (b) + (c)
//  	    flag = StopCriterion(mgInfo.defect, defectInitial, mgInfo.relChange, EpsPDefect, DampP, EpsPChange);
// #ifdef MG_DEBUG
//    	    protocol << "MG_DEBUG: " << ITE << ": " << "Defekt alt: " << defectOld << "        Defekt neu: " << mgInfo.defect << "\n";
//     	    protocol << "MG_DEBUG: "
//     		     << mgInfo.defect << " ?<? " << EpsPDefect << "    "
//     		     << mgInfo.defect << " ?<? " << defectInitial * DampP << "   "
//     		     << mgInfo.relChange << " ?<? " << EpsPChange
//		     << "  (Iteration " << ITE << ")\n";
//     	    protocol << "MG_DEBUG: L2Norm LX: " << constl2norm(LX[MaxLevel]) << "   " << "initial L2Norm: " << l2normX << "\n";
// #endif

            if (flag == CRIT_TRUE  &&  ITE >= MinIterations)
                break;

            // Set values for the next iteration
            defectOld = mgInfo.defect;
        } // end for (ITE = 1;  ITE <= MaxIterations;  ITE++)
    }

#ifdef MG_DEBUG
    protocol << "MG_DEBUG: ----\n";
#endif
#ifdef CLOCK_MEASURE
    TAll += ClockMG.GetTimeDiff();
#endif

    if (defectInitial > 1e-20)
        mgInfo.defectReduction = mgInfo.defect / defectInitial;
    else
        mgInfo.defectReduction = 0;

    // If we reached the maximum number of allowed iterations, ITE will be one
    // more than MaxIterations. Hence, reset this value
    if (ITE > MaxIterations)
        ITE--;

    Prot << "MultiGrid ITERATIONS " << ITE
         << "  NORM OF RESIDUAL " << mgInfo.defect << "\n      "
         << "  !!RES!!/!!INITIAL RES!!" << mgInfo.defectReduction << "\n"
         << "  --> RATE OF CONVERGENCE " << pow(mgInfo.defectReduction, 1.0 / (double)(ITE)) << "\n";

    for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
        delete LX[ActiveLevel];
        delete LB[ActiveLevel];
        delete LD[ActiveLevel];
//          delete LT[ActiveLevel];
//          delete LT2[ActiveLevel];
    }
    delete LD[MaxLevel];
//      delete LT[MaxLevel];
//      delete LT2[MaxLevel];
    if (prolongationType == 2) {
	for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
	    delete LD_noncon[ActiveLevel];
	}
	delete LD_noncon[MaxLevel];
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::ProjMultiDriver.\n";
        protocol.mFlush();
    }

    mgInfo.convRate = pow(mgInfo.defectReduction, 1.0 / (double)(ITE));
    mgInfo.steps    = ITE;

    return mgInfo;
}


MG_Info ParMultiGrid_3D::ProjNeumannMultiDriver(ParFiniteElement_3D& Elem, MultiCompactMatrix* A,
						DoubleVector  *LX1, DoubleVector *LB1, double l2normX,
						unsigned int MinIterations, unsigned int MaxIterations,
						double EpsPChange, double EpsPDefect, double DampP,
						double AMin, double AMax)
// 0nly linear prolongation supported (prolongationType = 2)
{
    double       defectInitial, defectOld;
    double       alpha, T, tmpDbl;
    MG_Info      mgInfo = { -100, -100, -100, -100, 0, -100 };
    unsigned int ITE = 0;
    int          flag;

#ifdef CLOCK_MEASURE
    DateTime ClockSingleOperation;
    DateTime ClockMG;
    double TAll = 0;
//      double TMultiGrid = 0;
#endif

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::ProjNeumannMultiDriver.\n";
        protocol.mFlush();
    }

    if (MaxLevel < MinLevel || MinLevel <= 0 || MaxLevel > MAXMULTI) {
        Err << "Wrong Parameter MaxLevel or MinLevel !!\n";
        return mgInfo;
    }

    if (LX1 == 0) {
        Err << "ProjNeummanMultiDriver: LX == 0 !!\n";
        MPI_Finalize();
        exit(0);
    }

    if (LB1 == 0) {
        Err << "ProjNeummanMultiDriver: LX == 0 !!\n";
        MPI_Finalize();
        exit(0);
    }

    if (LX1->GetLen() < MNumElements[MaxLevel]  ||  LB1->GetLen() < MNumElements[MaxLevel]) {
        Err << "ProjNeummanMultiDriver: Wrong len of x or f !!\n";
        MPI_Finalize();
        exit(0);
    }

    // Allocate a family of vectors for ...
    DoubleVector *LX[MAXARRAY];                   // ... the current solution
    DoubleVector *LB[MAXARRAY];                   // ... the current right hand side
    DoubleVector *LD[MAXARRAY];                   // ... the current defect
    DoubleVector *LDD[MAXARRAY];
    DoubleVector *LT[MAXARRAY];
    DoubleVector *LT2[MAXARRAY];
    DoubleVector *LD_noncon[MAXARRAY];            // ... the current defect (in nonconform representation)

    // Allocate memory for each member of a family
    for (ActiveLevel = MinLevel;ActiveLevel < MaxLevel;ActiveLevel++) {
        LX[ActiveLevel]  = new DoubleVector(MNumElements[ActiveLevel]);
        LB[ActiveLevel]  = new DoubleVector(MNumElements[ActiveLevel]);
        LD[ActiveLevel]  = new DoubleVector(MNumElements[ActiveLevel]);
        LDD[ActiveLevel] = new DoubleVector(MNumElements[ActiveLevel]);
        LT[ActiveLevel]  = new DoubleVector(MTotNumFaces[ActiveLevel]);
        LT2[ActiveLevel] = new DoubleVector(MTotNumFaces[ActiveLevel]);
    }

    // Initializing phase
    LX[MaxLevel]  = LX1;
    LB[MaxLevel]  = LB1;
    LD[MaxLevel]  = new DoubleVector(MNumElements[MaxLevel]);
    LDD[MaxLevel] = new DoubleVector(MNumElements[MaxLevel]);
    LT[MaxLevel]  = new DoubleVector(MTotNumFaces[MaxLevel]);
    LT2[MaxLevel] = new DoubleVector(MTotNumFaces[MaxLevel]);

//  Prot<<"before filter LB[MaxLevel]=\n";
//  OutputVector(LB[MaxLevel], MaxLevel);
//  Prot<<"\n";

    ActiveLevel = MaxLevel;
    ConstFilter(LB[MaxLevel]);

//  Prot<<"LB[MaxLevel]=\n";
//  OutputConstVector(LB[MaxLevel], MaxLevel);
//  Prot<<"\n";

    // only one level?
    if (MinLevel == MaxLevel) {
        (*LX[MaxLevel])=(*LB[MaxLevel]);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        CommunicateConstExact(LX[MaxLevel]);
#ifdef CLOCK_MEASURE
        TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

    } else {
        // multilevel
        unsigned int KITO[MAXMULTI], KIT[MAXMULTI];

#ifdef CLOCK_MEASURE
        ClockMG.SetTime();
#endif
        KITO[MaxLevel]=1;
        for (ActiveLevel = MinLevel + 1; ActiveLevel < MaxLevel; ActiveLevel++) {
            if (Cycle == 0)
                KITO[ActiveLevel] = 2;
            else
                KITO[ActiveLevel] = Cycle;
        }
        ActiveLevel = MaxLevel;

//      Prot << "Before Presmooth LX[MaxLevel] = \n";
//      OutputConstVector(LX[MaxLevel], MaxLevel);
//      Prot << "\n";

//#ifdef CLOCK_MEASURE
//        ClockSingleOperation.SetTime();
//#endif
//        if (PreSmSteps > 0)
//            ConstPreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps);
//#ifdef CLOCK_MEASURE
//        TSmooth += ClockSingleOperation.GetTimeDiff();
//#endif
//      ConstFilter(LX[MaxLevel]);

//      Prot << "After Presmooth LX[MaxLevel] = \n";
//      OutputConstVector(LX[MaxLevel], MaxLevel);
//      Prot << "\n";


#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
//      (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);
//      SetNeumannBoundValues(LD[MaxLevel]);
//      CommunicateNeumann();
//      GetNeumannBoundValuesMult(LD[MaxLevel]);

        // Calculate initial defect: LD = LB - A * LX in 3 steps
        // Step 1: LD = A * LX;
        CVectMult((*A)[MaxLevel], *LX[MaxLevel], *LD[MaxLevel], T);

        // Step 2: LD = - A * LX;
        (*LD[MaxLevel]) *= -1;

        // Step 3: LD = - A * LX + LB;
        (*LD[MaxLevel]) += (*LB[MaxLevel]);
        // ... done
      ConstFilter(LD[MaxLevel]);

//      Prot << "Defect LD[MaxLevel] = \n";
//      OutputConstVector(LD[MaxLevel], MaxLevel);
//      Prot << "\n";

#ifdef CLOCK_MEASURE
        TDefect += ClockSingleOperation.GetTimeDiff();
        TDefectCom += T;
#endif

        ActiveLevel--;

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        // Compute l2 norm of defect
        mgInfo.defect = constl2norm(LD[MaxLevel]);
        defectInitial = defectOld = mgInfo.defect;

#ifdef CLOCK_MEASURE
        TNorm += ClockSingleOperation.GetTimeDiff();
#endif

        for (ITE = 1;ITE <= MaxIterations;ITE++) {
            for (ActiveLevel = MinLevel;  ActiveLevel <= MaxLevel;  ActiveLevel++)
                KIT[ActiveLevel] = KITO[ActiveLevel];

            ActiveLevel = MaxLevel;
            do {
                // Descend to coarsest level (= MinLevel),
                // i.e. pre-smooth and restrict.
                while (ActiveLevel != MinLevel) {
                    // Pre-Smoothing
#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
                    if (PreSmSteps > 0)
                        ConstPreSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PreSmSteps);
#ifdef CLOCK_MEASURE
                    TSmooth += ClockSingleOperation.GetTimeDiff();
#endif
                  ConstFilter(LX[ActiveLevel]);

//                  Prot << "After Presmooth LX[" << ActiveLevel << "] = \n";
//                  OutputConstVector(LX[ActiveLevel], ActiveLevel);
//                  Prot << "\n";

#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
//                  (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel], *LD[ActiveLevel]);
//                  SetNeumannBoundValues(LD[ActiveLevel]);
//                  CommunicateNeumann();
//                  GetNeumannBoundValuesMult(LD[ActiveLevel]);

                    // Calculate defect LD = LB - A * LX in three steps
                    // Step 1: LD = A * LX
                    CVectMult((*A)[ActiveLevel], *LX[ActiveLevel], *LD[ActiveLevel], T);

                    // Step 2: LD = -A * LX
                    (*LD[ActiveLevel]) *= -1;

                    // Step 3: LD = LB - A * LX
                    (*LD[ActiveLevel]) += (*LB[ActiveLevel]);
                    // .. done

                  ConstFilter(LD[ActiveLevel]);

//                  Prot << "After Defect  LD[" << ActiveLevel << "] = \n";
//                  OutputConstVector(LD[ActiveLevel], ActiveLevel);
//                  Prot << "\n";

#ifdef CLOCK_MEASURE
                    TDefect += ClockSingleOperation.GetTimeDiff();
                    TDefectCom += T;
#endif

                    ActiveLevel--;

                    // Restriction of defect
#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
                    ConToRot(LD[ActiveLevel+1], LT[ActiveLevel+1], ActiveLevel+1);
#ifdef CLOCK_MEASURE
                    TRest += ClockSingleOperation.GetTimeDiff();
#endif
//                  Prot << "After ConToRot LT[" << ActiveLevel + 1 << "] = \n";
//                  OutputVector(LT[ActiveLevel + 1], ActiveLevel + 1);
//                  Prot << "\n";
                    Elem.ParRestrict(LT[ActiveLevel+1], LT2[ActiveLevel],
                                     MVertElem[ActiveLevel+1], MVertElem[ActiveLevel],
                                     MMidFaces[ActiveLevel+1], MMidFaces[ActiveLevel],
                                     MNeighElem[ActiveLevel+1], MNeighElem[ActiveLevel],
                                     MNumVertices[ActiveLevel+1], MNumVertices[ActiveLevel],
                                     MNumElements[ActiveLevel+1], MNumElements[ActiveLevel],
                                     this);
#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
                    RotToCon(LT2[ActiveLevel], LB[ActiveLevel], ActiveLevel);
                  ConstFilter(LB[ActiveLevel]);

//                  Prot << "After Restrict LB[" << ActiveLevel << "] = \n";
//                  OutputConstVector(LB[ActiveLevel], ActiveLevel);
//                  Prot << "\n";

#ifdef CLOCK_MEASURE
                    TRest += ClockSingleOperation.GetTimeDiff();
#endif

                    // Choose zero as initial vector on lower level
                    (*LX[ActiveLevel])=0;
                } // end while(ActiveLevel != MinLevel)

                // Exact solution on lowest level
                (*LX[MinLevel]) = (*LB[MinLevel]);
#ifdef CLOCK_MEASURE
                ClockSingleOperation.SetTime();
#endif
        		// Process 1 collects the distributed data and
        		// solves the coarse grid problem = C^{-1} LX
                CommunicateConstExact(LX[MinLevel]);
              ConstFilter(LX[MinLevel]);

//              Prot << "After CommunicateExact LX[" << MinLevel << "] = \n";
//              OutputConstVector(LX[MinLevel], MinLevel);
//              Prot << "\n";
#ifdef CLOCK_MEASURE
                TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

                // Ascend to finest level (= MaxLevel),
                // i.e. prolongate and post-smooth.
                while (ActiveLevel != MaxLevel) {
                    ActiveLevel++;
#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
                    *LDD[ActiveLevel] = *LD[ActiveLevel];
                    ConToRot(LX[ActiveLevel-1], LT2[ActiveLevel-1], ActiveLevel-1);
#ifdef CLOCK_MEASURE
                    TProl += ClockSingleOperation.GetTimeDiff();
#endif
                    Elem.ParProl(LT2[ActiveLevel-1],        LT[ActiveLevel],
                                 MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
                                 MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
                                 MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
                                 MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
                                 MNumElements[ActiveLevel], MNumElements[ActiveLevel-1],
                                 this);
#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif
                    RotToCon(LT[ActiveLevel], LD[ActiveLevel], ActiveLevel);
                  ConstFilter(LD[ActiveLevel]);

#ifdef CLOCK_MEASURE
                    TProl += ClockSingleOperation.GetTimeDiff();
#endif

//                  Prot << "After RotToCon LD[" << ActiveLevel << "] = \n";
//                  OutputConstVector(LD[ActiveLevel], ActiveLevel);
//                  Prot << "\n";

                    // Update solution: LX = LX + alpha * LD
                    alpha = ((ParVector*)LDD[ActiveLevel])->ConstScalProd(*LD[ActiveLevel], (Task*)this);
                    CVectMult((*A)[ActiveLevel], *LD[ActiveLevel], *LDD[ActiveLevel], T);
		    tmpDbl = ((ParVector*)LDD[ActiveLevel])->ConstScalProd(*LD[ActiveLevel], (Task*)this);
		    fabs(tmpDbl) > 1e-20  ?  alpha /= tmpDbl  :  alpha = 1.0;
                    alpha /= ((ParVector*)LDD[ActiveLevel])->ConstScalProd(*LD[ActiveLevel], (Task*)this);

		    if (alpha < AMin)
			alpha = AMin;
		    if (alpha > AMax)
			alpha = AMax;
		    if (! isnan(alpha))		// NaN can happen when right side is zero,
			(*LD[ActiveLevel]) *= alpha;   // thus defect is zero
                    (*LX[ActiveLevel]) += (*LD[ActiveLevel]);

                    if (PostSmSteps > 0)
                        ConstPostSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PostSmSteps);
                  ConstFilter(LX[ActiveLevel]);

//                  Prot << "After PostSmooth LX[" << ActiveLevel << "] = \n";
//                  OutputVector(LX[ActiveLevel], ActiveLevel);
//                  Prot << "\n";

                    KIT[ActiveLevel] = KIT[ActiveLevel] - 1;
                    if (KIT[ActiveLevel] == 0) {
                        if (Cycle == 0)
                            KIT[ActiveLevel] = 1;
                        else
                            KIT[ActiveLevel] = KITO[ActiveLevel];
                    } else {
                        break;
                    }
                }
            } while (ActiveLevel != MaxLevel);

#ifdef CLOCK_MEASURE
            ClockSingleOperation.SetTime();
#endif
            if (PreSmSteps > 0)
                ConstPreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps);
#ifdef CLOCK_MEASURE
            TSmooth += ClockSingleOperation.GetTimeDiff();
#endif
          ConstFilter(LX[MaxLevel]);

#ifdef CLOCK_MEASURE
            ClockSingleOperation.SetTime();
#endif

//          (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);
//          SetNeumannBoundValues(LD[MaxLevel]);
//          CommunicateNeumann();
//          GetNeumannBoundValuesMult(LD[MaxLevel]);

            // Calculate new defect LD = LB - A * LX in three steps
            // Step 1: LD = A * LX
            CVectMult((*A)[MaxLevel], *LX[MaxLevel], *LD[MaxLevel], T);

            // Step 2: LD = -A * LX
            (*LD[MaxLevel]) *= -1;

            // Step 3: LD = LB - A * LX
            (*LD[MaxLevel]) += (*LB[MaxLevel]);
            // .. done
          ConstFilter(LD[MaxLevel]);

#ifdef CLOCK_MEASURE
            TDefect += ClockSingleOperation.GetTimeDiff();
            TDefectCom += T;
#endif

            // Compute relative change of solution, i.e.
	    //   || x_{n+1} - x_{n} || / || x_{n} ||
	    // = || x || / || x_{n} ||
	    if (fabs(l2normX) < 1e-16) {	  // l2normX == 0 ?
		mgInfo.relChange = 0; //  constl2norm(LX[MaxLevel]);
	    } else {
		mgInfo.relChange = constl2norm(LX[MaxLevel]) / l2normX;
	    }

//          Prot << "Before l2 - norm LD[" << MaxLevel << "] = \n";
//          OutputVector(LD[MaxLevel], MaxLevel);
//          Prot << "\n";

            // Compute current defect of solution
            mgInfo.defect = constl2norm(LD[MaxLevel]);

	    // Here, we can actually control how accurate the equation is solved.
	    // There are many possibilities: Check, whether
            // (a) defect <= EpsPDefect
            // (b) defect <= defectInitial * DampP
            // (c) relChange <= EpsPChange

	    // Only (a)
	    flag = StopCriterion(mgInfo.defect, EpsPDefect);
#ifdef MG_DEBUG
 	    protocol << "MG_DEBUG: "
 		     << "        defect    ?<? EpsDefect\nMG_DEBUG: "
 		     << mgInfo.defect << " ?<? " << EpsPDefect
		     << "  (Iteration " << ITE << ")\n";
#endif

	    // Only (b)
//  	    flag = StopCriterion(mgInfo.defect, defectInitial * DampP);
//  #ifdef MG_DEBUG
//   	    protocol << "MG_DEBUG: "
//    		     << "        defect    ?<? defectInitial * DampP\n"
//    		     << mgInfo.defect << " ?<? " << defectInitial * DampP
//		     << "  (Iteration " << ITE << ")\n";
//  #endif

	    // (a) + (b) + (c)
//  	    flag = StopCriterion(mgInfo.defect, defectInitial, mgInfo.relChange, EpsPDefect, DampP, EpsPChange);
// #ifdef MG_DEBUG
//    	    protocol << "MG_DEBUG: " << ITE << ": " << "Defekt alt: " << defectOld << "        Defekt neu: " << mgInfo.defect << "\n";
//     	    protocol << "MG_DEBUG: "
//     		     << mgInfo.defect << " ?<? " << EpsPDefect << "    "
//     		     << mgInfo.defect << " ?<? " << defectInitial * DampP << "   "
//     		     << mgInfo.relChange << " ?<? " << EpsPChange
//		     << "  (Iteration " << ITE << ")\n";
//     	    protocol << "MG_DEBUG: L2Norm LX: " << constl2norm(LX[MaxLevel]) << "   " << "initial L2Norm: " << l2normX << "\n";
// #endif

            if (flag == CRIT_TRUE  &&  ITE >= MinIterations)
                break;

            // Set values for the next iteration
            defectOld = mgInfo.defect;
        } // end for (ITE = 1;  ITE <= MaxIterations;  ITE++)
    }

#ifdef MG_DEBUG
    protocol << "MG_DEBUG: ----\n";
#endif
#ifdef CLOCK_MEASURE
    TAll += ClockMG.GetTimeDiff();
#endif

    if (defectInitial > 1e-20)
        mgInfo.defectReduction = mgInfo.defect / defectInitial;
    else
        mgInfo.defectReduction = 0;

    // If we reached the maximum number of allowed iterations, ITE will be one
    // more than MaxIterations. Hence, reset this value
    if (ITE > MaxIterations)
        ITE--;

    Prot << "ParMultiGrid ITERATIONS " << ITE
         << "  NORM OF RESIDUAL " << mgInfo.defect << "\n      "
         << "  !!RES!!/!!INITIAL RES!!" << mgInfo.defectReduction << "\n"
         << "  --> RATE OF CONVERGENCE " << pow(mgInfo.defectReduction, 1.0 / (double)(ITE)) << "\n";

    for (ActiveLevel = MinLevel;ActiveLevel < MaxLevel;ActiveLevel++) {
        delete LX[ActiveLevel];
        delete LB[ActiveLevel];
        delete LD[ActiveLevel];
        delete LDD[ActiveLevel];
        delete LT[ActiveLevel];
        delete LT2[ActiveLevel];
    }
    delete LD[MaxLevel];
    delete LDD[MaxLevel];
    delete LT[MaxLevel];
    delete LT2[MaxLevel];

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::ProjNeumannMultiDriver.\n";
        protocol.mFlush();
    }

    mgInfo.convRate = pow(mgInfo.defectReduction, 1.0 / (double)(ITE));
    mgInfo.steps    = ITE;

    return mgInfo;
}


MG_Info ParMultiGrid_3D::ProjPrecondMultiLevel(ParFiniteElement_3D& Elem,
                                               FiniteElement_3D& ConElem,
                                               MultiCompactMatrix* A,
                                               DoubleVector  *LX1,
                                               unsigned int MaxIterations,
					       unsigned int prolongationType,
                                               double EpsPDefect,
                                               double AMin, double AMax)
{
    double       defectInitial, defectOld;
    double       alpha, T;
    MG_Info      mgInfo = { -100, -100, -100, -100, 0, -100 };
    unsigned int ITE = 0;
    int          flag;
    double       l2normX;
//  double EPS = 1e-10;

#ifdef CLOCK_MEASURE
    DateTime ClockSingleOperation;
    DateTime ClockMG;
    double   TAll = 0;
#endif

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::ProjPrecondMultiLevel.\n";
        protocol.mFlush();
    }

    if (MaxLevel < MinLevel || MinLevel <= 0 || MaxLevel > MAXMULTI) {
        Err << "Wrong Parameter MaxLevel or MinLevel !!\n";
        return mgInfo;
    }

    if (LX1 == 0)
        LX1 = new DoubleVector(MNumElements[MaxLevel]);

    if (LX1->GetLen() < MNumElements[MaxLevel]) {
        delete LX1;
        LX1 = new DoubleVector(MNumElements[MaxLevel]);
        Prot << "MultiGrid: new vectors LX1 !!\n";
        Prot.Flush();
    }

    // Allocate a family of vectors for ...
    DoubleVector *LX[MAXARRAY];                   // ... the current solution
    DoubleVector *LB[MAXARRAY];                   // ... the current right hand side
    DoubleVector *LD[MAXARRAY];                   // ... the current defect (in conform representation)
    DoubleVector *LD_noncon[MAXARRAY];            // ... the current defect (in nonconform representation)

    // Allocate memory for each member of a family
    for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
        LX[ActiveLevel] = new DoubleVector(MNumElements[ActiveLevel]);
        LB[ActiveLevel] = new DoubleVector(MNumElements[ActiveLevel]);
        LD[ActiveLevel] = new DoubleVector(MNumElements[ActiveLevel]);
    }

    // Initializing phase
     LX[MaxLevel] = LX1;
     LB[MaxLevel] = new DoubleVector(MNumElements[MaxLevel]);
    *LB[MaxLevel] = *LX1;
//  *LX[MaxLevel] = 0;
     LD[MaxLevel] = new DoubleVector(MNumElements[MaxLevel]);

    if (prolongationType == 2) {
	for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
	    LD_noncon[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
	}
	LD_noncon[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);
    }


     // only one level
    if (MinLevel == MaxLevel) {
        (*LX[MaxLevel]) = (*LB[MaxLevel]);
#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        CommunicateConstExact(LX[MaxLevel]);
#ifdef CLOCK_MEASURE
        TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

    } else {
        // multilevel
        unsigned int KITO[MAXMULTI], KIT[MAXMULTI];

#ifdef CLOCK_MEASURE
        ClockMG.SetTime();
#endif
        KITO[MaxLevel] = 1;
        for (ActiveLevel = MinLevel + 1; ActiveLevel < MaxLevel; ActiveLevel++) {
            if (Cycle == 0)
                KITO[ActiveLevel] = 2;
            else
                KITO[ActiveLevel] = Cycle;
        }
        ActiveLevel = MaxLevel;

//      Prot << "before presmooth x = \n";
//      OutputVector(LX[MaxLevel], MaxLevel);
//      Prot << "before presmooth b = \n";
//      OutputVector(LB[MaxLevel], MaxLevel);

//      ClockSingleOperation.SetTime();
//      if (PreSmSteps > 0)
//          PreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps, AMin, AMax);
//      TSmooth += ClockSingleOperation.GetTimeDiff();

//      Prot << "after presmooth x = \n";
//      OutputVector(LX[MaxLevel], MaxLevel);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif

        // Calculate initial defect: LD = LB - A * LX in 3 steps
        // Step 1: LD = A * LX;
//      (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);
        CVectMult((*A)[MaxLevel], *LX[MaxLevel], *LD[MaxLevel], T);

        // Step 2: LD = - A * LX;
        (*LD[MaxLevel]) *= -1;

        // Step 3: LD = - A * LX + LB;
        (*LD[MaxLevel]) += (*LB[MaxLevel]);
        // ... done

//      Prot << "defect d = \n";
//      OutputVector(LD[MaxLevel], MaxLevel);
//      Prot << "x = \n" << *LX[MaxLevel] << "\n";
//      Prot << "b = \n" << *LB[MaxLevel] << "\n";

#ifdef CLOCK_MEASURE
        TDefect += ClockSingleOperation.GetTimeDiff();
        TDefectCom += T;
#endif

        ActiveLevel--;

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        // Compute l2 norm of defect
        mgInfo.defect = constl2norm(LD[MaxLevel]);
        defectInitial = defectOld = mgInfo.defect;
#ifdef CLOCK_MEASURE
        TNorm += ClockSingleOperation.GetTimeDiff();
#endif

        for (ITE = 1; ITE <= MaxIterations; ITE++) {
            for (ActiveLevel = MinLevel; ActiveLevel <= MaxLevel; ActiveLevel++)
                KIT[ActiveLevel] = KITO[ActiveLevel];

            ActiveLevel = MaxLevel;
            do {
                // Descend to coarsest level (= MinLevel),
                // i.e. pre-smooth and restrict.
                while (ActiveLevel != MinLevel) {
                    // Pre-Smoothing
//  #ifdef CLOCK_MEASURE
//                      ClockSingleOperation.SetTime();
//  #endif
                    if (PreSmSteps > 0)
                        ConstPreSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PreSmSteps);
//  #ifdef CLOCK_MEASURE
//                      TSmooth += ClockSingleOperation.GetTimeDiff();
//  #endif

//                  Prot << "After presmooth x = \n";
//                  OutputVector(LX[ActiveLevel], ActiveLevel);

#ifdef CLOCK_MEASURE
                    ClockSingleOperation.SetTime();
#endif

                    // Calculate defect LD = LB - A * LX in three steps
                    // Step 1: LD = A * LX
//                  (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel], *LD[ActiveLevel]);
                    CVectMult((*A)[ActiveLevel], *LX[ActiveLevel], *LD[ActiveLevel], T);

                    // Step 2: LD = -A * LX
                    (*LD[ActiveLevel]) *= -1;

                    // Step 3: LD = LB - A * LX
                    (*LD[ActiveLevel]) += (*LB[ActiveLevel]);
                    // .. done

//                  Prot << "After defect x = \n";
//                  OutputVector(LD[ActiveLevel], ActiveLevel);

#ifdef CLOCK_MEASURE
                    TDefect += ClockSingleOperation.GetTimeDiff();
                    TDefectCom += T;
#endif

                    ActiveLevel--;

                    // Restriction of defect
#ifdef CLOCK_MEASURE
		    ClockSingleOperation.SetTime();
#endif
                    ConElem.Restrict(LD[ActiveLevel+1],           LB[ActiveLevel],
                                     MVertElem[ActiveLevel+1],    MVertElem[ActiveLevel],
                                     MMidFaces[ActiveLevel+1],    MMidFaces[ActiveLevel],
                                     MNeighElem[ActiveLevel+1],   MNeighElem[ActiveLevel],
                                     MNumVertices[ActiveLevel+1], MNumVertices[ActiveLevel],
                                     MNumElements[ActiveLevel+1], MNumElements[ActiveLevel]);
#ifdef CLOCK_MEASURE
		    TRest += ClockSingleOperation.GetTimeDiff();
#endif

//                  Prot << "After Restrict b = \n";
//                  OutputVector(LB[ActiveLevel], ActiveLevel);

                    // Choose zero as initial vector on lower level
                    (*LX[ActiveLevel]) = 0;
//                  CopyBoundaryData(LB[ActiveLevel]);

//                  Prot << "After copy boundary b = \n";
//                  OutputVector(LB[ActiveLevel], ActiveLevel);
                }

                // Exact solution on lowest level
                (*LX[MinLevel]) = (*LB[MinLevel]);

#ifdef CLOCK_MEASURE
                ClockSingleOperation.SetTime();
#endif
                CommunicateConstExact(LX[MinLevel]);

//              Prot << "After solve exact x = \n";
//              OutputVector(LX[MinLevel], MinLevel);
#ifdef CLOCK_MEASURE
                TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

                // Ascend to finest level (= StartLevel),
                // i.e. prolongate and post-smooth.
                while (ActiveLevel!=MaxLevel) {
                    ActiveLevel++;
#ifdef CLOCK_MEASURE
		    ClockSingleOperation.SetTime();
#endif
		    if (prolongationType == 2) {
			ConToRot(LX[ActiveLevel-1], LD_noncon[ActiveLevel-1], ActiveLevel-1);
			Elem.Prol(LD_noncon[ActiveLevel-1],  LD_noncon[ActiveLevel],
				  MVertElem[ActiveLevel],    MVertElem[ActiveLevel - 1],
				  MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel - 1],
				  MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel - 1],
				  MNumVertices[ActiveLevel], MNumVertices[ActiveLevel - 1],
				  MNumElements[ActiveLevel], MNumElements[ActiveLevel - 1]);
			RotToCon(LD_noncon[ActiveLevel], LD[ActiveLevel], ActiveLevel);
		    } else {
			ConElem.Prol(LX[ActiveLevel-1],         LD[ActiveLevel],
				     MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
				     MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
				     MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
				     MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
				     MNumElements[ActiveLevel], MNumElements[ActiveLevel-1]);
		    }
#ifdef CLOCK_MEASURE
		    TProl += ClockSingleOperation.GetTimeDiff();
#endif

//                  Prot << "After prol d = \n";
//                  OutputVector(LD[ActiveLevel], ActiveLevel);

                    // Update solution: LX = LX + alpha * LD
                    alpha = ConstStepControl((*A)[ActiveLevel], *LX[ActiveLevel],
                                              *LD[ActiveLevel], *LB[ActiveLevel],
					      AMin, AMax);
		    if (! isnan(alpha))	{	       // NaN can happen when right side is zero,
			(*LD[ActiveLevel]) *= alpha;   // thus defect is zero
		    }
//                  CopyBoundaryData(LD[ActiveLevel]);
                    (*LX[ActiveLevel]) += (*LD[ActiveLevel]);

//  #ifdef CLOCK_MEASURE
//                      ClockSingleOperation.SetTime();
//  #endif
                    if (PostSmSteps > 0)
                        ConstPostSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PostSmSteps);
//  #ifdef CLOCK_MEASURE
//                      TSmooth += ClockSingleOperation.GetTimeDiff();
//  #endif

                    KIT[ActiveLevel] = KIT[ActiveLevel] - 1;
                    if (KIT[ActiveLevel] == 0) {
                        if (Cycle == 0)
                            KIT[ActiveLevel] = 1;
                        else
                            KIT[ActiveLevel] = KITO[ActiveLevel];
                    } else {
                        break;
                    }
                }
            } while (ActiveLevel != MaxLevel);

//  #ifdef CLOCK_MEASURE
//              ClockSingleOperation.SetTime();
//  #endif
//              if (PreSmSteps > 0)
//                  ConstPreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps);

//  #ifdef CLOCK_MEASURE
//              TSmooth += ClockSingleOperation.GetTimeDiff();
//  #endif

#ifdef CLOCK_MEASURE
            ClockSingleOperation.SetTime();
#endif

            // Calculate new defect LD = LB - A * LX in three steps
            // Step 1: LD = A * LX
//          (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);
            CVectMult((*A)[MaxLevel], *LX[MaxLevel], *LD[MaxLevel], T);

            // Step 2: LD = -A * LX
            (*LD[MaxLevel]) *= -1;

            // Step 3: LD = LB - A * LX
            (*LD[MaxLevel]) += (*LB[MaxLevel]);
            // .. done

//          Prot << "Before norm d = \n";
//          OutputVector(LD[MaxLevel], MaxLevel);

//          Prot << "Before norm d = \n" << *LD[MaxLevel] << "\n";

#ifdef CLOCK_MEASURE
            TDefect += ClockSingleOperation.GetTimeDiff();
            TDefectCom += T;
            ClockSingleOperation.SetTime();
#endif

            // Compute relative change of solution
	    l2normX = constl2norm(LX1);
	    if (fabs(l2normX) < 1e-16) {	  // l2normX == 0 ?
		mgInfo.relChange = 0;
	    } else {
		mgInfo.relChange = constl2norm(LX[MaxLevel]) / l2normX;
	    }

            // Compute current defect of solution
            mgInfo.defect = constl2norm(LD[MaxLevel]);

//          ProtAdd << "     ParMultiGrid ITERATION " << ITE << "   !!RES!! = " << Def << "\n";

#ifdef CLOCK_MEASURE
            TNorm += ClockSingleOperation.GetTimeDiff();
#endif

            // Check, whether
            // a) defect <= EpsPDefect
            flag = StopCriterion(mgInfo.defect, EpsPDefect);

            if (flag == CRIT_TRUE)
                break;

            // Set values for the next iteration
            defectOld = mgInfo.defect;
        } // end for (ITE = 1;  ITE <= MaxIterations;  ITE++)
    }

#ifdef CLOCK_MEASURE
    TAll += ClockMG.GetTimeDiff();
#endif

    if (defectInitial > 1e-20)
        mgInfo.defectReduction = mgInfo.defect / defectInitial;
    else
        mgInfo.defectReduction = 0;

    // If we reached the maximum number of allowed iterations, ITE will be one
    // more than MaxIterations. Hence, reset this value
    if (ITE > MaxIterations)
        ITE--;

    Prot << "MultiGrid ITERATIONS " << ITE
         << "  NORM OF RESIDUAL " << mgInfo.defect << "\n      "
         << "  !!RES!!/!!INITIAL RES!!" << mgInfo.defectReduction << "\n"
         << "  --> RATE OF CONVERGENCE " << pow(mgInfo.defectReduction, 1.0 / (double)(ITE)) << "\n";

    for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
        delete LX[ActiveLevel];
        delete LB[ActiveLevel];
        delete LD[ActiveLevel];
    }
    delete LD[MaxLevel];
    delete LB[MaxLevel];
    if (prolongationType == 2) {
	for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
	    delete LD_noncon[ActiveLevel];
	}
	delete LD_noncon[MaxLevel];
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParMultiGrid_3D::ProjPrecondMultiLevel.\n";
        protocol.mFlush();
    }

    mgInfo.convRate = pow(mgInfo.defectReduction, 1.0 / (double)(ITE));
    mgInfo.steps    = ITE;

    return mgInfo;
}


MG_Info ParMultiGrid_3D::ProjPrecondAddMultiLevel(ParFiniteElement_3D& Elem,
                                                  FiniteElement_3D& ConElem,
                                                  MultiCompactMatrix* A,
                                                  DoubleVector  *LX1,
                                                  unsigned int MaxIterations,
						  unsigned int prolongationType,
						  double EpsPDefect,
						  double AMin, double AMax)
{
    double       defectInitial, defectOld;
    MG_Info      mgInfo = { -100, -100, -100, -100, 0, -100 };
    unsigned int ITE = 0;
    int          flag;

#ifdef CLOCK_MEASURE
    DateTime ClockSingleOperation;
    DateTime ClockMG;
    double   TAll = 0;
#endif

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParMultiGrid_3D::ProjPrecondAddMultiLevel.\n";
        protocol.mFlush();
    }

    if (MaxLevel < MinLevel || MinLevel <= 0 || MaxLevel > MAXMULTI) {
        Err << "Wrong Parameter MaxLevel or MinLevel !!\n";
        return mgInfo;
    }

    if (LX1 == 0)
        LX1 = new DoubleVector(MNumElements[MaxLevel]);

    if (LX1->GetLen() < MNumElements[MaxLevel]) {
        delete LX1;
        LX1 = new DoubleVector(MNumElements[MaxLevel]);
        Prot<<"MultiGrid: new vectors LX1 !!\n";
        Prot.Flush();
    }

    // Allocate a family of vectors for ...
    DoubleVector *LX[MAXARRAY];                   // ... the current solution
    DoubleVector *LB[MAXARRAY];                   // ... the current right hand side
    DoubleVector *LD[MAXARRAY];                   // ... the current defect
    DoubleVector *LD_noncon[MAXARRAY];            // ... the current defect (in nonconform representation)

    for (ActiveLevel = MinLevel;  ActiveLevel < MaxLevel;  ActiveLevel++) {
        LX[ActiveLevel] = new DoubleVector(MNumElements[ActiveLevel]);
        LB[ActiveLevel] = new DoubleVector(MNumElements[ActiveLevel]);
        LD[ActiveLevel] = new DoubleVector(MNumElements[ActiveLevel]);
    }
     LX[MaxLevel] = new DoubleVector(MNumElements[MaxLevel]);
    *LX[MaxLevel] = *LX1;
     LB[MaxLevel] = new DoubleVector(MNumElements[MaxLevel]);
    *LB[MaxLevel] = *LX1;
 // (*LX[MaxLevel]) = 0;
     LD[MaxLevel] = new DoubleVector(MNumElements[MaxLevel]);

    if (prolongationType == 2) {
	for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
	    LD_noncon[ActiveLevel] = new DoubleVector(MNumEquations[ActiveLevel]);
	}
	LD_noncon[MaxLevel] = new DoubleVector(MNumEquations[MaxLevel]);
    }

    // only one level
    if (MinLevel == MaxLevel) {
	(*LX[MaxLevel]) = (*LB[MaxLevel]);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        CommunicateConstExact(LX[MaxLevel]);
#ifdef CLOCK_MEASURE
        TEvalue += ClockSingleOperation.GetTimeDiff();
#endif

    } else {
        // multilevel
        unsigned int KITO[MAXMULTI], KIT[MAXMULTI];

#ifdef CLOCK_MEASURE
        ClockMG.SetTime();
#endif
        KITO[MaxLevel] = 1;
        for (ActiveLevel = MinLevel + 1; ActiveLevel < MaxLevel; ActiveLevel++) {
            if (Cycle == 0)
                KITO[ActiveLevel] = 2;
            else
                KITO[ActiveLevel] = Cycle;
        }
        ActiveLevel = MaxLevel;

 //      Prot << "before presmooth x = \n";
 //      OutputVector(LX[MaxLevel], MaxLevel);
 //      Prot << "before presmooth b = \n";
 //      OutputVector(LB[MaxLevel], MaxLevel);

 //      ClockSingleOperation.SetTime();
 //      if (PreSmSteps > 0)
 //          PreSmooth(A, LX[MaxLevel], LB[MaxLevel], PreSmSteps, AMin, AMax);
 //      TSmooth += ClockSingleOperation.GetTimeDiff();

 //      Prot << "after presmooth x = \n";
 //      OutputVector(LX[MaxLevel], MaxLevel);

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif

//      (*A)[MaxLevel]->VectMult(*LX[MaxLevel], *LD[MaxLevel]);
//      CVectMult((*A)[MaxLevel], *LX[MaxLevel], *LD[MaxLevel], T);
//      (*LD[MaxLevel]) *= -1;
//      (*LD[MaxLevel]) += (*LB[MaxLevel]);

//      (*LB[MaxLevel]) = (*LD[MaxLevel]);

        (*LB[MaxLevel]) = (*LX[MaxLevel]);
        (*LD[MaxLevel]) = (*LX[MaxLevel]);

//      Prot << "defect d = \n";
//      OutputVector(LD[MaxLevel], MaxLevel);
//      Prot << "x = \n" << *LX[MaxLevel] << "\n";
//      Prot << "b = \n" << *LB[MaxLevel] << "\n";

#ifdef CLOCK_MEASURE
        TDefect += ClockSingleOperation.GetTimeDiff();
#endif

        ActiveLevel--;

//      Def = LD[MaxLevel]->l2Norm();

#ifdef CLOCK_MEASURE
        ClockSingleOperation.SetTime();
#endif
        mgInfo.defect = constl2norm(LD[MaxLevel]);
        defectInitial = defectOld = mgInfo.defect;
#ifdef CLOCK_MEASURE
        TNorm += ClockSingleOperation.GetTimeDiff();
#endif

	for (ITE = 1;ITE <= MaxIterations;ITE++) {
	    ActiveLevel = MaxLevel;

	    while (ActiveLevel != MinLevel) {
		ActiveLevel--;
		// Restriction of defect
		ConElem.Restrict(LD[ActiveLevel+1], LB[ActiveLevel],
				 MVertElem[ActiveLevel+1], MVertElem[ActiveLevel],
				 MMidFaces[ActiveLevel+1], MMidFaces[ActiveLevel],
				 MNeighElem[ActiveLevel+1], MNeighElem[ActiveLevel],
				 MNumVertices[ActiveLevel+1], MNumVertices[ActiveLevel],
				 MNumElements[ActiveLevel+1], MNumElements[ActiveLevel]);
		LD[ActiveLevel]=LB[ActiveLevel];
//              CopyBoundaryData(LB[ActiveLevel]);
	    }

	    ActiveLevel = MaxLevel;

	    while (ActiveLevel != MinLevel) {
//              (*LX[ActiveLevel]) = *LB[ActiveLevel];
//              *LB[ActiveLevel] = 0.;
//              (*LX[ActiveLevel]) = 0.;
		if (PreSmSteps > 0)
		    ConstPreSmooth(A, LX[ActiveLevel], LB[ActiveLevel], PreSmSteps);
		ActiveLevel--;
	    }

	    (*LX[MinLevel]) = (*LB[MinLevel]);
	    CommunicateConstExact(LX[MinLevel]);

	    ActiveLevel = MinLevel;

	    while (ActiveLevel != MaxLevel) {
		ActiveLevel++;
#ifdef CLOCK_MEASURE
		ClockSingleOperation.SetTime();
#endif
		if (prolongationType == 2) {
		    ConToRot(LX[ActiveLevel-1], LD_noncon[ActiveLevel-1], ActiveLevel-1);
		    Elem.Prol(LD_noncon[ActiveLevel-1],  LD_noncon[ActiveLevel],
			      MVertElem[ActiveLevel],    MVertElem[ActiveLevel - 1],
			      MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel - 1],
			      MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel - 1],
			      MNumVertices[ActiveLevel], MNumVertices[ActiveLevel - 1],
			      MNumElements[ActiveLevel], MNumElements[ActiveLevel - 1]);
		    RotToCon(LD_noncon[ActiveLevel], LD[ActiveLevel], ActiveLevel);
		} else {
		    ConElem.Prol(LX[ActiveLevel-1], LD[ActiveLevel],
				 MVertElem[ActiveLevel], MVertElem[ActiveLevel-1],
				 MMidFaces[ActiveLevel], MMidFaces[ActiveLevel-1],
				 MNeighElem[ActiveLevel], MNeighElem[ActiveLevel-1],
				 MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
				 MNumElements[ActiveLevel], MNumElements[ActiveLevel-1]);
		}
#ifdef CLOCK_MEASURE
		TProl += ClockSingleOperation.GetTimeDiff();
#endif
//              CopyBoundaryData(LD[ActiveLevel]);
//              (*LD[ActiveLevel]) *= 0.05;
		(*LX[ActiveLevel]) += (*LD[ActiveLevel]);
	    }

	    // Check, whether
	    // a) defect <= EpsPDefect
	    flag = StopCriterion(mgInfo.defect, EpsPDefect);

	    if (flag == CRIT_TRUE)
		break;

	    // Set values for the next iteration
	    defectOld = mgInfo.defect;
	} // end for (ITE = 1;      ITE <= MaxIterations;  ITE++)
    }

    *LX1 += (*LX[MaxLevel]);

    if (defectInitial > 1e-20)
	mgInfo.defectReduction = mgInfo.defect / defectInitial;
    else
	mgInfo.defectReduction = 0;

#ifdef CLOCK_MEASURE
    TAll += ClockMG.GetTimeDiff();
#endif
    for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
	delete LX[ActiveLevel];
	delete LB[ActiveLevel];
	delete LD[ActiveLevel];
    }
    delete LX[MaxLevel];
    delete LB[MaxLevel];
    delete LD[MaxLevel];
    if (prolongationType == 2) {
	for (ActiveLevel = MinLevel; ActiveLevel < MaxLevel; ActiveLevel++) {
	    delete LD_noncon[ActiveLevel];
	}
	delete LD_noncon[MaxLevel];
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Leaving ParMultiGrid_3D::ProjPrecondAddMultiLevel.\n";
	protocol.mFlush();
    }

    mgInfo.convRate = pow(mgInfo.defectReduction, 1.0 / (double)(ITE));
    mgInfo.steps    = ITE;

    return mgInfo;
}


//  void ParMultiGrid_3D::IntpolToNonconform(DoubleVector *p_con, DoubleVector *p_non,
//  					 IntArray2D *ElemMeetFace, int TotNumFaces)
//  {
//      // Purpose: - Interpolates the cellwise constant vector p_con
//      //            to a facewise constant vector p_non.
//      int IELH0, IELH1, IELH2;			  // auxiliary variables
//      int IELH3, IELH4, IELH5, IELH6;		  // auxiliary variables

//  //      for (unsigned int k = 1; k <= p_con->GetLen(); k+=2) {
//  //    	(*p_con)(k)   = 1.0;
//  //    	(*p_con)(k+1) = 1.0;
//  //      }

//  //      for (unsigned int i = 1;  i <= p_con->GetLen();  i++) {
//  //  	std::cout << "Druckwert " << i << ": " << (*p_con)(i) << "\n";
//  //      }

//  //      DoubleVector* druck;
//  //      druck = new DoubleVector(TotNumFaces);
//      unsigned int cell1, cell2;
//      unsigned int counter;
//      for (unsigned int i = 1;  i <= TotNumFaces;  i++) {
//  	counter = 0;
//  	cell1 = (*ElemMeetFace)(1, i);
//  	cell2 = (*ElemMeetFace)(2, i);
//  	if (cell1 != 0) {
//  	    (*p_non)(i) += (*p_con)(cell1);
//  	    counter++;
//  	}
//  	if (cell2 != 0) {
//  	    (*p_non)(i) += (*p_con)(cell2);
//  	    counter++;
//  	}

//  #ifdef DEBUG
//  	if (counter) {
//  #endif
//  	    (*p_non)(i) /= counter;
//  #ifdef DEBUG
//  	} else {
//  	    protocol << progname << std::string(" (process ") << int_to_string(MyProcID) << std::string("):\n")
//  		     << std::string("  Unrecoverable error discovered:\n")
//  		     << std::string("    Found a face that has no neighboring elements.\n")
//  		     << std::string("  Program aborted in ParMultiGrid_3D::IntpolToNonconform.\n");
//  	    MPI_Abort(MPI_COMM_WORLD, FACE_WITHOUT_ELEMENTS);
//  	}
//  #endif
//  //	std::cout << "Druckwert in Flaeche " << i << ": " << (*p_non)(i) << "\n";
//      }
//  //    std::cout << "\n";

//      // Loop over all faces
//  //      for (unsigned int i = 1;  i <= ElemMeetFace->GetCols();  i++) {
//  //  	std::cout << "i" << i << "|   ";
//  //  	for (unsigned int j = 1;  j <= ElemMeetFace->GetRows();  j++) {
//  //  	    std::cout << (*ElemMeetFace)(j, i) << "  ";
//  //  	}
//  //  	std::cout << "\n";
//  //      }
//  //      std::cout << "\n";

//  //    for (unsigned int k = 1; k <= p_con->GetLen(); k++) {
//  //	(*p_con)(k) = 0.0;
//  //    }

//      return;
//  }


//  void ParMultiGrid_3D::IntpolToCon(DoubleVector *p_non, DoubleVector *p_con,
//  				  IntArray2D *MidFaces, int TotNumElements)
//  {
//      // Purpose: - Interpolates the facewise constant vector p_non
//      //            to a cellwise constant vector p_con.

//      for (unsigned int i = 1;  i <= TotNumElements;  i++) {
//  	(*p_con)(i) = ( (*p_non)((*MidFaces)(1, i)) + (*p_non)((*MidFaces)(2, i)) +
//  			(*p_non)((*MidFaces)(3, i)) + (*p_non)((*MidFaces)(4, i)) +
//  			(*p_non)((*MidFaces)(5, i)) + (*p_non)((*MidFaces)(6, i)) ) / 6;
//      }

//      return;
//  }
