#ifndef PARMULTIGRID3DH

#define PARMULTIGRID3DH

#include "SquareGrid_3D.h"
#include "ParFiniteElement_3D.h"
#include "ParVector.h"

#include <typecasts.h>				  // for int_to_string, double_to_string
#include "MG_Info.h"

#define REAL_BOUND              101
#define ART_BOUND               102

#define MAXMULTI        10
#define MAXARRAY        11

#define F_CYCLE  0
#define V_CYCLE  1
#define W_CYCLE  2

#define CRIT_TRUE  1
#define CRIT_FALSE 0

#define INIT_VALUE   -100

class ParMultiGrid_3D: public SquareGrid_3D
{
    friend class FiniteElement_3D;
    friend class TrilinearElement_3D;
    friend class RotatedElement_3D;

protected:
    int MNumElements[MAXARRAY];                     // NEL
    int MNumVertices[MAXARRAY];                     // NVT
    int MNumEdges[MAXARRAY];                        // NMT
    int MNumVertElem[MAXARRAY];                     // NVE
    int MNumElemVert[MAXARRAY];                     // NVEL
    int MNumBound[MAXARRAY];                        // NBCT
    int MNumVertBound[MAXARRAY];                    // NVBD

// 3-D
    int MTotNumEdges[MAXARRAY];                     // NET
    int MTotNumFaces[MAXARRAY];                     // NAT
    int MNumEdgeElem[MAXARRAY];                     // NEE
    int MNumFaceElem[MAXARRAY];                     // NAE
    int MNumElemEdge[MAXARRAY];                     // NEEL
    int MNumEdgeVert[MAXARRAY];                     // NVED
    int MNumFaceVert[MAXARRAY];                     // NVAR
    int MNumFaceEdge[MAXARRAY];                     // NEAR
    int MNumEdgesBound[MAXARRAY];                   // NEBD
    int MNumFacesBound[MAXARRAY];                   // NABD

    DoubleArray2D *MVertCoord[MAXARRAY];            // LCORVG
    DoubleArray2D *MMidCoord[MAXARRAY];             // LCORMG
    IntArray2D    *MVertElem[MAXARRAY];             // LVERT
    IntArray2D    *MNeighElem[MAXARRAY];            // LADJ
    IntArray2D    *MElemVert[MAXARRAY];             // LVEL
    IntArray2D    *MElemEdge[MAXARRAY];             // LMEL
    IntArray      *MInfoVertEdge[MAXARRAY];         // LNPR
    IntArray2D    *MInfoVertBound[MAXARRAY];        // LMM
    IntArray      *MVertBound[MAXARRAY];            // LVBD
    IntArray      *MElemBound[MAXARRAY];            // LEBD
    IntArray      *MPosBoundEntry[MAXARRAY];        // LBCT
    DoubleArray   *MVertParamBound[MAXARRAY];       // LVBDP
    DoubleArray   *MMidParamBound[MAXARRAY];        // LMBDP
// 3-D
    DoubleArray2D *MMidFaceCoord[MAXARRAY];         // LCORAG
    IntArray2D    *MMidEdges[MAXARRAY];             // LEDGE
    IntArray2D    *MMidFaces[MAXARRAY];             // LAREA
    IntArray2D    *MElemMeetEdge[MAXARRAY];         // LEEL
    IntArray2D    *MElemMeetFace[MAXARRAY];         // LAEL
    IntArray2D    *MVertMeetEdge[MAXARRAY];         // LVED
    IntArray2D    *MFaceMeetEdge[MAXARRAY];         // LAED
    IntArray2D    *MVertMeetFace[MAXARRAY];         // LVAR
    IntArray2D    *MEdgeMeetFace[MAXARRAY];         // LEAR
    IntArray2D    *MElemMeetVert[MAXARRAY];         // LEVE
    IntArray2D    *MFaceMeetVert[MAXARRAY];         // LAVE
    IntArray      *MMidFacesBound[MAXARRAY];        // LABD

    unsigned int   MNumEquations[MAXARRAY];

    DoubleVector  *E[MAXARRAY];
    DoubleVector  *EConst[MAXARRAY];

    DoubleVector  *MVolumes[MAXARRAY];
    DoubleVector  *Volumes;
    double         MSumVolumes[MAXARRAY];
    double         SumVolumes;

    unsigned int   ActiveLevel;                     //ILEV
    unsigned int   TotalLevel;                      //NLEV
    unsigned int   MinLevel;                        //NLMIN
    unsigned int   MaxLevel;                        //NLMAX
    unsigned int   Cycle;                           //ICYCLE
    unsigned int   PreSmSteps;                      //KPRSM
    unsigned int   PostSmSteps;                     //KPOSM

    unsigned int   smoother, solver;

//      void IntpolToNonconform(DoubleVector *p_con, DoubleVector *p_non, IntArray2D *ElemMeetFace, int TotNumFaces);
//      void IntpolToCon       (DoubleVector *p_non, DoubleVector *p_con, IntArray2D *MidFaces, int TotNumElements);

public:
    ParMultiGrid_3D();
    virtual ~ParMultiGrid_3D(VOID);

//      virtual IntArray *GetBoundInfo() {}
    virtual IntArray *GetBoundInfo() = 0;

    void   SetTotalLevel(unsigned int P_TotalLevel);
    void   SetPreSteps  (unsigned int steps)    { PreSmSteps  = steps;    }
    void   SetPostSteps (unsigned int steps)    { PostSmSteps = steps;    }
    void   SetCycle     (unsigned int num)      { Cycle       = num;      }
    void   SetSmoother  (unsigned int p_smooth) { smoother    = p_smooth; }
    void   SetSolver    (unsigned int p_solv)   { solver      = p_solv;   }
    void   SetLevel     (unsigned int ILEV);

    DoubleVector* GetRightSideVector(FiniteElement_3D& Elem);


// BCON     BCON(IBLOC)=.TRUE. means constant coefficients in
//          matrix IBLOC
// KAB      Pairs of multiindices occuring in the bilinear forms
//          specified separately for each matrix
// KABN     Number of additive terms in each bilinear form
// ICUB     Number of cubature formula in CB3H
// ILINT    0  full trilinear transformation
//          1  linear transformation only
//          2  axiparallel grid
    void AssembleMatrices(FiniteElement_3D&       Elem,
			  MultiCompactMatrix*     A,
			  unsigned int            BCON,
			  IntArray2D&             KAB,
			  unsigned int            KABN,
			  unsigned int            ICUB,
			  unsigned int            ISYMM,
			  unsigned int            ICLEAR,
			  unsigned int            ILINT);

    void AssembleTopMatrix(FiniteElement_3D&      Elem,
			   DoubleCompactMatrix*&  A,
			   unsigned int           BCON,
			   IntArray2D&            KAB,
			   unsigned int           KABN,
			   unsigned int           ICUB,
			   unsigned int           ISYMM,
			   unsigned int           ICLEAR,
			   unsigned int           ILINT);

    void AssembleRightHandSide(FiniteElement_3D&  Elem,
			       MultiVector        f,
			       unsigned int       BCON,
			       IntArray&          KB,
			       unsigned int       KBN,
			       unsigned int       ICUB,
			       unsigned int       ICLEAR,
			       unsigned int       ILINT);

    void CalcRightSide(FiniteElement_3D&  Elem,
		       DoubleVector*&     LB,
		       unsigned int       BCON,
		       IntArray&          KB,
		       unsigned int       KBN,
		       unsigned int       ICUB,
		       unsigned int       ICLEAR,
		       unsigned int       ILINT);

    double StepControl     (DoubleCompactMatrix *A, DoubleVector& x,
			    DoubleVector& d, DoubleVector& f,
			    double AMin, double AMax);
    double ConstStepControl(DoubleCompactMatrix *A, DoubleVector& x,
			    DoubleVector& d, DoubleVector& f,
			    double AMin, double AMax);

    MG_Info MultiDriver             (ParFiniteElement_3D& Elem, MultiCompactMatrix* A,
				     DoubleVector *LX1, DoubleVector *LB1, double l2normX,
				     unsigned int MinIterations, unsigned int MaxIterations,
				     double EpsUChange, double EpsUDefect, double DampU,
				     double AMin, double AMax);
    MG_Info MultiDriverSmooth       (ParFiniteElement_3D& Elem, MultiCompactMatrix* A,
				     DoubleVector *LX1, DoubleVector *LB1, double l2normX,
				     unsigned int MaxIterations,
				     double EpsUDefect,
				     int StartLevel,
				     double AMin, double AMax);
    MG_Info PrecondMultiLevel       (ParFiniteElement_3D& Elem,
				     MultiCompactMatrix* A,
				     DoubleVector  *LX1,
				     unsigned int MaxIterations,
				     double EpsUDefect,
				     double AMin, double AMax);
    MG_Info PrecondAddMultiLevel    (ParFiniteElement_3D& Elem,
				     MultiCompactMatrix* A,
				     DoubleVector  *LX1,
				     unsigned int MaxIterations,
				     double EpsUDefect,
				     double AMin, double AMax);
    MG_Info ProjPrecondMultiLevel   (ParFiniteElement_3D& Elem,
				     FiniteElement_3D& ConElem,
				     MultiCompactMatrix* A,
				     DoubleVector *LX1,
				     unsigned int MaxIterations,
				     unsigned int prolongationType,
				     double EpsPDefect,
				     double AMin, double AMax);
    MG_Info ProjPrecondAddMultiLevel(ParFiniteElement_3D& Elem,
				     FiniteElement_3D& ConElem,
				     MultiCompactMatrix* A,
				     DoubleVector *LX1,
				     unsigned int MaxIterations,
				     unsigned int prolongationType,
				     double EpsPDefect,
				     double AMin, double AMax);
//      MG_Info NeumannMultiDriver      (ParFiniteElement_3D& Elem,
//  				     MultiCompactMatrix* A,
//  				     DoubleVector *LX, DoubleVector *LB,
//  				     unsigned int MaxIterations, double EpsPDefect,
//  				     double AMin, double AMax);
    MG_Info ProjMultiDriver         (ParFiniteElement_3D& Elem, FiniteElement_3D& ConElem,
				     MultiCompactMatrix* A,
				     DoubleVector *LX, DoubleVector *LB, double l2normX,
				     unsigned int MinIterations, unsigned int MaxIterations, 
				     unsigned int prolongationType,
				     double EpsPChange, double EpsPDefect, double DampP,
				     double AMin, double AMax);
    MG_Info ProjNeumannMultiDriver  (ParFiniteElement_3D& Elem,
				     MultiCompactMatrix* A,
				     DoubleVector *LX, DoubleVector *LB,
				     unsigned int MaxIterations,
				     double EpsPChange, double EpsPDefect, double DampP);
    MG_Info ProjNeumannMultiDriver  (ParFiniteElement_3D& Elem, MultiCompactMatrix* A,
				     DoubleVector  *LX1, DoubleVector *LB1, double l2normX,
				     unsigned int MinIterations, unsigned int MaxIterations,
				     double EpsPChange, double EpsPDefect, double DampP,
				     double AMin, double AMax);


    virtual void ExactSol(MultiCompactMatrix* A,DoubleVector *LX, DoubleVector *LB) = 0;
    virtual void PreSmooth (MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB,
			    unsigned int Steps, double AMin, double AMax) = 0;
    virtual void PostSmooth(MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB,
			    unsigned int Steps, double AMin, double AMax) = 0;
    virtual void MultiPreSmooth(MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB,
				unsigned int Steps) = 0;
    virtual void MultiPostSmooth(MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB,
				 unsigned int Steps) = 0;
    virtual void ConstPreSmooth(MultiCompactMatrix* A,DoubleVector *LX, DoubleVector *LB,
				unsigned int Steps) = 0;
    virtual void ConstPostSmooth(MultiCompactMatrix* A,DoubleVector *LX, DoubleVector *LB,
				 unsigned int Steps) = 0;
    virtual void CopyBoundaryData(DoubleVector *LB) = 0;

    virtual void Communicate(VOID) = 0;
    virtual void CommunicateExact(DoubleVector *v) = 0;
    virtual void CommunicateConstExact(DoubleVector *v) = 0;
    virtual void SetBoundValues(DoubleVector* x) = 0;
    virtual void GetBoundValuesMult(DoubleVector* x) = 0;

    virtual void CommunicateProlRest(DoubleVector *x) = 0;

    virtual void CommunicateNeumann(VOID) = 0;
    virtual void SetNeumannBoundValues(DoubleVector* x) = 0;
    virtual void GetNeumannBoundValuesMult(DoubleVector* x) = 0;
    virtual int  StopCriterion(double newDefect, double epsDefect) = 0;
    virtual int  StopCriterion(double newDefect, double oldDefect, double change,
			       double epsDefect, double dampingRate, double epsChange) = 0;

    virtual double l2norm(DoubleVector *x) = 0;
    virtual double constl2norm(DoubleVector *x) = 0;
    virtual void   Filter(DoubleVector *x) = 0;
    virtual void   ConstFilter(DoubleVector *x) = 0;
    virtual void   CVectMult(DoubleCompactMatrix *C,
			     DoubleVector& x,DoubleVector& f,double& T) = 0;

    virtual void ConToRot(DoubleVector *vect1,
			  DoubleVector *vect2,unsigned int level) = 0;
    virtual void RotToCon(DoubleVector *vect1,
			  DoubleVector *vect2,unsigned int level) = 0;

    virtual int GetNodeType(int a,int& numneigh) = 0;
    virtual int GetNodeType(int a) = 0;
    virtual int GetNodeTypeCoarse(int a) = 0;

// Post-Process
    virtual void OutputVector(DoubleVector *ptr,int level) {}
    virtual void OutputConstVector(DoubleVector *ptr,int level) {}
};

#endif
