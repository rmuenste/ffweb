#ifndef H_PARCOMPACTMATRIX

#define H_PARCOMPACTMATRIX

#include <DoubleCompactMatrix.h>
#include <MultiCompactMatrix.h>
#include <ParFiniteElement_3D.h>
#include <blist.h>
#include "CComTool.h"
//#include "PerformInfo.h"

#include "MG_Info.h"

class Task;
//extern PerformInfo Perform;

class ParCompactMatrix: public DoubleCompactMatrix
{		
public:
  ParCompactMatrix(unsigned int aNumData,unsigned int aNumDiag)
    :DoubleCompactMatrix(aNumData,aNumDiag) {}
				
  ParCompactMatrix(unsigned int aNumData,unsigned int aNumDiag,BYTEPTR aName)
    :DoubleCompactMatrix(aNumData,aNumDiag,aName) {}
  
  ~ParCompactMatrix(void);

  DoubleVector& ParVectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect,
			    Task *MyTask);
  DoubleVector& ParVectMult(DoubleVector& aSrcVect,
			    DoubleVector& aDestVect,double a1,double a2,
			    Task *MyTask);
  DoubleVector& ParTimeMult(DoubleVector& aLump,DoubleVector& aSrcVect,
			    DoubleVector& aDestVect,double a1,double a2,
			    Task *MyTask);

  DoubleVector& ParNeumannVectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect,
				   Task *MyTask);
  DoubleVector& ParNeumannVectMult(DoubleVector& aSrcVect,
				   DoubleVector& aDestVect,double a1,double a2,
				   Task *MyTask);

  DoubleVector& JacobiSmooth(DoubleVector& x,DoubleVector& b,
			     unsigned int Nit,double Omega,
			     Task *MyTask,
			     DoubleVector *E);
  DoubleVector& SORSmooth(DoubleVector& x,DoubleVector& b,
			     unsigned int Nit,double Omega,
			     Task *MyTask,
			     DoubleVector *E);
  DoubleVector& ILUSmooth(DoubleVector& x,DoubleVector& b,
			     unsigned int Nit,double Omega,
			     Task *MyTask,DoubleVector *E);
  DoubleVector& ConstJacobiSmooth(DoubleVector& x,DoubleVector& b,
			     unsigned int Nit,double Omega,
			     Task *MyTask,DoubleVector *EConst);
  DoubleVector& ConstSORSmooth(DoubleVector& x,DoubleVector& b,
			       unsigned int Nit,double Omega,
			       Task *MyTask,DoubleVector *EConst);
  DoubleVector& ConstILUSmooth(DoubleVector& x,DoubleVector& b,
			       unsigned int Nit,double Omega,
			       Task *MyTask,DoubleVector *EConst);

  DoubleVector& NeumannJacobiSmooth(DoubleVector& x,DoubleVector& b,
				    unsigned int Nit,double Omega,
				    Task *MyTask,
				    DoubleVector *E);
	
	
  DoubleVector& BPS(MultiCompactMatrix *A, DoubleVector& x); 
  DoubleVector& ParCG(DoubleVector& x, DoubleVector& b, 
		      unsigned int Nit, double Eps, Task *MyTask); 
  MG_Info ParPrecondCG(DoubleVector& x, DoubleVector& b, const double l2normX,
			     unsigned int Nit, double Eps, 
			     double AMin, double AMax,
			     int flag, 
			     ParFiniteElement_3D& elem, 
			     MultiCompactMatrix *A, 
			     Task *MyTask); 
  MG_Info ParProjPrecondCG(DoubleVector& x, DoubleVector& b, const double l2normX,
			   unsigned int MinIterations, unsigned int MaxIterations, 
			   unsigned int prolongationType,
			   const double EpsPChange, const double EpsPDefect, const double DampP,
			   const double AMin, const double AMax, int flag, 
			   ParFiniteElement_3D& elem, 
			   FiniteElement_3D& conelem, 
			   MultiCompactMatrix *A, 
			   Task *MyTask);
  DoubleVector& ParMultiLevelCG(ParFiniteElement_3D& Elem,MultiCompactMatrix *A,
				DoubleVector& x, DoubleVector& b, 
				unsigned int Nit, double Eps, Task *MyTask); 

  DoubleVector& ParProjCG(DoubleVector& x, DoubleVector& b, 
		      unsigned int Nit, double Eps, Task *MyTask); 

  DoubleVector& ParNeumannCG(DoubleVector& x, DoubleVector& b, 
		      unsigned int Nit, double Eps, Task *MyTask); 
  DoubleVector& ParProjNeumannCG(DoubleVector& x, DoubleVector& b, 
		      unsigned int Nit, double Eps, Task *MyTask); 
  DoubleVector& ParCG_BPS(DoubleVector& x, DoubleVector& b, 
			  unsigned int Nit, double Eps, Task *MyTask); 
  unsigned int ParBiCGStab(DoubleVector& x, DoubleVector& b, 
		       unsigned int Nit, double Eps, Task *MyTask); 
};	

#endif
