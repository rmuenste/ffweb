#include "Task.h"
#include "ParCompactMatrix.h"

#include "DateTime.h"

extern DateTime ClockMVMult;
extern DateTime ClockMVMultCom;
extern double   TMVMult, TMVMultCom;		  // time spent in matrix vector multiplication routines
extern double   TSmooth,TSmoothCom;

DoubleVector& ParCompactMatrix::ParVectMult(DoubleVector& aSrcVect, DoubleVector& aDestVect,
					    Task *MyTask)
// Compute aDestVect = thisMatrix * aSrcVect
{
#ifdef CLOCK_MEASURE
    ClockMVMult.SetTime();
#endif

    if (aSrcVect.GetLen() == GetNumDiag()  &&  aDestVect.GetLen() == GetNumDiag()) {
	for (unsigned int index = 1; index <= GetNumDiag(); index++)
	    aDestVect(index) = aSrcVect(index) * (*this).Data((*Diagonal)(index));
	for (unsigned int index = 1; index <= GetNumDiag(); index++) {
	    for (int index2 = (*Diagonal)(index) + 1; index2 <= (*Diagonal)(index + 1) - 1; index2++)
		aDestVect(index) += ((*this).Data(index2) * aSrcVect((*Column)(index2)));
	}
#ifdef CLOCK_MEASURE
	ClockMVMultCom.SetTime();
#endif
	MyTask->SetBoundValues(&aDestVect);
	MyTask->Communicate();
	MyTask->GetBoundValuesMult(&aDestVect);
#ifdef CLOCK_MEASURE
	TMVMultCom += ClockMVMultCom.GetTimeDiff();
#endif
    }
#ifdef CLOCK_MEASURE
    TMVMult += ClockMVMult.GetTimeDiff();
#endif

    return aDestVect;
}

DoubleVector& ParCompactMatrix::ParVectMult(DoubleVector& aSrcVect, DoubleVector& aDestVect,
					    double a1, double a2, Task *MyTask)
// Compute aDestVect = a2 * aDestVect  +  a1 * thisMatrix * aSrcVect
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParCompactMatrix::ParVectMult.\n";
        protocol.mFlush();
    }

    DoubleVector *temp = new DoubleVector(aSrcVect.GetLen());

    if (aSrcVect.GetLen() == GetNumDiag()  &&  aDestVect.GetLen() == GetNumDiag()) {
	// a1 != 0
	if (fabs(a1 - 0.0) > FLOAT_EPS) {
	    // a2 == 0
	    if (fabs(a2 - 0.0) < FLOAT_EPS) {
		ParVectMult(aSrcVect, aDestVect, MyTask);
		aDestVect *= a1;
	    } else {
		ParVectMult(aSrcVect, *temp, MyTask);
		*temp *= a1;
		aDestVect *= a2;
		aDestVect += *temp;
	    }
	} else {
	    aDestVect *= a2;
	}
    }

    delete temp;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParCompactMatrix::ParVectMult.\n";
        protocol.mFlush();
    }

    return aDestVect;
}


DoubleVector& ParCompactMatrix::ParTimeMult(DoubleVector& aLump,
					    DoubleVector& aSrcVect, DoubleVector& aDestVect,
					    double a1, double a2, Task *MyTask)
// Compute aDestVect = a2 * aDestVect  +  aSrcVect * (a1 * thisMatrix + aLump)
{
#ifdef CLOCK_MEASURE
    ClockMVMult.SetTime();
#endif
    if (aSrcVect.GetLen() == GetNumDiag()  &&  aDestVect.GetLen() == GetNumDiag()) {
	aDestVect *= a2;
	for (unsigned int index = 1; index <= GetNumDiag(); index++)
	    aDestVect(index) += aSrcVect(index) * (a1 * (*this).Data((*Diagonal)(index)) + aLump(index));
	for (unsigned int index = 1; index <= GetNumDiag(); index++) {
	    for (int index2 = (*Diagonal)(index) + 1; index2 <= (*Diagonal)(index + 1) - 1; index2++)
		aDestVect(index) += (a1 * (*this).Data(index2) * aSrcVect((*Column)(index2)));
	}
#ifdef CLOCK_MEASURE
	ClockMVMultCom.SetTime();
#endif
	MyTask->SetBoundValues(&aDestVect);
	MyTask->Communicate();
	MyTask->GetBoundValuesMult(&aDestVect);
#ifdef CLOCK_MEASURE
	TMVMultCom += ClockMVMultCom.GetTimeDiff();
#endif
    }
#ifdef CLOCK_MEASURE
    TMVMult += ClockMVMult.GetTimeDiff();
#endif

    return aDestVect;
}


DoubleVector& ParCompactMatrix::ParNeumannVectMult(DoubleVector& aSrcVect, DoubleVector& aDestVect,
						   Task *MyTask)
// Compute aDestVect = thisMatrix * aSrcVect
{
#ifdef CLOCK_MEASURE
    ClockMVMult.SetTime();
#endif
    if (aSrcVect.GetLen() == GetNumDiag()  &&  aDestVect.GetLen() == GetNumDiag()) {
	for (unsigned int index = 1; index <= GetNumDiag(); index++)
	    aDestVect(index) = aSrcVect(index) * (*this).Data((*Diagonal)(index));
	for (unsigned int index = 1; index <= GetNumDiag(); index++) {
	    for (int index2 = (*Diagonal)(index) + 1; index2 <= (*Diagonal)(index + 1) - 1; index2++)
		aDestVect(index) += ((*this).Data(index2) * aSrcVect((*Column)(index2)));
	}
#ifdef CLOCK_MEASURE
	ClockMVMultCom.SetTime();
#endif
	MyTask->SetNeumannBoundValues(&aDestVect);
	MyTask->CommunicateNeumann();
	MyTask->GetNeumannBoundValuesMult(&aDestVect);
#ifdef CLOCK_MEASURE
	TMVMultCom += ClockMVMultCom.GetTimeDiff();
#endif
    }

#ifdef CLOCK_MEASURE
    TMVMult += ClockMVMult.GetTimeDiff();
#endif
    return aDestVect;
}

DoubleVector& ParCompactMatrix::ParNeumannVectMult(DoubleVector& aSrcVect, DoubleVector& aDestVect,
						   double a1, double a2, Task *MyTask)
// Compute aDestVect = a2 * aDestVect  +  a1 * thisMatrix * aSrcVect
{
    DoubleVector temp(aSrcVect.GetLen());

    if (aSrcVect.GetLen() == GetNumDiag() && aDestVect.GetLen() == GetNumDiag()) {
	// a1 != 0
	if (fabs(a1 - 0.0) > FLOAT_EPS) {
	    // a2 == 0
	    if (fabs(a2 - 0.0) < FLOAT_EPS) {
		ParNeumannVectMult(aSrcVect, aDestVect, MyTask);
		aDestVect *= a1;
	    } else {
		ParNeumannVectMult(aSrcVect, temp, MyTask);
		temp *= a1;
		aDestVect *= a2;
		aDestVect += temp;
	    }
	} else {
	    aDestVect *= a2;
	}
	return aDestVect;
    }

    return aDestVect;
}

DoubleVector& ParCompactMatrix::JacobiSmooth(DoubleVector& x,DoubleVector& b,
					     unsigned int Nit,double Omega,
					     Task *MyTask,
					     DoubleVector *E)
{
#ifdef CLOCK_MEASURE
    DateTime Clock;
    DateTime ClockHelp;
    Clock.SetTime();
#endif
    double T1 = 0, T2 = 0; 
    unsigned int ITE, IEQ;
    DoubleVector CVector(GetNumDiag());

//    Prot << "E = \n"; 
//    MyTask->OutputVector(E,2);

    for (ITE = 1; ITE <= Nit; ITE++) {
	CVector = 0;
	VectMult(x,CVector);

#ifdef CLOCK_MEASURE
	ClockHelp.SetTime();
#endif
	MyTask->SetBoundValues(&CVector);
	MyTask->Communicate();
	MyTask->GetBoundValuesMult(&CVector);
#ifdef CLOCK_MEASURE
	T2 += ClockHelp.GetTimeDiff(); 
#endif

	CVector -= b; 

//        Prot<<"CVector=\n";
//        MyTask->OutputVector(&CVector,2);

	for (IEQ = 1; IEQ <= GetNumDiag(); IEQ++) {
	    x(IEQ) -= (Omega * CVector(IEQ) / (*E)(IEQ));
//  	    protocol << "IEQ=" << IEQ << " :   " << (*E)(IEQ) << "\n";
	}
    }

#ifdef CLOCK_MEASURE
    T1 += Clock.GetTimeDiff();
    TSmooth += T1;
    TSmoothCom += T2;
#endif

//    for(ITE=1;ITE<=Nit;ITE++)
//    {
//        CVector=0;
//        for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
//  	  for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
//  	      CVector(IEQ)-=(Data(ICOL)*x(Col(ICOL)));
//  	  }
//        }
//        MyTask->SetBoundValues(&CVector);
//        MyTask->Communicate();
//        MyTask->GetBoundValuesMult(&CVector);

//        CVector+=b;

//        for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
//  	  x(IEQ)=(1.0-Omega)*x(IEQ)+(Omega*CVector(IEQ)/(*E)(IEQ));
//        }
//    }

    return x;
}

DoubleVector& ParCompactMatrix::SORSmooth(DoubleVector& x,DoubleVector& b,
					  unsigned int Nit,double Omega,
					  Task *MyTask,
					  DoubleVector *E)
{
#ifdef CLOCK_MEASURE
    DateTime Clock;
    DateTime ClockHelp;
    Clock.SetTime();
#endif

    unsigned int ITE,IEQ,ICOL;
    double T1=0,T2=0,Aux;
    DoubleVector *CVector = new DoubleVector(x);

    for (ITE = 1; ITE <= Nit; ITE++) {
	*CVector=0;
	VectMult(x,*CVector);

#ifdef CLOCK_MEASURE
	ClockHelp.SetTime();
#endif
	MyTask->SetBoundValues(CVector);
	MyTask->Communicate();
	MyTask->GetBoundValuesMult(CVector);
#ifdef CLOCK_MEASURE
	T2 += ClockHelp.GetTimeDiff(); 
#endif

	*CVector -= b; 

	for (IEQ = 1; IEQ <= GetNumDiag(); IEQ++) {
	    if (MyTask->GetNodeTypeSmooth(IEQ) == ART_BOUND) {
		Aux = (*CVector)(IEQ); 
		for (ICOL = Diag(IEQ) + 1; ICOL <= Diag(IEQ + 1) - 1; ICOL++) {
		    if (Col(ICOL) < IEQ)
			Aux -= Omega * (Data(ICOL) * (*CVector)(Col(ICOL))); 
		}
		(*CVector)(IEQ) = Omega * Aux / (*E)(IEQ); 
	    } else {
		(*CVector)(IEQ) = 0.8 * (*CVector)(IEQ) / (*E)(IEQ); 
	    }
	}
	x -= *CVector; 
    }

    delete CVector;

#ifdef CLOCK_MEASURE
    T1 += Clock.GetTimeDiff();
    TSmooth += T1;
    TSmoothCom += T2;
#endif

    return x;
}

DoubleVector& ParCompactMatrix::ILUSmooth(DoubleVector& x, DoubleVector& b,
					  unsigned int Nit, double Omega,
					  Task *MyTask, DoubleVector *E)
{
#ifdef CLOCK_MEASURE
    DateTime Clock;
    DateTime ClockHelp;
    Clock.SetTime();
#endif

    unsigned int ITE,IEQ;
    double T1 = 0, T2 = 0; 
    DoubleVector *CVector  = new DoubleVector(x.GetLen()); 
    DoubleVector *CVector2 = new DoubleVector(x.GetLen()); 
    DoubleVector *CVector3 = new DoubleVector(x.GetLen()); 

    for (ITE = 1; ITE <= Nit; ITE++) {
	*CVector=0;
	VectMult(x,*CVector);

#ifdef CLOCK_MEASURE
	ClockHelp.SetTime();
#endif
	MyTask->SetBoundValues(CVector);
	MyTask->Communicate();
	MyTask->GetBoundValuesMult(CVector);
#ifdef CLOCK_MEASURE
	T2 += ClockHelp.GetTimeDiff(); 
#endif

	*CVector -= b; 

//      Prot<<"Norm(CVector)="<<CVector->l2Norm()<<"\n";

	PermToNew(*CVector,*CVector2);
	ILU(*CVector2);
	PermToOld(*CVector2,*CVector3);

//      Prot<<"After ILU CVector3=\n"<<*CVector3<<"\n";

	for (IEQ = 1; IEQ <= GetNumDiag(); IEQ++) {
	    if (MyTask->GetNodeTypeSmooth(IEQ) == ART_BOUND) {
		x(IEQ) -= (*CVector3)(IEQ); 
	    } else {
		x(IEQ) -= 0.8 * (*CVector)(IEQ) / (*E)(IEQ); ;
	    }
	}
    }

    delete CVector;
    delete CVector2;
    delete CVector3;

#ifdef CLOCK_MEASURE
    T1 += Clock.GetTimeDiff(); 
    TSmooth += T1; 
    TSmoothCom += T2; 
#endif

    return x;
}


DoubleVector& ParCompactMatrix::ConstJacobiSmooth(DoubleVector& x,
						  DoubleVector& b,
						  unsigned int Nit,double Omega,
						  Task *MyTask,
						  DoubleVector *EConst)
{
#ifdef CLOCK_MEASURE
    DateTime Clock;
    DateTime ClockHelp;
    Clock.SetTime();
#endif
    unsigned int ITE,IEQ;
    double T1 = 0, T2 = 0; 
    DoubleVector CVector(GetNumDiag());

    for (ITE = 1; ITE <= Nit; ITE++) {
	CVector=0;
	MyTask->CVectMult(this, x, CVector, T2); 

	CVector -= b; 

	for (IEQ = 1; IEQ <= GetNumDiag(); IEQ++) {
	    x(IEQ) -= (Omega * CVector(IEQ) / (*EConst)(IEQ)); 
//  protocol << "(*EConst)(IEQ): " << (*EConst)(IEQ) << "\n";
	}
//  protocol << "fertig.\n";
    }
#ifdef CLOCK_MEASURE
    T1 += Clock.GetTimeDiff(); 
    TSmooth += T1; 
    TSmoothCom += T2; 
#endif

    return x;
}


DoubleVector& ParCompactMatrix::ConstSORSmooth(DoubleVector& x,
					       DoubleVector& b,
					       unsigned int Nit,double Omega,
					       Task *MyTask,
					       DoubleVector *EConst)
{
#ifdef CLOCK_MEASURE
    DateTime Clock;
    Clock.SetTime();
#endif

    double T1 = 0, T2 = 0; 
    unsigned int ITE,IEQ,ICOL;
    double Aux;
    DoubleVector CVector(x);

    for (ITE = 1; ITE <= Nit; ITE++) {
	CVector = 0; 
	MyTask->CVectMult(this,x,CVector,T2);

	CVector -= b; 

	for (IEQ = 1; IEQ <= GetNumDiag(); IEQ++) {
	    //      if(MyTask->GetNodeType(IEQ)!=ART_BOUND) {
	    Aux = CVector(IEQ); 
	    for (ICOL = Diag(IEQ) + 1; ICOL <= Diag(IEQ + 1) - 1; ICOL++) {
		if (Col(ICOL) < IEQ)
		    Aux -= Omega * (Data(ICOL) * CVector(Col(ICOL))); 
	    }
	    CVector(IEQ) = Omega * Aux / (*EConst)(IEQ); 
	    //      } else {
	    //CVector(IEQ)=0.8*CVector(IEQ)/(*EConst)(IEQ);
	    //}
	}

	x -= CVector; 
    }

#ifdef CLOCK_MEASURE
    T1 += Clock.GetTimeDiff();

    TSmooth += T1;
    TSmoothCom += T2;
#endif

    return x;
}

DoubleVector& ParCompactMatrix::ConstILUSmooth(DoubleVector& x, DoubleVector& b,
					       unsigned int Nit, double Omega,
					       Task *MyTask, DoubleVector *EConst)
{
#ifdef CLOCK_MEASURE
    DateTime Clock;
    Clock.SetTime();
#endif

    double T1 = 0, T2 = 0; 
    unsigned int ITE, IEQ;
    DoubleVector *CVector =new DoubleVector(x.GetLen()); 
    DoubleVector *CVector2 = new DoubleVector(x.GetLen()); 
    DoubleVector *CVector3 = new DoubleVector(x.GetLen()); 

    for (ITE = 1; ITE <= Nit; ITE++) {
	*CVector = 0;
	MyTask->CVectMult(this, x, *CVector, T2);

	*CVector -= b; 

//      Prot<<"Norm(CVector)="<<CVector->l2Norm()<<"\n";

	PermToNew(*CVector,*CVector2);
	ILU(*CVector2);
	PermToOld(*CVector2,*CVector3);

	for (IEQ = 1; IEQ <= GetNumDiag(); IEQ++) {
	    if (MyTask->GetElemTypeSmooth(IEQ) == ART_BOUND) {
		x(IEQ) -= (*CVector3)(IEQ);
	    } else {
		x(IEQ) -= 0.8 * (*CVector)(IEQ) / (*EConst)(IEQ); ;
	    }
	}

    }

    delete CVector;
    delete CVector2;
    delete CVector3;

#ifdef CLOCK_MEASURE
    T1 += Clock.GetTimeDiff();

    TSmooth += T1;
    TSmoothCom += T2;
#endif

    return x;
}


DoubleVector& ParCompactMatrix::NeumannJacobiSmooth(DoubleVector& x,DoubleVector& b,
						    unsigned int Nit,double Omega,
						    Task *MyTask,
						    DoubleVector *E)
{
#ifdef CLOCK_MEASURE
    double T1 = 0, T2 = 0; 
    DateTime Clock, ClockHelp;
    Clock.SetTime();
#endif

    unsigned int ITE, IEQ, ICOL;
    DoubleVector CVector(GetNumDiag());

    for (ITE = 1; ITE <= Nit; ITE++) {
	CVector = 0; 
	for (IEQ = 1; IEQ <= GetNumDiag(); IEQ++) {
	    for (ICOL = Diag(IEQ) + 1; ICOL <= Diag(IEQ + 1) - 1; ICOL++) {
		CVector(IEQ) -= (Data(ICOL) * x(Col(ICOL))); 
	    }
	}
#ifdef CLOCK_MEASURE
	ClockHelp.SetTime();
#endif
	MyTask->SetNeumannBoundValues(&CVector);
	MyTask->CommunicateNeumann();
	MyTask->GetNeumannBoundValuesMult(&CVector);
#ifdef CLOCK_MEASURE
	T2 += ClockHelp.GetTimeDiff(); 
#endif

	CVector += b; 

	for (IEQ = 1; IEQ <= GetNumDiag(); IEQ++) {
	    x(IEQ) = (1.0 - Omega) * x(IEQ) + (Omega * CVector(IEQ) / (*E)(IEQ)); 
	}
    }

#ifdef CLOCK_MEASURE
    T1 += Clock.GetTimeDiff();

    TSmooth += T1;
    TSmoothCom += T2;
#endif

    return x;
}


DoubleVector& ParCompactMatrix::ParCG(DoubleVector& x,DoubleVector& b,
				      unsigned int Nit,double Eps,Task *MyTask)
{
    unsigned int ITE;
    double Res,Fr,Sigma0,Alpha,Sigma1,Cappa,Gamma;

    if (GetNumDiag() != x.GetLen() || x.GetLen() != b.GetLen())
	return x;

    DoubleVector dr=b,dd=b,dd1=b;

    // MatrixMult
    (*this).ParVectMult(x,dr,MyTask);

    //residual
    dr -= b; 

    // SkalProd
    Res = sqrt(((ParVector)dr).ScalProd(dr, MyTask)); 

    if (Res <= Eps) {
	ITE = 0;
	Fr = Res;
	Prot << "Iterations " << ITE << "  CG - Verfahren  Norm of residual " << Fr << " !!Res!!/!!Initial Res!! " << Res << "\n";
// 	protocol << "Iterations " << ITE << "  CG - Verfahren  Norm of residual " << Fr << " !!Res!!/!!Initial Res!! " << Res << "\n";
	return x;
    } else {
	Sigma0=Res*Res;

	// Abstiegsrichtung dd
	dd = dr; dd *= -1;
	for (ITE = 1; ITE <= Nit; ITE++) {
	    // MatrixMult
	    (*this).ParVectMult(dd,dd1,MyTask);
	    // SkalProd
	    Alpha=((ParVector)dd).ScalProd(dd1,MyTask);
	    Alpha=Sigma0/Alpha;

	    // Loesung updaten
	    x.AddMultConst(dd,Alpha);
	    // Gradient berechnen
	    dr.AddMultConst(dd1,Alpha);
	    // Abbruchkriterium berechnen

	    Fr=sqrt(((ParVector)dr).ScalProd(dr,MyTask));

	    Prot<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";
// 	    protocol<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";

	    if(Fr<=Eps) {
		if(Res>=1e-70)
		    Res=Fr/Res;
		Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
		Prot.Flush();
		if(ITE==0)
		    Cappa=0;
		else
		    Cappa=pow(Res,(1/(double)ITE));
		Prot<<"Rate of convergence "<<Cappa<<"\n";
// 		protocol<<"Iterations "<<ITE<<"  ParCG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
// 		protocol<<"Rate of convergence "<<Cappa<<"\n";
		return x;
	    }
	    // Neue Abstiegsrichtung
	    Sigma1=Fr*Fr;

	    Gamma=Sigma1/Sigma0;
	    Sigma0=Sigma1;
	    dd*=Gamma;dd-=dr;
	}
	Prot<<"CONVERGENCE FAILED !!\n";
	Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	if(Res>=1e-70) {
	    Cappa=pow((Fr/Res),(1/(double)Nit));
	} else {
	    Cappa=0;
	}
	Prot<<"Rate of convergence "<<Cappa<<"\n";
// 	protocol<<"Iterations "<<Nit<<"  ParCG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
// 	protocol<<"Rate of convergence "<<Cappa<<"\n";
	return x;
    }
    if(Res>=1e-70)
	Res=Fr/Res;
    Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
    if(ITE==0)
	Cappa=0;
    else
	Cappa=pow(Res,(1/(double)ITE));
    Prot<<"Rate of convergence "<<Cappa<<"\n";

//  protocol<<"Iterations "<<Nit<<"  ParCG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
//  protocol<<"Rate of convergence "<<Cappa<<"\n";

    return x;
}

MG_Info ParCompactMatrix::ParPrecondCG(DoubleVector& x, DoubleVector& b, const double l2normX,
				       unsigned int MaxIterations, double Eps,
				       double AMin, double AMax,
				       int flag,
				       ParFiniteElement_3D& elem,
				       MultiCompactMatrix *A,
				       Task *MyTask)
{
    unsigned int ITE;
    double Sigma0, Alpha, Sigma1, Gamma;
    double       defectInitial, defectOld;
    MG_Info      cgInfo = { -99999, -99999, -99999, -99999, 99999, -99999 };

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParCompactMatrix::ParPrecondCG.\n";
        protocol.mFlush();
    }

    if (GetNumDiag() != x.GetLen() || x.GetLen() != b.GetLen())
	return cgInfo;

    DoubleVector dr = b, dd = b, dd1 = b, dg = b;

    if (flag == 0)
	Prot << "No preconditioning !!\n";
    else if (flag == 1)
	Prot << "Additive multilevel preconditioner !!\n";
    else if (flag == 2)
	Prot << "Multiplicative preconditioner !!\n";

// MatrixMult
    (*this).ParVectMult(x, dr, MyTask);

//residual
    dr -= b;

// SkalProd
    cgInfo.defect = sqrt(((ParVector)dr).ScalProd(dr, MyTask));
    defectInitial = defectOld = cgInfo.defect;

//  protocol << "cgInfo.defect: " << cgInfo.defect << "\n";
//      if (cgInfo.defect <= Eps) {
//  	ITE = 0;
//  	Prot << "Iterations " << ITE << "  CG - Verfahren  Norm of residual " << cgInfo.defect << " !!Res!!/!!Initial Res!! " << cgInfo.defect << "\n";
//      } else {
	if (flag == 0) {
	    dg = dr;
	    Sigma0 = cgInfo.defect * cgInfo.defect;
	} else if (flag == 1) {
	    dg = dr;
	    MyTask->PrecondAddMultiLevel(elem, A, &dg, 1, Eps, AMin, AMax);
	    Sigma0 = dr * dg;
	} else if (flag == 2) {
	    dg = dr;
	    MyTask->PrecondMultiLevel(elem, A, &dg, 1, Eps, AMin, AMax);
	    Sigma0 = dr * dg;
	}

	// Abstiegsrichtung dd
	dd = dg; dd *= -1;
	for (ITE = 1; ITE <= MaxIterations; ITE++) {
	    // MatrixMult
	    (*this).ParVectMult(dd, dd1, MyTask);
	    // SkalProd
	    Alpha = ((ParVector)dd).ScalProd(dd1, MyTask);
//  protocol << " l2norm dd  : " << dd.l2Norm() << "\n";
//  protocol << " l2norm dd1 : " << dd1.l2Norm() << "\n";
	    Alpha = Sigma0 / Alpha;

	    // Loesung updaten
	    x.AddMultConst(dd, Alpha);

	    // Gradient berechnen
	    dr.AddMultConst(dd1, Alpha);

	    // Abbruchkriterium berechnen
	    cgInfo.defect = sqrt(((ParVector)dr).ScalProd(dr, MyTask));

	    // Compute relative change of solution, i.e.
	    //   || x_{n+1} - x_{n} || / || x_{n} ||
	    // = || x || / || x_{n} ||
	    if (fabs(l2normX) < 1e-16) {	  // l2normX == 0 ?
		cgInfo.relChange = 0;
	    } else {
		cgInfo.relChange = sqrt(((ParVector)x).ScalProd(x, MyTask)) / l2normX;
	    }

	    Prot << "  Iteration " << ITE << "  !!Res!! = " << cgInfo.defect << "\n";
//  protocol << "cgInfo.defect: " << cgInfo.defect << "\n";

	    if (cgInfo.defect <= Eps)
		break;

	    // Neue Abstiegsrichtung
	    if (flag == 0) {
		dg = dr;
		Sigma1 = cgInfo.defect * cgInfo.defect;
	    } else if (flag == 1) {
		dg = dr;
		MyTask->PrecondAddMultiLevel(elem, A, &dg, 1, Eps, AMin, AMax);
		Sigma1 = dr * dg;
	    } else if (flag == 2) {
		dg = dr;
		MyTask->PrecondMultiLevel(elem, A, &dg, 3, Eps, AMin, AMax);
		Sigma1 = dr * dg;
	    }

	    Gamma = Sigma1 / Sigma0;
	    Sigma0 = Sigma1;
	    dd *= Gamma; dd -= dg;
	}

	if (ITE == MaxIterations)
	    Prot << "CONVERGENCE FAILED !!\n";
//      }

    if (defectInitial >= 1e-70)
	cgInfo.defectReduction = cgInfo.defect / defectInitial;

    Prot << "  CG-Method ITERATIONS " << ITE
	 << "  NORM OF RESIDUAL " << cgInfo.defect << "\n      "
	 << "  !!RES!!/!!INITIAL RES!!" << cgInfo.defectReduction << "\n";
    if (ITE == 0)
	cgInfo.convRate = 0;
    else
	cgInfo.convRate = pow(cgInfo.defectReduction, (1 / (double)ITE));
    Prot << "Rate of convergence " << cgInfo.convRate << "\n";
    cgInfo.steps    = ITE;

//      protocol << "cgInfo.defect: " << cgInfo.defect << "\n"
//  	     << "cgInfo.defectReduction: " << cgInfo.defectReduction << "\n"
//  	     <<	"cgInfo.relChange: " << cgInfo.relChange << "\n"
//  	     << "cgInfo.convRate: " << cgInfo.convRate << "\n"
//  	     << "cgInfo.steps: " << cgInfo.steps << "\n";

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParCompactMatrix::ParPrecondCG.\n";
        protocol.mFlush();
    }

    return cgInfo;
}

DoubleVector& ParCompactMatrix::ParProjCG(DoubleVector& x,DoubleVector& b,
					  unsigned int Nit,double Eps,Task *MyTask)
// Not controlled by S.H.M.B.
{
    unsigned int ITE;
    double Res,Fr,Sigma0,Alpha,Sigma1,Cappa,Gamma;
    double T2;

    if(GetNumDiag()!=x.GetLen() || x.GetLen()!=b.GetLen())
	return x;

    DoubleVector dr=b,dd=b,dd1=b;

// MatrixMult
//  (*this).ParVectMult(x,dr,MyTask);
    MyTask->CVectMult(this,x,dr,T2);

//residual
    dr-=b;

// SkalProd
    Res=sqrt(((ParVector)dr).ConstScalProd(dr,MyTask));

    if(Res<=Eps) {
	ITE=0;
	Fr = Res;
	Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	return x;
    } else {
	Sigma0=Res*Res;

// Abstiegsrichtung dd
	dd = dr; dd *= -1;
	for (ITE = 1; ITE <= Nit; ITE++) {
// MatrixMult
//      (*this).ParVectMult(dd,dd1,MyTask);
	    MyTask->CVectMult(this,dd,dd1,T2);
// SkalProd
	    Alpha=((ParVector)dd).ConstScalProd(dd1,MyTask);
	    Alpha=Sigma0/Alpha;

// Loesung updaten
	    x.AddMultConst(dd,Alpha);
// Gradient berechnen
	    dr.AddMultConst(dd1,Alpha);
// Abbruchkriterium berechnen

	    Fr=sqrt(((ParVector)dr).ConstScalProd(dr,MyTask));

	    ProtAdd<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";

	    if(Fr<=Eps) {
		if(Res>=1e-70)
		    Res=Fr/Res;
		Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
		if(ITE==0)
		    Cappa=0;
		else
		    Cappa=pow(Res,(1/(double)ITE));
		Prot<<"Rate of convergence "<<Cappa<<"\n";
		return x;
	    }
// Neue Abstiegsrichtung
	    Sigma1=Fr*Fr;

	    Gamma=Sigma1/Sigma0;
	    Sigma0=Sigma1;
	    dd*=Gamma;dd-=dr;
	}
	Prot<<"CONVERGENCE FAILED !!\n";
	Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	if(Res>=1e-70) {
	    Cappa=pow((Fr/Res),(1/(double)Nit));
	} else {
	    Cappa=0;
	}
	Prot<<"Rate of convergence "<<Cappa<<"\n";
	return x;
    }
    if(Res>=1e-70)
	Res=Fr/Res;
    Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
    if(ITE==0)
	Cappa=0;
    else
	Cappa=pow(Res,(1/(double)ITE));
    Prot<<"Rate of convergence "<<Cappa<<"\n";
    return x;
}

MG_Info ParCompactMatrix::ParProjPrecondCG(DoubleVector& x, DoubleVector& b, const double l2normX,
					   unsigned int MinIterations, unsigned int MaxIterations, 
					   unsigned int prolongationType,
					   const double EpsPChange, const double EpsPDefect, const double DampP,
					   const double AMin, const double AMax, int flag,
					   ParFiniteElement_3D& elem,
					   FiniteElement_3D& conelem,
					   MultiCompactMatrix *A,
					   Task *MyTask)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParCompactMatrix::ParProjPrecondCG.\n";
        protocol.mFlush();
    }

#ifdef CLOCK_MEASURE
    DateTime Clock, ClockTotal;
    double   TimeVectMult, TimePrecond, TimeSkal, TimeTotal;
    TimeVectMult = TimePrecond = TimeSkal = TimeTotal = 0;
    Clock.SetTime();
#endif
    double       T2;
    unsigned int ITE;
    int          abflag;
    double       Sigma0, Alpha, Sigma1, Gamma;
//      double MaxNorm;
    double       defectInitial, defectOld;
    MG_Info      cgInfo = { -100, -100, -100, -100, 0, -100 };

    if (GetNumDiag() != x.GetLen()  ||  x.GetLen() != b.GetLen())
	return cgInfo;

    DoubleVector dr = b, dd = b, dd1 = b, dg = b;

//  if(flag==0)
//    Prot<<"No preconditioning !!\n";
//  else if(flag==1)
//    Prot<<"Additive multilevel preconditioner !!\n";
//  else if(flag==2)
//    Prot<<"Multiplicative preconditioner !!\n";

    // MatrixMult
    //(*this).ParVectMult(x,dr,MyTask);
    MyTask->CVectMult(this,x,dr,T2);

    //residual
    dr -= b;
#ifdef CLOCK_MEASURE
    TimeVectMult += Clock.GetTimeDiff();
    Clock.SetTime();
#endif

    // inner product: defect = || dr ||_L^{2}
    cgInfo.defect = sqrt(((ParVector)dr).ConstScalProd(dr, MyTask));
    defectInitial = defectOld = cgInfo.defect;
#ifdef CLOCK_MEASURE
    TimeSkal += Clock.GetTimeDiff();
    Clock.SetTime();
#endif

    if (flag == 0) {
	dg = dr;
	Sigma0 = cgInfo.defect * cgInfo.defect;
    } else if (flag == 1) {
	dg = dr;
	MyTask->ProjPrecondAddMultiLevel(elem, conelem, A, &dg, 1, prolongationType, EpsPDefect, AMin, AMax);
	Sigma0 = ((ParVector)dr).ConstScalProd(dg, MyTask);
    } else if (flag == 2) {
	dg = dr;
	MyTask->ProjPrecondMultiLevel(elem, conelem, A, &dg, 1, prolongationType, EpsPDefect, AMin, AMax);
	Sigma0 = ((ParVector)dr).ConstScalProd(dg, MyTask);
    }
#ifdef CLOCK_MEASURE
    TimePrecond += Clock.GetTimeDiff();
#endif

    // Abstiegsrichtung dd
    dd = dg; dd *= -1;
    for (ITE = 1; ITE <= MaxIterations; ITE++) {
	// MatrixMult
#ifdef CLOCK_MEASURE
	Clock.SetTime();
#endif

	//(*this).ParVectMult(dd,dd1,MyTask);
	MyTask->CVectMult(this, dd, dd1, T2);
#ifdef CLOCK_MEASURE
	TimeVectMult += Clock.GetTimeDiff();
	Clock.SetTime();
#endif

	// SkalProd
	Alpha = ((ParVector)dd).ConstScalProd(dd1, MyTask);
	Alpha = Sigma0 / Alpha;
#ifdef CLOCK_MEASURE
	TimeSkal += Clock.GetTimeDiff();
#endif

	// Loesung updaten
	x.AddMultConst(dd, Alpha);
	// Gradient berechnen
	dr.AddMultConst(dd1, Alpha);

	// Abbruchkriterium berechnen
#ifdef CLOCK_MEASURE
	Clock.SetTime();
#endif
	cgInfo.defect = sqrt(((ParVector)dr).ConstScalProd(dr, MyTask));
#ifdef CLOCK_MEASURE
	TimeSkal += Clock.GetTimeDiff();
#endif

	// Compute relative change of solution, i.e.
	//   || x_{n+1} - x_{n} || / || x_{n} ||
	// = || x || / || x_{n} ||
	if (fabs(l2normX) < 1e-16) {	  // l2normX == 0 ?
	    cgInfo.relChange = 0;
	} else {
	    cgInfo.relChange = sqrt(((ParVector)x).ConstScalProd(x, MyTask)) / l2normX;
	}

	//Prot<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";
	//Prot.Flush();

	// Here, we can actually control how accurate the equation is solved.
	// There are many possibilities: Check, whether
	// (a) defect <= EpsPDefect
	// (b) defect <= defectInitial * DampP
	// (c) relChange <= EpsPChange

	// Only (a)
	abflag = MyTask->StopCriterion(cgInfo.defect, EpsPDefect);
#ifdef MG_DEBUG
	protocol << "MG_DEBUG: " 
		 << "        defect    ?<? EpsDefect\n"
		 << "MG_DEBUG: " << cgInfo.defect << " ?<? " << EpsPDefect
		 << "  (Iteration " << ITE << ")\n";
#endif

	    // (a) + (b) + (c)
//  	abflag = MyTask->StopCriterion(cgInfo.defect, defectInitial, cgInfo.relChange, EpsPDefect, DampP, EpsPChange);
//  #ifdef MG_DEBUG
//  	protocol << "MG_DEBUG: ITE: " << ITE << "\n"
//  		 << "MG_DEBUG: " << "        defect    ?<? EpsDefect         defect   ?<? defectInitial * DampP      relChange  ?<? EpsChange\n"
//  		 << "MG_DEBUG: " << cgInfo.defect << " ?<? " << EpsPDefect << "    "
//  		 << cgInfo.defect << " ?<? " << defectInitial * DampP << "   "
//  		 << cgInfo.relChange << " ?<? " << EpsPChange
//		 << "  (Iteration " << ITE << ")\n";
//  #endif

	if (abflag == CRIT_TRUE  &&  ITE >= MinIterations)
	    break;

	// Neue Abstiegsrichtung
#ifdef CLOCK_MEASURE
	Clock.SetTime();
#endif
	if (flag == 0) {
	    dg = dr;
	    Sigma1 = cgInfo.defect * cgInfo.defect;
	} else if (flag == 1) {
	    dg = dr;
	    MyTask->ProjPrecondAddMultiLevel(elem, conelem, A, &dg, 1, prolongationType, EpsPDefect, AMin, AMax);
	    Sigma1 = ((ParVector)dr).ConstScalProd(dg, MyTask);
	} else if (flag == 2) {
	    dg = dr;
	    MyTask->ProjPrecondMultiLevel(elem, conelem, A, &dg, 1, prolongationType, EpsPDefect, AMin, AMax);
	    Sigma1 = ((ParVector)dr).ConstScalProd(dg, MyTask);
	}
#ifdef CLOCK_MEASURE
	TimePrecond += Clock.GetTimeDiff();
#endif

	Gamma = Sigma1 / Sigma0;
	Sigma0 = Sigma1;
	dd *= Gamma; dd -= dg;
    }

#ifdef CLOCK_MEASURE
    TimeTotal = ClockTotal.GetTimeDiff();
#endif

    if (defectInitial >= 1e-70)
	cgInfo.defectReduction = cgInfo.defect / defectInitial;
    else
        cgInfo.defectReduction = 0;

    // If we reached the maximum number of allowed iterations, ITE will be one
    // more than MaxIterations. Hence, reset this value
    if (ITE > MaxIterations)
        ITE--;

    Prot << "Multigrid-Preconditioned CG-Method ITERATIONS " << ITE
         << "  NORM OF RESIDUAL " << cgInfo.defect << "\n      "
         << "  !!RES!!/!!INITIAL RES!!" << cgInfo.defectReduction << "\n";

    if (ITE == 0)
	cgInfo.convRate = 0;
    else
	cgInfo.convRate = pow(cgInfo.defectReduction, (1 / (double)ITE));
    cgInfo.steps    = ITE;

    Prot << "  --> RATE OF CONVERGENCE " << cgInfo.convRate << "\n";

#ifdef CLOCK_MEASURE
    Prot << "\n * ********* Time measurement ParProjPrecond *************\n";
    Prot << "   Time for matrix - vector multiplication: " << TimeVectMult << " s\n";
    Prot << "   Time for scalar products: " << TimeSkal << " s\n";
    Prot << "   Time for preconditioner: " << TimePrecond << " s\n";
    Prot << "   Total time:              " << TimeTotal << " s\n";
    Prot << "*****************************************\n\n";
#endif

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParCompactMatrix::ParProjPrecondCG.\n";
        protocol.mFlush();
    }

    return cgInfo;
}

DoubleVector& ParCompactMatrix::ParCG_BPS(DoubleVector& x,DoubleVector& b,
					  unsigned int Nit,double Eps,Task *MyTask)
{
    unsigned int ITE;
    double Res,Fr,Sigma0,Alpha,Sigma1,Cappa,Gamma;

    if(GetNumDiag()!=x.GetLen() || x.GetLen()!=b.GetLen())
	return x;

    DoubleVector dr=b,dd=b,dd1=b,dg=b;

// MatrixMult
    (*this).ParVectMult(x,dr,MyTask);
//residual
    dr-=b;
// SkalProd
    Res=sqrt(((ParVector)dr).ScalProd(dr,MyTask));

    if(Res<=Eps) {
	ITE=0;
	Fr=Res;
	Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	return x;
    } else {
//      	Sigma0=Res*Res; without preconditioning
	dg=dr;
//		MyTask->BPS(dg);
	Sigma0=((ParVector)dr).ScalProd(dg,MyTask);

// Abstiegsrichtung dd
	dd = dg; dd *= -1;
	for (ITE = 1; ITE <= Nit; ITE++) {
// MatrixMult
	    (*this).ParVectMult(dd,dd1,MyTask);
// SkalProd
// 			Prot<<"dd1=\n"<<dd1<<"\n";
// 			Prot<<"dd=\n"<<dd<<"\n";
	    Alpha=((ParVector)dd).ScalProd(dd1,MyTask);
	    Alpha=Sigma0/Alpha;

// Loesung updaten
	    x.AddMultConst(dd,Alpha);
// Gradient berechnen
	    dr.AddMultConst(dd1,Alpha);
// Abbruchkriterium berechnen

	    Fr=sqrt(((ParVector)dr).ScalProd(dr,MyTask));

	    Prot<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";

	    if(Fr<=Eps) {
		if(Res>=1e-70)
		    Res=Fr/Res;
		ProtAdd<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
		if(ITE==0)
		    Cappa=0;
		else
		    Cappa=pow(Res,(1/(double)ITE));
		Prot<<"Rate of convergence "<<Cappa<<"\n";
		return x;
	    }
// Neue Abstiegsrichtung
//			Sigma1=Fr*Fr; without preconditioning
	    dg=dr;
//			MyTask->BPS(dg);

//			Prot<<"dr=\n"<<dr<<"\n";
//			Prot<<"dg=\n"<<dg<<"\n";

	    Sigma1=((ParVector)dr).ScalProd(dg,MyTask);

	    Gamma=Sigma1/Sigma0;
	    Sigma0=Sigma1;
	    dd*=Gamma;dd-=dg;
	}
	Prot<<"CONVERGENCE FAILED !!\n";
	Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	if(Res>=1e-70) {
	    Cappa=pow((Fr/Res),(1/(double)Nit));
	} else {
	    Cappa=0;
	}
	Prot<<"Rate of convergence "<<Cappa<<"\n";
	return x;
    }
    if(Res>=1e-70)
	Res=Fr/Res;
    Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
    if(ITE==0)
	Cappa=0;
    else
	Cappa=pow(Res,(1/(double)ITE));
    Prot<<"Rate of convergence "<<Cappa<<"\n";
    return x;
}

unsigned int ParCompactMatrix::ParBiCGStab(DoubleVector& x,DoubleVector& b,
					   unsigned int Nit,double Eps,Task *MyTask)
{
    unsigned int ITE;
    double Rho0, Rho1, Alpha, Beta, Omega0, Omega1, Omega2, Res, Fr, Cappa;

    if (GetNumDiag() != x.GetLen() || x.GetLen() != b.GetLen())
	return FALSE;

    DoubleVector dr = b;
    DoubleVector dr0(b.GetLen());
    DoubleVector dp(b.GetLen());
    DoubleVector dpa(b.GetLen());
    DoubleVector dsa(b.GetLen());

    Rho0 = 1;
    Alpha = 1;
    Omega0 = 1;

    dr = 0;
    ParVectMult(x, dr, MyTask);
    dr *= -1;
    dr += b;

    Res = sqrt(((ParVector)dr).ScalProd(dr, MyTask));
    if (Res <= 1e-10) {
	ITE = 0;
	Fr = Res;
	Prot << "Iterations " << ITE << "  BiCG - Verfahren  Norm of residual " << Fr << " !!Res!!/!!Initial Res!! " << Res << "\n";
	return TRUE;
    } else {
	dr0=dr;
	for (ITE = 1; ITE <= Nit; ITE++) {
	    Rho1=((ParVector)dr0).ScalProd(dr,MyTask);
	    Beta=(Rho1*Alpha)/(Rho0*Omega0);
	    Rho0=Rho1;

	    dp*=Beta;
	    dp+=dr;
	    dp.AddMultConst(dpa,-Beta*Omega0);

	    ParVectMult(dp,dpa,MyTask);

	    Alpha=((ParVector)dr0).ScalProd(dpa,MyTask);
	    Alpha=Rho1/Alpha;

	    dr.AddMultConst(dpa, -Alpha);

	    ParVectMult(dr, dsa, MyTask);

	    Omega1 = ((ParVector)dsa).ScalProd(dr, MyTask);
	    Omega2 = ((ParVector)dsa).ScalProd(dsa, MyTask);
	    Omega0 = Omega1 / Omega2;

	    x.AddMultConst(dp, Alpha);
	    x.AddMultConst(dr, Omega0);
	    dr.AddMultConst(dsa, -Omega0);

	    Fr = sqrt(((ParVector)dr).ScalProd(dr, MyTask));
	    ProtAdd << "  Iteration " << ITE << "  !!Res!! = " << Fr << "\n";
	    //Prot.Flush();

	    if (Fr < 1e-10) {
		//	if(Res > 1e-20)
		//    Res = Fr / Res;
		//Prot << "Iterations " << ITE << "  BiCG - Stab - Verfahren  Norm of residual " << Fr << " !!Res!!/!!Initial Res!! " << Res << "\n";
		Prot.Flush();
		//	MPI_Barrier(MPI_COMM_WORLD);
		if(ITE == 0)
		    Cappa = 0;
		else
		    Cappa = pow(Res, (1 / (double)ITE));
		Prot << "Rate of convergence " << Cappa << "\n";
		return TRUE;
	    }
	    //      Prot << "After norm !!\n";
	    //Prot.Flush();
	}
	Prot << "CONVERGENCE FAILED !!\n";
	Prot << "Iterations " << Nit << "  BiCG - Stab - Verfahren  Norm of residual " << Fr << " !!Res!!/!!Initial Res!! " << Res << "\n";
	if (Res >= 1e-70) {
	    Cappa = pow((Fr / Res), (1 / (double)Nit));
	} else {
	    Cappa = 0;
	}
	Prot << "Rate of convergence " << Cappa << "\n";
	return FALSE;
    }
    if (Res >= 1e-70)
	Res = Fr / Res;
    Prot << "Iterations " << Nit << "  BiCG - Stab - Verfahren  Norm of residual " << Fr << " !!Res!!/!!Initial Res!! " << Res << "\n";
    if (ITE == 0)
	Cappa = 0;
    else
	Cappa = pow(Res, (1 / (double)ITE));
    Prot << "Rate of convergence " << Cappa << "\n";
    return TRUE;
}


DoubleVector& ParCompactMatrix::ParNeumannCG(DoubleVector& x,DoubleVector& b,
					     unsigned int Nit,double Eps,Task *MyTask)
{
    unsigned int    ITE;
    double Res, Fr, Sigma0, Alpha, Sigma1, Cappa, Gamma;

    if(GetNumDiag()!=x.GetLen() || x.GetLen()!=b.GetLen())
	return x;

    MyTask->Filter(&x);
    MyTask->Filter(&b);

    DoubleVector dr=b,dd=b,dd1=b;

// MatrixMult
    ParNeumannVectMult(x,dr,MyTask);
    MyTask->Filter(&dr);

//residual
    dr-=b;

// SkalProd
    Res=sqrt(((ParVector)dr).ScalProd(dr,MyTask));

    if(Res<=Eps) {
	ITE=0;
	Fr=Res;
	Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	return x;
    } else {
	Sigma0=Res*Res;

// Abstiegsrichtung dd
	dd=dr;dd*=-1;
	for (ITE = 1; ITE <= Nit; ITE++) {
// MatrixMult
	    ParNeumannVectMult(dd,dd1,MyTask);
	    MyTask->Filter(&dd1);

// SkalProd
	    Alpha=((ParVector)dd).ScalProd(dd1,MyTask);
	    Alpha=Sigma0/Alpha;

// Loesung updaten
	    x.AddMultConst(dd,Alpha);
// Gradient berechnen
	    dr.AddMultConst(dd1,Alpha);
// Abbruchkriterium berechnen

	    Fr=sqrt(((ParVector)dr).ScalProd(dr,MyTask));

	    ProtAdd<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";

	    if(Fr<=Eps) {
		if(Res>=1e-70)
		    Res=Fr/Res;
		Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
		if(ITE==0)
		    Cappa=0;
		else
		    Cappa=pow(Res,(1/(double)ITE));
		Prot<<"Rate of convergence "<<Cappa<<"\n";
		return x;
	    }
// Neue Abstiegsrichtung
	    Sigma1=Fr*Fr;
	    MyTask->Filter(&dr);

	    Gamma=Sigma1/Sigma0;
	    Sigma0=Sigma1;
	    dd*=Gamma;dd-=dr;
	}
	Prot<<"CONVERGENCE FAILED !!\n";
	Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	if(Res>=1e-70) {
	    Cappa=pow((Fr/Res),(1/(double)Nit));
	} else {
	    Cappa=0;
	}
	Prot<<"Rate of convergence "<<Cappa<<"\n";
	return x;
    }
    if(Res>=1e-70)
	Res=Fr/Res;
    Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
    if(ITE==0)
	Cappa=0;
    else
	Cappa=pow(Res,(1/(double)ITE));
    Prot<<"Rate of convergence "<<Cappa<<"\n";
    return x;
}

DoubleVector& ParCompactMatrix::ParProjNeumannCG(DoubleVector& x,DoubleVector& b,
						 unsigned int Nit,double Eps,Task *MyTask)
{
    unsigned int ITE;
    double Res, Fr, Sigma0, Alpha, Sigma1, Cappa, Gamma;
    double T2;

    if(GetNumDiag()!=x.GetLen() || x.GetLen()!=b.GetLen())
	return x;

    MyTask->ConstFilter(&x);
    MyTask->ConstFilter(&b);

    DoubleVector dr=b,dd=b,dd1=b;

// MatrixMult
//  ParNeumannVectMult(x,dr,MyTask);
    MyTask->CVectMult(this,x,dr,T2);
    MyTask->ConstFilter(&dr);

//residual
    dr-=b;

// SkalProd
    Res=sqrt(((ParVector)dr).ConstScalProd(dr,MyTask));

    if(Res<=Eps) {
	ITE=0;
	Fr=Res;
	Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	return x;
    } else {
	Sigma0=Res*Res;

// Abstiegsrichtung dd
	dd=dr;dd*=-1;
	for (ITE = 1; ITE <= Nit; ITE++) {
// MatrixMult
//      ParNeumannVectMult(dd,dd1,MyTask);
	    MyTask->CVectMult(this,dd,dd1,T2);
	    MyTask->ConstFilter(&dd1);

// SkalProd
	    Alpha=((ParVector)dd).ConstScalProd(dd1,MyTask);
	    Alpha=Sigma0/Alpha;

// Loesung updaten
	    x.AddMultConst(dd,Alpha);
// Gradient berechnen
	    dr.AddMultConst(dd1,Alpha);
// Abbruchkriterium berechnen

	    Fr=sqrt(((ParVector)dr).ConstScalProd(dr,MyTask));

	    ProtAdd<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";

	    if(Fr<=Eps) {
		if(Res>=1e-70)
		    Res=Fr/Res;
		Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
		if(ITE==0)
		    Cappa=0;
		else
		    Cappa=pow(Res,(1/(double)ITE));
		Prot<<"Rate of convergence "<<Cappa<<"\n";
		return x;
	    }
// Neue Abstiegsrichtung
	    Sigma1=Fr*Fr;
	    MyTask->ConstFilter(&dr);

	    Gamma=Sigma1/Sigma0;
	    Sigma0=Sigma1;
	    dd*=Gamma;dd-=dr;
	}
	Prot<<"CONVERGENCE FAILED !!\n";
	Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	if(Res>=1e-70) {
	    Cappa=pow((Fr/Res),(1/(double)Nit));
	} else {
	    Cappa=0;
	}
	Prot<<"Rate of convergence "<<Cappa<<"\n";
	return x;
    }
    if(Res>=1e-70)
	Res=Fr/Res;
    Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
    if(ITE==0)
	Cappa=0;
    else
	Cappa=pow(Res,(1/(double)ITE));
    Prot<<"Rate of convergence "<<Cappa<<"\n";
    return x;
}
