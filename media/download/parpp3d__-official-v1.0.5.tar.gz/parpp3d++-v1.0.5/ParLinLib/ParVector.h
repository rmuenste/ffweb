#ifndef PARDOUBLEVECTORH

#define PARDOUBLEVECTORH

#include "DoubleVector.h"

class Task; 

class ParVector: public DoubleVector
{
public:
    ParVector(unsigned int mySize):DoubleVector(mySize) {}
    ParVector(unsigned int mySize, BYTEPTR aName):DoubleVector(mySize, aName) {}
    ParVector(DoubleVector& aDoubleVector):DoubleVector(aDoubleVector) {}
    ~ParVector(void) {}
  
    // Dot product of two vectors   (double)aNumber = v1 * v2
    double	ScalProd(DoubleVector& v2, Task *MyTask); 
    double	ConstScalProd(DoubleVector& v2, Task *MyTask); 
    ParVector& operator = (ParVector& aParVector); 
    ParVector& operator = (double aNumber); 
}; 

#endif
