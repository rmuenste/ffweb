#ifndef GLOBALH

#define GLOBALH

#include "Output.h"
#include "Errorcodes.h"			  // for error codes
#include <coutput.h>
#include <typecasts.h>

#ifdef NO_NAMESPACE_STD_USAGE
# define STD_CIN   cin
# define STD_COUT  cout
# define STD_CERR  cerr
#else
# define STD_CIN   std::cin
# define STD_COUT  std::cout
# define STD_CERR  std::cerr
#endif

extern Output  Err;
extern Output  Prot;
extern Output  ProtAdd;
extern COutput protocol;

#define ARRAY_LIMIT_ERROR  1001

// if defect is smaller than this limit every iteration will be ended 
// despite other criteria.
#define MACHINE_EPS 1e-14			 

// floating-point equality and inequality comparisons are unreliable.
// Thus use fabs(a - b) < FLOAT_EPS
#define FLOAT_EPS   1e-10			  

#endif
