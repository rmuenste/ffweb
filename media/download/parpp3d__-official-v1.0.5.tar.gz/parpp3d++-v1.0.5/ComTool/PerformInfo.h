#ifndef PERFORMINFOH

#define PERFORMINFOH

#include <DateTime.h>

class PerformInfo
{
private:
  DateTime TI_TMVMult;
  DateTime TI_TComMVMult;
  DateTime TI_TCoarseSolve;
  DateTime TI_TPreSmoother;
  DateTime TI_TPostSmoother;

  int NIterations;
  int NPreIterations;
  int NPostIterations;
  int NCoarseSolve;

  double   TMVMult;
  double   TComMVMult;
  double   TCoarseSolve;
  double   TPreSmoother;
  double   TPostSmoother;
  
public:
  PerformInfo(void);

  void MVMult_Set(void);
  void ComMVMult_Set(void);
  void CoarseSolve_Set(void);
  void PreSmoother_Set(void);
  void PostSmoother_Set(void);

  void MVMult_Stop(void);
  void ComMVMult_Stop(void);
  void CoarseSolve_Stop(void);
  void PreSmoother_Stop(void);
  void PostSmoother_Stop(void);

  friend Output& operator<<(Output& o,PerformInfo& aPerformInfo);
};

#endif
