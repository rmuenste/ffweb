
#include "CComTool.h"
#include <LinLib.h>

extern Output StdOut;

// asyncron communication

void  CComTool::ASyncSend(int ProcNum,void* data,int len,MPI_Datatype type)
{
  //  Prot<<"SyncSend len="<<len<<"\n"; 
  //Prot.Flush();
  if(MPI_Isend(data,len,type,ProcNum,STD_TAG,MPI_COMM_WORLD,&Std_Request[ProcNum])!=MPI_SUCCESS)
  {
    printf("!!! Error AsyncSend ProcNum=%d !!!\n",ProcNum);
    MPI_Finalize();
    exit(0);
  }
}


void CComTool::ASyncRecieve(int ProcNum,void* data,int len,MPI_Datatype type)
{
  MPI_Status Std_Status;
  MPI_Request Std_Request;

  //  if(MPI_Irecv(data,len,type,ProcNum,STD_TAG,MPI_COMM_WORLD,&Std_Request[ProcNum])!=MPI_SUCCESS)
  if(MPI_Irecv(data,len,type,ProcNum,STD_TAG,MPI_COMM_WORLD,&Std_Request)!=MPI_SUCCESS)
    {
      printf("!!! Error AsyncRecv ProcNum=%d !!!\n",ProcNum);
      MPI_Finalize();
      exit(0);
   }
  if(MPI_Wait(&Std_Request,&Std_Status)!=MPI_SUCCESS)
    {
      printf("!!! Error MPI_Wait ProcNum=%d !!!\n",ProcNum);
      MPI_Finalize();
      exit(0);
    }
}

void  CComTool::SyncSend(int ProcNum,void* data,int len,MPI_Datatype type)
{
  if(MPI_Ssend(data,len,type,ProcNum,STD_TAG,MPI_COMM_WORLD)!=MPI_SUCCESS)
  {
    printf("!!! Error SyncSend !!!\n");
    MPI_Finalize();
    exit(0);
  }
}


void CComTool::SyncRecieve(int ProcNum,void* data,int len,MPI_Datatype type)
{
  if(MPI_Recv(data,len,type,ProcNum,STD_TAG,MPI_COMM_WORLD,&Std_Status[ProcNum])!=MPI_SUCCESS)
  {
    printf("!!! Error SyncRecv !!!\n");
    MPI_Finalize();
    exit(0);
  }
}
