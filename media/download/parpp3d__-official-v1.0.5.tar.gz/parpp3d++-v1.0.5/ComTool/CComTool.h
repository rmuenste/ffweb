#ifndef _H_CComTool
#define _H_CComTool

#include <mpi.h>				  // for MPI_Finalize()

#define MAX_PROC  300
#define STD_TAG   1

class CComTool
{
public:
  CComTool() {}
  
  void  ASyncSend(int ProcNum,void* data,int len,MPI_Datatype type);
  void  ASyncRecieve(int ProcNum,void *data,int len,MPI_Datatype type);
  void  SyncSend(int ProcNum,void* data,int len,MPI_Datatype type);
  void  SyncRecieve(int ProcNum,void *data,int len,MPI_Datatype type);
  
protected:
  MPI_Status Std_Status[MAX_PROC];
  MPI_Request Std_Request[MAX_PROC];
};

#endif
