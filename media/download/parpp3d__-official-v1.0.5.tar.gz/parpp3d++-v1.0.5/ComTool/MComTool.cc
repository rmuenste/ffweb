#include "MComTool.h"

#ifndef MAC_CODE
MComTool::MComTool()
{
  MPI_Comm_rank(MPI_COMM_WORLD,&MyProcID);
  MPI_Comm_size(MPI_COMM_WORLD,&nProcs);
}

void MComTool::SetCommunication(blistlist_base *neighlist)
{
}

MComTool::~MComTool()
{
}

#endif

void MComTool::SyncAll(void)
{
  MPI_Barrier(MPI_COMM_WORLD);
}

void MComTool::Sync(int num)
{
  //  MPI_Wait(&Std_Request[num-1],&Std_Status[num-1]);
}

void  MComTool::Send(int ProcNum,DoubleVector* vect) 
{
  CComTool::ASyncSend(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_DOUBLE);
}
	
void MComTool::Recieve(int ProcNum,DoubleVector* vect)
{
  CComTool::ASyncRecieve(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_DOUBLE);
}

void  MComTool::Send(int ProcNum,DOUBLE num) 
{
  CComTool::ASyncSend(ProcNum-1,&num,1,MPI_DOUBLE);
}

void MComTool::Recieve(int ProcNum,DOUBLE* num)
{
  CComTool::ASyncRecieve(ProcNum-1,num,1,MPI_DOUBLE);
}

void  MComTool::Send(int ProcNum,int num) 
{
  CComTool::ASyncSend(ProcNum-1,&num,1,MPI_INT);
}

void MComTool::Recieve(int ProcNum,int* num)
{
  CComTool::ASyncRecieve(ProcNum-1,num,1,MPI_INT);
}

void  MComTool::Send(int ProcNum,DoubleArray2D* vect) 
{
  CComTool::ASyncSend(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_DOUBLE);
}
	
void MComTool::Recieve(int ProcNum,DoubleArray2D* vect)
{
  CComTool::ASyncRecieve(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_DOUBLE);
}

void  MComTool::Send(int ProcNum,IntArray* vect) 
{
  CComTool::ASyncSend(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_INT);
}
	
void MComTool::Recieve(int ProcNum,IntArray* vect)
{
  CComTool::ASyncRecieve(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_INT);
}

void  MComTool::SyncSend(int ProcNum,DoubleVector* vect) 
{
  CComTool::SyncSend(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_DOUBLE);
}
	
void MComTool::SyncRecieve(int ProcNum,DoubleVector* vect)
{
  CComTool::SyncRecieve(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_DOUBLE);
}

void  MComTool::SyncSend(int ProcNum,DOUBLE num) 
{
  CComTool::SyncSend(ProcNum-1,&num,1,MPI_DOUBLE);
}

void MComTool::SyncRecieve(int ProcNum,DOUBLE* num)
{
  CComTool::SyncRecieve(ProcNum-1,num,1,MPI_DOUBLE);
}

void  MComTool::SyncSend(int ProcNum,int num) 
{
  CComTool::SyncSend(ProcNum-1,&num,1,MPI_INT);
}

void MComTool::SyncRecieve(int ProcNum,int* num)
{
  CComTool::SyncRecieve(ProcNum-1,num,1,MPI_INT);
}

void  MComTool::SyncSend(int ProcNum,DoubleArray2D* vect) 
{
  CComTool::SyncSend(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_DOUBLE);
}
	
void MComTool::SyncRecieve(int ProcNum,DoubleArray2D* vect)
{
  CComTool::SyncRecieve(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_DOUBLE);
}

void  MComTool::SyncSend(int ProcNum,IntArray* vect) 
{
  CComTool::SyncSend(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_INT);
}
	
void MComTool::SyncRecieve(int ProcNum,IntArray* vect)
{
  CComTool::SyncRecieve(ProcNum-1,vect->GetDataPtr(),vect->GetLen(),MPI_INT);
}
