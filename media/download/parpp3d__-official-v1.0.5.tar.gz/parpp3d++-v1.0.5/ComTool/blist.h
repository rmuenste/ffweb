
#ifndef BLIST_H
#define BLIST_H

#include <LinLib.h>
#include "Const.h"

#define NUM_BOUNDCOMP  8

#define SORT_X  	1
#define SORT_Y  	2
#define SORT_NONE   3

#define true  1
#define false 0

struct link {
  link* next;
	
  link() {next=0;}
  link(link* p) {next=p;}
};

struct blink : public link {
  int node;
  int type;
  int node1;
  int node2;
  int node3;
  int node4;
  int numneigh;
	
  blink(int num,int ptype):link() {node=num;type=ptype;}
  blink(int num,int ptype,int pnumneigh):link() {node=num;type=ptype;numneigh=pnumneigh;}
  blink(blink* p,int num,int ptype):link((link*)p) {node=num;type=ptype;}
  blink(int num,int ptype,int n1,int n2,int n3,int n4):link() 
    {node=num;type=ptype;node1=n1;node2=n2;node3=n3;node4=n4;}
  blink(blink* p,int num,int ptype,int n1,int n2,int n3,int n4):link((link*)p) 
    {node=num;type=ptype;node1=n1;node2=n2;node3=n3;node4=n4;}
  blink(blink* p,blink* plink):link((link*)p)
    {node=plink->node;type=plink->type;node1=plink->node1;node2=plink->node2;
    node3=plink->node3;node4=plink->node4;numneigh=plink->numneigh;}
};

struct coord_link : public link {
  double x;
  double y;
	
  coord_link(double px,double py):link() {x=px;y=py;}
  coord_link(coord_link* p,double px,double py):link(p) {x=px;y=py;}
};

struct coord_link_3D : public link {
  double x,y,z;
	
  coord_link_3D(double px,double py,double pz):link() {x=px;y=py;z=pz;}
  coord_link_3D(coord_link_3D* p,double px,double py,double pz):link(p) {x=px;y=py;z=pz;}
};



struct IntArray_blink : public link {
  IntArray *ptr;
  int neigh;
	
  IntArray_blink(IntArray *pptr,int num):link() {ptr=pptr;neigh=num;}
  IntArray_blink(IntArray_blink* p,IntArray *pptr,int num):link(p) {ptr=pptr;neigh=num;}
};

struct DVector_blink : public link {
  DoubleVector *ptr;
  int neigh;
	
  DVector_blink(DoubleVector *pptr,int num):link() {ptr=pptr;neigh=num;}
  DVector_blink(DVector_blink* p,DoubleVector *pptr,int num):link(p) {ptr=pptr;neigh=num;}
};

class blist_base {
  blink* last;
  int len;
  public:
  void insert(blink* a);
  void append(blink* a);
  void append(int num,int type);
  void append(int num,int type,int numneigh);
  void append(blink* f1,blink *f2,int num,int type);
  void append(int num,int type,int n1,int n2,int n3,int n4);
  void append(blink* f1,blink *f2,int num,int type,int n1,int n2,int n3,int n4);
  
  void clear() {last=0;len=0;}
  blist_base() {last=0;len=0;}
  blist_base(blink* a) {a->next=a;last=a;len=0;}
  blist_base(blist_base* cp);
  ~blist_base();
  
  int get_len() {return len;}
  int find(int a,int b,blink*& f1,blink*& f2);
  int find(int a,int b);
  int find(int a,int b,int c,int d);
  int findmid(int a,int b,int c,int d);
  int find(int a);
  blink* find_node(int a);
  
  blink* get_first() {if(last) return (blink*)last->next; else return 0;}
  blink* get_next(blink* ptr) {if(ptr!=last) return (blink*)ptr->next; else return 0;}
	
};

class coord_base {
  coord_link* last;
  int len;
  public:
  void insert(coord_link* a);
  void append(coord_link* a);
  void append(double px,double py);
  void clear() {last=0;len=0;}
	
  coord_base() {last=0;len=0;}
  coord_base(coord_link* a) {a->next=a;last=a;len=0;}
  coord_base(coord_base* cp);
  ~coord_base();
	
  coord_link* get_first() {if(last) return (coord_link*)last->next; else return 0;}
  coord_link* get_next(coord_link* ptr) {if(ptr!=last) return (coord_link*)ptr->next; else return 0;}
};

class coord_base_3D {
  coord_link_3D* last;
  int len;
  public:
  void insert(coord_link_3D* a);
  void append(coord_link_3D* a);
  void append(double px,double py,double pz);
  void clear() {last=0;len=0;}
	
  coord_base_3D() {last=0;len=0;}
  coord_base_3D(coord_link_3D* a) {a->next=(struct link*)a;last=a;len=0;}
  coord_base_3D(coord_base_3D* cp);
  ~coord_base_3D();
	
  coord_link_3D* get_first() {if(last) return (coord_link_3D*)last->next; else return 0;}
  coord_link_3D* get_next(coord_link_3D* ptr) {if(ptr!=last) return (coord_link_3D*)ptr->next; else return 0;}
};


struct blist : public link {
  blist_base *base;
  int neigh;
  int spinfo;
	
  blist(blist_base *ptr):link() {base=ptr;}
  blist(blist* p,blist_base *ptr):link(p) {base=ptr;}
  blist(blist* cp) {neigh=cp->neigh;spinfo=cp->spinfo;base=new blist_base(cp->base);}
};

class bIntArraylist_base {
  IntArray_blink* last;
  public:
  bIntArraylist_base() {last=0;}
  bIntArraylist_base(IntArray_blink* a) {a->next=a;last=a;}
  bIntArraylist_base(bIntArraylist_base* cp);
  ~bIntArraylist_base();

  void insert(IntArray_blink* a);
  void append(IntArray_blink* a);
  void clear() {last=0;}
  void print_list();
	
  IntArray_blink* get_first() {if(last) return (IntArray_blink*)last->next; else return 0;}
  IntArray_blink* get_next(IntArray_blink* ptr) {if(ptr!=last) return (IntArray_blink*)ptr->next; else return 0;}
	
};

class bDVectorlist_base {
  DVector_blink* last;
  public:
  void insert(DVector_blink* a);
  void append(DVector_blink* a);
	
  void clear() {last=0;}
  bDVectorlist_base() {last=0;}
  bDVectorlist_base(DVector_blink* a) {a->next=a;last=a;}
  bDVectorlist_base(bDVectorlist_base* cp);
  ~bDVectorlist_base();
  void print_list();
	
  DVector_blink* get_first() {if(last) return (DVector_blink*)last->next; else return 0;}
  DVector_blink* get_next(DVector_blink* ptr) {if(ptr!=last) return (DVector_blink*)ptr->next; else return 0;}
	
};

class blistlist_base {
  blist* last;
  public:
  blistlist_base() {last=0;}
  blistlist_base(blist* a) {a->next=a;last=a;}
  blistlist_base(blistlist_base *cp);
	
  void insert(blist* a);
  void append(blist* a);
  void clear() {last=0;}
	
  void print_list();
	
  blist* get_first() {if(last) return (blist*)last->next; else return 0;}
  blist* get_next(blist* ptr) {if(ptr!=last) return (blist*)ptr->next; else return 0;}
};

class node_base {
  blistlist_base* neigh;
  public:
  node_base() {neigh=new blistlist_base();} 
  node_base(node_base *cp);
  
  blist* find(int a,int b,blink*& f1,blink*& f2);
  blist* find(int a,int b);
  blist* find(int a,int b,int c,int d);
  blist* findmid(int a,int b,int c,int d);
  int find(int a);
  blist* find_neighlist(int num);
  blink* find_node(int a);
  blink* find_node(int a,int& num);

  void set_BoundNode(int num,int pnode,int ptype);
  void build_array(bIntArraylist_base*& ptr);
  void build_array_all(bIntArraylist_base*& ptr);
  void build_array(bDVectorlist_base*& ptr);
  void build_neumann_array(bIntArraylist_base*& ptr);
  void build_neumann_array(bDVectorlist_base*& ptr);
  
  void new_neigh(int num,int info);
  blist_base* get_node(int num);
  blistlist_base* get_neighlist() {return neigh;}
  
  void printNodes() {neigh->print_list();}
};

//
// elemlist
//

struct elemlink : public link {
  int elem,face;
  int node1,node2,node3,node4;
  double normal;
  double normalneigh;

  elemlink(int el,int face,int node1,int node2,int node3,int node4);
};

class elemlist_base {
  elemlink* last;
  int len;
public:
  elemlist_base() {last=0;len=0;}
  elemlist_base(elemlink* a) {a->next=a;last=a;len=0;}
  ~elemlist_base() { len=0; }

  void insert(elemlink* a);
  void append(elemlink* a);
  void clear() {last=0;len=0;}
  elemlink *find_node(int elem);
  elemlink *find_node(int elem,int face);
  
  int get_len() {return len;}
  elemlink* find_elem(int a);
  
  elemlink* get_first() {if(last) return (elemlink*)last->next; else return 0;}
  elemlink* get_next(elemlink* ptr) {if(ptr!=last) return (elemlink*)ptr->next; else return 0;}
	
};

struct elemlist : public link {
  elemlist_base *base;
  int neigh;

  elemlist():link() {base=0;}
  elemlist(elemlist_base *ptr):link() {base=ptr;}
  elemlist(elemlist* p,elemlist_base *ptr):link(p) {base=ptr;}
};

class elemlistlist_base {
  elemlist* last;

public:
  elemlistlist_base() {last=0;}
	
  void insert(elemlist* a);
  void append(elemlist* a);
  void print_list();
	
  elemlist* get_first() {if(last) return (elemlist*)last->next; else return 0;}
  elemlist* get_next(elemlist* ptr) {if(ptr!=last) return (elemlist*)ptr->next; else return 0;}
};

class elem_base {
  elemlistlist_base* neigh;

public:
  elem_base() {neigh=new elemlistlist_base();} 
  
  void build_array(bIntArraylist_base*& ptr,bIntArraylist_base*& ptr2);
  void build_array(bDVectorlist_base*& ptr);
  
  void insertelem(int elem,int neigh,int face,int node1,int node2,
		  int node3,int node4);
  void new_neigh(int num);
  elemlink* find_node(int elem);
  elemlink* find_node(int elem,int face);
  elemlist* get_node(int num);
  elemlistlist_base* get_neighlist() {return neigh;}
  
  void printElems() {neigh->print_list();}
};


#endif
