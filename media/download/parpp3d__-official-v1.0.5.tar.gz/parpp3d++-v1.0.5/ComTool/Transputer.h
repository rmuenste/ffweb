#ifndef TRANSPUTERH

#define TRANSPUTERH

extern "C" {
#include <sys/root.h>
#include <sys/link.h>
#include <sys/comm.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sys_rpc.h>
#include <sys/rrouter.h>
#include <sys/topology.h>
//#include <unistd.h>
}
#endif
