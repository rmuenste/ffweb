#include "PerformInfo.h"

PerformInfo::PerformInfo(void)
{
  NIterations=0;
  NPreIterations=0;
  NPostIterations=0;

  TMVMult=0;
  TComMVMult=0;
  TCoarseSolve=0;
  TPreSmoother=0;
  TPostSmoother=0;
  TCoarseSolve=0;
}

void PerformInfo::MVMult_Set(void)
{
  TI_TMVMult.SetTime();
}

void PerformInfo::ComMVMult_Set(void)
{
  TI_TComMVMult.SetTime();
}

void PerformInfo::CoarseSolve_Set(void)
{
  TI_TCoarseSolve.SetTime();
}
 
void PerformInfo::PreSmoother_Set(void)
{
  TI_TPreSmoother.SetTime();
}
  
void PerformInfo::PostSmoother_Set(void)
{
  TI_TPostSmoother.SetTime();
}

void PerformInfo::MVMult_Stop(void)
{
  TMVMult+=TI_TMVMult.GetTimeDiff();
}

void PerformInfo::ComMVMult_Stop(void)
{
  TComMVMult+=TI_TComMVMult.GetTimeDiff();
}

void PerformInfo::CoarseSolve_Stop(void)
{
  TCoarseSolve+=TI_TCoarseSolve.GetTimeDiff();
  NCoarseSolve++;
}

void PerformInfo::PreSmoother_Stop(void)
{
  TPreSmoother+=TI_TPreSmoother.GetTimeDiff();
  NPreIterations++;
}

void PerformInfo::PostSmoother_Stop(void)
{
  TPostSmoother+=TI_TPostSmoother.GetTimeDiff();
  NPostIterations++;
}

Output& operator<<(Output& o,PerformInfo& aPerformInfo)
{
  o<<"MatrixVector-Mult (seconds):      "<<aPerformInfo.TMVMult<<"\n";
  o<<"Com. MatrixVector-Mult (seconds): "<<aPerformInfo.TComMVMult<<"\n";
  o<<"Coarse grid solver (seconds):     "<<aPerformInfo.TCoarseSolve<<"\n";
  o<<"Coarse grid iter. (seconds):      "<<aPerformInfo.NCoarseSolve<<"\n";
  o<<"Pre smoothing (seconds):          "<<aPerformInfo.TPreSmoother<<"\n";
  o<<"Pre smoothing iter. (seconds):    "<<aPerformInfo.NPreIterations<<"\n";
  o<<"Post smoothing (seconds):         "<<aPerformInfo.TPostSmoother<<"\n";
  o<<"Post smoothing iter. (seconds):   "<<aPerformInfo.NPostIterations<<"\n";

  return o;
}


