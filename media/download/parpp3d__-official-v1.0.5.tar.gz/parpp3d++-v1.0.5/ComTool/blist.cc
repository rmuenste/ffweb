#include "blist.h"

blist_base::blist_base(blist_base *cp)
{
    blink *temp,*cp_temp,*next;
	
    len=0;last=0;

    len=cp->len;
    temp=cp->get_first();
    if(temp)
    {
	cp_temp=new blink(NULL,temp);
	last=next=cp_temp;
	while(temp=cp->get_next(temp))
	{
	    cp_temp=new blink(NULL,temp);
	    next->next=cp_temp;
	    next=cp_temp;
	}
	next->next=last;
	last=next;
    }
}

blist_base::~blist_base()
{
    blink *temp=last,*next;
	
    do {
	next=(blink*)temp->next;
	delete temp;
	temp=next;
    } while(temp!=last);
}

void blist_base::insert(blink* a)
{
    if(last)
	a->next=last->next;
    else
	last=a;
    last->next=a;
    len++;
}

void blist_base::append(blink* a)
{
    if(last) {
	a->next=last->next;
	last->next=(struct link*)a;last=a;
    } else
	a->next=(struct link*)a;last=a;
    len++;
}

void blist_base::append(int num,int type)
{
    blink *temp;

    for(temp=this->get_first();temp;temp=this->get_next(temp))
    {
	if(temp->node==num)
	    return;
    }

    temp=new blink(num,type);
    append(temp);
}

void blist_base::append(int num,int type,int numneigh)
{
    blink *temp;

    for(temp=this->get_first();temp;temp=this->get_next(temp))
    {
	if(temp->node==num)
	    return;
    }

    temp=new blink(num,type,numneigh);
    append(temp);
}

void blist_base::append(blink *f1,blink *f2,int num,int type)
{
    blink *temp=new blink(num,type);
    if(f1==last) 
    {
	temp->next=f2->next;
	f2->next=temp;
    } else {
	temp->next=f1->next;
	f1->next=temp;
    }

    len++;
}

void blist_base::append(int num,int type,int n1,int n2,int n3,int n4)
{
    blink *temp=new blink(num,type,n1,n2,n3,n4);
    append(temp);
}

void blist_base::append(blink *f1,blink *f2,int num,int type,
			int n1,int n2,int n3,int n4)
{
    blink *temp=new blink(num,type,n1,n2,n3,n4);
    if(f1==last) 
    {
	temp->next=f2->next;
	f2->next=temp;
    } else {
	temp->next=f1->next;
	f1->next=temp;
    }

    len++;
}

int blist_base::find(int a,int b,blink*& f1,blink*& f2)
{
    blink *p;
    int flag1=false,flag2=false;
	
    for(p=this->get_first();p;p=this->get_next(p)) 
    {
	if(p->node==a)
	{
	    flag1=true;
	    f1=p;
	}
	if(p->node==b)
	{
	    flag2=true;
	    f2=p;
	}
	if(flag1==true && flag2==true)
	    break;
    }
    if(flag1==true && flag2==true)
	return true;
    else
	return false;
}

int blist_base::find(int a,int b)
{
    blink *p;
    int flag1=false,flag2=false;
	
    for(p=this->get_first();p;p=this->get_next(p))
    { 
	if(p->node==a)
	{
	    flag1=true;
	}
	if(p->node==b)
	{
	    flag2=true;
	}
	if(flag1==true && flag2==true)
	    break;
    }
    if(flag1==true && flag2==true)
	return true;
    else
	return false;
}

int blist_base::find(int a,int b,int c,int d)
{
    blink *p;
    int flag1=false,flag2=false,flag3=false,flag4=false;
  
    for(p=this->get_first();p;p=this->get_next(p))
    { 
	if(p->node==a)
	{
	    flag1=true;
	}
	if(p->node==b)
	{
	    flag2=true;
	}
	if(p->node==c)
	{
	    flag3=true;
	}
	if(p->node==d)
	{
	    flag4=true;
	}
	if(flag1==true && flag2==true && flag3==true && flag4==true)
	    break;
    }
    if(flag1==true && flag2==true && flag3==true && flag4==true)
	return true;
    else
	return false;
}

int blist_base::findmid(int a,int b,int c,int d)
{
    blink *p;
//  int flag1=false,flag2=false,flag3=false,flag4=false;
  
    for(p=this->get_first();p;p=this->get_next(p))
    { 
	if(p->node1==a || p->node2==a || p->node3==a || p->node4==a)
	    if(p->node1==b || p->node2==b || p->node3==b || p->node4==b)
		if(p->node1==c || p->node2==c || p->node3==c || p->node4==c)
		    if(p->node1==d || p->node2==d || p->node3==d || p->node4==d)	
			return true;
    }
    return false;
}



int blist_base::find(int a)
{
    blink *p;
	
    for(p=this->get_first();p;p=this->get_next(p))
    { 
	if(p->node==a)
	    return true;
    }
    return false;
}

blink* blist_base::find_node(int a)
{
    blink *p;
	
    for(p=this->get_first();p;p=this->get_next(p))
    { 
	if(p->node==a)
	    return p;
    }
    return NULL;
}

//
// blistlist_base
//

blistlist_base::blistlist_base(blistlist_base *cp)
{
    blist *temp,*cp_temp,*next;

    last=0;
	
    temp=cp->get_first();
    if(temp)
    {
	cp_temp=new blist(temp);
	last=next=cp_temp;
	while(temp=cp->get_next(temp))
	{
	    cp_temp=new blist(temp);
	    next->next=cp_temp;
	    next=cp_temp;
	}
	next->next=last;
	last=next;
    }
}

void blistlist_base::insert(blist* a)
{
    if(last)
	a->next=last->next;
    else
	last=a;
    last->next=a;
}

void blistlist_base::append(blist* a)
{
    if(last) {
	a->next=last->next;
	last->next=(struct link*)a;last=a;
    } else
	a->next=(struct link*)a;last=a;
}

//
// bIntArraylist_base
//

bIntArraylist_base::bIntArraylist_base(bIntArraylist_base *cp)
{
    IntArray_blink *temp,*cp_temp,*next;
    IntArray* arr;

    last=0;
  
    temp=cp->get_first();
    if(temp)
    {
	arr=new IntArray(*(temp->ptr));
	cp_temp=new IntArray_blink(arr,temp->neigh);
	last=next=cp_temp;
	while(temp=cp->get_next(temp))
	{
	    arr=new IntArray(*(temp->ptr));
	    cp_temp=new IntArray_blink(arr,temp->neigh);
	    next->next=cp_temp;
	    next=cp_temp;
	}
	next->next=last;
	last=next;
    }
}

bIntArraylist_base::~bIntArraylist_base()
{
    IntArray_blink *temp=last,*next;
	
    do {
	next=(IntArray_blink*)temp->next;
	if(temp->ptr)
	    delete temp->ptr;
	delete temp;
	temp=next;
    } while(temp!=last);
}


void bIntArraylist_base::insert(IntArray_blink* a)
{
    if(last)
	a->next=last->next;
    else
	last=a;
    last->next=a;
}

void bIntArraylist_base::append(IntArray_blink* a)
{
    if(last) {
	a->next=last->next;
	last->next=(struct link*)a;last=a;
    } else
	a->next=(struct link*)a;last=a;
}

void bIntArraylist_base::print_list()
{
    IntArray_blink *temp;

    for(temp=this->get_first();temp;temp=this->get_next(temp))
    {
	Prot<<"neigh "<<temp->neigh<<"\n";
	Prot<<"    Array=\n"<<*(temp->ptr)<<"\n\n";
    }
}

//
// bDVectorlist
//

bDVectorlist_base::bDVectorlist_base(bDVectorlist_base *cp)
{
    DVector_blink *temp,*cp_temp,*next;
    DoubleVector* vect;
 
    last=0;
 
    temp=cp->get_first();
    if(temp)
    {
	vect=new DoubleVector(*(temp->ptr));
	cp_temp=new DVector_blink(vect,temp->neigh);
	last=next=cp_temp;
	while(temp=cp->get_next(temp))
	{
	    vect=new DoubleVector(*(temp->ptr));
	    cp_temp=new DVector_blink(vect,temp->neigh);
	    next->next=cp_temp;
	    next=cp_temp;
	}
	next->next=last;
	last=next;
    }
}

bDVectorlist_base::~bDVectorlist_base()
{
    DVector_blink *temp=last,*next;
	
    do {
	next=(DVector_blink*)temp->next;
	if(temp->ptr)
	    delete temp->ptr;
	delete temp;
	temp=next;
    } while(temp!=last);
}

void bDVectorlist_base::insert(DVector_blink* a)
{
    if(last)
	a->next=last->next;
    else
	last=a;
    last->next=a;
}

void bDVectorlist_base::append(DVector_blink* a)
{
    if(last) {
	a->next=last->next;
	last->next=(struct link*)a;last=a;
    } else
	a->next=(struct link*)a;last=a;
}

void bDVectorlist_base::print_list()
{
    DVector_blink *temp;

    for(temp=this->get_first();temp;temp=this->get_next(temp))
    {
	Prot<<"neigh: "<<temp->neigh<<"\n";
	Prot<<"    Vector=\n"<<*(temp->ptr)<<"\n\n";
    }
}

//
//  coord_base
//

coord_base::coord_base(coord_base *cp)
{
    coord_link *temp,*cp_temp,*next;
  
    last=0;

    temp=cp->get_first();
    if(temp)
    {
	cp_temp=new coord_link(temp->x,temp->y);
	last=next=cp_temp;
	while(temp=cp->get_next(temp))
	{
	    cp_temp=new coord_link(temp->x,temp->y);
	    next->next=cp_temp;
	    next=cp_temp;
	}
	next->next=last;
	last=next;
    }
}


coord_base::~coord_base()
{
    coord_link *temp=last,*next;
	
    do {
	next=(coord_link*)temp->next;
	delete temp;
	temp=next;
    } while(temp!=last);
}

void coord_base::insert(coord_link* a)
{
    if(last)
	a->next=last->next;
    else
	last=a;
    last->next=a;
}

void coord_base::append(coord_link* a)
{
    if(last) {
	a->next=last->next;
	last->next=(struct link*)a;last=a;
    } else
	a->next=(struct link*)a;last=a;
}

void coord_base::append(double px,double py)
{
    coord_link *temp=new coord_link(px,py);
    append(temp);
}

coord_base_3D::coord_base_3D(coord_base_3D *cp)
{
    coord_link_3D *temp,*cp_temp,*next;

    last=0;
	
    temp=cp->get_first();
    if(temp)
    {
	cp_temp=new coord_link_3D(temp->x,temp->y,temp->z);
	last=next=cp_temp;
	while(temp=cp->get_next(temp))
	{
	    cp_temp=new coord_link_3D(temp->x,temp->y,temp->z);
	    next->next=cp_temp;
	    next=cp_temp;
	}
	next->next=last;
	last=next;
    }
}


coord_base_3D::~coord_base_3D()
{
    coord_link_3D *temp=last,*next;
	
    do {
	next=(coord_link_3D*)temp->next;
	delete temp;
	temp=next;
    } while(temp!=last);
}

void coord_base_3D::insert(coord_link_3D* a)
{
    if(last)
	a->next=last->next;
    else
	last=a;
    last->next=a;
}

void coord_base_3D::append(coord_link_3D* a)
{
    if(last) {
	a->next=last->next;
	last->next=(struct link*)a;last=a;
    } else
	a->next=(struct link*)a;last=a;
}

void coord_base_3D::append(double px,double py,double pz)
{
    coord_link_3D *temp=new coord_link_3D(px,py,pz);
    append(temp);
}

//
//  node_base
//

node_base::node_base(node_base *cp)
{
    neigh=new blistlist_base(cp->neigh);
}

blist* node_base::find(int a,int b)
{
    blist *node_list;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node_list->base->find(a,b))
	    return node_list;
    }

    return NULL;
}

blist* node_base::find(int a,int b,int c,int d)
{
    blist *node_list;
  
    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node_list->base->find(a,b,c,d))
	    return node_list;
    }
  
    return NULL;
}

blist* node_base::findmid(int a,int b,int c,int d)
{
    blist *node_list;
  
    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node_list->base->findmid(a,b,c,d))
	    return node_list;
    }
  
    return NULL;
}



blist* node_base::find(int a,int b,blink*& f1,blink*& f2)
{
    blist *node_list;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node_list->base->find(a,b,f1,f2))
	    return node_list;
    }

    return NULL;
}

int node_base::find(int a)
{
    blist *node_list;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node_list->base->find_node(a))
	    return true;
    }
  
    return false;
}

blink* node_base::find_node(int a)
{
    blist *node_list;
    blink *node;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node=node_list->base->find_node(a))
	    return node;
    }
  
    return NULL;
}

blink* node_base::find_node(int a,int& num)
{
    blist *node_list;
    blink *node;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node=node_list->base->find_node(a))
	{
	    num=node_list->neigh;
	    return node;
	}
    }
  
    return NULL;
}

blist* node_base::find_neighlist(int num)
{
    blist *node_list;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node_list->neigh==num)
	    return node_list;
    }
  
    return NULL;
}

void node_base::set_BoundNode(int num,int pnode,int ptype)
{
    blist *node_list;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node_list->neigh==num)
	{
	    blink *temp=new blink(pnode,ptype);
	    node_list->base->append(temp);
	    return;
	}
    }
}

void node_base::build_array(bIntArraylist_base*& ptr)
{
    ptr=new bIntArraylist_base;

    blist *list_temp;
	
    for(list_temp=neigh->get_first();list_temp;list_temp=neigh->get_next(list_temp))
    {
	int size=0,i=1;
	blink *temp;
	IntArray *arr;
	
	for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	{
	    if(temp->type==ART_BOUND)
		size++;
	}
	
	if(size) {
	    arr=new IntArray(size);
	
	    for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	    {
		if(temp->type==ART_BOUND)
		    (*arr)(i++)=temp->node;
	    }
		
	    IntArray_blink *link_temp=new IntArray_blink(arr,list_temp->neigh);
	    ptr->append(link_temp);
	}
    } 
}

void node_base::build_array_all(bIntArraylist_base*& ptr)
{
    ptr=new bIntArraylist_base;

    blist *list_temp;
	
    for(list_temp=neigh->get_first();list_temp;list_temp=neigh->get_next(list_temp))
    {
	int size=0,i=1;
	blink *temp;
	IntArray *arr;
	
	for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	{
	    size++;
	}
	
	if(size) {
	    arr=new IntArray(size);
	
	    for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	    {
		(*arr)(i++)=temp->node;
	    }
		
	    IntArray_blink *link_temp=new IntArray_blink(arr,list_temp->neigh);
	    ptr->append(link_temp);
	}
    } 
}

void node_base::build_neumann_array(bIntArraylist_base*& ptr)
{
    ptr=new bIntArraylist_base;

    blist *list_temp;
	
    for(list_temp=neigh->get_first();list_temp;list_temp=neigh->get_next(list_temp))
    {
	int size=0,i=1;
	blink *temp;
	IntArray *arr;
	
	for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	{
	    size++;
	}
	
	if(size) {
	    arr=new IntArray(size);
	
	    for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	    {
		(*arr)(i++)=temp->node;
	    }
		
	    IntArray_blink *link_temp=new IntArray_blink(arr,list_temp->neigh);
	    ptr->append(link_temp);
	}
    } 
}

void node_base::build_array(bDVectorlist_base*& ptr)
{
    ptr=new bDVectorlist_base;

    blist *list_temp;
	
    for(list_temp=neigh->get_first();list_temp;list_temp=neigh->get_next(list_temp))
    {	
	int size=0;
//  int i=1;
	blink *temp;
	DoubleVector *vect;
	
	for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	{
	    if(temp->type==ART_BOUND)
		size++;
	}
	
	if(size) {
	    vect=new DoubleVector(size);
		
	    DVector_blink *link_temp=new DVector_blink(vect,list_temp->neigh);
	    ptr->append(link_temp);
	}
    } 
}

void node_base::build_neumann_array(bDVectorlist_base*& ptr)
{
    ptr=new bDVectorlist_base;

    blist *list_temp;
	
    for(list_temp=neigh->get_first();list_temp;list_temp=neigh->get_next(list_temp))
    {	
	int size=0;
//  int i=1;
	blink *temp;
	DoubleVector *vect;
	
	for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	{
	    size++;
	}
	
	if(size) {
	    vect=new DoubleVector(size);
		
	    DVector_blink *link_temp=new DVector_blink(vect,list_temp->neigh);
	    ptr->append(link_temp);
	}
    } 
}

void blistlist_base::print_list()
{
    blist *node_list;

    for(node_list=this->get_first();node_list;node_list=this->get_next(node_list))
    {
	Prot<<"neigh num: "<<node_list->neigh<<" spinfo="<<node_list->spinfo<<"\n";
	blink *temp;
	
	for(temp=node_list->base->get_first();temp;temp=node_list->base->get_next(temp))
	{
	    Prot<<"    Node="<<temp->node<<"  Type=";
	    if (temp->type == ART_BOUND)
		Prot<<"artifical boundary node\n";
	    else if (temp->type == REAL_BOUND) 
		Prot<<"real boundary node\n";
	    else
		Prot<<"unknown node information\n";

	}
	Prot<<"\n\n";
    }
}

void node_base::new_neigh(int num,int info)
{
    if(num)
    {
	blist *node_list;

	for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
	{
	    if(node_list->neigh==num)
		return;
	}
	blist_base *base_temp=new blist_base();
	blist *list_temp=new blist(base_temp);
	list_temp->neigh=num;
	list_temp->spinfo=info;
	neigh->append(list_temp);
    }
}


blist_base* node_base::get_node(int num)
{
    blist *node_list;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node_list->neigh==num)
	{
	    return node_list->base;
	}
    }
    return NULL;
}

//
// elemlink
//

elemlink::elemlink(int el,int fa,int n1,int n2,int n3,int n4):link()
{
    elem=el;
    face=fa;
    node1=n1;
    node2=n2;
    node3=n3;
    node4=n4;
}

//
// elemlist_base
//

void elemlist_base::insert(elemlink* a)
{
    if(last)
	a->next=last->next;
    else
	last=a;
    last->next=a;
}

void elemlist_base::append(elemlink* a)
{
    if(last) {
	a->next=last->next;
	last->next=(struct link*)a;last=a;
    } else
	a->next=(struct link*)a;last=a;
}

elemlink* elemlist_base::find_node(int elem)
{
    elemlink *p;
	
    for(p=this->get_first();p;p=this->get_next(p))
    { 
	if(p->elem==elem)
	    return p;
    }
    return NULL;
}

elemlink* elemlist_base::find_node(int elem,int face)
{
    elemlink *p;
	
    for(p=this->get_first();p;p=this->get_next(p))
    { 
	if(p->elem==elem && p->face==face)
	    return p;
    }
    return NULL;
}

//
// elemlistlist_base
//

void elemlistlist_base::insert(elemlist* a)
{
    if(last)
	a->next=last->next;
    else
	last=a;
    last->next=a;
}

void elemlistlist_base::append(elemlist* a)
{
    if(last) {
	a->next=last->next;
	last->next=(struct link*)a;last=a;
    } else
	a->next=(struct link*)a;last=a;
}

void elemlistlist_base::print_list()
{
    elemlist *node_list;

    for(node_list=this->get_first();node_list;node_list=this->get_next(node_list))
    {
	Prot<<"neigh num: "<<node_list->neigh<<"\n";
	elemlink *temp;
	
	for(temp=node_list->base->get_first();temp;temp=node_list->base->get_next(temp))
	{
	    Prot<<"    Element="<<temp->elem<<"\n";
	}
	Prot<<"\n\n";
    }
}

//
// elem_base
//
void elem_base::insertelem(int elem,int num,int face,int node1,int node2,
			   int node3,int node4)
{
    if(num)
    {
	elemlist *node_list;
	int flag=false;

	for(node_list=neigh->get_first();node_list;
	    node_list=neigh->get_next(node_list))
	{
	    if(node_list->neigh==num)
	    {
		flag=true;
		break;
	    }
	}
	if(flag==false)
	{
	    elemlist_base *base_temp=new elemlist_base();
	    node_list=new elemlist(base_temp);
	    node_list->neigh=num;
	    neigh->append(node_list);
	}
	elemlink *link_temp=new elemlink(elem,face,node1,node2,node3,node4);
	node_list->base->insert(link_temp);
    }
}

void elem_base::new_neigh(int num)
{
    if(num)
    {
	elemlist *node_list;

	for(node_list=neigh->get_first();node_list;
	    node_list=neigh->get_next(node_list))
	{
	    if(node_list->neigh==num)
		return;
	}
	elemlist_base *base_temp=new elemlist_base();
	elemlist *list_temp=new elemlist(base_temp);
	list_temp->neigh=num;
	neigh->append(list_temp);
    }
}


elemlist* elem_base::get_node(int num)
{
    elemlist *node_list;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node_list->neigh==num)
	{
	    return node_list;
	}
    }
    return NULL;
}

void elem_base::build_array(bIntArraylist_base*& ptr,
			    bIntArraylist_base*& ptr2)
{
    ptr=new bIntArraylist_base;
    ptr2=new bIntArraylist_base;

    elemlist *list_temp;
	
    for(list_temp=neigh->get_first();list_temp;list_temp=neigh->get_next(list_temp))
    {
	int size=0,i=1;
	elemlink *temp;
	IntArray *arr,*arr2;
	
	for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	{
	    size++;
	}
	
	if(size) {
	    arr=new IntArray(size);
	    arr2=new IntArray(size);
	
	    for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	    {
		(*arr)(i)=temp->elem;
		(*arr2)(i++)=temp->face;
	    }
		
	    IntArray_blink *link_temp=new IntArray_blink(arr,list_temp->neigh);
	    ptr->append(link_temp);
	    IntArray_blink *link_temp2=new IntArray_blink(arr2,list_temp->neigh);
	    ptr2->append(link_temp2);
	}
    } 
}

void elem_base::build_array(bDVectorlist_base*& ptr)
{
    ptr=new bDVectorlist_base;

    elemlist *list_temp;
	
    for(list_temp=neigh->get_first();list_temp;list_temp=neigh->get_next(list_temp))
    {	
	int size=0;
//  int i=1;
	elemlink *temp;
	DoubleVector *vect;
	
	for(temp=list_temp->base->get_first();temp;temp=list_temp->base->get_next(temp))
	{
	    size++;
	}
	
	if(size) {
	    vect=new DoubleVector(size);
      
	    DVector_blink *link_temp=new DVector_blink(vect,list_temp->neigh);
	    ptr->append(link_temp);
	}
    } 
}

elemlink* elem_base::find_node(int elem)
{
    elemlist *node_list;
    elemlink *node;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node=node_list->base->find_node(elem))
	    return node;
    }
  
    return NULL;
}

elemlink* elem_base::find_node(int elem,int face)
{
    elemlist *node_list;
    elemlink *node;

    for(node_list=neigh->get_first();node_list;node_list=neigh->get_next(node_list))
    {
	if(node=node_list->base->find_node(elem,face))
	    return node;
    }
  
    return NULL;
}


