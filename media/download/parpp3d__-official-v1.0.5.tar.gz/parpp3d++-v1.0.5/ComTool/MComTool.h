#include "CComTool.h"
#include "blist.h"

#define MASTER 1

class MComTool:public CComTool
{
private:
  int MyProcID,nProcs;

public:
  MComTool();
  ~MComTool();

  int MyRank() {return MyProcID;}

  int TotalRank() {return nProcs;}

  void SyncAll(void);

  void Sync(int num);

  void SetCommunication(blistlist_base *neighlist);

  void Send(int ProcNum,DoubleVector* vect);
  
  void Recieve(int ProcNum,DoubleVector* vect);
  
  void Send(int ProcNum,DOUBLE num); 
  
  void Recieve(int ProcNum,DOUBLE* num);

  void Send(int ProcNum,int num); 
  
  void Recieve(int ProcNum,int* num);
  
  void Send(int ProcNum,DoubleArray2D* vect); 
  
  void Recieve(int ProcNum,DoubleArray2D* vect);	

  void Send(int ProcNum,IntArray* vect); 
  
  void Recieve(int ProcNum,IntArray* vect);	

//sync
  void SyncSend(int ProcNum,DoubleVector* vect);
  
  void SyncRecieve(int ProcNum,DoubleVector* vect);
  
  void SyncSend(int ProcNum,DOUBLE num); 
  
  void SyncRecieve(int ProcNum,DOUBLE* num);

  void SyncSend(int ProcNum,int num); 
  
  void SyncRecieve(int ProcNum,int* num);
  
  void SyncSend(int ProcNum,DoubleArray2D* vect); 
  
  void SyncRecieve(int ProcNum,DoubleArray2D* vect);	

  void SyncSend(int ProcNum,IntArray* vect); 
  
  void SyncRecieve(int ProcNum,IntArray* vect);	

};
