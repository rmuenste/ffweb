#ifndef _H_CMsg
#define _H_CMsg

#ifdef MAC_CODE
	#include <LLink.h>
#endif

#include <LinLib.h>

#ifdef MAC_CODE

class CMsg : public LLink
{
	public:
		int From,To;
};

class VMsg : public CMsg
{
	public:
		DoubleVector *Msg;
};

class DMsg : public CMsg
{
	public:
		DOUBLE Msg;
};

class D2Msg : public CMsg
{
	public:
		DoubleArray2D *Msg;
};

#else

class CMsg
{
	public:
		int From,To;
};

class VMsg
{
	public:
		DoubleVector *Msg;
};

class DMsg
{
	public:
		DOUBLE Msg;
};

class D2Msg
{
	public:
		DoubleArray2D *Msg;
};

#endif
	

#endif