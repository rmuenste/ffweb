#ifndef CONST_H
#define CONST_H

#define NUM_BOUND				4
#define NUM_BOUNDCOMP		8
#define NUM_BOUNDINFO		12
#define REALBOUNDCOMP		5

#define STARTNODE	1
#define ENDNODE		2
#define NODESTEP		3
#define VECLEN			4
#define TYPE				5
#define START_2_NODE	5
#define END_2_NODE			6
#define NODE_2_STEP		7
#define VEC_2_LEN			8
#define NORMALE_X         9
#define NORMALE_Y         10
#define NORMALE_2_X     11
#define NORMALE_2_Y     12

#define REAL_BOUND		101
#define ART_BOUND		102

#define DOWN_NEIGH		1
#define RIGHT_NEIGH		2
#define UP_NEIGH			3
#define LEFT_NEIGH		4
#define DOWNRIGHT_NEIGH		5
#define UPRIGHT_NEIGH		6
#define UPLEFT_NEIGH		7
#define DOWNLEFT_NEIGH		8

#define DOWN_BOUND				1
#define RIGHT_BOUND				2
#define UP_BOUND					3
#define LEFT_BOUND					4
#define DOWNRIGHT_BOUND		5
#define UPRIGHT_BOUND			6
#define UPLEFT_BOUND				7
#define DOWNLEFT_BOUND		8

#define XSTART		1
#define XSTEP		2
#define XNUM		3
#define YSTEP		4
#define YNUM		5

#endif
