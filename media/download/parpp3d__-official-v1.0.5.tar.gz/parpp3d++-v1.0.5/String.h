#ifndef STRINGH

#define STRINGH

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

class String
{
	private:
		int	 len;
		char	*str;
		
	public:
		String(void);
		String(const char *str1); 
		~String(void);
		
		String& operator=  (String& astr);
		String& operator=  (const char *astr); 
		String& operator+= (String& astr);
		String& operator+= (const char *astr);
		String& operator+= (int aNumber);
		String& operator+= (unsigned aNumber);
		
		operator char*() {return str; }
		
		void Info(void);
};

#endif	
