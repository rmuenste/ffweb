// ===========================================================================
//  ProcessApp.cp
// ===========================================================================
//

#include "CProcessApp.h"
#include <iostream>
#include <cinput.h>

// Global variables
Output  Prot(NO);            // these 2 are deprecated output streams for protocol messages
Output  ProtAdd(NO);         // I was just too busy so far to remove all their appearances from the code
Output  Err(YES);
Output  StdOut(NO);
Output  CA(YES);
Output  CW(YES);
Output  PDIFF(YES);

COutput protocol(ACTIVE);    // This is the proper output stream. It can be made to show up on
                             // screen or only write to a file or to do both.

//PerformInfo Perform;
int         MyProcID, nProcs;
DateTime   *GlobalTime;
bool        Debug;
std::string progname;

#ifndef NO_OUT_OF_MEMORY_HANDLER
// local functions
void OutOfMemory();
#endif

// ===========================================================================
//      Main Program
// ===========================================================================

int main(int argc,char **argv)
{
    // Initialize MPI.
    MPI_Init(&argc,&argv);

    GlobalTime = new DateTime();
    GlobalTime->SetTime();

    // Determine my rank in the world group and the number of processes.
    MPI_Comm_rank(MPI_COMM_WORLD, &MyProcID);
    MPI_Comm_size(MPI_COMM_WORLD, &nProcs);

    progname = argv[0];
    std::string alt_path("./");

    // Define input files:
    std::string infile(progname); infile += std::string(".dat");

    // Define output files:
    // One that contains all output from this program,
    // the other contain specific numerical results.
    // First, the old style output files (obsolete)
    String file1(alt_path.c_str()); file1 += progname.c_str(); file1 += ".out";      file1 += MyProcID;
    String file2(alt_path.c_str()); file2 += progname.c_str(); file2 += ".outcw";    file2 += MyProcID;
    String file3(alt_path.c_str()); file3 += progname.c_str(); file3 += ".outca";    file3 += MyProcID;
    String file4(alt_path.c_str()); file4 += progname.c_str(); file4 += ".outpdiff"; file4 += MyProcID;
    String errorfile(alt_path.c_str()); errorfile += progname.c_str(); errorfile += ".errors"; errorfile += MyProcID;

    // And now the current style output files
    std::string outfile1(alt_path); outfile1 += progname; outfile1 += std::string(".out.p"); outfile1 += int_to_string (MyProcID, "0", 3);
//  std::string outfile2(alt_path); outfile2 += progname; outfile2 += std::string(".cw");    outfile2 += int_to_string (MyProcID, "0", 3);
//  std::string outfile3(alt_path); outfile3 += progname; outfile3 += std::string(".ca");    outfile3 += int_to_string (MyProcID, "0", 3);
//  std::string outfile4(alt_path); outfile4 += progname; outfile4 += std::string(".pdiff"); outfile4 += int_to_string (MyProcID, "0", 3);


    if (MyProcID != 0) {
        Prot.SetFlag(NO);                         // Don't write protocol messages to file (old format)
//          Prot.SetFile(file1);                  // Write protocol messages to file (old format)
        StdOut.SetFlag(NO);
        //ProtAdd.SetFile(file1);
        ProtAdd.SetFlag(NO);
        CA.SetFlag(NO);
        CW.SetFlag(NO);
        PDIFF.SetFlag(NO);

        protocol.mToggleScreenOutput(OFF);        // Don't show protocol messages on screen (new format)
        protocol.mSetFile(outfile1.c_str());
    } else {
//        Prot.SetFlag(NO);		          // Don't write protocol messages to file (old format)
 	Prot.SetFile(file1);			  // Write protocol messages to file (old format)
        //Prot.SetScreen();                       // Show protocol messages on screen (old format)
        StdOut.SetFlag(NO);
        Err.SetFile(errorfile);
        // StdOut.SetScreen();
        //StdOut.SetFile(file1);
        //ProtAdd.SetFile(file1);
        ProtAdd.SetFlag(NO);
        CW.SetFile(file2);
        CA.SetFile(file3);
        PDIFF.SetFile(file4);

        protocol.mToggleScreenOutput(ON);          // Show protocol messages on screen (new format)
        protocol.mSetFile(outfile1.c_str());
    }

    // Define which configuration file we use.
    CProcessApp MyProcess(infile.c_str());

#ifndef NO_OUT_OF_MEMORY_HANDLER
    // Define an action when we run out of memory.
    std::set_new_handler(OutOfMemory);
#endif

    // Finally run the program.
    MyProcess.Run();

    // We are done.
    MPI_Finalize();
    return (0);
}


CProcessApp::CProcessApp(const char* mFile) : File(mFile)
{

}


void CProcessApp::Run()
{
    CInput Daten(File); 
    int    TestLoops, loop; 

    MemInfo Space; 
    Prot << "MemInfo after start :\n" << Space << "\n"; 
    Prot.Flush(); 

    Daten.GoToNextLine(); 
    Daten >> TestLoops; 
    Prot << "TestLoops = " << TestLoops << "\n"; 
    Daten.GoToNextLine(); 
    for (loop = 1; loop <= TestLoops; loop++) {
        protocol << "---------------------------------------------------------------------------------\n"
                 << "         SIMULATION No." << loop << "\n"
                 << "---------------------------------------------------------------------------------\n"; 
        protocol << "         INPUT DATA SECTION\n"
                 << "---------------------------------------------------------------------------------\n"; 
        protocol << " number of parallel processes         : " << nProcs << "\n"; 

        ReadData(Daten); 
	CheckParams(); 

        protocol << "\n\n---------------------------------------------------------------------------------\n"
                 << "         OUTPUT DATA SECTION\n"
                 << "---------------------------------------------------------------------------------\n";

        // Init Tasks
        InitTasks();

        protocol << "---------------------------------------------------------------------------------\n"
                 << "         SIMULATION No." << loop << " COMPLETED\n"
                 << "---------------------------------------------------------------------------------\n"; 
	Daten.GoToNextLine();
    }
}


void CProcessApp::InitTasks()
{
    Task *mTask;

    mTask = new Task(&Param);
    mTask->Run();
//    delete mTask;
}


void CProcessApp::ReadData(CInput& Daten)
{
    std::string message;			  // To speed up compiling (operator << of protocol is a template)
						  // and minimize memory consumption combine a series of messages
						  // to one single message.
    message = std::string("");

    Daten >> Param.Func;
    Daten.GoToNextLine();
    switch(Param.Func) {
    case 0:
	message += std::string(" type of hard-coded simulation        : unit cube\n");
	break;
    case 2:
	message += std::string(" type of hard-coded simulation        : Asmo\n");
	break;
    case 3:
	message += std::string(" type of hard-coded simulation        : Driven-Cavity (Deville)\n");
	break;
    case 4:
	message += std::string(" type of hard-coded simulation        : channel flow with two consecutive cylinders\n");
	break;
    case 5:
	message += std::string(" type of hard-coded simulation        : DFG Benchmark 3D-2Z\n");
	break;
    case 100:
	message += std::string(" type of hard-coded simulation        : Laplace-Test\n");
	break;
    case 101:
	message += std::string(" type of hard-coded simulation        : Laplace-Test\n");
	break;
    default:
	message += std::string(" type of hard-coded simulation        : unknown\n");
	protocol << message; protocol.mFlush();
	message = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Illegal configuration number.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message;
	protocol  << message;

        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }

    Daten >> Param.GridFile; Daten.GoToNextLine();
    message += std::string(" coarse grid file                     : ") + Param.GridFile + std::string("\n")
	     + std::string("---------------------------------------------------------------------------------\n");
    protocol << message; protocol.mFlush();
    message = std::string("");

    // Parse restart section of configuration file.
    Daten >> Param.Restart; Daten.GoToNextLine();
    if (Param.Restart == 0) {                     // Don't bother user with restart information
        protocol.mDeactivate();                   // if we don't have a restart.
    } else if (Param.Restart == 1) {
        message += std::string(" restart                              : with solution from same mg-level\n");
    } else if (Param.Restart == 2) {
        message += std::string(" restart                              : with solution from coarser mg-level\n");
    } else {
	protocol << message; protocol.mFlush();
	message
	    = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Restart information invalid.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message;
	protocol  << message;

        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }


    Daten >> Param.RestartITE; Daten.GoToNextLine();
    Daten >> Param.RestartBaseDir; Daten.GoToNextLine();
    // Check whether there is a trailing slash at path name
    if (Param.RestartBaseDir.substr(Param.RestartBaseDir.length() - 1, 1).compare("/")) {
 	Param.RestartBaseDir += "/";
    }
    Daten >> Param.RestartSolFile; Daten.GoToNextLine();
    Daten >> Param.SolFileFrequency; Daten.GoToNextLine();
    Daten >> Param.SolFileNumber; Daten.GoToNextLine();
    Daten >> Param.SolFilePrefix; Daten.GoToNextLine();
    message += std::string(" restart with iteration               : ") + int_to_string(Param.RestartITE, "", 2);
    message += std::string("\n base directory for restart files     : ") + Param.RestartBaseDir;
    message += std::string("\n prefix file to actually restart from : ") + Param.RestartSolFile;
    message += std::string("\n write restart file every             : ") + int_to_string(Param.SolFileFrequency, "", 2) + std::string(" iteration(s)");
    message += std::string("\n number of restart files to keep      : ") + int_to_string(Param.SolFileNumber, "", 2);
    message += std::string("\n prefix restart files                 : ") + Param.SolFilePrefix + std::string("\n");
    protocol << message; protocol.mFlush();
    message = std::string("");

    if (Param.Restart == 0) {
        protocol.mActivate();                     // Switch talkative mode on
	message += std::string(" base directory for restart files     : ") + Param.RestartBaseDir;
	message += std::string("\n write restart file every             : ") + int_to_string(Param.SolFileFrequency, "", 2) + std::string(" iteration(s)");
	message += std::string("\n number of restart files to keep      : ") + int_to_string(Param.SolFileNumber, "", 2);
	message += std::string("\n prefix restart files                 : ") + Param.SolFilePrefix + std::string("\n");
	protocol << message; protocol.mFlush();
	message = std::string("");
    }

    // Parse partition section of configuration file.
    Daten >> Param.PartitionTool;
    Daten.GoToNextLine();

    Daten >> Param.PartitionCR;
    Daten.GoToNextLine();
    message += std::string(" partition information is             :");
    if (Param.PartitionCR > 0) {
        message += std::string(" read from file\n");
    } else {
	if (nProcs == 1)			  // partition only when multiply processes are used
	    message += std::string(" not needed\n");
	else if (Param.PartitionTool == 0)	  // use Party?
	    message += std::string(" created by 3rd party library <party>\n");
	else if (Param.PartitionTool == 1)	  // or METIS?
	    message += std::string(" created by 3rd party library <metis> (v1)\n");
	else if (Param.PartitionTool == 2)	  // or METIS?
	    message += std::string(" created by 3rd party library <metis> (v2)\n");
	else {					  // value not defined
	    message += std::string(" illegal input data discovered\n");
	    protocol << message; protocol.mFlush();
	    MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
	}
    }

    Daten >> Param.PartitionBaseDir; Daten.GoToNextLine();
    // Check whether there is a trailing slash at path name
    if (Param.PartitionBaseDir.substr(Param.PartitionBaseDir.length() - 1, 1).compare("/")) {
 	Param.PartitionBaseDir += "/";
    }
    Daten >> Param.PartitionFile; Daten.GoToNextLine();
    message += std::string(" base directory for partition files   : ") + Param.PartitionBaseDir;
    message += std::string("\n partition file                       : ") + Param.PartitionFile;
    message += std::string("\n---------------------------------------------------------------------------------\n");
    protocol << message; protocol.mFlush();
    message = std::string("");

    // Parse finite elements section of configuration file.
    Daten >> Param.EpsEqu;   Daten.GoToNextLine();
    Daten >> Param.NFine;    Daten.GoToNextLine();
    Param.ElemType = 2;
    Param.BoundCond = 1;
    message += std::string(" viscosity parameter nu, given in 1/nu:") + double_to_string(Param.EpsEqu, "f", 1);
    message += std::string("\n maximum mg-level                     : ") + int_to_string(Param.NFine, "", 2);
//  message += std::string("\n element type                         : ") + int_to_string(Param.ElemType, "", 2);
    message += std::string("\n element type                         : non-parametric, mean value,\n                                        rotated tri-linear finite element");
    message += std::string("\n boundary condition                   : ") + int_to_string(Param.BoundCond, "", 2) + std::string("\n");
    Param.EpsEqu = 1.0 / Param.EpsEqu; 

    // Cubature formulas used
    Daten >> Param.ICUB;     Daten.GoToNextLine();
    message += std::string(" cubature formula for matrix assembl. : ") + int_to_string(Param.ICUB, "", 2);

    Daten >> Param.ICUBRHS;  Daten.GoToNextLine(); 
    message += std::string("\n cubature formula for right hand side : ") + int_to_string(Param.ICUBRHS, "", 2);

//      Param.ICUBMAX = 7;
//      message += std::string("\n cubature formula for max.error       : ") + int_to_string(Param.ICUBMAX, "", 2);
//      Param.ICUBL2 = 7;
//      message += std::string("\n cubature formula for l2 error        : ") + int_to_string(Param.ICUBL2, "", 2);
//  Prot << "ICUB=" << Param.ICUB << "\n"; 
//  Prot << "ICUBRHS=" << Param.ICUBRHS << "\n"; 
//  Prot<<"ICUB for Max-Error: "<<Param.ICUBMAX<<"\n";
//  Prot<<"ICUB for L2-Error: "<<Param.ICUBL2<<"\n";

    Daten >> Param.Lump; Daten.GoToNextLine(); 
    message += std::string("\n enable mass matrix lumping           : ");
    Param.Lump == 0 ? message += std::string("yes\n") : message += std::string("no\n");
//  Prot<<"Lump: "<<Param.Lump<<"\n";

    Param.Stab = 1;
    Daten >> Param.UpSam;        Daten.GoToNextLine();

    message += std::string(" method of stabilisation              : ");
    Param.Stab == 1 ? message += std::string("upwind") : message += std::string("streamline diffusion");
    message += std::string("\n samarski upwind parameter            :") + double_to_string(Param.UpSam, "f", 2)
	     + std::string("\n");

    // velocity section
    Daten >> Param.MinFixpItU;   Daten.GoToNextLine();
    Daten >> Param.MaxFixpItU;   Daten.GoToNextLine();
//      Param.OmgMin = 1.0;		  // lower limit for opt. OMEGA		(unused so far)
//      Param.OmgMax = 1.0;		  // upper limit for opt. OMEGA		(unused so far)
    Daten >> Param.OmgIni;       Daten.GoToNextLine();
    Daten >> Param.MinIItU;      Daten.GoToNextLine();
    Daten >> Param.MaxIItU;      Daten.GoToNextLine();
    Daten >> Param.EpsUChange;   Daten.GoToNextLine();
    Daten >> Param.EpsUDefect;   Daten.GoToNextLine();
    Daten >> Param.DampUMG;      Daten.GoToNextLine();
    Daten >> Param.AMinU;        Daten.GoToNextLine();
    Daten >> Param.AMaxU;        Daten.GoToNextLine();
    message += std::string(" parameter for velocity computation");
    message += std::string("\n - min. number of fixpoint iterations : ") + int_to_string(Param.MinFixpItU, "", 2);
    message += std::string("\n - max. number of fixpoint iterations : ") + int_to_string(Param.MaxFixpItU, "", 2);
//  	+ std::string("\n lower limit for opt. Omega           :") + double_to_string(Param.OmgMin, "f", 1);
//  	+ std::string("\n upper limit for opt. Omega           :") + double_to_string(Param.OmgMax, "f", 1);
    message += std::string("\n - value for opt. omega               :") + double_to_string(Param.OmgIni, "f", 1) ;
    message += std::string("\n - min. number of multigrid/cg steps  : ") + int_to_string(Param.MinIItU, "", 2);
    message += std::string("\n - max. number of multigrid/cg steps  : ") + int_to_string(Param.MaxIItU, "", 2);
    message += std::string("\n - limit for changes                  :") + double_to_string(Param.EpsUChange, "e", 2);
    message += std::string("\n - limit for defects                  :") + double_to_string(Param.EpsUDefect, "e", 2);
    message += std::string("\n - limit for defect improvement       :") + double_to_string(Param.DampUMG, "e", 2);
    message += std::string("\n - lower limit for opt. alpha         :") + double_to_string(Param.AMinU, "f", 1);
    message += std::string("\n - upper limit for opt. alpha         :") + double_to_string(Param.AMaxU, "f", 1) + std::string("\n");

    Daten >> Param.PreSteps_burg;  Daten.GoToNextLine();
    Daten >> Param.PostSteps_burg; Daten.GoToNextLine();
    Daten >> Param.Smoother_burg;  Daten.GoToNextLine();

    Prot << "PreSteps for burgers: " << Param.PreSteps_burg << "\n"
	 << "PostSteps for burgers: " << Param.PostSteps_burg << "\n"
	 << "Smoother for burgers: " << Param.Smoother_burg << "\n"; 
    message += std::string(" - number of pre-smoothing steps      : ") + int_to_string(Param.PreSteps_burg, "", 2) + std::string("\n")
             + std::string(" - number of post-smoothing steps     : ") + int_to_string(Param.PostSteps_burg, "", 2) + std::string("\n");

    switch(Param.Smoother_burg) {
    case 1:
	message += std::string(" - smoother used                      : jacobi\n");
	break;
    case 2:
	message += std::string(" - smoother used                      : sor\n");
	break;
    case 3:
	message += std::string(" - smoother used                      : ilu\n");
	break;
    case 4:
	message += std::string(" - smoother used                      : cg\n");
	break;
    default:
	message += std::string(" - smoother used                      : unknown\n");
	protocol << message; protocol.mFlush();
	message = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Illegal entry in configuration file for burgers equation smoother.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message; protocol  << message;
	MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }

    Daten >> Param.MGOmega_burg; Daten.GoToNextLine();
    message += std::string(" - omega for smoother                 :") + double_to_string(Param.MGOmega_burg, "e", 2) + std::string("\n");
    Prot << "MGOmega for burgers: " << Param.MGOmega_burg << "\n"; 

    Daten >> Param.Solver_burg;    Daten.GoToNextLine();
    Prot << "Solver for burgers: " << Param.Solver_burg << "\n"; 
    switch(Param.Solver_burg) {
    case 1:
	message += std::string(" - coarse grid solver used            : jacobi\n");
	break;
    case 2:
	message += std::string(" - coarse grid solver used            : sor\n");
	break;
    case 3:
	message += std::string(" - coarse grid solver used            : gauss-seidel\n");
	break;
    case 4:
	message += std::string(" - coarse grid solver used            : cg\n");
	break;
    default:
	message += std::string(" - coarse grid solver used            : unknown\n");
	protocol << message; protocol.mFlush();
	message = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Illegal entry in configuration file for burgers equation solver.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message; protocol  << message;
        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }
    Daten >> Param.SolverMaxIt_burg; Daten.GoToNextLine();
    message += std::string(" - max. iterations coarse grid solver : ") + int_to_string(Param.SolverMaxIt_burg, "", 2) + std::string("\n");

    Daten >> Param.Cycle_burg;     Daten.GoToNextLine();
    switch(Param.Cycle_burg) {
    case 0:
	message += std::string(" - multigrid cycle used               : f-cycle\n");
	break;
    case 1:
	message += std::string(" - multigrid cycle used               : v-cycle\n");
	break;
    case 2:
	message += std::string(" - multigrid cycle used               : w-cycle\n");
	break;
    default:
	message += std::string(" - multigrid cycle used               : unknown\n");
	protocol << message; protocol.mFlush();
	message = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Illegal entry in configuration file for burgers equation multigrid cycle.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message; protocol  << message;
        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }


    // ----------------
    // pressure section
    // ----------------
    Daten >> Param.MinIItP;         Daten.GoToNextLine();
    Daten >> Param.MaxIItP;         Daten.GoToNextLine();
    Daten >> Param.EpsPChange;      Daten.GoToNextLine();
    Daten >> Param.EpsDivergence;   Daten.GoToNextLine();// divergence warrant (controls u, but is used when p is computed)
    Daten >> Param.DampPMG;         Daten.GoToNextLine();
    Daten >> Param.AMinP;           Daten.GoToNextLine();
    Daten >> Param.AMaxP;           Daten.GoToNextLine();
    Daten >> Param.PreSteps_press;  Daten.GoToNextLine();
    Daten >> Param.PostSteps_press; Daten.GoToNextLine();
    Daten >> Param.Smoother_press;  Daten.GoToNextLine();
    message += std::string(" parameter for pressure computation");
    message += std::string("\n - min. number of multigrid/cg steps  : ") + int_to_string(Param.MinIItP, "", 2);
    message += std::string("\n - max. number of multigrid/cg steps  : ") + int_to_string(Param.MaxIItP, "", 2);
    message += std::string("\n - limit for changes                  :") + double_to_string(Param.EpsPChange, "e", 2);
    message += std::string("\n - limit for divergence of velocity   :") + double_to_string(Param.EpsDivergence, "e", 2);
    message += std::string("\n - limit for defect improvement       :") + double_to_string(Param.DampPMG, "e", 2);
    message += std::string("\n - lower limit for opt. alpha         :") + double_to_string(Param.AMinP, "f", 1);
    message += std::string("\n - upper limit for opt. alpha         :") + double_to_string(Param.AMaxP, "f", 1);
    message += std::string("\n - number of pre-smoothing steps      : ") + int_to_string(Param.PreSteps_press, "", 2);
    message += std::string("\n - number of post-smoothing steps     : ") + int_to_string(Param.PostSteps_press, "", 2) + std::string("\n");

    Prot << "Smoother for pressure: " << Param.Smoother_press << "\n"; 
    switch(Param.Smoother_press) {
    case 1:
	message += std::string(" - smoother used                      : jacobi\n");
	break;
    case 2:
	message += std::string(" - smoother used                      : sor\n");
	break;
    case 3:
	message += std::string(" - smoother used                      : ilu\n");
	break;
    case 4:
	message += std::string(" - smoother used                      : cg\n");
	break;
    default:
	message += std::string(" - smoother used                      : unknown\n");
	protocol << message; protocol.mFlush();
	message = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Illegal entry in configuration file for pressure poisson equation\n    smoother.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message; protocol  << message;
	MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }

    Daten >> Param.MGOmega_press; Daten.GoToNextLine();
    message += std::string(" - omega for smoother                 :") + double_to_string(Param.MGOmega_press, "e", 2) + std::string("\n");
    Prot << "MGOmega for pressure: " << Param.MGOmega_press << "\n"; 

    Daten >> Param.SolverType_press; Daten.GoToNextLine();
    switch(Param.SolverType_press) {
    case 1:
	message += std::string(" - solver scheme used                 : conventional multigrid\n");
	break;
    case 2:
	message += std::string(" - solver scheme used                 : cg method preconditioned with one\n")
                 + std::string("                                        additive multigrid step\n");
	break;
    case 3:
	message += std::string(" - solver scheme used                 : cg method preconditioned with one\n")
                 + std::string("                                        multiplicative multigrid step\n");
	break;
    default:
	message += std::string(" - solver scheme used                 : unknown\n");
	protocol << message; protocol.mFlush();
	message = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Illegal entry in configuration file for pressure poisson equation\n    solver scheme.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message; protocol  << message;
        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }
    
    Daten >> Param.Solver_press;    Daten.GoToNextLine();
    Prot << "Solver for pressure: " << Param.Solver_press << "\n"; 
    switch(Param.Solver_press) {
    case 1:
	message += std::string(" - coarse grid solver used            : jacobi\n");
	break;
    case 2:
	message += std::string(" - coarse grid solver used            : sor\n");
	break;
    case 3:
	message += std::string(" - coarse grid solver used            : gauss-seidel\n");
	break;
    case 4:
	message += std::string(" - coarse grid solver used            : cg\n");
	break;
    case 5:
	message += std::string(" - coarse grid solver used            : bicgstab\n");
	break;
    default:
	message += std::string(" - coarse grid solver used            : unknown\n");
	protocol << message; protocol.mFlush();
	message = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Illegal entry in configuration file for pressure poisson equation\n    solver.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message; protocol  << message;
        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }
    Daten >> Param.SolverMaxIt_press; Daten.GoToNextLine();
    message += std::string(" - max. iterations coarse grid solver : ") + int_to_string(Param.SolverMaxIt_press, "", 2) + std::string("\n");

    Daten >> Param.Cycle_press;     Daten.GoToNextLine();
    switch(Param.Cycle_press) {
    case 0:
	message += std::string(" - multigrid cycle used               : f-cycle\n");
	break;
    case 1:
	message += std::string(" - multigrid cycle used               : v-cycle\n");
	break;
    case 2:
	message += std::string(" - multigrid cycle used               : w-cycle\n");
	break;
    default:
	message += std::string(" - multigrid cycle used               : unknown\n");
	protocol << message; protocol.mFlush();
	message = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Illegal entry in configuration file for pressure poisson equation\n    multigrid cycle.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message; protocol  << message;
        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }

    Daten >> Param.ProlType_press;  Daten.GoToNextLine();
    switch(Param.ProlType_press) {
    case 1:
	message += std::string(" - pressure prolongation is performed : constant\n");
	break;
    case 2:
	message += std::string(" - pressure prolongation is performed : linear\n");
	break;
    default:
	message += std::string(" - pressure prolongation is performed : in an unknown way (") + 
			       int_to_string(Param.ProlType_press) + std::string(")\n");
	protocol << message; protocol.mFlush();
	message
	    = progname + std::string(" (process ") + int_to_string(MyProcID) + std::string("):\n  Unrecoverable error discovered:\n    Illegal entry in configuration file for pressure prolongation.\n  Program aborted in CProcessApp::ReadData.\n");

	STD_CERR << message; protocol  << message;
        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }

    message += std::string("---------------------------------------------------------------------------------\n");
    protocol << message; protocol.mFlush();
    message = std::string("");

    // Read time step parameters
    Daten >> Param.Method;  Daten.GoToNextLine();
    if (Param.Method == 1) {
	message += std::string(" projection scheme used               : Chorin\n");
	Prot << "Method = Chorin\n";
    } else if (Param.Method == 2 || Param.Restart > 0) {
	message += std::string(" projection scheme used               : Van Kan\n");
	Prot << "Method = Van Kan\n";
    } else {
	message += std::string(" projection scheme used               : Van Kan with ") + int_to_string(abs(Param.Method), "", 2)
	         + std::string(" initial Chorin steps\n");
	Prot << "Method = Van Kan with initial Chorin steps\n";
    }
    Daten >> Param.MaxTimeIterations;    Daten.GoToNextLine();
    Daten >> Param.TEnd;            Daten.GoToNextLine();
    Daten >> Param.EpsNS;           Daten.GoToNextLine();
    Daten >> Param.DtStart;         Daten.GoToNextLine();
    Daten >> Param.TStepControlITE; Daten.GoToNextLine();
    Daten >> Param.DtMin;           Daten.GoToNextLine();
    Daten >> Param.DtMax;           Daten.GoToNextLine();
    Daten >> Param.TInitPhase;      Daten.GoToNextLine();
    Daten >> Param.EPSADI;          Daten.GoToNextLine();
    Daten >> Param.EPSADL;          Daten.GoToNextLine();

    message += std::string(" number of time iterations            : ") + int_to_string(Param.MaxTimeIterations, "", 2) + std::string("\n");
    message += std::string(" simulation length                    :") + double_to_string(Param.TEnd, "f", 2) + std::string(" sec\n");
    message += std::string(" lower limit for time derivate        :") + double_to_string(Param.EpsNS, "e", 2) + std::string("\n");
    if (Param.Restart > 0  &&  Param.RestartITE > 1) {
	message += std::string(" time step to start with              : read from restart file(s)\n");
    } else {
	message += std::string(" time step to start with              :") + double_to_string(Param.DtStart, "e", 2) + std::string(" sec\n");
    }
    message += std::string(" iterations between time step control : ") + int_to_string(Param.TStepControlITE, "", 2) + std::string("\n");
    message += std::string(" minimum time step                    :") + double_to_string(Param.DtMin, "e", 2) + std::string(" sec\n");
    message += std::string(" maximum time step                    :") + double_to_string(Param.DtMax, "e", 2) + std::string(" sec\n");
    message += std::string(" duration of starting time            :") + double_to_string(Param.TInitPhase, "f", 2) + std::string(" sec\n");
    message += std::string(" accuracy for acceptance in start     :") + double_to_string(Param.EPSADI, "e", 2) + std::string("\n");
    message += std::string(" accuracy for acceptance after start  :") + double_to_string(Param.EPSADL, "e", 2) + std::string("\n");

    message += std::string("---------------------------------------------------------------------------------\n");

    // Read output control parameters
    Daten >> Param.OutputBaseDir;
    // Check whether there is a trailing slash at path name
    if (Param.OutputBaseDir.substr(Param.OutputBaseDir.length() - 1, 1).compare("/")) {
 	Param.OutputBaseDir += "/";
    }
    Daten.GoToNextLine();
    message += std::string(" base directory for output files      : ") + Param.OutputBaseDir + std::string("\n");

    Daten >> Param.AVSOutputLevel;  Daten.GoToNextLine();
    Daten >> Param.AVSGridFile;     Daten.GoToNextLine();
    Daten >> Param.AVSSolutionFile; Daten.GoToNextLine();
    Daten >> Param.DtAVS;           Daten.GoToNextLine();
    
    if (Param.AVSOutputLevel > Param.NFine) {
	Param.AVSOutputLevel = Param.NFine;
    }

    message += std::string(" write solution in avs format         : ");
    if (Param.AVSOutputLevel == 0) {
	message += std::string("no\n");
    } else {
	// Param.DtAVS == 0
	if (fabs(Param.DtAVS - 0.0) < FLOAT_EPS) {
	    message += std::string("every iteration\n");
	} else {
	    message += std::string("every") + double_to_string(Param.DtAVS, "f", 2) + std::string(" seconds\n");
	}
        message += std::string(" level for avs output                 : ") + int_to_string(Param.AVSOutputLevel, "", 2) + std::string("\n");
        message += std::string(" prefix grid file     (avs output)    : ") + Param.AVSGridFile + std::string("\n");
        message += std::string(" prefix solution file (avs output)    : ") + Param.AVSSolutionFile + std::string("\n");
    }

    Daten >> Param.GMVOutputLevel;  Daten.GoToNextLine();
    Daten >> Param.GMVGridFile;     Daten.GoToNextLine();
    Daten >> Param.GMVSolutionFile; Daten.GoToNextLine();
    Daten >> Param.DtGMV;           Daten.GoToNextLine();

    if (Param.GMVOutputLevel > Param.NFine) {
	Param.GMVOutputLevel = Param.NFine;
    }

    message += std::string(" write solution in gmv format         : ");
    if (Param.GMVOutputLevel == 0) {
	message += std::string("no\n");
    } else {
	// Param.DtGMV == 0
	if (fabs(Param.DtGMV - 0.0) < FLOAT_EPS) {
	    message += std::string("every iteration\n");
	} else {
	    message += std::string("every") + double_to_string(Param.DtGMV, "f", 2) + std::string(" seconds\n");
	}
        message += std::string(" level for gmv output                 : ") + int_to_string(Param.GMVOutputLevel, "", 2);
        message += std::string("\n prefix grid file     (gmv output)    : ") + Param.GMVGridFile;
        message += std::string("\n prefix solution file (gmv output)    : ") + Param.GMVSolutionFile + std::string("\n");
    }


    // switch whether to print the name of important functions when they're entered
    // and when we leave them.
    Daten >> Debug;
    if (Debug) {
	message += std::string("---------------------------------------------------------------------------------\n");
        message += std::string(" Tracing important function calls     : on\n");
    }

    protocol << message; protocol.mFlush();
    message = std::string("");

    return;
} // end ReadData


void CProcessApp::CheckParams()
{
    std::string message;
    std::string filename;
    std::ifstream *infile;
    std::ofstream *outfile;

    // Check whether grid file can be read.
    if (Param.PartitionCR == 1) {
	filename = Param.GridFile;

	infile = new std::ifstream(filename.c_str(), std::ios::in);

	if (infile->fail()) 
	    message += std::string("    From ") + filename + std::string(" cannot be read.\n");
	infile->close();
    }

    // Check whether partition file can be read.
    if (Param.PartitionCR == 1) {
	filename = Param.PartitionBaseDir + Param.PartitionFile;

	infile = new std::ifstream(filename.c_str(), std::ios::in);

	if (infile->fail()) 
	    message += std::string("    From ") + filename + std::string(" cannot be read.\n");
	infile->close();
    }

    // Check whether restart solution can be read.
    if (Param.Restart > 0) {
	filename = Param.RestartBaseDir + Param.RestartSolFile;
	filename += std::string(".p") + int_to_string (MyProcID, "0", 3);
	filename += std::string(".sol");

	infile = new std::ifstream(filename.c_str(), std::ios::in);
	if (infile->fail()) 
	    message += std::string("    From ") + filename + std::string(" cannot be read.\n");
	infile->close();
    }

    // Check whether AVS output can be written
    if (Param.AVSOutputLevel > 0) {
	filename = Param.OutputBaseDir + Param.AVSSolutionFile;
	filename += std::string(".t000.p") + int_to_string (MyProcID, "0", 3);
	filename += std::string(".inp");

	outfile = new std::ofstream(filename.c_str(), std::ios::out);
	if (outfile->fail()) 
	    message += std::string("    To ") + filename + std::string(" cannot be written.\n");
	outfile->close();

	// A file with zero length has been created. Clean this up.
	// Unfortunately, I do not know how to do this with
	// native C/C++ functions.
	unlink(filename.c_str());
    }

    // Check whether GMV output can be written
    if (Param.GMVOutputLevel > 0) {
	filename = Param.OutputBaseDir + Param.GMVSolutionFile;
	filename += std::string(".t000.p") + int_to_string (MyProcID, "0", 3);
	filename += std::string(".gmv");

	outfile = new std::ofstream(filename.c_str(), std::ios::out);
	if (outfile->fail()) 
	    message += std::string("    To ") + filename + std::string(" cannot be written.\n");
	outfile->close();

	// A file with zero length has been created. Clean this up.
	// Unfortunately, I do not know how to do this with
	// native C/C++ functions.
	unlink(filename.c_str());
    }

    if (message != "") {
	message = progname + std::string(" (process ") + int_to_string(MyProcID)
	    + std::string("):\n  Unrecoverable error discovered:\n") + message
	    + std::string("  Program aborted in CProcessApp::CheckParams.\n");

	STD_CERR << message;
	protocol  << message;

        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }

    return;
}

#ifndef NO_OUT_OF_MEMORY_HANDLER
void OutOfMemory()
{
    protocol << "\n"
	     <<progname << " (process " << MyProcID << "):\n"
	     << "  Operator new failed. Run out of memory.\n";
    Err << "\n"
	<< progname << " (process " << MyProcID << "):\n"
	<< "  Operator new failed. Run out of memory.\n";

    throw std::bad_alloc();
} // end OutOfMemory
#endif

