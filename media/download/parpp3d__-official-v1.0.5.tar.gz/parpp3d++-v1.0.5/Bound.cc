#include "Task.h"
#ifdef NO_NAMESPACE_STD_USAGE
# define STD_CIN   cin
# define STD_COUT  cout
# define STD_CERR  cerr
#else
# define STD_CIN   std::cin
# define STD_COUT  std::cout
# define STD_CERR  std::cerr
#endif

#define PI    3.1415926535897931
#define PI2   9.869604401
//  #define PI27  8.482300165

double ParGrid::Solution(double X, double Y, double Z, double T)
// Inflow is prescribed in this function.
// If you also do boussinesq, you will have to modify FeatDomainBound::SetBoundRightBouss, too.
//
// X|Y|Z: coordinates of vertex
// T    : elapsed simulated time
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Visiting ParGrid::Solution.\n";
        protocol.mFlush();
    }

    if (CoeffRhs == COEFF_RHSV1 || CoeffRhs == COEFF_L2V1) {
	//
	// Prescribe inflow in x direction
	//
        switch (Param->Func) {
	case 0:					  // flow through unit cube
	    // inflow surface is at X = 0
	    // elsewhere Dirichlet boundary with no-slip condition
	    //
	    // constant inflow in x direction of magnitude 1
    	    if (X <= 0.0) {
		return 1.0;
	    } else {
		return 0.0;
	    }

        case 2:					  // channel flow around Asmo vehicle
	    // inflow surface is at X = -0.782
	    // elsewhere Dirichlet boundary with no-slip condition
	    //
	    // constant inflow in x direction of magnitude 1
//    	    if (X <= -0.782  ||  Y <= 0.01  ||  Y >= 1.09  ||  Z <= 0.05  ||  Z >= 0.295) {
    	    if (X <= -0.782) {
//              return 16.0*2.25/pow(0.41, 4)*Y*(0.41-Y)*Z*(0.41-Z);
  		return 1.0;
	    } else {
		return 0.0;
	    }

        case 3:					  // driven cavity (pursuant to Deville et al.)
	    // only tangential flow in z direction,
	    // thus no forces in x direction
            return 0.0;

        case 4:					  // channel flow with two consecutive cylinders
	    // inflow identical to original DFG Benchmark 3D-2Z configuration,
	    // see case 5.
        case 5:					  // channel flow with one cylinder (DFG Benchmark 3D-2Z)
	    // inflow surface is at X = -0.782
	    // elsewhere Dirichlet boundary with no-slip condition
	    //
	    // three possible inflows in x direction :
	    // (a) inflow for steady channel flow
	    // (b) inflow for unsteady channel flow
	    // (c) time dependent inflow for unsteady channel flow
            if (X < 1e-8) {
                // (a) steady flow
//              return 16.0 * 0.45 / pow(0.41, 4) * Y * (0.41 - Y) * Z * (0.41 - Z);

                // (b) unsteady flow
		return 16.0 * 2.25 / pow(0.41, 4) * Y * (0.41 - Y) * Z * (0.41 - Z);

		// (c) gradually (linear) increasing unsteady inflow
//              return 10.0 * MIN(T, 0.1) *
// 		       16.0 * 2.25 / pow(0.41, 4) * Y * (0.41 - Y) * Z * (0.41 - Z);

            } else {
                return 0.0;
            }

	case 100:				  // Laplace Test
	    return 0.0;
//  	    return X*X+Y*Y+Z*Z;
            break;

	case 101:				  // Laplace Test
            return X*Y*Z*DTime;
            break;

        default:
            break;
        }

    } else if (CoeffRhs == COEFF_RHSV2 || CoeffRhs == COEFF_L2V2) {
	//
	// Prescribe inflow in y direction
	//
        switch (Param->Func) {
	case 0:					  // flow through unit cube
        case 2:					  // channel flow around Asmo vehicle
        case 3:					  // driven cavity (pursuant to Deville et al.)
        case 4:					  // channel flow with two consecutive cylinders
        case 5:					  // channel flow with one cylinder (DFG Benchmark 3D-2Z)
	    // all these configurations have no inflow or other forces in y direction,
	    // thus nothing here.
	    return 0.0;

        case 100:
  	    return 0.0;
//  	    return X*Y*Z;
	    break;

        case 101:
            return X*Y*Z*DTime;
            break;

        default:
            break;
        }

    } else if (CoeffRhs == COEFF_RHSV3 || CoeffRhs == COEFF_L2V3) {
	// Prescribe inflow in z direction
        switch (Param->Func) {
        case 0:					  // flow through unit cube
        case 2:					  // channel flow around Asmo vehicle
        case 4:					  // channel flow with two consecutive cylinders
        case 5:					  // channel flow with one cylinder (DFG Benchmark 3D-2Z)
	    // all these configurations have no inflow or other forces in z direction,
	    // thus nothing here.
            return 0.0;

        case 3:					  // driven cavity (pursuant to Deville et al.)
	    // tangential flow in z direction of magnitude 1
	    // at upper lid of cavity (i.e. at y=1)
            if (fabs(Y - 1.0) < 1e-8) {
                return 1;
            } else {
                return 0.0;
            }

        case 100:				  // Laplace Test
	    return 0.0;
//  	    return X*Y*Z;
            break;

        case 101:				  // Laplace Test
            return X*Y*Z*DTime;
            break;

        default:
            return 0.0;
        }
    }

    return 0.0;
}


int SquareGrid_3D::BoundaryCondition (unsigned int Func, double X, double Y, double Z, double T)
{
    double dist = 0.05;

    // Explanation of return values:
    // 0 = Neumann boundary
    // 1 = Dirichlet boundary
    const int neumann = 0;
    const int dirichlet = 1;

    switch (Func) {
    case 0:					  // flow through unit cube
	// outflow surface is at X = 1,
	// Dirichlet boundary conditions elsewhere
	dist = 0.001;
    	if (X > 1.0 - dist)
	    return neumann;
	else
	    return dirichlet;

    case 2:					  // channel flow around Asmo vehicle
	// outflow surface is at X = 3.682749
	// Dirichlet boundary conditions elsewhere
    	if (X > 3.682749 - dist)
	    return neumann;
	else
	    return dirichlet;

    case 3:					  // driven cavity (pursuant to Deville et al.)
	// All boundary points have Dirichlet boundary condition.
	return dirichlet;

    case 4:					  // channel flow with two consecutive cylinders
        // boundary conditions identical to original DFG Benchmark 3D-2Z configuration,
	// see case 5.
    case 5:					  // channel flow with one cylinder (DFG Benchmark 3D-2Z)
	// All points fullfilling
	//    x<2.5 || y=0 || y=0.41 || z=0 || z=0.41
	// have Dirichlet boundary condition. These are all points on the
	// channel boundary (besides the rear outflow surface) and all
	// points on the cylinder(s).
	if (   fabs(X-2.5)  > 1e-8
	    || fabs(Y-0.41) < 1e-8 || fabs(Y)      < 1e-8
	    || fabs(Z-0.41) < 1e-8 || fabs(Z)      < 1e-8)
	    return dirichlet;

	// All remaining points (residing on the back end of the channel)
	// have Neumann boundary condition.
	else
	    return neumann;

    case 100:
	// 3d driven cavity configuration:
	// All boundary points
	// have Dirichlet boundary condition.
	return dirichlet;
    }

    return neumann;
}


int Task::TestNeumann(int node)
// Neumann and Dirichlet boundary nodes are distinguished in this function
// depending on the coordinates.
// Function is used for conforming boundary nodes only.
// For nonconforming boundary nodes see TestNeumannMid.
//
// returncode 0 means: Neumann boundary node
// returncode 1 means: Dirichlet boundary node
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Visiting Task::TestNeumann.\n";
        protocol.mFlush();
    }


    // Determine coordinates
    double X = (*VertCoord)(1, node);
    double Y = (*VertCoord)(2, node);
    double Z = (*VertCoord)(3, node);

    return BoundaryCondition(Param->Func, X, Y, Z, 0);
}


int Task::TestNeumannMid(int node, int node1, int node2, int node3, int node4)
// Neumann and Dirichlet boundary nodes are distinguished in this function
// depending on the coordinates.
// Function is used for nonconforming boundary nodes only.
// For conforming boundary nodes see TestNeumann.
//
// returncode 0 means: Neumann boundary node
// returncode 1 means: Dirichlet boundary node
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Visiting Task::TestNeumannMid.\n";
        protocol.mFlush();
    }

    // Determine coordinates of midpoint of current element
    double X = 0.25 * ((*VertCoord)(1, node1) + (*VertCoord)(1, node2)
  	             + (*VertCoord)(1, node3) + (*VertCoord)(1, node4));
    double Y = 0.25 * ((*VertCoord)(2, node1) + (*VertCoord)(2, node2)
	             + (*VertCoord)(2, node3) + (*VertCoord)(2, node4));
    double Z = 0.25 * ((*VertCoord)(3, node1) + (*VertCoord)(3, node2)
	             + (*VertCoord)(3, node3) + (*VertCoord)(3, node4));

    return BoundaryCondition(Param->Func, X, Y, Z, 0);
}


double ParGrid::SolutionDX(double X, double Y, double Z)
{
    protocol << "Warning (process " << MyProcID << "): Unexptected usage of ParGrid::SolutionDX.\n";

    if (CoeffRhs == COEFF_RHSV1) {
//          if (Param->Func == 101)
//              return Y*DTime;
	switch (Param->Func) {
	default:
	    return 0;
	}

    } else if (CoeffRhs == COEFF_RHSV2) {
//          if (Param->Func == 101)
//              return Y*DTime;
	switch (Param->Func) {
	default:
	    return 0;
	}
    }

    else
	protocol << "Warning (process " << MyProcID << "): Illegal case in ParGrid::SolutionDX.\n";

    return 0;
}


double ParGrid::SolutionDY(double X, double Y, double Z)
{
    protocol << "Warning (process " << MyProcID << "): Unexptected usage of ParGrid::SolutionDY.\n";

    if (CoeffRhs == COEFF_RHSV1) {
//          if (Param->Func == 101)
//              return X*DTime;
	switch (Param->Func) {
	default:
	    return 0;
	}

    } else if (CoeffRhs == COEFF_RHSV2) {
//          if (Param->Func == 101)
//              return X*DTime;
	switch (Param->Func) {
	default:
	    return 0;
	}
    }

    else
	protocol << "Warning (process " << MyProcID << "): Illegal case in ParGrid::SolutionDY.\n";

    return 0;
}


double ParGrid::SolutionDZ(double X, double Y, double Z)
{
    protocol << "Warning (process " << MyProcID << "): Unexptected usage of ParGrid::SolutionDZ.\n";

    if (CoeffRhs == COEFF_RHSV1) {
//          if (Param->Func == 101)
//              return X*DTime;
	switch (Param->Func) {
	default:
	    return 0;
	}
    } else if (CoeffRhs == COEFF_RHSV2) {
//          if (Param->Func == 101)
//              return X*DTime;
	switch (Param->Func) {
	default:
	    return 0;
	}
    }

    else
	protocol << "Warning (process " << MyProcID << "): Illegal case in ParGrid::SolutionDZ.\n";

    return 0;
}


double ParGrid::RightSideCoeff(double X, double Y, double Z, int IB, int BFIRST)
{
//     double XPI = PI27*(X-DTime), EXPXY=exp(-(X+Y));
    switch (CoeffRhs) {
    case COEFF_RHSV1:
        if (IB == 1) {
	    return 0;
//          if (Param->Func == 101) return X*Y+X*Y*Y*DTime*DTime+Y*X*X*DTime*DTime;
        } else if (IB == 2) {
	    return 0;
//          if (Param->Func == 101) return Solution(X, Y, Z)*Param->XStep*Param->Delta*(X*Y+X*Y*Y*DTime*DTime+Y*X*X*DTime*DTime);
        } else if (IB == 3) {
	    return 0;
//          if (Param->Func == 101) return Solution(X, Y, Z)*Param->XStep*Param->Delta*(X*Y+X*Y*Y*DTime*DTime+Y*X*X*DTime*DTime);
        }

    case COEFF_RHSV2:
        if (IB == 1) {
	    return 0;
//          if (Param->Func == 101) return X*Y+X*Y*Y*DTime*DTime+Y*X*X*DTime*DTime;
        } else if (IB == 2) {
	    return 0;
//  	    if (Param->Func == 101) return Solution(X, Y, Z)*Param->XStep*Param->Delta*(X*Y+X*Y*Y*DTime*DTime+Y*X*X*DTime*DTime);
        } else if (IB == 3) {
	    return 0;
//          if (Param->Func == 101) return Solution(X, Y, Z)*Param->XStep*Param->Delta*(X*Y+X*Y*Y*DTime*DTime+Y*X*X*DTime*DTime);
        }

    case COEFF_RHSV3:
        if (IB == 1) {
	    return 0;
//          if (Param->Func == 101) return X*Y+X*Y*Y*DTime*DTime+Y*X*X*DTime*DTime;
        } else if (IB == 2) {
	    return 0;
//          if (Param->Func == 101) return Solution(X, Y, Z)*Param->XStep*Param->Delta*(X*Y+X*Y*Y*DTime*DTime+Y*X*X*DTime*DTime);
        } else if (IB == 3) {
	    return 0;
//          if (Param->Func == 101) return Solution(X, Y, Z)*Param->XStep*Param->Delta*(X*Y+X*Y*Y*DTime*DTime+Y*X*X*DTime*DTime);
        }

    case COEFF_L2V1:
	return 0;
//      if (Param->Func == 101) return X*Y*DTime;
    case COEFF_L2V2:
	return 0;
//      if (Param->Func == 101) return X*Y*DTime;
    case COEFF_L2V3:
	return 0;

    default:
	protocol << "Warning (process " << MyProcID << "): Illegal case in ParGrid::RightSideCoeff.\n";
	break;
    }

    return 0;
}


double ParGrid::StiffCoeff(double X, double Y, double Z, int IA, int IB,
                           int BFIRST)
{
    DBAS = RotElement->GetDBAS();
    KDFL = RotElement->GetKDFL();
    KDFG = RotElement->GetKDFG();

    if (Coeff == COEFFA1) {
        return Param->EpsEqu;
    } else if (Coeff == COEFFP1 || Coeff == COEFFP2) {
        return 1;
    } else if (Coeff == COEFFN) {
        return -1;
    } else if (Coeff == COEFFA2) {
        std::string message
            = progname + " (process " + int_to_string(MyProcID) + "):\n"
            + "  Unrecoverable error discovered:\n"
            + "    Request for a case not implemented.\n"
	    + "  Program aborted in ParGrid::StiffCoeff.\n";

	STD_CERR << message;
	protocol  << message;

	MPI_Abort(MPI_COMM_WORLD, ILLEGAL_COEFF_CASE_ERROR);
    } else if (Coeff == COEFFM) {
        return 1;
    }

    else
	protocol << "DEBUG(" << MyProcID << "): Illegal case in ParGrid::SolutionDX.\n";

    return 0;
}

// Featflow: TPARV
void Task::BoundaryProjection()
{
    int IVT, IEL, INPR, type, numneigh;
    double PXM,PYM,RAD,RADH,DL,PX,PY,PZ;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::BoundaryProjection.\n";
        protocol.mFlush();
    }

    switch (Param->Func) {
    case 0:					  // flow through unit cube
    case 2:					  // channel flow around Asmo vehicle
    case 3:					  // driven cavity (pursuant to Deville et al.)
        return;

    case 4:					  // channel flow with two consecutive cylinders
        // derivated from 3D-2Z benchmark configuration:
        // flow around two consecutive cylinders with circular cross-section, steady case
        for (IVT=1; IVT <= NumVertices; IVT++) {
            INPR=(*InfoVertEdge)(IVT);
            //  0: inner point
            // >0: point on boundary component with this very number

            if (INPR != 0) {
                // For all boundary points ...
                IEL=(*ElemVert)(4,IVT);
                PX= (*VertCoord)(1,IVT);
                PY= (*VertCoord)(2,IVT);
                PZ= (*VertCoord)(3,IVT);
//                protocol << "parq3d: BoundaryProjection : IVT="<<IVT<<" PX="<<PX<<" PY="<<PY<<" PZ="<<PZ<<" DL="<<DL<<"\n";

                if ( (fabs(PX-0.) > 1e-8) && (fabs(PX-2.50) > 1e-8) &&
                     (fabs(PY-0.) > 1e-8) && (fabs(PY-0.41) > 1e-8) &&
                     (fabs(PZ-0.) > 1e-8) && (fabs(PZ-0.41) > 1e-8) ) {

                    // ... that are also inside the channel
                    // (i.e. 0 < x < 2.5,  0 < y < 0.41,  0 < z < 0.41) ...

                    // We have two inner cylinders...
                    if (PX > 0.4 && PX < 0.6) {
                        PXM = 0.50;
                        PYM = 0.20;
                    } else if (PX > 0.7 && PX < 0.9) {
                        PXM = 0.80;
                        PYM = 0.225;
                    } else {
			std::string message
			    = progname + std::string(" (process ") + int_to_string(MyProcID)
			    + std::string("):\n")
			    + std::string("  Unrecoverable error discovered:\n")
			    + std::string("    Found an inner boundary point that is neither part of cylinder 1 nor 2.\n")
			    + std::string("  Solution:\n")
			    + std::string("    Check whether grid file and simulation type chosen match.\n")
			    + std::string("  Program aborted in Task::BoundaryProjection.\n");

			STD_CERR << message;
			protocol  << message;

			MPI_Abort(MPI_COMM_WORLD, ILLEGAL_BOUNDARY_INFO_ERROR);
                    }
                    RAD = 0.05;

                    // ... compute distance to cylinder ...
                    DL=sqrt( pow(PX-PXM,2) + pow(PY-PYM,2) );
//                  Prot<<"BoundProj.: IVT="<<IVT<<" PX="<<PX<<" PY="<<PY<<" PZ="<<PZ<<" DL="<<DL<<"\n";
//                  protocol << "parq3d: BoundaryProjection : IVT="<<IVT<<" PX="<<PX<<" PY="<<PY<<" PZ="<<PZ<<" DL="<<DL<<"\n";

                    // ... and move them onto the boundary of the inner cylinder.
                    (*VertCoord)(1,IVT) = PXM + RAD/DL*(PX-PXM);
                    (*VertCoord)(2,IVT) = PYM + RAD/DL*(PY-PYM);

                } else if ( (fabs(PZ-0.0)<=1e-8) || (fabs(PZ-0.41)<=1e-8) ) {
                    // We have two inner cylinders...
                    if (PX > 0.4 && PX < 0.6) {
                        PXM = 0.50;
                        PYM = 0.20;
                        RAD = 0.05;
                        RADH= 0.05+1e-8;
                    } else if (PX > 0.7 && PX < 0.9) {
                        PXM = 0.80;
                        PYM = 0.225;
                        RAD = 0.05;
                        RADH= 0.05+1e-8;
                    } else {
                        continue;
                    }

                    type = GetNodeType(IVT, numneigh);
                    if ( (fabs(PX-PXM) <= RADH) &&
                         (fabs(PY-PYM) <= RADH) && numneigh == 0 && IEL==0 ) {
                        DL=sqrt( pow(PX-PXM,2) + pow(PY-PYM,2) );
//                      Prot<<"BoundProj.: IVT="<<IVT<<" PX="<<PX<<" PY="<<PY<<" PZ="<<PZ<<" DL="<<DL<<"\n";
//                      protocol << "parq3d: BoundaryProjection : IVT="<<IVT<<" PX="<<PX<<" PY="<<PY<<" PZ="<<PZ<<" DL="<<DL<<"\n";
                        (*VertCoord)(1,IVT) = PXM + RAD/DL*(PX-PXM);
                        (*VertCoord)(2,IVT) = PYM + RAD/DL*(PY-PYM);
                    }
                }
            } // End if (INPR != 0)
        } // End for-loop IVT
        break;

    case 5:					  // channel flow with one cylinder (DFG Benchmark 3D-2Z)
        // 3D-2Z benchmark configuration:
        // flow around a cylinder with circular cross-section, steady case
        for (IVT = 1; IVT <= NumVertices; IVT++) {
            INPR=(*InfoVertEdge)(IVT);
            //  0: inner point
            // >0: point on boundary component with this very number

            if (INPR != 0) {
                // For all boundary points ...
		if (ElemVert->GetRows() < 4) {
		    std::string message
			= progname + std::string(" (process ") + int_to_string(MyProcID)
			+ std::string("):\n")
			+ std::string("  Warning in Task::BoundaryProjection:\n")
			+ std::string("    Boundary Projection cannot be performed. There are too less\n")
			+ std::string("    elements on the current grid to apply our check whether a\n")
			+ std::string("    vertex belongs to the cylinder.\n")
			+ std::string("    Boundary Projection is skipped.\n");

//  			STD_CERR << message;
			protocol  << message;
		} else {
		    IEL=(*ElemVert)(4,IVT);
		    PX= (*VertCoord)(1,IVT);
		    PY= (*VertCoord)(2,IVT);
		    PZ= (*VertCoord)(3,IVT);

		    if ( (fabs(PX-0.) > 1e-8) && (fabs(PX-2.50) > 1e-8) &&
			 (fabs(PY-0.) > 1e-8) && (fabs(PY-0.41) > 1e-8) &&
			 (fabs(PZ-0.) > 1e-8) && (fabs(PZ-0.41) > 1e-8) ) {
			// ... that are also inside the channel
			// (i.e. 0 < x < 2.5,  0 < y < 0.41,  0 < z < 0.41) ...
			PXM = 0.50;
			PYM = 0.20;
			RAD = 0.05;

			// ... compute distance to cylinder ...
			DL=sqrt( pow(PX-PXM,2) + pow(PY-PYM,2) );
//                      Prot<<"BoundProj.: IVT="<<IVT<<" PX="<<PX<<" PY="<<PY<<" PZ="<<PZ<<" DL="<<DL<<"\n";

			// ... and move them onto the boundary of the inner cylinder.
			(*VertCoord)(1,IVT) = PXM + RAD/DL*(PX-PXM);
			(*VertCoord)(2,IVT) = PYM + RAD/DL*(PY-PYM);

		    } else if ( (fabs(PZ-0.0) <= 1e-8)  ||  (fabs(PZ-0.41) <= 1e-8) ) {
			PXM = 0.50;
			PYM = 0.20;
			RAD = 0.05;
			RADH= 0.05 + 1e-8;

			type=GetNodeType(IVT,numneigh);
			if ( (fabs(PX-PXM) <= RADH)  &&  (fabs(PY-PYM) <= RADH)  &&  numneigh == 0  &&  IEL == 0 ) {
			    DL=sqrt( pow(PX-PXM,2) + pow(PY-PYM,2) );
//                          Prot<<"BoundProj.: IVT="<<IVT<<" PX="<<PX<<" PY="<<PY<<" PZ="<<PZ<<" DL="<<DL<<"\n";
			    (*VertCoord)(1,IVT) = PXM + RAD/DL*(PX-PXM);
			    (*VertCoord)(2,IVT) = PYM + RAD/DL*(PY-PYM);
			}
		    }
		} // end else case of if (ElemVert->GetRows() < 4)
            } // end if (INPR != 0)
        } // end for-loop IVT
        break;

    } // End switch statement

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::BoundaryProjection.\n";
        protocol.mFlush();
    }

    return;
} // end Task::BoundaryProjection

void FeatDomainBound::SetBound(DoubleCompactMatrix* LA)
{
    int   IEQ,ICOL;
    blink* temp;
    real_nodeBase=Mreal_nodeBase[MaxLevel];

    for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp))
    {
	if (temp->type==REAL_BOUND)
	{
	    IEQ=temp->node;
	    (*LA).Data((*LA).Diag(IEQ))=1;
	    for(ICOL=(*LA).Diag(IEQ)+1;ICOL<=(*LA).Diag(IEQ+1)-1;ICOL++)
		(*LA).Data(ICOL)=0;
	}
    }
}

void FeatDomainBound::SetBoundRightU(DoubleVector* U, double T)
{
    int   IEQ;
    double X,Y,Z;
    blink* temp;
    real_nodeBase=Mreal_nodeBase[MaxLevel];
    VertCoord=MVertCoord[MaxLevel];

    switch (Param->Func) {
    default:
	if (Param->ElemType==1) {
	    for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp)) {
		if (temp->type==REAL_BOUND) {
		    IEQ=temp->node;
		    X=(*VertCoord)(1,IEQ);
		    Y=(*VertCoord)(2,IEQ);
		    Z=(*VertCoord)(3,IEQ);
		    (*U)(IEQ) = Solution(X, Y, Z, T);
		}
	    }
	} else if (Param->ElemType==2) {
	    for (temp = real_nodeBase->get_first(); temp; temp = real_nodeBase->get_next(temp)) {
		if (temp->type == REAL_BOUND) {
		    X = 0.25 * ((*VertCoord)(1,temp->node1) + (*VertCoord)(1,temp->node2)
			     +  (*VertCoord)(1,temp->node3) + (*VertCoord)(1,temp->node4));
		    Y = 0.25 * ((*VertCoord)(2,temp->node1) + (*VertCoord)(2,temp->node2)
			     +  (*VertCoord)(2,temp->node3) + (*VertCoord)(2,temp->node4));
		    Z = 0.25 * ((*VertCoord)(3,temp->node1) + (*VertCoord)(3,temp->node2)
			     +  (*VertCoord)(3,temp->node3) + (*VertCoord)(3,temp->node4));
//                  Prot << "SetBoundRight node=" << temp->node << " X=" << X << " Y=" << Y << " Z=" << Z << " U=" << (*U)(temp->node) << " Sol=" << Solution(X, Y, Z) << "\n";
		    (*U)(temp->node) = Solution(X, Y, Z, T);
		}
	    }
	}
	break;

    } // end switch statement

    return;
}


void FeatDomainBound::SetBoundRightF(DoubleVector* F, double T)
{
    switch (Param->Func) {
    default:
	SetBoundRightU(F, T);
	return;
    } // end switch statement

    return;
}


#ifdef INCLUDE_TEMPERATURE
void FeatDomainBound::SetBoundRightBouss(DoubleVector* b)
// For boussinesq we have to prescribe inflow, too.
// This is done here.
{
    int   IEQ;
    double        X,Y,Z;
    blink* temp;
    real_nodeBase=Mreal_nodeBase[MaxLevel];
    VertCoord=MVertCoord[MaxLevel];

    if (Param->ElemType==1) {
        for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp)) {
            if (temp->type==REAL_BOUND) {
                IEQ=temp->node;
                X=(*VertCoord)(1,IEQ);
                Y=(*VertCoord)(2,IEQ);
                Z=(*VertCoord)(3,IEQ);
                (*b)(IEQ)=1;
            }
        }
    } else if (Param->ElemType==2) {
        for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp)) {
            if (temp->type==REAL_BOUND) {
                X = 0.25 * ((*VertCoord)(1,temp->node1) + (*VertCoord)(1,temp->node2)
			 +  (*VertCoord)(1,temp->node3) + (*VertCoord)(1,temp->node4));
                Y = 0.25 * ((*VertCoord)(2,temp->node1) + (*VertCoord)(2,temp->node2)
			 +  (*VertCoord)(2,temp->node3) + (*VertCoord)(2,temp->node4));
                Z = 0.25 * ((*VertCoord)(3,temp->node1) + (*VertCoord)(3,temp->node2)
			 +  (*VertCoord)(3,temp->node3) + (*VertCoord)(3,temp->node4));

                if (Param->Func == 4  ||  Param->Func == 5  ||  Param->Func == 7) {
                    if (fabs(X) < 1e-8)
                        (*b)(temp->node) = 1.0;
                    else
                        (*b)(temp->node) = 0.0;
                } else if (Param->Func == 6) {
                    double DL=sqrt(pow(X-0.5,2)+pow(Y-0.5,2));
                    if (fabs(Z) < 1e-8  &&  DL < 0.19)
                        (*b)(temp->node) = 1.;
                    else if (fabs(Z)<1e-8)
                        (*b)(temp->node) = -1;
                    else
                        (*b)(temp->node) = 0.;
                }
            }
        }
    }
}
#endif


void FeatDomainBound::SetLumpBound(MultiVector* Lump)
{
    blink* temp;
    real_nodeBase=Mreal_nodeBase[MaxLevel];
    VertCoord=MVertCoord[MaxLevel];
    DoubleVector *b=(*Lump)[MaxLevel];

    for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp)) {
        if (temp->type==REAL_BOUND) {
            (*b)(temp->node)=0.0;
        }
    }
}

void FeatDomainBound::SetLocalBound(DoubleCompactMatrix* LA,DoubleVector* LB,DoubleVector* LX)
{
//     int IVT;
    int ICOL,IEQ;
    double X,Y,Z;
    blink* temp;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): SB: Entering FeatDomainBound::SetLocalBound!!!.\n";
        protocol.mFlush();
    }

    for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp)) {
        if (temp->type==REAL_BOUND) {
            IEQ=temp->node;
            X = (*VertCoord)(1,IEQ);
            Y = (*VertCoord)(2,IEQ);
            Z = (*VertCoord)(3,IEQ);
	    STD_COUT << "DEBUG(" << MyProcID << "): SB: Useless statement in FeatDomainBound::SetLocalBound!!!.\n";
//          (*LX)(IEQ)=0;
//          (*LB)(IEQ)=0;
        } else {
            IEQ=temp->node;
            (*LA).Data((*LA).Diag(IEQ))=1;
            (*LX)(IEQ)=0;
            (*LB)(IEQ)=0;
        }
        (*LA).Data((*LA).Diag(IEQ))=1;
        for(ICOL=(*LA).Diag(IEQ)+1;ICOL<=(*LA).Diag(IEQ+1)-1;ICOL++)
            (*LA).Data(ICOL)=0;
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): SB:  Leaving FeatDomainBound::SetLocalBound!!!.\n";
        protocol.mFlush();
    }

    return;
}


void FeatDomainBound::SetHarmonicBound(DoubleCompactMatrix* LA,DoubleVector* LB,DoubleVector* LX,DoubleVector* BOUND)
{
//     int IVT;
    int ICOL,IEQ;
    blink* temp;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): SB: Entering FeatDomainBound::SetHarmonicBound!!!.\n";
        protocol.mFlush();
    }

    for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp)) {
        if (temp->type==REAL_BOUND) {
            IEQ=temp->node;
            (*LX)(IEQ)=0;
            (*LB)(IEQ)=0;
        } else {
            IEQ=temp->node;
            (*LA).Data((*LA).Diag(IEQ))=1;
            (*LX)(IEQ)=(*BOUND)(IEQ);
            (*LB)(IEQ)=(*BOUND)(IEQ);
        }
        (*LA).Data((*LA).Diag(IEQ))=1;
        for(ICOL=(*LA).Diag(IEQ)+1;ICOL<=(*LA).Diag(IEQ+1)-1;ICOL++)
            (*LA).Data(ICOL)=0;
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): SB:  Leaving FeatDomainBound::SetHarmonicBound!!!.\n";
        protocol.mFlush();
    }
}


void FeatDomainBound::SetBoundValues(DoubleVector* x)
{
    DVector_blink *vect;
    DoubleVector *ptr;
    IntArray_blink *temp_list;
    IntArray *arr;
    int i;

    SendBound = MSendBound[ActiveLevel];
    SendBoundData = MSendBoundData[ActiveLevel];

    for (temp_list = SendBound->get_first(), vect = SendBoundData->get_first();
	 temp_list;
	 temp_list = SendBound->get_next(temp_list), vect = SendBoundData->get_next(vect))
    {
	ptr = vect->ptr;
	arr = temp_list->ptr;
	for (i = 1; i <= arr->GetLen(); i++)
	    (*ptr)(i) = (*x)((*arr)(i));
    }

    return;
}


void FeatDomainBound::GetBoundValuesMult(DoubleVector* x)
{
    DVector_blink *vect;
    DoubleVector *ptr;
    IntArray_blink *temp_list;
    IntArray *arr;
    int i;

    RecvBound = MRecvBound[ActiveLevel];
    RecvBoundData = MRecvBoundData[ActiveLevel];

    for (temp_list = RecvBound->get_first(), vect = RecvBoundData->get_first();
	 temp_list;
	 temp_list = RecvBound->get_next(temp_list), vect = RecvBoundData->get_next(vect))
    {
	ptr = vect->ptr;
	arr = temp_list->ptr;
	for (i = 1; i <= arr->GetLen(); i++) {
//                ProtAdd << "(*ptr)=" << (*ptr)(i) << "\n";
	    (*x)((*arr)(i)) += (*ptr)(i);
	}
    }
}


void    FeatDomainBound::GetElemBoundValues(DoubleVector* x)
{
    DVector_blink *vect;
    DoubleVector *ptr;
    IntArray_blink *temp_list;
    IntArray *arr;
    int i;

    RecvElemBound=MRecvElemBound[ActiveLevel];
    RecvElemBoundData=MRecvElemBoundData[ActiveLevel];

    for(temp_list=RecvElemBound->get_first(),
            vect=RecvElemBoundData->get_first();
        temp_list;
        temp_list=RecvElemBound->get_next(temp_list),
            vect=RecvElemBoundData->get_next(vect))
    {
	ptr=vect->ptr;
	arr=temp_list->ptr;
	for(i=1;i<=arr->GetLen();i++)
	    (*x)((*arr)(i))=(*ptr)(i);
    }
}


void    FeatDomainBound::SetElemBoundValues(DoubleVector* x)
{
    DVector_blink *vect;
    DoubleVector *ptr;
    IntArray_blink *temp_list;
    IntArray *arr;
    int i;

    SendElemBound=MSendElemBound[ActiveLevel];
    SendElemBoundData=MSendElemBoundData[ActiveLevel];

    for(temp_list=SendElemBound->get_first(),
            vect=SendElemBoundData->get_first();
        temp_list;
        temp_list=SendElemBound->get_next(temp_list),
            vect=SendElemBoundData->get_next(vect))
    {
	ptr=vect->ptr;
	arr=temp_list->ptr;
	for(i=1;i<=arr->GetLen();i++)
	    (*ptr)(i)=(*x)((*arr)(i));
    }
}


void    FeatDomainBound::HalfBoundValues(DoubleVector* x,DoubleVector* x2)
{
    blist* temp_list;
    myBase=MmyBase[ActiveLevel];

    for(temp_list=myBase->get_neighlist()->get_first();temp_list;
        temp_list=myBase->get_neighlist()->get_next(temp_list)) {
        blink *temp_node;
        for(temp_node=temp_list->base->get_first();temp_node;
            temp_node=temp_list->base->get_next(temp_node)) {
            (*x)(temp_node->node)=(*x2)(temp_node->node)=0;
        }
    }
}

void    FeatDomainBound::SetSPValues(DoubleVector* x,DoubleVector* x2)
{
    blist* temp_list;
    myBase=MmyBase[ActiveLevel];

    for(temp_list=myBase->get_neighlist()->get_first();temp_list;
        temp_list=myBase->get_neighlist()->get_next(temp_list))
    {
	if (temp_list->spinfo==0)
	{
	    blink *temp_node;
	    for(temp_node=temp_list->base->get_first();temp_node;
		temp_node=temp_list->base->get_next(temp_node))
	    {
//  if (temp_node->numneigh==1 && temp_node->type==REAL_BOUND)
		(*x)(temp_node->node)=(*x2)(temp_node->node)=0;
	    }
	}
    }
}

void    FeatDomainBound::SetNeumannBoundValues(DoubleVector* x)
{
    DVector_blink *vect;
    DoubleVector *ptr;
    IntArray_blink *temp_list;
    IntArray *arr;
    int i;

    SendNeumannBound=MSendNeumannBound[ActiveLevel];
    SendNeumannBoundData=MSendNeumannBoundData[ActiveLevel];

    for(temp_list=SendNeumannBound->get_first(),vect=SendNeumannBoundData->get_first();
	temp_list;temp_list=SendNeumannBound->get_next(temp_list),vect=SendNeumannBoundData->get_next(vect))
    {
	ptr=vect->ptr;
	arr=temp_list->ptr;
	for(i=1;i<=arr->GetLen();i++)
	    (*ptr)(i)=(*x)((*arr)(i));
    }
}

void    FeatDomainBound::GetNeumannBoundValuesMult(DoubleVector* x)
{
    DVector_blink *vect;
    DoubleVector *ptr;
    IntArray_blink *temp_list;
    IntArray *arr;
    int i;

    RecvNeumannBound=MRecvNeumannBound[ActiveLevel];
    RecvNeumannBoundData=MRecvNeumannBoundData[ActiveLevel];

    for(temp_list=RecvNeumannBound->get_first(),vect=RecvNeumannBoundData->get_first();
	temp_list;temp_list=RecvNeumannBound->get_next(temp_list),vect=RecvNeumannBoundData->get_next(vect))
    {
	ptr=vect->ptr;
	arr=temp_list->ptr;
	for(i=1;i<=arr->GetLen();i++)
	    (*x)((*arr)(i))+=(*ptr)(i);
    }
}

void    FeatDomainBound::HalfNeumannBoundValues(DoubleVector* x,DoubleVector* x2)
{
    blist* temp_list;

    for(temp_list=myBase->get_neighlist()->get_first();temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
    {
	blink *temp_node;
	for(temp_node=temp_list->base->get_first();temp_node;temp_node=temp_list->base->get_next(temp_node))
	{
	    (*x)(temp_node->node)=0;
	}
    }
}

void     FeatDomainBound::SetBoundData(DoubleVector *recv,DoubleVector *set)
{
    for(int i=1;i<=set->GetLen();i++)
	(*set)(i)=(*recv)(i);
}

void ParGrid::SetMultiBound(MultiCompactMatrix* A, DoubleVector* LB, DoubleVector* LX, double T)
{
    int   ICOL,IEQ,ILEV;
    double        X,Y,Z;
    blink* temp;
    DoubleCompactMatrix *LA;

    for(ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
	real_nodeBase=Mreal_nodeBase[ILEV];
	VertCoord=MVertCoord[ILEV];
	LA=(*A)[ILEV];

	for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp))
	{
	    if (temp->type==REAL_BOUND)
	    {
		IEQ=temp->node;
		if (ILEV==MaxLevel) {
		    X=(*VertCoord)(1,IEQ);
		    Y=(*VertCoord)(2,IEQ);
		    Z=(*VertCoord)(3,IEQ);
		    (*LB)(IEQ)=Solution(X, Y, Z, T);
		    (*LX)(IEQ)=Solution(X, Y, Z, T);
		}

		(*LA).Data((*LA).Diag(IEQ))=1;
		for(ICOL=(*LA).Diag(IEQ)+1;ICOL<=(*LA).Diag(IEQ+1)-1;ICOL++)
		    (*LA).Data(ICOL)=0;
	    }
	}
    }
}

void ParGrid::SetMultiBound(MultiCompactMatrix* A)
{
    int   ICOL,IEQ,ILEV;
//   double        X,Y,Z;
    blink* temp;
    DoubleCompactMatrix *LA;

    for(ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
	real_nodeBase=Mreal_nodeBase[ILEV];
	VertCoord=MVertCoord[ILEV];
	LA=(*A)[ILEV];

	for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp))
	{
	    if (temp->type==REAL_BOUND)
	    {
		IEQ=temp->node;

		(*LA).Data((*LA).Diag(IEQ))=1;
		for(ICOL=(*LA).Diag(IEQ)+1;ICOL<=(*LA).Diag(IEQ+1)-1;ICOL++)
		    (*LA).Data(ICOL)=0;
	    }
	}
    }
}

void ParGrid::SetBoundDefekt(DoubleVector* LB)
{
    int IEQ;
    blink* temp;

    real_nodeBase = Mreal_nodeBase[MaxLevel];

    for (temp = real_nodeBase->get_first();
         temp;
         temp = real_nodeBase->get_next(temp)) {
        if (temp->type == REAL_BOUND) {
            IEQ = temp->node;
            (*LB)(IEQ) = 0;
        }
    }
}

void ParGrid::SetMidMultiBound(MultiCompactMatrix* A,DoubleVector* LB,DoubleVector* LX, double T)
{
    int   ICOL,IEQ,ILEV;
    double        X,Y,Z;
    blink* temp;
    DoubleCompactMatrix *LA;

    for(ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
	real_nodeBase=Mreal_nodeBase[ILEV];
	VertCoord=MVertCoord[ILEV];
	LA=(*A)[ILEV];

	for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp))
	{
	    if (temp->type==REAL_BOUND)
	    {
		if (ILEV==MaxLevel) {
		    X=0.25*((*VertCoord)(1,temp->node1)+(*VertCoord)(1,temp->node2)
			    +(*VertCoord)(1,temp->node3)+(*VertCoord)(1,temp->node4));
		    Y=0.25*((*VertCoord)(2,temp->node1)+(*VertCoord)(2,temp->node2)
			    +(*VertCoord)(2,temp->node3)+(*VertCoord)(2,temp->node4));
		    Z=0.25*((*VertCoord)(3,temp->node1)+(*VertCoord)(3,temp->node2)
			    +(*VertCoord)(3,temp->node3)+(*VertCoord)(3,temp->node4));
		    (*LB)(temp->node)=Solution(X, Y, Z, T);
		    (*LX)(temp->node)=Solution(X, Y, Z, T);
		}

		IEQ=temp->node;
		(*LA).Data((*LA).Diag(IEQ))=1;
		for(ICOL=(*LA).Diag(IEQ)+1;ICOL<=(*LA).Diag(IEQ+1)-1;ICOL++)
		    (*LA).Data(ICOL)=0;
	    }
	}
    }
}

void ParGrid::CreateBoundInfo()
{
//   int IEQ;
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering ParGrid::CreateBoundInfo.\n";
        protocol.mFlush();
    }

    int ILEV;
    blink* temp;

    for(ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
	NumVertices=MNumVertices[ILEV];
	real_nodeBase=Mreal_nodeBase[ILEV];

	NumVertBound=0;
	for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp))
	{
	    if (temp->type==REAL_BOUND)
	    {
		NumVertBound++;
	    }
	}
	VertBound=new IntArray(NumVertBound,"VertBound");
	NumVertBound=0;
	for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp))
	{
	    if (temp->type==REAL_BOUND)
	    {
		NumVertBound++;
		(*VertBound)(NumVertBound)=temp->node;
	    }
	}

	MNumVertBound[ILEV]=NumVertBound;
	MVertBound[ILEV]=VertBound;
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving ParGrid::CreateBoundInfo.\n";
        protocol.mFlush();
    }
}


void Task::CheckBound(double dnu,double& dpf1,double& dpf2)
{

//=======================================================================
// *** Parameters for lift (dfw) and drag (daw)
// ***
// *** dfw=2 int_s [dpf(1) dut/dn n_y - p n_x] ds / dpf(2)
// *** daw=2 int_s [dpf(1) dut/dn n_x + p n_y] ds / dpf(2)
// ***
//=======================================================================
//
    double RHO  =1.0;
    double DIST =0.041;

    // steady
    // double UMEAN = 0.45 * 4.0 / 9.0;
    // unsteady
    // double UMEAN = 2.25 * 4.0 / 9.0;
    double UMEAN = 1.0;

    dpf1 = RHO * dnu;
    dpf2 = RHO * DIST * pow(UMEAN, 2);
}


void Task::CalcLiftDrag(DoubleVector *sol1, DoubleVector *sol2, DoubleVector *sol3, DoubleVector *p,
                        FiniteElement_3D *elem,
			double& dfw1, double& daw1, double& dfw2, double& daw2)
{
    int iabd,ielbd;
    int iah;
    int IVT1,IVT2,IVT3,IVT4,IVE,IVT;
    double P1X,P1Y,P1Z,P2X,P2Y,P2Z,P3X,P3Y,P3Z,P4X,P4Y,P4Z,DNX,DNY,DNZ;
//      int flag, jp, jdfl;
//      int ILD, IEL, IAT, IAREA, IADJ;
//      double AX1, AY1, AZ1;
    double AX2, AY2, AZ2;
    double AX3, AY3, AZ3;
    double AX4, AY4, AZ4;
    double AX, AY, AZ;
    double DHN;

    double PXC,PYC,PZC,PXA,PYA,PZA,DNAR1,DNAR2,pf1,pf2;
//    double DFAC;
    double DTX,DTY,DTZ;
    double dareal,dpcont,XX,YY,ZZ,dut;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CalcLiftDrag.\n";
        protocol.mFlush();
    }

    dfw1 = 0.0; daw1 = 0.0;
    dfw2 = 0.0; daw2 = 0.0;
    dnu = Param->EpsEqu;

    SetLevel(MaxLevel);

    Volumes = MVolumes[MaxLevel];
    DoubleVector lp(NumVertices);
    IntpolConToKon(*p, lp);

    CheckBound(dnu, pf1, pf2);
    if (MNumDragBound[MaxLevel] > 0  ||  MNumDragBound2[MaxLevel] > 0) {
	for (unsigned int i = 1; i <= 2; i++) {
	    switch (i) {
	    case 1:
		// First obstacle for which drag and lift are to be computed.
		NumDragBound  = MNumDragBound[MaxLevel];
		DragBound     = MDragBound[MaxLevel];
		ElemDragBound = MElemDragBound[MaxLevel];
		break;

	    case 2:
		NumDragBound  = MNumDragBound2[MaxLevel];
		DragBound     = MDragBound2[MaxLevel];
		ElemDragBound = MElemDragBound2[MaxLevel];
		break;
	    }

	    for (unsigned int iat = 1; iat <= NumDragBound; iat++) {
		iabd = (*DragBound)(iat);
		ielbd = (*ElemDragBound)(iat);

		for (unsigned int ia = 1; ia <= 6; ia++) {
		    iah = (*MidFaces)(ia, ielbd);
		    if (iah == iabd) {
			PXC = 0.0;
			PYC = 0.0;
			PZC = 0.0;

			for (IVE = 1; IVE <= 8; IVE++) {
			    IVT = (*VertElem)(IVE, ielbd);
			    PXC += (*VertCoord)(1, IVT);
			    PYC += (*VertCoord)(2, IVT);
			    PZC += (*VertCoord)(3, IVT);
			}

			PXC *= 0.125;
			PYC *= 0.125;
			PZC *= 0.125;

			if (ia == 1) {
			    IVT1 = (*VertElem)(1, ielbd);
			    IVT2 = (*VertElem)(2, ielbd);
			    IVT3 = (*VertElem)(3, ielbd);
			    IVT4 = (*VertElem)(4, ielbd);
			}
			if (ia == 2) {
			    IVT1 = (*VertElem)(1, ielbd);
			    IVT2 = (*VertElem)(2, ielbd);
			    IVT3 = (*VertElem)(6, ielbd);
			    IVT4 = (*VertElem)(5, ielbd);
			}
			if (ia == 3) {
			    IVT1 = (*VertElem)(2, ielbd);
			    IVT2 = (*VertElem)(3, ielbd);
			    IVT3 = (*VertElem)(6, ielbd);
			    IVT4 = (*VertElem)(7, ielbd);
			}
			if (ia == 4) {
			    IVT1 = (*VertElem)(3, ielbd);
			    IVT2 = (*VertElem)(4, ielbd);
			    IVT3 = (*VertElem)(8, ielbd);
			    IVT4 = (*VertElem)(7, ielbd);
			}
			if (ia == 5) {
			    IVT1 = (*VertElem)(4, ielbd);
			    IVT2 = (*VertElem)(1, ielbd);
			    IVT3 = (*VertElem)(5, ielbd);
			    IVT4 = (*VertElem)(8, ielbd);
			}
			if (ia == 6) {
			    IVT1 = (*VertElem)(5, ielbd);
			    IVT2 = (*VertElem)(6, ielbd);
			    IVT3 = (*VertElem)(7, ielbd);
			    IVT4 = (*VertElem)(8, ielbd);
			}
			P1X = (*VertCoord)(1, IVT1);
			P1Y = (*VertCoord)(2, IVT1);
			P1Z = (*VertCoord)(3, IVT1);
			P2X = (*VertCoord)(1, IVT2);
			P2Y = (*VertCoord)(2, IVT2);
			P2Z = (*VertCoord)(3, IVT2);
			P3X = (*VertCoord)(1, IVT3);
			P3Y = (*VertCoord)(2, IVT3);
			P3Z = (*VertCoord)(3, IVT3);
			P4X = (*VertCoord)(1, IVT4);
			P4Y = (*VertCoord)(2, IVT4);
			P4Z = (*VertCoord)(3, IVT4);

			XX = (P1X + P2X + P3X + P4X) * 0.25;
			YY = (P1Y + P2Y + P3Y + P4Y) * 0.25;
			ZZ = (P1Z + P2Z + P3Z + P4Z) * 0.25;

			PXA = (P1X + P2X + P3X + P4X) * 0.25;
			PYA = (P1Y + P2Y + P3Y + P4Y) * 0.25;
			PZA = (P1Z + P2Z + P3Z + P4Z) * 0.25;

			AX2 = P2X - P1X;
			AY2 = P2Y - P1Y;
			AZ2 = P2Z - P1Z;
			AY3 = P3Y - P1Y;
			AX3 = P3X - P1X;
			AZ3 = P3Z - P1Z;
			AY4 = P4Y - P1Y;
			AX4 = P4X - P1X;
			AZ4 = P4Z - P1Z;

			AX = PXC - PXA;
			AY = PYC - PYA;
			AZ = PZC - PZA;

			DNX = (AY3 * AZ2) - (AZ3 * AY2);
			DNY = (AZ3 * AX2) - (AX3 * AZ2);
			DNZ = (AX3 * AY2) - (AY3 * AX2);
			DNAR1 = sqrt(DNX * DNX + DNY * DNY + DNZ * DNZ);

			DNX = (AY4 * AZ3) - (AZ4 * AY3);
			DNY = (AZ4 * AX3) - (AX4 * AZ3);
			DNZ = (AX4 * AY3) - (AY4 * AX3);
			DNAR2 = sqrt(DNX * DNX + DNY * DNY + DNZ * DNZ);

			DNX /= DNAR2;
			DNY /= DNAR2;
			DNZ /= DNAR2;

			DHN = DNX * AX + DNY * AY + DNZ * AZ;
			if (DHN < 0.) {
			    DNX = -DNX;
			    DNY = -DNY;
			    DNZ = -DNZ;
			}

			DNZ = 0.;

			DTX =  DNY;
			DTY = -DNX;
			DTZ =  DNZ;

			dareal = 0.5 * (DNAR1 + DNAR2);
			//    dpcont = (*p)(ielbd);
			dpcont = 0.25 * (lp(IVT1) + lp(IVT2) + lp(IVT3) + lp(IVT4));

			//  DNX = DNY = DTX = DTY = 1.0;
			//  IEL = 1;
			//  dareal = pf1 = dpcont = 1.;
			//    elem->CalcValueCoeff(PXC, PYC, PZC, DTX, DTY, DNX, DNY, sol1, sol2, ielbd, dut);
			elem->CalcValueCoeff(XX, YY, ZZ, DTX, DTY, DNX, DNY, sol1, sol2, ielbd, dut);

			switch (i) {
			case 1:
			    dfw1 += dareal * (pf1 * dut * DNY - dpcont * DNX);
			    daw1 -= dareal * (pf1 * dut * DNX + dpcont * DNY);
			    break;

			case 2:
			    dfw2 += dareal * (pf1 * dut * DNY - dpcont * DNX);
			    daw2 -= dareal * (pf1 * dut * DNX + dpcont * DNY);
			    break;
			}
			//    Prot << "PXC=" << PXC << " PYC=" << PYC << " PZC=" << PZC << "\n";
			//    Prot << "PXC=" << PXC << " PYC=" << PYC << " PZC=" << PZC << " dareal=" << dareal << " pf1=" << pf1 << " dut=" << dut << " dpcont=" << dpcont << " dnx=" << DNX << " dny=" << DNY << "\n";
			//    Prot << "dfw: iar=" << iabd << " ielbd=" << ielbd << " dfw=" << dfw << "\n";
			//    Prot << "daw: iar=" << iabd << " ielbd=" << ielbd << " daw=" << daw << "\n";
		    }
		}
	    } // end for (unsigned int iat = 1; iat <= NumDragBound; iat++)
	} // end for (unsigned int i = 1; i <= 2; i++)
    }

    if (pf2 > 1e-8) {
	dfw1 = 2.0 * dfw1 / pf2;
	daw1 = 2.0 * daw1 / pf2;

	dfw2 = 2.0 * dfw2 / pf2;
	daw2 = 2.0 * daw2 / pf2;
    }
    CommunicateSP(dfw1);
    CommunicateSP(daw1);
    CommunicateSP(dfw2);
    CommunicateSP(daw2);

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CalcLiftDrag.\n";
        protocol.mFlush();
    }

    return;
}


void Task::SetCoeffInfo(int level)
{
//
// need this to calculate drag and lift values
//
    int         iel, iar, type, iat;
    IntArray2D *DragLiftInfo;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::SetCoeffInfo.\n";
        protocol.mFlush();
    }

    if (Param->Func != 2  &&  Param->Func != 4  &&  Param->Func != 5)
        return;

    NumDragBound  = 0;
    NumDragBound2 = 0;
    if (level == MaxLevel) {
        MidFaces    = MMidFaces[MaxLevel];
        VertElem    = MVertElem[MaxLevel];
        VertCoord   = MVertCoord[MaxLevel];
        ActiveLevel = MaxLevel;
        blink *temp;

        DragLiftInfo = new IntArray2D(7, NumElements+1);
        SetDragLiftInfo(DragLiftInfo);

        // Traverse each face in our grid.
        for (iel = 1;iel <= NumElements; iel++) {
            for (iat = 1; iat <= NUMOFFACE; iat++) {
                iar  = (*MidFaces)(iat,iel);

		if ((*DragLiftInfo)(iat, iel) == 1) {
		    temp = Mreal_nodeBase[MaxLevel]->find_node(iar);

		    if (temp)
			type = temp->type;
		    else
			type = ART_BOUND;

//                  protocol << "    Face = " << setw(5) << setfill('0') << iar << "  Type = ";
//                  if (type == ART_BOUND)
//                      protocol << "artifical boundary face\n";
//                  else if (type == REAL_BOUND)
//                      protocol << "real boundary face\n";
//                  else if (type == NEUMANN_BOUND)
//                      protocol << "neumann boundary face\n";
//                  else
//                      protocol << "unknown: " << type << " !!\n";

		    if (type == REAL_BOUND)
			NumDragBound++;
		} else if ((*DragLiftInfo)(iat, iel) == 2) {
		    temp = Mreal_nodeBase[MaxLevel]->find_node(iar);

		    if (temp)
			type = temp->type;
		    else
			type = ART_BOUND;

		    if (type == REAL_BOUND)
			NumDragBound2++;
		} // end if (*DragLiftInfo)(iat, iel)...
            } // end for iat
	} // end for iel

        if (NumDragBound > 0) {
            MDragBound[MaxLevel]     = DragBound     = new IntArray(NumDragBound,"VertBound");
            MElemDragBound[MaxLevel] = ElemDragBound = new IntArray(NumDragBound,"ElemBound");
            NumDragBound = 0;
            for (iel = 1; iel <= NumElements; iel++) {
                for (iat = 1; iat <= NUMOFFACE; iat++) {
                    iar  = (*MidFaces)(iat, iel);

		    if ((*DragLiftInfo)(iat, iel) == 1) {
			temp = Mreal_nodeBase[MaxLevel]->find_node(iar);
			if (temp)
			    type = temp->type;
			else
			    type = ART_BOUND;

			if (type == REAL_BOUND) {
			    NumDragBound++;
			    (*DragBound)(NumDragBound)     = iar;
			    (*ElemDragBound)(NumDragBound) = iel;
			}
                    }
                }
            }
        } // end if (NumDragBound > 0)
	MNumDragBound[MaxLevel] = NumDragBound;

        if (NumDragBound2 > 0) {
            MDragBound2[MaxLevel]     = DragBound     = new IntArray(NumDragBound2, "VertBound");
            MElemDragBound2[MaxLevel] = ElemDragBound = new IntArray(NumDragBound2, "ElemBound");
            NumDragBound2 = 0;
            for (iel = 1; iel <= NumElements; iel++) {
                for (iat = 1; iat <= NUMOFFACE; iat++) {
                    iar  = (*MidFaces)(iat, iel);

		    if ((*DragLiftInfo)(iat, iel) == 2) {
			temp = Mreal_nodeBase[MaxLevel]->find_node(iar);
			if (temp)
			    type = temp->type;
			else
			    type = ART_BOUND;

			if (type == REAL_BOUND) {
			    NumDragBound2++;
			    (*DragBound)(NumDragBound2)     = iar;
			    (*ElemDragBound)(NumDragBound2) = iel;
			}
                    }
                }
            }
        } // end if (NumDragBound2 > 0)
	MNumDragBound2[MaxLevel] = NumDragBound2;

	delete DragLiftInfo;
    } // end if (level == MaxLevel)

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::SetCoeffInfo.\n";
        protocol.mFlush();
    }

    return;
}


void Task::SetDragLiftInfo(IntArray2D *DragLiftInfo)
{
    if (Param->Func != 2  &&  Param->Func != 4  &&  Param->Func != 5)
        return;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::SetDragLiftInfo.\n";
        protocol.mFlush();
    }

    unsigned int iar;
    int    ivt1, ivt2, ivt3, ivt4, ivt5, ivt6, ivt7, ivt8;
    double xv1, xv2, xv3, xv4, xv5, xv6, xv7, xv8;
    double yv1, yv2, yv3, yv4, yv5, yv6, yv7, yv8;
    double zv1, zv2, zv3, zv4, zv5, zv6, zv7, zv8;
    double px, py, pz;

    // Traverse each face in our grid.
    for (unsigned int iel = 1;  iel <= NumElements;  iel++) {
        for (unsigned int iat = 1;  iat <= 6;  iat++) {
            iar  = (*MidFaces)(iat, iel);

            // Identify the eight vertices that make up the current element.
            ivt1 = (*VertElem)(1, iel);
            ivt2 = (*VertElem)(2, iel);
            ivt3 = (*VertElem)(3, iel);
            ivt4 = (*VertElem)(4, iel);
            ivt5 = (*VertElem)(5, iel);
            ivt6 = (*VertElem)(6, iel);
            ivt7 = (*VertElem)(7, iel);
            ivt8 = (*VertElem)(8, iel);

            // Identify their coordinates
            xv1 = (*VertCoord)(1, ivt1);
            yv1 = (*VertCoord)(2, ivt1);
            zv1 = (*VertCoord)(3, ivt1);
            xv2 = (*VertCoord)(1, ivt2);
            yv2 = (*VertCoord)(2, ivt2);
            zv2 = (*VertCoord)(3, ivt2);
            xv3 = (*VertCoord)(1, ivt3);
            yv3 = (*VertCoord)(2, ivt3);
            zv3 = (*VertCoord)(3, ivt3);
            xv4 = (*VertCoord)(1, ivt4);
            yv4 = (*VertCoord)(2, ivt4);
            zv4 = (*VertCoord)(3, ivt4);
            xv5 = (*VertCoord)(1, ivt5);
            yv5 = (*VertCoord)(2, ivt5);
            zv5 = (*VertCoord)(3, ivt5);
            xv6 = (*VertCoord)(1, ivt6);
            yv6 = (*VertCoord)(2, ivt6);
            zv6 = (*VertCoord)(3, ivt6);
            xv7 = (*VertCoord)(1, ivt7);
            yv7 = (*VertCoord)(2, ivt7);
            zv7 = (*VertCoord)(3, ivt7);
            xv8 = (*VertCoord)(1, ivt8);
            yv8 = (*VertCoord)(2, ivt8);
            zv8 = (*VertCoord)(3, ivt8);

            if (iar == (*MidFaces)(1, iel)) {
                px = (xv1 + xv2 + xv3 + xv4) * 0.25;
                py = (yv1 + yv2 + yv3 + yv4) * 0.25;
                pz = (zv1 + zv2 + zv3 + zv4) * 0.25;
            }

            else if (iar == (*MidFaces)(2, iel)) {
                px = (xv1 + xv2 + xv6 + xv5) * 0.25;
                py = (yv1 + yv2 + yv6 + yv5) * 0.25;
                pz = (zv1 + zv2 + zv6 + zv5) * 0.25;
            }

            else if (iar == (*MidFaces)(3, iel)) {
                px = (xv2 + xv3 + xv6 + xv7) * 0.25;
                py = (yv2 + yv3 + yv6 + yv7) * 0.25;
                pz = (zv2 + zv3 + zv6 + zv7) * 0.25;
            }

            else if (iar == (*MidFaces)(4, iel)) {
                px = (xv3 + xv4 + xv8 + xv7) * 0.25;
                py = (yv3 + yv4 + yv8 + yv7) * 0.25;
                pz = (zv3 + zv4 + zv8 + zv7) * 0.25;
            }

            else if (iar == (*MidFaces)(5, iel)) {
                px = (xv4 + xv1 + xv5 + xv8) * 0.25;
                py = (yv4 + yv1 + yv5 + yv8) * 0.25;
                pz = (zv4 + zv1 + zv5 + zv8) * 0.25;
            }

            else if (iar == (*MidFaces)(6, iel)) {
                px = (xv5 + xv6 + xv7 + xv8) * 0.25;
                py = (yv5 + yv6 + yv7 + yv8) * 0.25;
                pz = (zv5 + zv6 + zv7 + zv8) * 0.25;
            }

            switch (Param->Func) {
            case 4:
		// two consecutive cylinders
		(*DragLiftInfo)(iat, iel) = 0;
		if (pz > 0  &&  pz < 0.41) {
		    if (px >= 0.44  &&  px <= 0.56  &&
			py >= 0.145 &&  py <= 0.255) {
			(*DragLiftInfo)(iat, iel) = 1;
		    }

		    if (px >= 0.74  &&  px <= 0.86  &&
			py >= 0.17  &&  py <= 0.28) {
			(*DragLiftInfo)(iat, iel) = 2;
		    }
		}
                break;

            case 5:
		// cylinder (DFG Benchmark 3D-2Z)
		(*DragLiftInfo)(iat, iel) = 0;
                if (px >= 0.45  &&  px <= 0.55  &&
                    py >= 0.15  &&  py <= 0.25  &&
                    pz >  0     &&  pz <  0.41) {
                    (*DragLiftInfo)(iat, iel) = 1;
                }
                break;

            case 2:
		// Asmo
		(*DragLiftInfo)(iat, iel) = 0;
                if (px > -0.0001  &&  px < 0.8  &&
                    py >  0.02    &&  py < 0.3   &&
                    pz >  0.02    &&  pz < 1.0) {
                    (*DragLiftInfo)(iat, iel) = 1;
                }
                break;

            default:
                (*DragLiftInfo)(iat, iel) = 0;
            }
        }
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::SetDragLiftInfo.\n";
        protocol.mFlush();
    }

    return;
} // end SetDragLiftInfo
