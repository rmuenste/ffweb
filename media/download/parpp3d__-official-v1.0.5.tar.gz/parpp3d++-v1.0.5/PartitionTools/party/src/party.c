/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            party.c
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <values.h>
#include <math.h>
#include <malloc.h>
#include <string.h>
#include "party_lib.h"
#include "alloc.h"
#include "error.h"

static long	t=0;
static long	t_all=0, 
		t_pre=0,
	        t_part=0,
		t_rest=0;

static void times_output (int Times)
{ t_all = t_pre+t_part+t_rest;
  printf("TIME                : ");
  printf ("%.2f sec", ((float)t_all)/1000);
  if (t_all/60000)
    printf ("  (%.2f min)\n", ((float)t_all)/60000);
  else
    printf ("\n");
  if (Times > 1) 
  { printf("  Pre               : %.2f\n",((float)t_pre)/1000);
    printf("  Part              : %.2f\n",((float)t_part)/1000);
    if (Times > 2)
      party_lib_times_output (Times-2);
    printf("  Rest              : %.2f\n",((float)t_rest)/1000);
  };
}


void main (int argc, char **argv)
{ int         	i, cutsize; 
  char        	graphfile[100], *xyzfile=NULL, global[100], local[100], 
		*partfile=NULL;
  int       	runs=1, p=2, Output=1, Times=2, recursive=1,
   		n=0, *edge_p=NULL, *edge=NULL, *edge_w=NULL, *part;
  float 	*vertex_w=NULL, *x=NULL, *y=NULL, *z=NULL, add_bal=0.0;

  sprintf (graphfile, "Grid32x32");
  sprintf (global, "all");
  sprintf (local, "hs");
 
/* Start of the time*/
  INIT_TIME();
  party_lib_times_start();

/* check parameter */
  if (argc == 1)
  { puts("party [-f graphfile] [-xyz coorfile] [-g global] [-l local] [-# runs] [-p parts] [-b balance] [-r recursive] [-s partfile] [-o output] [-t times]");
    puts("-f   graphfile (Grid32x32)                    -s save partition in partfile ()");
    puts("-xyz coordinate file ()                       -o output: 0..4 (1)");
    puts("-g   global method:{opt,lin,sca,ran,gai,far,  -t times output: 0..4 (2)");
    puts("     coo,mul,spm,spl,ine,all,<file>} (all)"); 
    puts("-l   local method: {hs,kl,ckl,no} (hs)");
    puts("-#   number of runs (1)");
    puts("-p   number of parts (2)");
    puts("-b   additional imbalance (0.0)               < Default values are in");
    puts("-r   recursive?: 0/1 (1)                        brackets (). >");
    puts("\nExample with default values:");
  };
  i = 0;
  while (++i<argc)
  { if     (!strcmp(argv[i],"-f")  && i+1<argc) strcpy (graphfile, argv[++i]);
    else if(!strcmp(argv[i],"-xyz")&& i+1<argc) xyzfile = argv[++i];
    else if(!strcmp(argv[i],"-g")  && i+1<argc) strcpy (global, argv[++i]);
    else if(!strcmp(argv[i],"-l")  && i+1<argc) strcpy (local, argv[++i]);
    else if(!strcmp(argv[i],"-#")  && i+1<argc) runs = atoi(argv[++i]);
    else if(!strcmp(argv[i],"-p")  && i+1<argc) p = atoi(argv[++i]);
    else if(!strcmp(argv[i],"-b")  && i+1<argc) add_bal = atof(argv[++i]);
    else if(!strcmp(argv[i],"-r")  && i+1<argc) recursive = atof(argv[++i]);
    else if(!strcmp(argv[i],"-s")  && i+1<argc) partfile = argv[++i];
    else if(!strcmp(argv[i],"-o")  && i+1<argc) Output = atoi(argv[++i]);
    else if(!strcmp(argv[i],"-t")  && i+1<argc) Times = atoi(argv[++i]);
    else 
    { fprintf(stderr, "PARTY ERROR...option %s not legal or without value\n", argv[i]);
      exit(1);
    };
  };
  if (Output > 0)
  { printf ("========== ");
    printf (VERSION);
    puts (" ==========================");
    printf("Graphfile           : %s\n", graphfile);
    if (xyzfile)
      printf("XYZfile             : %s\n", xyzfile);
    printf("Global / Local      : %s / %s\n", global, local);
    printf("Parts  / add. Bal.  : %d / %.2f\n", p, add_bal);
  };

/* load graph */
  if (graph_load(graphfile,xyzfile,&n,&vertex_w,&x,&y,&z,&edge_p,&edge,&edge_w))
    EXIT ("PARTY", "failed graph_load");

  if (!(part = (int*)calloc((unsigned)n,sizeof(int))))
    EXIT ("PARTY", "no memory");

  if (graph_check_and_info (n,vertex_w,x,y,z,edge_p,edge,edge_w,Output))
    EXIT ("PARTY", "failed graph_check_and_info");

  ADD_NEW_TIME(t_pre);


  if (party_lib(global,local,runs,n,vertex_w,x,y,z,edge_p,edge,edge_w,p,add_bal,recursive,part,&cutsize,Output-1))
    EXIT ("PARTY", "failed party_lib");

  ADD_NEW_TIME(t_part);


  if (part_check(n,vertex_w,p,add_bal,recursive,part, Output-2))
  { fprintf(stderr,"PARTY ERROR...failed part_check %s\n", global);
    exit(1);
  };

  if (Output > 0)
    if (part_info (n,vertex_w,edge_p,edge,edge_w,p,part,Output))
      EXIT ("PARTY", "failed part_info");

  if (partfile)
  { if (!strcmp(partfile,"default"))
    { if (strstr(graphfile, "/"))
	sprintf (partfile, "%s", strrchr(graphfile, '/')+1);
      else
	sprintf (partfile, "%s", graphfile);
      if (strstr(partfile, ".chaco"))
	sprintf ((char*)strstr(partfile,".chaco"), "%s%s+%s%s%d", ".", global, local, ".", p);
      else
	sprintf (&(partfile[strlen(partfile)]), "%s%s+%s%s%d", ".", global, local, ".", p);
    };
 
    if (part_save(partfile,n,part))
      EXIT ("PARTY", "failed part_save");
  };

  if (graph_free (n,vertex_w,x,y,z,edge_p,edge,edge_w))
    EXIT ("PARTY", "failed graph_free");
  free((char*)part);

  if (Output > 0)
    print_alloc_statistics();
  ADD_NEW_TIME(t_rest);
  if (Times > 0)
    times_output(Times);
  if (Output > 0)
    puts("========== PARTY End ==============================================");
  exit(0);
}
