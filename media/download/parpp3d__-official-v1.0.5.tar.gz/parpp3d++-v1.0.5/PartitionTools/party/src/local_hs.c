/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            local_hs.c
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <values.h>
#include <math.h>
#include "alloc.h"
#include "bucket.h"
#include "vertex.h"
#include "error.h"
#include "party_lib.h"

#define MAX(A,B)         (((A)>(B))?(A):(B))

static long	t=0;
static long     t_pre=0,
                t_comb=0,
                t_bip_pre=0,
                t_bip_past=0,
                t_bip_pure=0,
                t_post=0;

void hs_times_start (void)
{ 
  t_pre=t_comb=t_bip_pre=t_bip_past=t_bip_pure=t_post=0;
}

void hs_times_output (void)
{ if (t_pre||t_comb||t_bip_pre||t_bip_pure||t_bip_past||t_post)
  { printf("      HS pre            : %.2f\n",((float)t_pre )/1000);
    printf("      HS comb           : %.2f\n",((float)t_comb)/1000);
    printf("      HS bip pre        : %.2f\n",((float)t_bip_pre )/1000);
    printf("      HS bip pure       : %.2f\n",((float)t_bip_pure)/1000);
    printf("      HS bip past       : %.2f\n",((float)t_bip_past )/1000);
    printf("      HS post           : %.2f\n",((float)t_post)/1000);
  }
}

static void build_hs (BUCKETS* B, VERTEX* S, int limit, int help_min, int diff_min, float size_min)
{ VERTEX  *vertex;

  while (H(S)<limit  &&  W(S)<=size_min  &&  bucket_max_key(B)>=diff_min  &&  H(S)+bucket_max_key(B)>=help_min)
  { vertex = BUCKET_MAX(B);
    bucket_delete (BE(vertex));
    LOCKED(vertex) = 1;
    H(S) += H(vertex);
    W(S) += W(vertex);
    FRONT_NEXT(vertex, SET(S));

    FOR_ALL_NEIGHBORS_W (vertex, neighbor, weight,
    { if (PART(neighbor) == PART(vertex)  &&  !LOCKED(neighbor))
        bucket_new_key(BE(neighbor), H(neighbor)+=(2*weight));
    });
  };
}

static void move_logically_back (VERTEX* vertex_list, BUCKETS* B)
{ 
  FOR_ALL_VERTICES(vertex_list, vertex,
  { LOCKED(vertex) = 0;
    bucket_insert (B, BE(vertex), H(vertex));
    FOR_ALL_NEIGHBORS_W (vertex, neighbor, weight,
    { if (PART(neighbor) == PART(vertex)  &&  !LOCKED(neighbor))
        bucket_new_key (BE(neighbor), H(neighbor)-=(2*weight));
    });
  });
}

static void move_physically_over (VERTEX *list, BUCKETS* B, int p0, int p1)
{
  FOR_ALL_VERTICES(list, vertex,
  { FOR_ALL_NEIGHBORS_W (vertex, neighbor, weight,
    { if (PART(neighbor) == p0  || PART(neighbor) == p1)
        if (PART(neighbor) != PART(vertex))
          bucket_new_key (BE(neighbor), H(neighbor)-=(2*weight));
        else if (LOCKED(neighbor))
          H(neighbor) += 2*weight;
    });
    LOCKED(vertex) = 0;
  });
 
  FOR_ALL_VERTICES (list, vertex,
  { PART(vertex) = (PART(vertex)==p0)?p1:p0;
    H(vertex) *= -1;
    bucket_insert (B, BE(vertex), H(vertex));
  });
}

static void move_physically_back (VERTEX** S_old, BUCKETS* B, int p0, int p1)
{ VERTEX    *vertex;
  int          i=0;
 
  while (S_old[i])
  { vertex = (S_old[i++]);
    bucket_delete (BE(vertex));
    PART(vertex) = (PART(vertex)==p0)?p1:p0;
    H(vertex) *= -1;
    bucket_insert (B, BE(vertex), H(vertex));
    FOR_ALL_NEIGHBORS_W (vertex, neighbor, weight,
    { if (PART(neighbor) == p0  || PART(neighbor) == p1)
        if (PART(neighbor) == PART(vertex))
          bucket_new_key (BE(neighbor), H(neighbor)-=(2*weight));
        else
          bucket_new_key (BE(neighbor), H(neighbor)+=(2*weight));
    });
  };
}

static int hs_direct (VERTEX *V0, VERTEX *V1, VERTEX **cluster_list, VERTEX **S_old, BUCKETS *B0, BUCKETS *B1, float max_cluster_weight, int Output)
{ int        	limit, cutsize=0;
  float      	weight_0=W(V0), weight_1=W(V1);
  VERTEX	*vertex, S0[1], S1[1], *S, BS[1], *V0_orig=V0;  

  FOR_ALL_VERTICES (SET(V0), vertex,
  { H(vertex) = 0;
    FOR_ALL_NEIGHBORS_W (vertex, neighbor, weight,
    { if (PART(neighbor) == PART(V0))
        H(vertex) -= weight;
      else if (PART(neighbor) == PART(V1))
      { H(vertex) += weight;
        cutsize += weight;
      };
    });
    bucket_insert(B0, BE(vertex), H(vertex));
  });
  FOR_ALL_VERTICES (SET(V1), vertex,
  { H(vertex) = 0;
    FOR_ALL_NEIGHBORS_W (vertex, neighbor, weight,
    { if (PART(neighbor) == PART(V1))
        H(vertex) -= weight;
      else if (PART(neighbor) == PART(V0))
      { H(vertex) += weight;
        cutsize += weight;
      };
    });
    bucket_insert(B1, BE(vertex), H(vertex));
  });
  cutsize = cutsize/2;

  ADD_NEW_TIME(t_bip_pre);
  if (Output > 1)
    printf("HS start on %d and %d...  max. weight is %8.2f and cutsize %d\n",PART(V0), PART(V1),MAX(weight_0,weight_1),cutsize);

  limit = cutsize >> 1;
  while (limit > 0)
  { if (Output > 3)
      printf("HS Step1 searches for %d-helpful set\n",limit);
    SET(S0) = SET(S1) = NULL;
    H(S0) = H(S1) = 0;
    W(S0) = W(S1) = 0.0;
    build_hs(B0, S0, limit, -(MAXINT-1), 0, MAXFLOAT);
    if (H(S0) < limit)
      build_hs(B1, S1, limit, -(MAXINT-1), 0, MAXFLOAT);

    if (H(S0) > 0 || H(S1) > 0)
    { if (H(S0) > H(S1))
      { move_logically_back (SET(S1), B1);
        S = S0;
	{ VERTEX  *Vchange;
          BUCKETS *Bchange;
          Bchange = B0;
          B0 = B1;
          B1 = Bchange;
          Vchange = V0;
          V0 = V1;
          V1 = Vchange;
          { int c=weight_0;
            weight_0 = weight_1;
            weight_1 = c;
          };
        };
      }
      else
      { move_logically_back (SET(S0), B0);
	S = S1;
      };
      if (H(S) < limit)
        limit = H(S);
    }
    else
    { move_logically_back (SET(S0), B0);
      move_logically_back (SET(S1), B1);
      limit = 0;
      S = NULL;
      if (Output > 2)
        puts("HS Step1  no helpful set found");
    };

    if (S)
    { int   i=0;
      VERTEX* list=SET(S);
      while(list)
      { S_old[i++] = list;
	list = NEXT(list);
      };
      S_old[i] = NULL;
      cutsize -= H(S);
      if (Output > 3)
        printf("HS Step1 found S  with %d/%.2f (help./weight)\n",H(S),W(S));
      move_physically_over (SET(S), B0, PART(V0), PART(V1)); 
      if (Output > 2)
        printf("HS Step1  try balance %8.2f and cutsize %d\n",fabs(weight_0-weight_1+2*W(S)),cutsize);

      SET(BS) = NULL;
      H(BS) = 0;
      W(BS) = 0.0;
      build_hs(B0, BS, MAXINT, -H(S)+1, -(MAXINT-1), weight_0+W(S)-max_cluster_weight);

      if (weight_0+W(S)-W(BS)<max_cluster_weight && weight_1-W(S)+W(BS)<max_cluster_weight)
      { move_physically_over (SET(BS), B1, PART(V0), PART(V1));
        weight_0 += (W(S)-W(BS));
        weight_1 -= (W(S)-W(BS));
        cutsize -= H(BS);
        if ((limit<<=1) > cutsize>>1)
          limit = cutsize>>1;
        if (Output > 3)
          printf("HS Step2 found BS with %d/%.2f (help./weight)\n",H(BS),W(BS));
        if (Output > 2)
          printf("HS Step2  new balance %8.2f and cutsize %d\n",fabs(weight_0-weight_1),cutsize);
      }
      else
      { move_logically_back (SET(BS), B0);
	cutsize += H(S);
	move_physically_back (S_old, B1, PART(V0), PART(V1));
	limit >>= 1;
        if (Output > 2)
          puts("HS Step2  no success");
      }
    }
  };

  if (Output > 1)
    printf("HS end   on %d and %d...  max. weight is %8.2f and cutsize %d\n",PART(V0), PART(V1), MAX(weight_0,weight_1),cutsize);
  ADD_NEW_TIME(t_bip_pure);

  SET(V0) = SET(V1) = NULL;
  while (bucket_not_empty(B0))
  { vertex = BUCKET_MAX(B0);
    bucket_delete (BE(vertex));
    FRONT_NEXT(vertex, SET(V0));
    if (SET(vertex) != V0)
      change_cluster_edge (vertex, V0_orig, V0, cluster_list);
  };
  while (bucket_not_empty(B1))
  { vertex = BUCKET_MAX(B1);
    bucket_delete (BE(vertex));
    FRONT_NEXT(vertex, SET(V1));
    if (SET(vertex) != V1)
      change_cluster_edge (vertex, V0_orig, V1, cluster_list);
  };
  W(V0) = weight_0;
  W(V1) = weight_1;
  return 0;
}

int local_hs (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, 
	int p, float add_bal, int *part, int Output)
{ int            i, j, degree_weigted, maxdegree=0;
  float          max_cluster_weight=0.0, max_vertex_weight=1.0;
  VERTEX      	 *vertices, *vertex, **neighbors,
                 *cluster, *cluster_list=NULL, **S_old;
  BUCKET_ELE     *bucket_element;
  BUCKETS        **B;

  INIT_TIME();

  CALLOC ("LOCAL_HS",vertices,VERTEX,n);
  CALLOC ("LOCAL_HS",neighbors,VERTEX*,edge_p[n]);
  CALLOC ("LOCAL_HS",cluster,VERTEX,p);
  CALLOC ("LOCAL_HS",S_old,VERTEX*,n);
  CALLOC ("LOCAL_HS",bucket_element,BUCKET_ELE,n);
  CALLOC ("LOCAL_HS",B,BUCKETS*,p);

  if (vertex_w)
  { max_vertex_weight = 0.0;
    for (i=0; i<n; i++)
    { max_cluster_weight += vertex_w[i];
      if (vertex_w[i] > max_vertex_weight)
        max_vertex_weight = vertex_w[i];
    };
    max_cluster_weight = max_cluster_weight/p + max_vertex_weight + add_bal;
  }
  else
    max_cluster_weight = (float)n/p + 1.0 + add_bal;

  for (i=0; i<p; i++)
  { vertex = &(cluster[i]);
    W(vertex) = 0.0;
    SET(vertex) = NULL;
    PART(vertex) = i;
    CALLOC ("LOCAL_HS",NEIG(vertex),VERTEX*,p-1);
    CALLOC ("LOCAL_HS",NW(vertex),int,p-1);
    FRONT_NEXT(vertex, cluster_list);
  };

  for (i=0; i<n; i++)
  { vertex = &(vertices[i]);
    BE(vertex) = &(bucket_element[i]);
    bucket_element[i].element = (void*)vertex;

    DEGREE(vertex) = edge_p[i+1] - edge_p[i];
    W(vertex) = (vertex_w)?vertex_w[i]:1.0; 

    if (part[i]<0 || part[i]>=p)
    { fprintf(stderr, "LOCAL_HS ERROR...part[%d]=%d not in range 0..%d!\n",i,part[i],p-1);
      return 1;
    };
    j = part[i];

    cluster[j].part = part[i];
    PART(vertex) = part[i];
    FRONT_NEXT(vertex, cluster[j].set);
    SET(vertex) = &(cluster[j]);
    cluster[j].weight += W(vertex);

    NEIG(vertex) = &(neighbors[edge_p[i]]); 
    NW(vertex) = (edge_w)?&(edge_w[edge_p[i]]):NULL;
    LOCKED(vertex) = 0;
    degree_weigted = 0;
    for (j=edge_p[i]; j<edge_p[i+1]; j++)
    { neighbors[j] = &(vertices[edge[j]]);
      degree_weigted += ((edge_w)?abs(edge_w[j]):1);
    };
    if (degree_weigted > maxdegree)
      maxdegree = degree_weigted;
  };
  for (i=0; i<p; i++)
    if (bucket_calloc(&(B[i]),-maxdegree, maxdegree))
      FAILED ("LOCAL_HS", "bucket_calloc");

  if (Output > 1)
  { printf("HS Cluster-sizes:");
    for (i=0; i<p; i++)
      printf(" %d:%.3f",cluster[i].part, cluster[i].weight); 
    puts("");
  };

  construct_cluster_edges (cluster, p);
  
  for (i=0; i<p; i++)
    if (cluster[i].weight >= max_cluster_weight)
    { printf("graph with %d vertices saved in 'error'\n",n);
      if(graph_save("error",NULL,n,vertex_w,NULL,NULL,NULL,edge_p,edge,edge_w))
	FAILED ("LOCAL_HS", "graph_save");
      printf("Old cutsize is %d\n",cut(cluster,p));
      balance_cluster (&(cluster[i]), cluster, max_cluster_weight, max_vertex_weight, p, B[i],Output);
      printf("New cutsize is %d\n",cut(cluster,p));
    };

  ADD_NEW_TIME(t_pre);
  if (Output > 0)
  { float max_weight = 0.0;
    for (i=0; i<p; i++)
      if (cluster[i].weight > max_weight)
        max_weight = cluster[i].weight;
    printf("HS START... max. weight: %.3f (%.3f)  cutsize: %3d\n", max_weight, max_cluster_weight, cut(cluster,p));
  };

  while (cluster_list)
  { vertex = cluster_list;
    cluster_list = NEXT(cluster_list);
    while (DEGREE(vertex) > 0) 
    { ADD_NEW_TIME(t_comb);
      DEGREE(vertex) --;
      if (hs_direct(vertex,NEIG(vertex)[DEGREE(vertex)],&cluster_list,S_old,B[0],B[1],max_cluster_weight,Output))
        FAILED ("LOCAL_HS", "hs_direct");
      ADD_NEW_TIME(t_bip_past);
    };
    if (Output > 2)
    { printf("CL: ");
      FOR_ALL_VERTICES(cluster_list,ver,
      { printf(" %d:", PART(ver)); 
        FOR_ALL_NEIGHBORS(ver, neighbor,
        { printf("%d,",PART(neighbor));
        });
      });
      puts("");
    };
  };
  ADD_NEW_TIME(t_comb);

  for (i=0; i<n; i++)
    part[i] = vertices[i].part;
  if (Output > 0)
  { float max_weight = 0.0;
      for (i=0; i<p; i++)
        if (cluster[i].weight > max_weight)
          max_weight = cluster[i].weight;
    printf("HS END  ... max. weight: %.3f (%.3f)  cutsize: %3d \n", max_weight, max_cluster_weight, cut(cluster,p));
  };
  for (i=0; i<p; i++)
    bucket_free (B[i]);
  for (i=0; i<p; i++)
  { FREE(cluster[i].neighbor,VERTEX*,p-1);
    FREE(cluster[i].neighbor_w,int,p-1);
  };
  FREE(vertices,VERTEX,n);
  FREE(neighbors,VERTEX*,edge_p[n]);
  FREE(cluster,VERTEX,p);
  FREE(S_old,VERTEX*,n);
  FREE(bucket_element,BUCKET_ELE,n);
  FREE(B,BUCKETS*,p);
  ADD_NEW_TIME(t_post);
  return 0;
}
