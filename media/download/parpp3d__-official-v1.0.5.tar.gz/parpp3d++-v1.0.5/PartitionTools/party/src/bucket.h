/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            bucket.h
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
typedef struct BUCKET_ELE     { struct BUCKETS         *buckets;
                                struct BUCKET_ELE      **prev, *next;
                                void                   *element;
	                      } BUCKET_ELE;

typedef struct BUCKETS        { int                    total_buckets;
                                int                    const_add;
                                BUCKET_ELE             **bucket;
			        int                    max_bucket;
		              } BUCKETS;

#define bucket_clear(A)        { int i; \
                                 for (i=0; i<(A)->total_buckets; i++) \
                                   (A)->bucket[i] = NULL; \
                                 (A)->max_bucket = -1; \
                               }
#define bucket_empty(A)	       (((A)->max_bucket)<0)
#define bucket_not_empty(A)    (((A)->max_bucket)>=0)
#define bucket_max_key(A)      ((A)->max_bucket-(A)->const_add)
#define bucket_max_element(A)  (((A)->bucket[A->max_bucket])->element)

extern int bucket_calloc ( 
	BUCKETS **buckets, int from, int to); 
extern void bucket_free (
	BUCKETS *buckets);
extern void bucket_insert (
	BUCKETS *buckets, BUCKET_ELE *element, int key);
extern void bucket_delete (
	BUCKET_ELE *element);
extern void bucket_new_key (
	BUCKET_ELE *element, int key); 
extern int bucket_print (
	BUCKETS *buckets);

