/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            vertex.h
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#define PART(A)          ((A)->part)
#define W(A)             ((A)->weight)
#define H(A)             ((A)->help)
#define DEGREE(A)        ((A)->degree)
#define LOCKED(A)        ((A)->locked)
#define NEXT(A)          ((A)->next)
#define SET(A)           ((A)->set)
#define BE(A)            ((A)->bucket_element)
#define NEIG(A)          ((A)->neighbor)
#define NW(A)            ((A)->neighbor_w)

#define BUCKET_MAX(A)         ((VERTEX*)(bucket_max_element(A)))
#define FRONT_NEXT(A,B)  {NEXT(A)=(B); (B)=(A);}
#define FOR_ALL_VERTICES(L,V,C) \
        { VERTEX *V=L; \
          while(V) \
          { C; \
            V = NEXT(V); \
          } \
        }
#define FOR_ALL_NEIGHBORS(V,N,C) \
        { int xx; \
          VERTEX *N; \
          for(xx=0; xx<DEGREE(V); xx++) \
          { N = (NEIG(V))[xx]; \
            C; \
          }; \
        }
#define FOR_ALL_NEIGHBORS_W(V,N,W,C) \
        { int xx, W; \
          VERTEX *N; \
          for(xx=0; xx<DEGREE(V); xx++) \
          { N = (NEIG(V))[xx]; \
            W = (NW(V)) ? (NW(V))[xx] : 1; \
            C; \
          }; \
        }

typedef struct VERTEX { int                    part;
                        float                  weight;
                        int                    help;
                        int                    degree;
                        short                  locked;
                        struct VERTEX          **neighbor;
                        int                    *neighbor_w;
                        struct VERTEX          *next;
                        struct VERTEX          *set;
                        struct BUCKET_ELE      *bucket_element;
                      } VERTEX;

extern void construct_cluster_edges (
	VERTEX *cluster, int p);
extern void change_cluster_edge (
	VERTEX *vertex, VERTEX *orig_cluster, VERTEX *to, 
	VERTEX **cluster_list);
extern void balance_cluster (
	VERTEX *c, VERTEX *cluster, float max_cluster_weight, 
	float max_vertex_weight, int p, BUCKETS *B, int Output);
extern int cut (
	VERTEX *cluster, int p);

