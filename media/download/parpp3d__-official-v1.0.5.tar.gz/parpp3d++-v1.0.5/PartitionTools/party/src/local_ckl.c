/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            local_ckl.c
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <values.h>
#include <math.h>
#include "alloc.h"
#include "error.h"
#include "party_lib.h"

#ifdef CHACO
#include "chaco.h"
extern int DEBUG_PARAMS;
extern int ECHO;
extern int OUTPUT_METRICS;
extern int OUTPUT_TIME;
extern int PRINT_HEADERS;
extern int FREE_GRAPH;
extern int KL_METRIC;
#define Chaco_seed      7654321

int local_ckl (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, 
	int p, float add_bal, int *part)
{
  int   i, mesh_dim[3], ndims=3, *adjacency, *vwgts=NULL;
  short *part_short;
  float	*ewgts=NULL;

  DEBUG_PARAMS=ECHO=OUTPUT_METRICS=OUTPUT_TIME=PRINT_HEADERS=FREE_GRAPH=KL_METRIC = 0;
  KL_METRIC = 1;
  mesh_dim[0] = p;
  if (p<8)
    ndims--;
  if (p<4)
    ndims--;

  if (add_bal != 0.0)
    printf("LOCAL_CKL WARNING: additional balance not implemented with local_ckl!\n");
  if (p > 8)
  { fprintf(stderr, "LOCAL_CKL ERROR...local_ckl works only for p<=8 and you wanted p=%d!\n",p);
    return 1;
  };

  CALLOC ("LOCAL_CKL",part_short,short,n);
  CALLOC ("LOCAL_CKL",adjacency,int,edge_p[n]);
  if (vertex_w)
    CALLOC ("LOCAL_CKL",vwgts,int,n);
  if (edge_w)
    CALLOC ("LOCAL_CKL",ewgts,float,edge_p[n]);
  for (i=0; i<edge_p[n]; i++)
    adjacency[i] = (edge[i]) + 1;
  if (vertex_w)
  { printf("LOCAL_CKL WARNING: vertex weights in local_ckl transfered to integers!\n");
    for (i=0; i<n; i++)
      vwgts[i] = (int)(vertex_w[i]);
  };
  if (edge_w)
    for (i=0; i<edge_p[n]; i++)
      ewgts[i] = (float)(edge_w[i]);
  for (i=0; i<n; i++)
    part_short[i] = (short)(part[i]);

  if (interface(n,edge_p,adjacency,vwgts,ewgts,NULL,NULL,NULL,
		NULL,NULL,
		part_short,
		1,-1,mesh_dim,NULL,
		7,1,0,0,ndims,0,Chaco_seed))
    FAILED ("LOCAL_CKL", "Chaco interface");

  for (i=0; i<n; i++)
    part[i] = part_short[i];
  FREE(part_short,short,n);
  FREE(adjacency,int,edge_p[n]);
  if (vwgts)
    FREE(vwgts,int,n);
  if (ewgts)
    FREE(ewgts,int,edge_p[n]);
  return 0;
}
#endif
