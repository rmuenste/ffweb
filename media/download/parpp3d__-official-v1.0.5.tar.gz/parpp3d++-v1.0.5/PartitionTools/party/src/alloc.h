/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            alloc.h
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <malloc.h>
#include <time.h>

#ifdef RUSAGE
#include <sys/time.h>
#include <sys/resource.h>
extern struct rusage	Rusage;
#define INIT_TIME()  	{getrusage(RUSAGE_SELF,&Rusage); \
		         t=Rusage.ru_utime.tv_sec*1000+ \
		           Rusage.ru_utime.tv_usec/1000;}
#define ADD_NEW_TIME(T) {T-=t; getrusage(RUSAGE_SELF,&Rusage); \
			 T+=(t=Rusage.ru_utime.tv_sec*1000+ \
			       Rusage.ru_utime.tv_usec/1000);}
#else
#define INIT_TIME()      {t=clock()/1000;}
#define ADD_NEW_TIME(T)  {T-=t; T+=(t=clock()/1000);}
#endif

extern int alloc_memory;
extern int max_memory;

#define CALLOC(P,V,T,N) \
{ if (!((V) = (T*)calloc((unsigned)(N),sizeof(T)))) \
  { fprintf(stderr, P); \
    fprintf(stderr, " ERROR...no memory!\n"); \
    fprintf(stderr, "%d + %d additional memory is too much.\n",alloc_memory,(unsigned)(N) * sizeof(T)); \
    return 1; \
  }; \
  alloc_memory += (unsigned)(N) * sizeof(T); \
  if (alloc_memory > max_memory) \
    max_memory = alloc_memory; \
}

#define FREE(V,T,N) \
{ free((char*)V); \
  alloc_memory -= (unsigned)(N) * sizeof(T); \
}

