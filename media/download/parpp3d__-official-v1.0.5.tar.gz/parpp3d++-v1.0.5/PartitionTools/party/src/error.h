/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            error.h
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#define WARNING(P,T) \
{ fprintf (stderr, P); \
  fprintf (stderr, " WARNING..."); \
  fprintf (stderr, T); \
  fprintf (stderr, "!\n"); \
}

#define ERROR(P,T) \
{ fprintf (stderr, P); \
  fprintf (stderr, " ERROR..."); \
  fprintf (stderr, T); \
  fprintf (stderr, "!\n"); \
  return 1; \
}

#define FAILED(P,T) \
{ fprintf (stderr, P); \
  fprintf (stderr, " ERROR...failed "); \
  fprintf (stderr, T); \
  fprintf (stderr, "!\n"); \
  return 1; \
}

#define EXIT(P,T) \
{ fprintf (stderr, P); \
  fprintf (stderr, " EXIT..."); \
  fprintf (stderr, T); \
  fprintf (stderr, "!\n"); \
  exit (1); \
}
