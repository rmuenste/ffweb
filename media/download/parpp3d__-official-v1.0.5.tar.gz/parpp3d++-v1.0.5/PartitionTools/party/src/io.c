/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            io.c
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <values.h>
#include <stdlib.h>
#include <math.h>
#include "alloc.h"
#include <string.h>
#include "error.h"
#include "party_lib.h"

static int graph_load_grid (int *n, float **x, float **y, 
	int **edge_p, int **edge)
{ int 	i, j, e=4*32*31;

  (*n) = 32*32;
  CALLOC ("GRAPH_LOAD_GRID",*edge_p,int,(*n)+1);
  CALLOC ("GRAPH_LOAD_GRID",*edge,int,e);
  CALLOC ("GRAPH_LOAD_GRID",*x,float,*n);
  CALLOC ("GRAPH_LOAD_GRID",*y,float,*n);

  e = 0;
  (*edge_p)[0] = 0;
  for (i=0; i<32; i++)
    for (j=0; j<32; j++)
    { if (i>0)
        (*edge)[e++] = 32*(i-1)+j;
      if (j>0)
	(*edge)[e++] = 32*i+j-1;
      if (j<31)
	(*edge)[e++] = 32*i+j+1;
      if (i<31)
	(*edge)[e++] = 32*(i+1)+j;
      (*edge_p)[32*i+j+1] = e;
      (*x)[32*i+j] = i;
      (*y)[32*i+j] = j;
    };
  return 0;
}

int graph_load (char *graphfile, char *xyzfile, int *n, float **vertex_w,
	float **x, float **y, float **z, int **edge_p, int **edge, int **edge_w)
{ FILE  *f, *fxyz;                          
  int   i, e, Edge=0, neighbor, code=0;
  char  *s, string[10000];

  if (!strcmp(graphfile,"Grid32x32"))
  { if (graph_load_grid (n,x,y,edge_p,edge))
      FAILED ("GRAPH_LOAD", "graph_load_grid");
    return 0;
  };

  if ( (f = fopen( graphfile, "r" )) == NULL )
  { fprintf(stderr, "GRAPH_LOAD ERROR...not able to read file %s!\n",graphfile);
    return 1;
  };

/* COMMENT LINES */
  if (!(fgets (string, 10000, f)))
  { fprintf(stderr, "GRAPH_LOAD ERROR...failed to read from file %s!\n",graphfile);
    return 1;
  };
  while (string[0] == '%'  ||  string[0] == '#')
    if (!(fgets (string, 10000, f)))
    { fprintf(stderr, "GRAPH_LOAD ERROR...failed to read from file %s!\n",graphfile);
      return 1;
    };

/* HEAD LINE */
  *n = atoi (strtok(string, " \n"));
  s = (char*) strtok((char*)NULL, " \n");
  e = 2 * atoi (s);
  if (s = (char*) strtok((char*)NULL, " \n"))
    code = atoi (s);
	
  CALLOC ("GRAPH_LOAD",*edge_p,int,(*n)+1);
  CALLOC ("GRAPH_LOAD",*edge,int,e);
  if ((code/100)%10 == 1)
  { fprintf(stderr, "GRAPH_LOAD ERROR...the option x1x of the code in the first line is not accepted!\n");
    return 1;
  };
  if ((code/10)%10 == 1)
    CALLOC ("GRAPH_LOAD",*vertex_w,float,*n);
  if (code%10 == 1)
    CALLOC ("GRAPH_LOAD",*edge_w,int,e);

/* n VERTICES LINES */
  for (i=0; i<*n; i++)
  { if (!(fgets (string, 10000, f)))
    { fprintf(stderr, "GRAPH_LOAD ERROR...failed to read from file %s!\n",graphfile);
      return 1;
    };
    s = (char*)strtok (string, " \n");

    /* Read Number of node */
    if ((code/100)%10 == 1)
      s = (char*)strtok ((char*)NULL, " \n");

    /* read weight of a node */
    if ((code/10)%10 == 1)
    { (*vertex_w)[i] = atoi (s);
      s = (char*)strtok ((char*)NULL, " \n");
    };

    /* read edges of a node */ 
    while (s)
    { neighbor = atoi(s);
      s = (char*)strtok ((char*)NULL, " \n");	
      if (neighbor<=0 || neighbor>*n)
      { fprintf(stderr, "GRAPH_LOAD ERROR...neighbor %d of vertex %d is out of range [%d,%d]!\n",neighbor,i+1,1,*n);
        return 1;
      };
      neighbor--;  /* Because base is 1 */
      (*edge)[Edge] = neighbor;
      if (code%10 == 1)
      { (*edge_w)[Edge] = atoi(s);
        s = (char*)strtok ((char*)NULL, " \n");
      }
      Edge++;
    };
    (*edge_p)[i+1] = Edge;   
  };
  if (fclose(f))
    FAILED ("GRAPH_LOAD", "fclose");
  if (Edge != e)
  { fprintf(stderr, "GRAPH_LOAD ERROR...wrong number of %d edges in file...I counted %d directed edges, it should be %d edges in the first line of the file!\n",e/2,Edge,(Edge)/2);
    return 1;
  };

  if (xyzfile)
  { if ((fxyz=fopen(xyzfile,"r")) == NULL)
    { fprintf(stderr, "GRAPH_LOAD ERROR...not able to read file %s!\n",xyzfile);
      return 1;
    };
    if (!(fgets (string, 10000, fxyz)))
    { fprintf(stderr, "GRAPH_LOAD ERROR...failed to read from file %s!\n",graphfile);
      return 1;
    };
    if (s = (char*) strtok(string, " \n"))
    { CALLOC ("GRAPH_LOAD",*x,float,*n); 
      (*x)[0] = atof (s);
      if (s = (char*) strtok((char*)NULL, " \n"))
      { CALLOC ("GRAPH_LOAD",*y,float,*n);
	(*y)[0] = atof (s);
        if (s = (char*) strtok((char*)NULL, " \n"))
	{ CALLOC ("GRAPH_LOAD",*z,float,*n);
	  (*z)[0] = atof(s); 
        };
      };
    };

    for (i=1; i<*n; i++)
    { if (!(fgets (string, 10000, fxyz)))
      { fprintf(stderr, "GRAPH_LOAD ERROR...failed to read from file %s!\n",graphfile);
        return 1;
      };
      if (*x)
	if (s=(char*)strtok(string," \n")) 
	  (*x)[i] = atof (s);
        else
        { fprintf(stderr, "GRAPH_LOAD ERROR...no x coordinate of vertex %d in file %s!\n",i,xyzfile);
  	  return 1;
        };
      if (*y)
        if (s=(char*)strtok((char*)NULL, " \n"))
	  (*y)[i] = atof (s);
        else
        { fprintf(stderr, "GRAPH_LOAD ERROR...no y coordinate of vertex %d in file %s!\n",i,xyzfile);
	  return 1;
        };
      if (*z)
        if (s=(char*)strtok((char*)NULL, " \n"))
	  (*z)[i] = atof(s);
        else
	{ fprintf(stderr, "GRAPH_LOAD ERROR...no z coordinate of vertex %d in file %s!\n",i,xyzfile);
	  return 1;
	};
    };
    if (fclose(fxyz))
      FAILED ("GRAPH_LOAD", "fclose");
  };
  return 0;
}


int graph_save (char *graphfile, char *xyzfile, int n, 
	float *vertex_w, float *x, float *y, float *z,
	int *edge_p, int *edge, int *edge_w)
{ FILE 	*f, *fxyz;                          
  int	i, j;

  if ( (f = fopen( graphfile, "w" )) == NULL )
  { fprintf(stderr,"GRAPH_SAVE ERROR...not able to write file %s!\n",graphfile);
    return 1;
  };
  fprintf(f,"%d %d",n,edge_p[n]/2);
  if (vertex_w || edge_w)
  { fprintf(f," 0");
    if (vertex_w)
      fprintf(f,"1");
    else
      fprintf(f,"0");
    if (edge_w)
      fprintf(f,"1");
    else
      fprintf(f,"0");
  };
  fprintf(f,"\n");
  for (i=0; i<n; i++)
  { if (vertex_w)
      fprintf(f,"%d ",(int)vertex_w[i]);
    for (j=edge_p[i]; j<edge_p[i+1]; j++)
    { fprintf(f,"%d",edge[j]+1);
      if (edge_w)
        fprintf(f,"%d",edge_w[j]);
      if (j<edge_p[i+1]-1)
        fprintf(f," ");
    };
    fprintf(f,"\n");
  };
  if (fclose(f))
    FAILED ("GRAPH_SAVE", "fclose");

  if (x)
  { if ((fxyz=fopen(xyzfile,"w")) == NULL)
    { fprintf(stderr,"GRAPH_SAVE ERROR...not able to write file %s!\n",xyzfile);
      return 1;
    };
    for (i=0; i<n; i++)
    { fprintf(fxyz,"%f",x[i]);
      if (y)
      { fprintf(fxyz," %f",y[i]);
	if (z)
	  fprintf(fxyz," %f",z[i]);
      };
      fprintf(fxyz,"\n");
    };
    if (fclose(fxyz))
      FAILED ("GRAPH_SAVE", "fclose");
  };
  return 0;
}

int graph_free (int n, float *vertex_w, float *x, float *y, float *z,
	int *edge_p, int *edge, int *edge_w)
{ if (x) 
    FREE(x,float,n);
  if (y) 
    FREE(y,float,n);
  if (z) 
    FREE(z,float,n);
  if (vertex_w)
    FREE(vertex_w,float,n);
  if (edge_w)
    FREE(edge_w,int,edge_p[n]);
  FREE(edge,int,edge_p[n]);
  FREE(edge_p,int,n+1);
  return 0;
}

int graph_print (int n, float *vertex_w, float *x, float *y, float *z,
	int *edge_p, int *edge, int *edge_w)
{ int	i;

  printf("n: %d\n",n);
  if (vertex_w)
    for (i=0; i<n; i++)
      printf("vertex_w[%d]: %f\n",i,vertex_w[i]);
  if (x)
    for (i=0; i<n; i++)
      printf("x[%d]: %f\n",i,x[i]);
  if (y)
    for (i=0; i<n; i++)
      printf("y[%d]: %f\n",i,y[i]);
  if (z)
    for (i=0; i<n; i++)
      printf("z[%d]: %f\n",i,z[i]);
  for (i=0; i<=n; i++)
    printf("edge_p[%d]: %d\n",i,edge_p[i]);
  for (i=0; i<edge_p[n]; i++)
    printf("edge[%d]: %d\n",i,edge[i]);
  if (edge_w)
    for (i=0; i<edge_p[n]; i++)
      printf("edge_w[%d]: %d\n",i,edge_w[i]);
  return 0;
}


int part_save (char *partfile, int n, int *part)
{ FILE  *f;
  int   i;

  if ( (f = fopen( partfile, "w" )) == NULL )
    fprintf(stderr, "SAVE_PARTITION_IN_FILE ERROR...not able to write file '%s'\n",partfile);
  else
  { for (i=0; i<n; i++)
      if (fprintf (f,"%d\n", part[i]) == EOF)
        FAILED ("SAVE_PARTITION_IN_FILE", "fprintf");
    if (fclose(f))
      FAILED ("SAVE_PARTITION_IN_FILE", "fclose");
  };
  return 0;
}
