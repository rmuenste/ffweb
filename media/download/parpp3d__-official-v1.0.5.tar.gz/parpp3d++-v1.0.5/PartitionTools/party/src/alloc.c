/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            alloc.c
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "alloc.h"
#include "party_lib.h"

#ifdef RUSAGE
struct rusage	Rusage;
#endif

int alloc_memory = 0;
int max_memory = 0;

void print_alloc_statistics (void)
{
  printf("MEMORY (current/max): %d / %d\n",alloc_memory,max_memory);
}
