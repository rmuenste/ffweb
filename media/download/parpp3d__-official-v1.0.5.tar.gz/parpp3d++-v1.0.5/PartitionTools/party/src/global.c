/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            global.c
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <values.h>
#include <math.h>
#include "alloc.h"
#include "bucket.h"
#include "error.h"
#include "party_lib.h"

#define MAX_CLUSTER_WEIGHT(MCW,N,VW,ADD,P) \
        { MCW = 0.0; \
	  if (VW) \
          { int i; \
            float mvw=0.0; \
            for (i=0; i<N; i++) \
            { MCW += VW[i]; \
              if (VW[i] > mvw) \
                mvw = VW[i]; \
            }; \
            MCW = MCW/P + mvw + ADD; \
          } \
          else \
            MCW = (float)N/P + 1.0 + ADD; \
        }

static int 		cutsize_best;
static int 		solutions;
static float* 		weight;
static int 		*status;
static int 		**lb;
static int		*max_lb;
static BUCKETS  	*B;
static BUCKET_ELE	*bucket_ele;
static int 		N;
static float 		*Vertex_w; 
static int 		*Edge_p;
static int 		*Edge; 
static int 		*Edge_w;
static int 		*Part;
static int 		P;
static int 		OUTPUT;
static void branch (int cut)
{ int	i, j, k, new_cut, vertex, neighbor;

  if (bucket_empty(B))
  { solutions++;
    if (cut < cutsize_best)
    { cutsize_best = cut;
      for (i=0; i<N; i++)
	Part[i] = status[i];
      if (OUTPUT > 1)
        printf("GLOBAL_OPT Cut of solution %4d: %5d\n",solutions,cut);
    }
    else
      if (OUTPUT > 3)
        printf("GLOBAL_OPT Cut of solution %4d: %5d\n",solutions,cut);
  }
  else
  { vertex = (int)(bucket_max_element(B));
    bucket_delete (&(bucket_ele[vertex]));
    for (i=0; i<P; i++)
      if (weight[i] > (Vertex_w?Vertex_w[vertex]:1.0))
      { status[vertex] = i;
	new_cut = cut + max_lb[vertex] - lb[vertex][i];
	if (new_cut<cutsize_best || OUTPUT>2)
	{ for (j=Edge_p[vertex]; j<Edge_p[vertex+1]; j++)
	    if (status[neighbor=Edge[j]]<0)
            { new_cut += (Edge_w?Edge_w[j]:1);
	      lb[neighbor][i] += (Edge_w?Edge_w[j]:1);
	      if (lb[neighbor][i] > max_lb[neighbor])
	      { new_cut += (max_lb[neighbor] - lb[neighbor][i]);
	        max_lb[neighbor] = lb[neighbor][i];
              };
	    };
          if (new_cut<cutsize_best || OUTPUT>2)
  	  { weight[i] -= (Vertex_w?Vertex_w[vertex]:1.0);
	    branch (new_cut);
	    weight[i] += (Vertex_w?Vertex_w[vertex]:1.0);
          };
	  for (j=Edge_p[vertex]; j<Edge_p[vertex+1]; j++)
	    if (status[neighbor=Edge[j]]<0)
	    { if (max_lb[neighbor] == lb[neighbor][i])
	      { lb[neighbor][i] -= (Edge_w?Edge_w[j]:1);
		max_lb[neighbor] = lb[neighbor][0];
	        for (k=1; k<P; k++)
	          if (lb[neighbor][k] > max_lb[neighbor])
	            max_lb[neighbor] = lb[neighbor][k];
              }
	      else
		lb[neighbor][i] -= (Edge_w?Edge_w[j]:1);
	    };
        }; 
      };
    status[vertex] = -1;
    bucket_insert(B, &(bucket_ele[vertex]), 0);
  }
}
int global_opt (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, 
	int p, float add_bal, int *part, int *locked, int Output)
{ int           i, j, neighbor, cut=0; 
  float         max_cluster_weight;
  int           maxdegree=0, degree_weighted;

  if (n > 200)
    fprintf(stderr,"GLOBAL_OPT WARNING...graph with %d vertices is much too large for 'opt', it may take some lifetimes!\n",n);
  else if (n > 50)
    fprintf(stderr,"GLOBAL_OPT WARNING...graph with %d vertices is very large for 'opt', it may take some time!\n",n);

  N = n;
  Vertex_w = vertex_w;
  Edge_p = edge_p;
  Edge = edge;
  Edge_w = edge_w;
  Part = part;
  P = p;
  OUTPUT = Output;

  MAX_CLUSTER_WEIGHT(max_cluster_weight,n,vertex_w,add_bal,p)

  CALLOC ("GLOBAL_OPT",status,int,n);
  CALLOC ("GLOBAL_OPT",weight,float,p);
  CALLOC ("GLOBAL_OPT",max_lb,int,n);
  CALLOC ("GLOBAL_OPT",lb,int*,n);
  CALLOC ("GLOBAL_OPT",bucket_ele,BUCKET_ELE,n);
  for (i=0; i<p; i++)
    weight[i] = max_cluster_weight;

  for (i=0; i<n; i++)
  { status[i] = -1;
    CALLOC ("GLOBAL_OPT",lb[i],int,p);
    bucket_ele[i].element = (void*)i;
    degree_weighted = 0;
    if (edge_w)
    { for (j=edge_p[i]; j<edge_p[i+1]; j++)
	degree_weighted += abs(edge_w[j]);
    }
    else
      degree_weighted = edge_p[i+1]-edge_p[i];
    if (degree_weighted > maxdegree)
      maxdegree = degree_weighted;
  };
  if (bucket_calloc(&B,0,0))
    FAILED ("GLOBAL_OPT", "bucket_calloc");

  solutions = 0;
  if (locked)
  { int locked_vertices = 0;
    for (i=0; i<n; i++)
      if (locked[i] >= 0  &&  locked[i] < p)
      { locked_vertices++;
	status[i] = locked[i];
	weight[locked[i]] -= (vertex_w?vertex_w[i]:1.0);
	cut += (max_lb[i] - lb[i][locked[i]]);
	for (j=Edge_p[i]; j<Edge_p[i+1]; j++)
          if (status[neighbor=Edge[j]]<0)
	  { lb[neighbor][locked[i]] += (Edge_w?Edge_w[j]:1);
	    cut += (Edge_w?Edge_w[j]:1);
	    if (lb[neighbor][locked[i]] > max_lb[neighbor])
	    { cut += (max_lb[neighbor] - lb[neighbor][locked[i]]);
	      max_lb[neighbor] = lb[neighbor][locked[i]];
	    };
	  };
      }
      else
	bucket_insert(B, &(bucket_ele[i]), 0);
    if (Output > 0)
      printf("GLOBAL_OPT...%d locked and %d variable vertices.\n",locked_vertices,n-locked_vertices);
    cutsize_best = MAXINT;
    branch (cut);
  }
  else
  { if (party_lib("all","hs",1,n,vertex_w,NULL,NULL,NULL,edge_p,edge,edge_w,p,add_bal,0,part,&cutsize_best,0))
      FAILED ("GLOBAL_OPT", "party_lib");
    cutsize_best++;
    if (Output > 0)
      printf("GLOBAL_OPT starts with cutsize %d...\n",cutsize_best);
    for (i=0; i<n-1; i++)
      bucket_insert(B, &(bucket_ele[i]), 0);
    status[n-1] = 0;
    weight[0] -= (vertex_w?vertex_w[n-1]:1.0);
    for (j=Edge_p[n-1]; j<Edge_p[n]; j++)
      lb[Edge[j]][0] = max_lb[Edge[j]] = (Edge_w?Edge_w[j]:1);
    branch (0);
  };
  if (solutions == 0)
    ERROR ("GLOBAL_OPT", "no solutions");

  FREE(status,int,n);
  FREE(weight,float,p);
  FREE(max_lb,int,n);
  for (i=0; i<n; i++)
    FREE(lb[i],int,p);
  FREE(lb,int*,n);
  FREE(bucket_ele,BUCKET_ELE,n);
  bucket_free (B);
  if (Output > 0)
    printf ("GLOBAL_OPT...# of Solutions:%d   Best cutsize:%d\n",solutions,cutsize_best);
  return 0;
}

int global_linear (int n, float *vertex_w, int p, float add_bal, int *part)
{ int   i, j=0;
  float vertex_weight, cluster_weight=0.0, max_cluster_weight=0.0;

  MAX_CLUSTER_WEIGHT(max_cluster_weight,n,vertex_w,add_bal,p);

  for (i=0; i<n; i++)
  { vertex_weight = (vertex_w)?vertex_w[i]:1;
    if (cluster_weight + vertex_weight >= max_cluster_weight)
    { j++;
      cluster_weight = 0.0;
    };
    part[i] = j;
    cluster_weight += vertex_weight;
  };
  return 0; 
}

int global_scattered (int n, float *vertex_w, int p, float add_bal, int *part)
{ int     i,  number;
  float   *weight, vertex_weight, max_cluster_weight=0.0;

  CALLOC ("GLOBAL_SCATTERED",weight,float,p);
  MAX_CLUSTER_WEIGHT(max_cluster_weight,n,vertex_w,add_bal,p);

  for (i=0; i<n; i++)
  { number = i%p;
    vertex_weight = (vertex_w)?vertex_w[i]:1;
    while (weight[number]+vertex_weight >= max_cluster_weight)
      number = (number+1)%p;
    part[i] = number;
    weight[number] += vertex_weight;
  };
  FREE(weight,float,p);
  return 0;
}

#define RANDOM_SEED  time ((time_t*)NULL)
static srand_set = 0;

int global_random (int n, float *vertex_w, int p, float add_bal, int *part)
{ int     i, number;
  float   *weight, vertex_weight, max_cluster_weight=0.0;

  CALLOC ("GLOBAL_RANDOM",weight,float,p);
  MAX_CLUSTER_WEIGHT(max_cluster_weight,n,vertex_w,add_bal,p);

  if (!srand_set)
  { srand ((long)RANDOM_SEED);
    srand_set = 1;
  };

  for (i=0; i<n; i++)
  { number = (rand()/10)%p;
    vertex_weight = (vertex_w)?vertex_w[i]:1;
    while (weight[number] + vertex_weight >= max_cluster_weight)
      number = (number+1)%p;
    part[i] = number;
    weight[number] += vertex_weight;
  };
  FREE(weight,float,p);
  return 0;
}

int global_gain (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, int p, float add_bal, int *part)
{ int            i, j, maxdegree=0, degree_weighted, 
                 *diff, vertex;
  float          vertex_weight, cluster_weight=0.0, max_cluster_weight=0.0;
  BUCKETS        *B;
  BUCKET_ELE     *bucket_ele;

  CALLOC ("GLOBAL_GAIN",diff,int,n);
  CALLOC ("GLOBAL_GAIN",bucket_ele,BUCKET_ELE,n);
  MAX_CLUSTER_WEIGHT(max_cluster_weight,n,vertex_w,add_bal,p);

  for (i=0; i<n; i++)
  { part[i] = -1;
    bucket_ele[i].element = (void*)i;
    degree_weighted = 0;
    diff[i] = 0;
    if (edge_w)
    { for (j=edge_p[i]; j<edge_p[i+1]; j++)
      { diff[i] -= edge_w[j];
        degree_weighted += abs(edge_w[j]);
      };
    }
    else
    { diff[i] -= (edge_p[i+1]-edge_p[i]);
      degree_weighted = edge_p[i+1]-edge_p[i];
    };
    if (degree_weighted > maxdegree)
      maxdegree = degree_weighted;
  };
  if (bucket_calloc(&B,-maxdegree, maxdegree))
    FAILED ("GLOBAL_GAIN", "bucket_calloc");
   
  for (i=0; i<n; i++)
    bucket_insert(B, &(bucket_ele[i]), diff[i]);
  
  j=0; 
  while (bucket_not_empty(B))
  { vertex = (int)(bucket_max_element(B));
    bucket_delete (&(bucket_ele[vertex]));
 
    vertex_weight = (vertex_w)?vertex_w[vertex]:1; 
    if (cluster_weight + vertex_weight >= max_cluster_weight)
    { j++;
      cluster_weight = 0.0;
    };
    part[vertex] = j;
    cluster_weight += vertex_weight;
    for (i=edge_p[vertex]; i<edge_p[vertex+1]; i++)
      if (part[edge[i]] == -1)
        bucket_new_key(&(bucket_ele[edge[i]]), diff[edge[i]]+=(2*((edge_w)?edge_w[i]:1)));
  };
  FREE(diff,int,n);
  FREE(bucket_ele,BUCKET_ELE,n);
  bucket_free (B);
  return 0;
}

int global_farhat (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, int p, float add_bal, int *part)
{ int            i, j, k, maxdegree=0, degree_weighted, 
                 *diff, vertex;
  float          cluster_weight=0.0, max_cluster_weight=0.0;
  BUCKETS        *B;
  BUCKET_ELE     *bucket_ele;
  int		 *queue, front_queue=0, end_queue=0;

  CALLOC ("GLOBAL_FARHET",diff,int,n);
  CALLOC ("GLOBAL_FARHET",bucket_ele,BUCKET_ELE,n);
  CALLOC ("GLOBAL_FARHET",queue,int,n);
  MAX_CLUSTER_WEIGHT(max_cluster_weight,n,vertex_w,add_bal,p);

  for (i=0; i<n; i++)
  { part[i] = -1;
    bucket_ele[i].element = (void*)i;
    degree_weighted = 0;
    diff[i] = 0;
    if (edge_w)
    { for (j=edge_p[i]; j<edge_p[i+1]; j++)
      { diff[i] -= edge_w[j];
        degree_weighted += abs(edge_w[j]);
      };
    }
    else
    { diff[i] -= (edge_p[i+1]-edge_p[i]);
      degree_weighted = edge_p[i+1]-edge_p[i];
    };
    if (degree_weighted > maxdegree)
      maxdegree = degree_weighted;
  };
  if (bucket_calloc(&B,-maxdegree, maxdegree))
    FAILED ("GLOBAL_FARHAT", "bucket_calloc");
  for (i=0; i<n; i++)
    bucket_insert(B, &(bucket_ele[i]), diff[i]);

  for (i=0; i<p; i++)
  { cluster_weight = 0.0;
    if (front_queue < end_queue)
    { vertex = queue[front_queue];
      for (j=front_queue+1; j<end_queue; j++)
        if (diff[queue[j]] > diff[vertex])
	  vertex = queue[j];
    }
    else if (bucket_not_empty(B))
      vertex = (int)(bucket_max_element(B));
    else
      vertex = 0;

    front_queue = 0;
    end_queue = 1;
    queue[0] = vertex;
    while (bucket_not_empty(B) && cluster_weight+((vertex_w)?vertex_w[vertex]:1) < max_cluster_weight) 
    { bucket_delete (&(bucket_ele[vertex]));
      part[vertex] = i;
      for (k=edge_p[vertex]; k<edge_p[vertex+1]; k++)
      { if (part[edge[k]] == -1)
	{ queue[end_queue++] = edge[k];
	  part[edge[k]] = -2;
        };
	if (part[edge[k]] == -2)
	  bucket_new_key(&(bucket_ele[edge[k]]), diff[edge[k]]+=((edge_w)?edge_w[k]:1));
      };	  
      cluster_weight += ((vertex_w)?vertex_w[vertex]:1);
      front_queue++;
      if (front_queue < end_queue)
        vertex = queue[front_queue];
      else if (bucket_not_empty(B))
        vertex = (int)(bucket_max_element(B));
    };
    if (bucket_not_empty(B))
      for (j=front_queue; j<end_queue; j++)
        part[queue[j]] = -1;
  };
  FREE(diff,int,n);
  FREE(bucket_ele,BUCKET_ELE,n);
  FREE(queue,int,n);
  bucket_free (B);
  return 0;
}

static float *longest;
static int compare (const int *a, const int *b)
{ if (longest[(*a)] < longest[(*b)])
    return -1;
  else if (longest[(*a)] > longest[(*b)])
    return 1;
  else
    return 0;
}
int global_coordinate (int n, float *vertex_w, float *x, float *y, float *z, int p, float add_bal, int *part)
{ int   i, j, *vertices;
  float max_diff, x_min, x_max, y_min, y_max, z_min, z_max;
  float vertex_weight, cluster_weight=0.0, max_cluster_weight=0.0;

  longest = x;

  MAX_CLUSTER_WEIGHT(max_cluster_weight,n,vertex_w,add_bal,p);

  if (!x)
    ERROR ("GLOBAL_COORDINATE", "no x coordinates");
  CALLOC ("GLOBAL_COORDINATE",vertices,int,n);
  for (i=0; i<n; i++)
    vertices[i] = i;

  x_max = x_min = x[0];
  for (i=1; i<n; i++)
    if (x[i] < x_min)
      x_min = x[i];
    else if (x[i] > x_max)
      x_max = x[i];
  max_diff = x_max - x_min;
  if (y)
  { y_min = y_max = y[0];
    for (i=1; i<n; i++)
      if (y[i] < y_min)
        y_min = y[i];
      else if (y[i] > y_max)
        y_max = y[i];
    if (y_max-y_min > max_diff)
    { longest = y;
      max_diff = y_max-y_min;
    };
  };
  if (z)
  { z_max = z_min = z[0];
    for (i=1; i<n; i++)
      if (z[i] < z_min)
        z_min = z[i];
      else if (z[i] > z_max)
        z_max = z[i];
    if (z_max-z_min > max_diff)
      longest = z;
  };

  qsort (vertices, n, sizeof(int), (int(*)(const void*, const void*))compare);

  j=0;
  for (i=0; i<n; i++)
  { vertex_weight = (vertex_w)?vertex_w[vertices[i]]:1;
    if (cluster_weight + vertex_weight >= max_cluster_weight)
    { j++;
      cluster_weight = 0.0;
    };
    part[vertices[i]] = j;
    cluster_weight += vertex_weight;
  };

  FREE(vertices,int,n);
  return 0;
}

int global_file (int n, char *filename, int p, int *part)
{ int   i;
  FILE  *f;

  if ((f = fopen(filename, "r")) == NULL)
  { fprintf(stderr, "GLOBAL_FILE ERROR...no valid filename %s in global_file.\n", filename);
    return 1;
  }
  for (i=0; i<n; i++)
  { if (fscanf(f, "%d", &(part[i])) == EOF)
    { fprintf(stderr, "GLOBAL_FILE ERROR...Partition file %s is too short!\n", filename);
      return 1;
    }
    else if (part[i] < 0  ||  part[i] >=p)
    { fprintf(stderr, "GLOBAL_FILE ERROR...wrong number %d in partition file %s. Range:[0,%d]\n", part[i],filename,p-1);
      return 1;
    };
  };
  if (fscanf(f, "%d", &i) != EOF)
  { fprintf(stderr, "GLOBAL_FILE ERROR...partition file %s is too long!\n", filename);
    return 1;
  };
  if (fclose(f))
    FAILED ("GLOBAL_FILE", "fclose");
  return 0;
}

#ifdef CHACO
#include "chaco.h"
extern int DEBUG_PARAMS;
extern int ECHO;
extern int OUTPUT_METRICS;
extern int OUTPUT_TIME;
extern int PRINT_HEADERS;
extern int FREE_GRAPH;
extern int WARNING_EVECS;
extern double SRESTOL;
#define Chaco_vmax      500
#define Chaco_eigtol    0.001
#define Chaco_seed      7654321

int global_multilevel (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, int p, float add_bal, int *part)
{ int   i, mesh_dim[3], ndims=3, *adjacency, *vwgts=NULL;
  short *part_short;
  float	*ewgts=NULL;

  DEBUG_PARAMS=ECHO=OUTPUT_METRICS=OUTPUT_TIME=PRINT_HEADERS=FREE_GRAPH = 0;
  WARNING_EVECS = 0;
  SRESTOL = 10.0;
  mesh_dim[0] = p;
  if (p<8)
    ndims--;
  if (p<4)
    ndims--;

  if (add_bal != 0.0)
    WARNING ("GLOBAL_MULTILEVEL", "additional balance not implemented");

  CALLOC ("GLOBAL_MULTILEVEL",part_short,short,n);
  CALLOC ("GLOBAL_MULTILEVEL",adjacency,int,edge_p[n]);
  if (vertex_w)
    CALLOC ("GLOBAL_MULTILEVEL",vwgts,int,n);
  if (edge_w)
    CALLOC ("GLOBAL_MULTILEVEL",ewgts,float,edge_p[n]);
  for (i=0; i<edge_p[n]; i++)
    adjacency[i] = (edge[i]) + 1;
  if (vertex_w)
  { WARNING ("GLOBAL_MULTILEVEL", "vertex weights transfered to integers");
    for (i=0; i<n; i++)
      if ((vwgts[i]=(int)(vertex_w[i])) == 0)
      { WARNING("GLOBAL_MULTILEVEL", "vertex weight set from 0 to 1");
	vwgts[i]=1;
      };
  };
  if (edge_w)
    for (i=0; i<edge_p[n]; i++)
      ewgts[i] = (float)(edge_w[i]);

  if (interface(n,edge_p,adjacency,vwgts,ewgts,NULL,NULL,NULL,
		NULL,NULL,
		part_short,
		1,-1,mesh_dim,NULL,
		1,2,1,Chaco_vmax,ndims,Chaco_eigtol,Chaco_seed))
    FAILED ("GLOBAL_MULTILEVEL", "Chaco interface");

  for (i=0; i<n; i++)
    part[i] = part_short[i];
  FREE(part_short,short,n);
  FREE(adjacency,int,edge_p[n]);
  if (vwgts) 
    FREE(vwgts,int,n);
  if (ewgts)
    FREE(ewgts,int,edge_p[n]);
  return 0;
}

int global_spectral_m (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, int p, float add_bal, int *part)
{ int   i, mesh_dim[3], ndims=3, *adjacency, *vwgts=NULL;
  short *part_short;
  float *ewgts=NULL;

  DEBUG_PARAMS=ECHO=OUTPUT_METRICS=OUTPUT_TIME=PRINT_HEADERS=FREE_GRAPH = 0;
  WARNING_EVECS = 0;
  SRESTOL = 10.0;
  mesh_dim[0] = p;
  if (p<8)
    ndims--;
  if (p<4)
    ndims--;

  if (add_bal != 0.0)
    WARNING ("GLOBAL_SPECTRAL_M", "additional balance not implemented");

  CALLOC ("GLOBAL_SPECTRAL_M",part_short,short,n);
  CALLOC ("GLOBAL_SPECTRAL_M",adjacency,int,edge_p[n]);
  if (vertex_w)
    CALLOC ("GLOBAL_SPECTRAL_M",vwgts,int,n);
  if (edge_w)
    CALLOC ("GLOBAL_SPECTRAL_M",ewgts,float,edge_p[n]);
  for (i=0; i<edge_p[n]; i++)
    adjacency[i] = edge[i] + 1;
  if (vertex_w)
  { WARNING ("GLOBAL_SPECTRAL_M", "vertex weights transfered to integers");
    for (i=0; i<n; i++)
      if ((vwgts[i]=(int)(vertex_w[i])) == 0)
      { WARNING("GLOBAL_SPECTRAL_M", "vertex weight set from 0 to 1");
	vwgts[i]=1;
      };
  };
  if (edge_w)
    for (i=0; i<edge_p[n]; i++)
      ewgts[i] = (float)(edge_w[i]);

  if (interface(n,edge_p,adjacency,vwgts,ewgts,NULL,NULL,NULL,
		NULL,NULL,
		part_short,
		1,-1,mesh_dim,NULL,
		2,2,1,Chaco_vmax,ndims,Chaco_eigtol,Chaco_seed))
    FAILED ("GLOBAL_SPECTRAL_M", "Chaco interface");

  for (i=0; i<n; i++)
    part[i] = part_short[i];
  FREE(part_short,short,n);
  FREE(adjacency,int,edge_p[n]);
  if (vwgts)
    FREE(vwgts,int,n);
  if (ewgts)
    FREE(ewgts,int,edge_p[n]);
  return 0;
}

int global_spectral_l (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, int p, float add_bal, int *part)
{ int   i, mesh_dim[3], ndims=3, *adjacency, *vwgts=NULL;
  short *part_short;
  float *ewgts=NULL;

  DEBUG_PARAMS=ECHO=OUTPUT_METRICS=OUTPUT_TIME=PRINT_HEADERS=FREE_GRAPH = 0;
  WARNING_EVECS = 0;
  SRESTOL = 10.0;
  mesh_dim[0] = p;
  if (p<8)
    ndims--;
  if (p<4)
    ndims--;

  if (add_bal != 0.0)
    WARNING ("GLOBAL_SPECTRAL_L", "additional balance not implemented");

  CALLOC ("GLOBAL_SPECTRAL_L",part_short,short,n);
  CALLOC ("GLOBAL_SPECTRAL_L",adjacency,int,edge_p[n]);
  if (vertex_w)
    CALLOC ("GLOBAL_SPECTRAL_L",vwgts,int,n);
  if (edge_w)
    CALLOC ("GLOBAL_SPECTRAL_L",ewgts,float,edge_p[n]);
  for (i=0; i<edge_p[n]; i++)
    adjacency[i] = edge[i] + 1;
  if (vertex_w)
  { WARNING ("GLOBAL_SPECTRAL_L", "vertex weights transfered to integers");
    for (i=0; i<n; i++)
      if ((vwgts[i]=(int)(vertex_w[i])) == 0)
      { WARNING("GLOBAL_SPECTRAL_L", "vertex weight set from 0 to 1");
	vwgts[i]=1;
      };
  };
  if (edge_w)
    for (i=0; i<edge_p[n]; i++)
      ewgts[i] = (float)(edge_w[i]);

  if (interface(n,edge_p,adjacency,vwgts,ewgts,NULL,NULL,NULL,
		NULL,NULL,
		part_short,
		1,-1,mesh_dim,NULL,
		2,2,0,Chaco_vmax,ndims,Chaco_eigtol,Chaco_seed))
    FAILED ("GLOBAL_MULTILEVEL", "Chaco interface");

  for (i=0; i<n; i++)
    part[i] = part_short[i];
  FREE(part_short,short,n);
  FREE(adjacency,int,edge_p[n]);
  if (vwgts)
    FREE(vwgts,int,n);
  if (ewgts)
    FREE(ewgts,int,edge_p[n]);
  return 0;
}

int global_inertial (int n, float *vertex_w, float *x, float *y, float *z, int p, float add_bal, int *part)
{ int   i, mesh_dim[3], ndims=3,*vwgts=NULL;
  short *part_short;

  DEBUG_PARAMS=ECHO=OUTPUT_METRICS=OUTPUT_TIME=PRINT_HEADERS=FREE_GRAPH = 0;
  WARNING_EVECS = 0;
  SRESTOL = 10.0;
  mesh_dim[0] = p;
  if (p<8)
    ndims--;
  if (p<4)
    ndims--;

  if (add_bal != 0.0)
    WARNING ("GLOBAL_INERTIAL", "additional balance not implemented");

  if (!x)
    ERROR ("GLOBAL_INERTIAL", "no x coordinates");
  CALLOC ("GLOBAL_INERTIAL",part_short,short,n);
  if (vertex_w)
    CALLOC ("GLOBAL_INERTIAL",vwgts,int,n);
  if (vertex_w)
  { WARNING ("GLOBAL_INERTIAL", "vertex weights transfered to integers");
    for (i=0; i<n; i++)
      if ((vwgts[i]=(int)(vertex_w[i])) == 0)
      { WARNING("GLOBAL_INERTIAL", "vertex weight set from 0 to 1");
	vwgts[i]=1;
      };
  };

  if (interface(n,NULL,NULL,vwgts,NULL,x,y,z,
	        NULL,NULL,
	        part_short,
	        1,-1,mesh_dim,NULL,
	        3,2,-1,-1,ndims,-1,Chaco_seed))
    FAILED ("GLOBAL_INERTIAL", "Chaco interface");

  for (i=0; i<n; i++)
    part[i] = part_short[i];
  FREE(part_short,short,n);
  if (vwgts)
    FREE(vwgts,int,n);
  return 0;
}
#endif
