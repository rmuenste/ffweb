/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            party_lib.c
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <values.h>
#include <math.h>
#include <string.h>
#include "error.h"
#include "alloc.h"
#include "party_lib.h"

static long    	t=0;
static long	t_global=0, 
	       	t_local=0, 
	       	t_part_rest=0; 

void party_lib_times_start (void)
{ void hs_times_start ();
  void kl_times_start ();

  hs_times_start ();
  kl_times_start ();
  t_global = t_local = t_part_rest = 0;
}

void party_lib_times_output (int Times)
{ void hs_times_output ();
  void kl_times_output ();

  if (Times > 0)
  { printf("    Global            : %.2f\n",((float)t_global)/1000);
    printf("    Local             : %.2f\n",((float)t_local)/1000);
    if (Times > 1)
    { hs_times_output();
      kl_times_output();
    };
    printf("    Part-rest         : %.2f\n",((float)t_part_rest)/1000);
  };
}

int party_lib (char *Global, char *Local, int runs, int n, float *vertex_w, 
	float *x, float *y, float *z, int *edge_p, int *edge, int *edge_w, 
	int p, float add_bal, int recursive, int *part, int *cutsize, 
	int Output)
{ int   run, cut_new, parts, *part_new, error=0;
  char  globals[100], *globals_left, global[100];

  INIT_TIME();
  if (Output < -100)
  { printf(VERSION);
    puts("\nCopyright by Robert Preis (preis@hni.uni-paderborn.de)");
  };
  if (Output > 0)
  { printf("PARTY_LIB START %s-%s-%d on n=%d and e=%d in %d parts...\n", Global,Local,runs,n,edge_p[n],p);
    if (graph_check_and_info(n,vertex_w,x,y,z,edge_p,edge,edge_w,Output-1))
      FAILED ("PARTY_LIB", "graph_check");
  };
  if (!part)
    ERROR ("PARTY_LIB", "'part' parameter is NULL! You have to allocate memory for 'part' before calling 'party_lib()' in this new version");
  if (p <= 0)
  { fprintf(stderr, "PARTY_LIB ERROR...p=%d too small!\n",p);
    return 1;
  }
  else if (p == 1)
  { int i;
    for (i=0; i<n; i++)
      part[i] = 0;
    (*cutsize) = 0;
    return 0;
  }
  else if (p > n)
    fprintf(stderr, "PARTY WARNING...p=%d larger than n=%d!\n",p,n);
  if (recursive)
  { if (p != (1<<((int)(log((double)p + 0.1)/log((double)2)))))
    { fprintf(stderr, "PARTY_LIB WARNING...p has to be a^2 in the recursive mode. I set it from %d to %d\n",p,(1<<((int)(log((double)p + 0.1)/log((double)2)))));
       p = 1 << ((int)(log((double)p + 0.1)/log((double)2)));
    };
    if (p == 1)
      parts = 1;
    else
      parts = 2;
  }
  else 
    parts = p;
   
  CALLOC("PARTY_LIB",part_new,int,n);
  (*cutsize) = MAXINT;

  if (!strncmp(Global,"all",3))
  {
#ifdef CHACO
    if (x)
      sprintf(globals,"lin,sca,ran,gai,far,coo,mul,spm,spl,ine");
    else
      sprintf(globals,"lin,sca,ran,gai,far,mul,spm,spl");
#else
    if (x)
      sprintf(globals,"lin,sca,ran,gai,far,coo");
    else
      sprintf(globals,"lin,sca,ran,gai,far");
#endif
    if ((int)strlen(Global) > 3)
      printf("PARTY_LIB WARNING...'all' can not be used in a sequenz of global methods, e.g. the rest '%s' is ignored!\n",Global+3);
  }
  else
    sprintf(globals,"%s",Global);

  globals_left = globals;

  while (globals_left)
  { sprintf(global,"%s",globals);
    strncpy (global, globals_left, strcspn(globals_left,","));
    global[strcspn(globals_left,",")] = 0;
    globals_left = strpbrk (globals_left, ",");
    if (globals_left)
      globals_left++;

    for (run=0; run<runs; run++)
    { ADD_NEW_TIME(t_part_rest);
      if (!strcmp(global, "opt"))
	error = global_opt       (n,vertex_w,edge_p,edge,edge_w,parts,add_bal,part_new,NULL,Output);
      else if (!strcmp(global, "lin"))    
        error = global_linear    (n,vertex_w,parts,add_bal,part_new);
      else if (!strcmp(global, "sca"))
        error = global_scattered (n,vertex_w,parts,add_bal,part_new);
      else if (!strcmp(global, "ran"))
        error = global_random    (n,vertex_w,parts,add_bal,part_new);
      else if (!strcmp(global, "gai"))
        error = global_gain      (n,vertex_w,edge_p,edge,edge_w,parts,add_bal,part_new);
      else if (!strcmp(global, "far"))
        error = global_farhat    (n,vertex_w,edge_p,edge,edge_w,parts,add_bal,part_new);
      else if (!strcmp(global, "coo"))
        error = global_coordinate(n,vertex_w,x,y,z,parts,add_bal,part_new);
#ifdef CHACO
      else if (!strcmp(global, "mul"))
        error = global_multilevel(n,vertex_w,edge_p,edge,edge_w,parts,add_bal,part_new);
      else if (!strcmp(global, "spm"))
        error = global_spectral_m(n,vertex_w,edge_p,edge,edge_w,parts,add_bal,part_new);
      else if (!strcmp(global, "spl"))
        error = global_spectral_l(n,vertex_w,edge_p,edge,edge_w,parts,add_bal,part_new);
      else if (!strcmp(global, "ine"))
        error = global_inertial  (n,vertex_w,x,y,z,parts,add_bal,part_new);
#endif
      else if (!strcmp(global, "part"))
      { int i;
	for (i=0; i<n; i++)
	  part_new[i] = part[i];
      }
      else 
        error = global_file      (n,global,parts,part_new);
      if (error)
      { fprintf(stderr,"PARTY_LIB ERROR...failed global %s\n", global);
        return 1;
      };
      ADD_NEW_TIME(t_global);

      if (Output > 1)
        printf("PARTY_LIB global %s to cutsize %5d \n",global, cut_size(n,edge_p,edge,edge_w,part_new));
      ADD_NEW_TIME(t_part_rest);
      
      if (!strcmp(Local,"kl"))
        error = local_kl(n,vertex_w,edge_p,edge,edge_w,parts,add_bal,part_new,Output-3);
      else if (!strcmp(Local,"hs"))
        error = local_hs(n,vertex_w,edge_p,edge,edge_w,parts,add_bal,part_new,Output-3);
#ifdef CHACO
      else if (!strcmp(Local,"ckl"))
	error = local_ckl(n,vertex_w,edge_p,edge,edge_w,parts,add_bal,part_new);
#endif
      else if (strcmp(Local,"no"))
      { fprintf(stderr,"PARTY_LIB ERROR...unknown local method '%s'\n", Local);
        return 1;
      };
      if (error)
      { fprintf(stderr,"PARTY_LIB ERROR...failed %s\n", Local);
        return 1;
      };
      ADD_NEW_TIME(t_local);
     
      cut_new=cut_size(n,edge_p,edge,edge_w,part_new);
      if (Output > 1)
        printf("PARTY_LIB local  %5s to cutsize %6d \n",Local, cut_new);

      if (cut_new < (*cutsize))
      { int i;
        for (i=0; i<n; i++)
  	  part[i] = part_new[i];
        (*cutsize) = cut_new;
      };
    };
  };
  FREE (part_new,int,n);

  if (recursive  &&  p>2)
  { int 	i, j, n0=0, n1=0, e0=0, e1=0, cutsize0, cutsize1, *changes,
		*edge_p0=NULL, *edge_p1=NULL, *edge0=NULL, *edge1=NULL, 
		*edge_w0=NULL, *edge_w1=NULL, *part0=NULL, *part1=NULL;
    float	*vertex_w0=NULL, *vertex_w1=NULL, *x0=NULL, *x1=NULL, 
		*y0=NULL, *y1=NULL, *z0=NULL, *z1=NULL;

    for (i=0; i<n; i++)
      if (part[i]==0)
      { n0++;
        for (j=edge_p[i]; j<edge_p[i+1]; j++)
	  if (part[edge[j]] == 0)
	    e0++;
      }
      else
      { n1++;
	for (j=edge_p[i]; j<edge_p[i+1]; j++)
	  if (part[edge[j]] == 1)
	    e1++;
      };

    if (vertex_w)
    { CALLOC("PARTY_LIB",vertex_w0,float,n0);
      CALLOC("PARTY_LIB",vertex_w1,float,n1);
    };
    if (x)
    { CALLOC("PARTY_LIB",x0,float,n0);
      CALLOC("PARTY_LIB",x1,float,n1);
    };
    if (y)
    { CALLOC("PARTY_LIB",y0,float,n0);
      CALLOC("PARTY_LIB",y1,float,n1);
    };
    if (z)
    { CALLOC("PARTY_LIB",z0,float,n0);
      CALLOC("PARTY_LIB",z1,float,n1);
    };
    CALLOC("PARTY_LIB",edge_p0,int,n0+1);
    CALLOC("PARTY_LIB",edge_p1,int,n1+1);
    CALLOC("PARTY_LIB",edge0,int,e0);
    CALLOC("PARTY_LIB",edge1,int,e1);
    CALLOC("PARTY_LIB",part0,int,n0);
    CALLOC("PARTY_LIB",part1,int,n1);
    CALLOC("PARTY_LIB",changes,int,n);
    if (edge_w)
    { CALLOC("PARTY_LIB",edge_w0,int,e0);
      CALLOC("PARTY_LIB",edge_w1,int,e1);
    };
	      
    n0 = n1 = e0 = e1 = 0;
    for (i=0; i<n; i++)
    { if (part[i] == 0)
      { changes[i] = n0;
        if (vertex_w)
	  vertex_w0[n0] = vertex_w[i];
        if (x)
	  x0[n0] = x[i];
        if (y)
	  y0[n0] = y[i];
        if (z)
	  z0[n0] = z[i];
        for (j=edge_p[i]; j<edge_p[i+1]; j++)
          if (part[edge[j]]==0)
	  { if (edge_w)
	      edge_w0[e0] = edge_w[j];
	    edge0[e0++] = edge[j];
	  };
        n0++;
	edge_p0[n0] = e0;
      }
      else
      { changes[i] = n1;
        if (vertex_w)
	  vertex_w1[n1] = vertex_w[i];
        if (x)
	  x1[n1] = x[i];
	if (y)
	  y1[n1] = y[i];
        if (z)
	  z1[n1] = z[i];
	for (j=edge_p[i]; j<edge_p[i+1]; j++)
	  if (part[edge[j]]==1)
	  { if (edge_w)
	      edge_w1[e1] = edge_w[j];
	    edge1[e1++] = edge[j];
          };
        n1++;
	edge_p1[n1] = e1;
      };
    };
    for (i=0; i<e0; i++)
      edge0[i] = changes[edge0[i]];
    for (i=0; i<e1; i++)
      edge1[i] = changes[edge1[i]];

    if (party_lib(Global,Local,runs,n0,vertex_w0,x0,y0,z0,edge_p0,edge0,
	edge_w0,p/2,add_bal,recursive,part0,&cutsize0,Output))
      FAILED ("PARTY_LIB", "party_lib");
    if (party_lib(Global,Local,runs,n1,vertex_w1,x1,y1,z1,edge_p1,edge1,
	edge_w1,p/2,add_bal,recursive,part1,&cutsize1,Output))
      FAILED ("PARTY_LIB", "party_lib");

    for (i=0; i<n; i++)
    { if (part[i] == 0)
        part[i] = part0[changes[i]];
      else
	part[i] = p/2 + part1[changes[i]];
    };
    (*cutsize) += cutsize0 + cutsize1; 

    if (vertex_w)
    { FREE(vertex_w0,float,n0);
      FREE(vertex_w1,float,n1);
    };
    if (x)
    { FREE(x0,float,n0);
      FREE(x1,float,n1);
    };
    if (y)
    { FREE(y0,float,n0);
      FREE(y1,float,n1);
    };
    if (z)
    { FREE(z0,float,n0);
      FREE(z1,float,n1);
    };
    FREE(edge_p0,int,n0+1);
    FREE(edge_p1,int,n1+1);
    FREE(edge0,int,e0);
    FREE(edge1,int,e1);
    if (edge_w)
    { FREE(edge_w0,int,e0);
      FREE(edge_w1,int,e1);
    };
    FREE(part0,int,n0);
    FREE(part1,int,n1);
    FREE(changes,int,n);
  };

  if (Output > 0)
  { if (part_check(n,vertex_w,p,add_bal,recursive,part,Output-1))
      FAILED ("PARTY_LIB", "part_check");
    printf("PARTY_LIB END   %s-%s-%d on n=%d and e=%d in %d parts...\n", Global,Local,runs,n,edge_p[n],p);
  };
  ADD_NEW_TIME(t_part_rest);
  return 0;
}
