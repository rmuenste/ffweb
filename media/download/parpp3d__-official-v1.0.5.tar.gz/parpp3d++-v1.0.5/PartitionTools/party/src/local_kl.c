/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            local_kl.c
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <values.h>
#include <math.h>
#include "alloc.h"
#include "bucket.h"
#include "vertex.h"
#include "error.h"
#include "party_lib.h"

#define MAX(A,B)         (((A)>(B))?(A):(B))
#define KL_BAD_STEPS   (total_weight/4) /* Allowed steps without improvement */

static long    	t=0;
static long	t_pre=0,
               	t_comb=0,
               	t_bip_pre=0,
               	t_bip_past=0,
               	t_bip_pure=0,
               	t_post=0;

void kl_times_start (void)
{
  t_pre=t_comb=t_bip_pre=t_bip_past=t_bip_pure=t_post=0;
}

void kl_times_output (void)
{ if(t_pre||t_comb||t_bip_pre||t_bip_pure||t_bip_past||t_post)
  { printf("      KL pre            : %.2f\n",((float)t_pre )/1000);
    printf("      KL comb           : %.2f\n",((float)t_comb)/1000);
    printf("      KL bip pre        : %.2f\n",((float)t_bip_pre )/1000);
    printf("      KL bip pure       : %.2f\n",((float)t_bip_pure )/1000);
    printf("      KL bip past       : %.2f\n",((float)t_bip_past)/1000);
    printf("      KL post           : %.2f\n",((float)t_post)/1000);
  }
}

static int kl_direct (float total_weight, int p, VERTEX *V0, VERTEX *V1, VERTEX **cluster_list, BUCKETS **B, float max_cluster_weight, int Output)
{ float         no_better_steps,
                max_weight_a, max_weight_b, weight_0, weight_1;
  int           i, cutsize=0, akt_cutsize, best_cost, step;
  VERTEX      	*vertex, *V[2], *v[2], *locked_list, *best_change;

  V[0] = V0;
  V[1] = V1;

  for (i=0; i<p; i++)
  { FOR_ALL_VERTICES (SET(V[i]), vertex,
    { H(vertex) = 0;
      FOR_ALL_NEIGHBORS_W (vertex, neighbor, weight,
      { if (PART(neighbor) == PART(V[i]))
          H(vertex) -= weight;
        else if (PART(neighbor) == PART(V[i^1]))
        { H(vertex) += weight;
          cutsize += weight;
        };
      });
      bucket_insert(B[i], BE(vertex), H(vertex));
    });
  };
  cutsize = cutsize/2;

  ADD_NEW_TIME(t_bip_pre);
  if (Output > 1)
    printf("KL start on %d and %d...  balance is %8.2f and cutsize %d\n",PART(V[0]), PART(V[1]),W(V0)-W(V1),cutsize);

  best_cost = cutsize;
  do 
  { step = 0;
    no_better_steps = 0.0;
    akt_cutsize = cutsize = best_cost;
    locked_list = best_change = NULL;
    weight_0 = W(V0);
    weight_1 = W(V1);
    if (Output > 3)
      puts ("STEP VERTEX BALANCE CHANGE CUTSIZE");

    while (bucket_not_empty(B[0])  &&  bucket_not_empty(B[1])  &&  no_better_steps < KL_BAD_STEPS)
    { step++;
      v[0] = BUCKET_MAX(B[0]);
      v[1] = BUCKET_MAX(B[1]);
      max_weight_a = MAX(weight_0-W(v[0]),weight_1+W(v[0]));
      max_weight_b = MAX(weight_0+W(v[1]),weight_1-W(v[1]));
      if (max_weight_a >= max_cluster_weight)
        if (max_weight_b >= max_cluster_weight)
	  if (H(v[0])>H(v[1]) || (H(v[0])==H(v[1]) && max_weight_a<=max_weight_b))
	    vertex = v[0];
          else 
	    vertex = v[1];
	else
	  vertex = v[1];
      else if (max_weight_b >= max_cluster_weight)
	vertex = v[0];
      else
        if (H(v[0])>H(v[1]) || (H(v[0])==H(v[1]) && max_weight_a<=max_weight_b))
	  vertex = v[0];
        else 
	  vertex = v[1];
      bucket_delete (BE(vertex));

      no_better_steps += W(vertex);

      NEXT(vertex) = locked_list;
      locked_list = vertex;
      LOCKED(vertex) = 1;
      if (PART(vertex) == PART(V[0]))
      { PART(vertex) = PART(V[1]);
        weight_0 -= W(vertex);
        weight_1 += W(vertex);
      }
      else
      { PART(vertex) = PART(V[0]);
        weight_0 += W(vertex);
	weight_1 -= W(vertex);
      };
         
      H(vertex) *= -1; 
      akt_cutsize += H(vertex);	            	

      FOR_ALL_NEIGHBORS_W( vertex, neighbor, weight,
      { if ((PART(neighbor)==PART(V[0]) || PART(neighbor)==PART(V[1])) && !(LOCKED(neighbor)))
          bucket_new_key( BE(neighbor), H(neighbor) += ((PART(neighbor)!=PART(vertex))?2*weight:-2*weight));
      });

      if (akt_cutsize<best_cost && weight_0<max_cluster_weight && weight_1<max_cluster_weight) 
      { best_change = locked_list;
        best_cost = akt_cutsize;
        if (Output > 3)
	  printf ("New best cutsize : %d\n",best_cost);
        no_better_steps = 0.0;
      };

      if (Output > 3)
        printf ("%3d  %4d    %+4.2f %5d   %5d\n", step, (int)vertex, weight_0-weight_1, akt_cutsize-cutsize,akt_cutsize); 
    };

    while (locked_list != best_change)
    { vertex = locked_list;
      locked_list = NEXT(locked_list);
      H(vertex) *= -1;
      LOCKED(vertex) = 0;
      if (PART(vertex) == PART(V[0]))
        PART(vertex) = PART(V[1]);
      else
        PART(vertex) = PART(V[0]);
      FOR_ALL_NEIGHBORS_W( vertex, neighbor, weight,
      { if ((PART(neighbor)==PART(V[0]) || PART(neighbor)==PART(V[1])) && !(LOCKED(neighbor)))
          bucket_new_key(BE(neighbor), H(neighbor) += ((PART(neighbor)!=PART(vertex))?2*weight:-2*weight));
      });
      if (PART(vertex) == PART(V[0]))
        bucket_insert (B[0], BE(vertex), H(vertex));
      else
        bucket_insert (B[1], BE(vertex), H(vertex));
    };
    while (locked_list)
    { vertex = locked_list;
      locked_list = NEXT(locked_list);
      LOCKED(vertex) = 0;
      FOR_ALL_NEIGHBORS_W( vertex, neighbor, weight,
      { if ((PART(neighbor)==PART(V[0]) || PART(neighbor)==PART(V[1])) && LOCKED(neighbor))
          H(neighbor) += ((PART(vertex)!=PART(neighbor))?2*weight:-2*weight);
      });
      if (PART(vertex) == PART(V[0]))
      { W(V0) += W(vertex);
        W(V1) -= W(vertex);
        bucket_insert (B[0], BE(vertex), H(vertex));
      }
      else
      { W(V1) += W(vertex);
        W(V0) -= W(vertex);
        bucket_insert (B[1], BE(vertex), H(vertex));
      };
    };

    if (Output > 2)
      printf ("New Cutsize         : %d\n", best_cost);
  } while (best_cost < cutsize);
 
  if (Output > 1)
    printf("KL end   on %d and %d...  balance is %8.2f and cutsize %d\n",PART(V[0]), PART(V[1]),W(V0)-W(V1),cutsize);
  ADD_NEW_TIME(t_bip_pure);

  for (i=0; i<2; i++)
  { W(V[i]) = 0.0;
    SET(V[i]) = NULL;
    while (bucket_not_empty(B[i]))
    { vertex = BUCKET_MAX(B[i]);
      bucket_delete (BE(vertex));
      FRONT_NEXT(vertex, SET(V[i]));
      if (SET(vertex) != V[i])
        change_cluster_edge (vertex, V[0], V[i], cluster_list);
      W(V[i]) += W(vertex);
    };
  };
  return 0;
}

int local_kl (int n, float *vertex_w, int *edge_p, int *edge, 
	int *edge_w, int p, float add_bal, int *part, int Output)
{ int            i, j, degree_weigted, maxdegree=0;
  float          total_weight=0.0, max_cluster_weight, max_vertex_weight=1.0;
  VERTEX         *vertices, *vertex, **neighbors,
                 *cluster, *cluster_list=NULL;
  BUCKET_ELE     *bucket_element;
  BUCKETS        *B[2];

  INIT_TIME();

  CALLOC ("LOCAL_KL",vertices,VERTEX,n);
  CALLOC ("LOCAL_KL",neighbors,VERTEX*,edge_p[n]);
  CALLOC ("LOCAL_KL",cluster,VERTEX,p);
  CALLOC ("LOCAL_KL",bucket_element,BUCKET_ELE,n);

  if (vertex_w)
  { max_vertex_weight = 0.0;
    for (i=0; i<n; i++)
    { total_weight += vertex_w[i];
      if (vertex_w[i] > max_vertex_weight)
        max_vertex_weight = vertex_w[i];
    };
    max_cluster_weight = total_weight/p + max_vertex_weight + add_bal;
  }
  else
    max_cluster_weight = (total_weight=n)/p + 1.0 + add_bal;

  for (i=0; i<p; i++)
  { vertex = &(cluster[i]);
    W(vertex) = 0.0;
    SET(vertex) = NULL;
    PART(vertex) = PART(vertex) = i;
    CALLOC ("LOCAL_KL",NEIG(vertex),VERTEX*,p-1);
    CALLOC ("LOCAL_KL",NW(vertex),int,p-1);
    FRONT_NEXT(vertex, cluster_list);
  };

  for (i=0; i<n; i++)
  { vertex = &(vertices[i]);
    BE(vertex) = &(bucket_element[i]);
    bucket_element[i].element = (void*)vertex;
    
    DEGREE(vertex) = edge_p[i+1] - edge_p[i];
    W(vertex) = (vertex_w)?vertex_w[i]:1.0;
   
    if (part[i]<0 || part[i]>=p)
    { fprintf(stderr, "LOCAL_KL ERROR...part[%d]=%d not in range 0..%d!\n",i,part[i],p-1);
      return 1;
    };
    j = part[i];

    cluster[j].part = part[i];
    PART(vertex) = part[i];
    FRONT_NEXT(vertex, cluster[j].set);
    SET(vertex) = &(cluster[j]);
    cluster[j].weight += W(vertex);

    NEIG(vertex) = &(neighbors[edge_p[i]]);
    NW(vertex) = (edge_w)?&(edge_w[edge_p[i]]):NULL;
    LOCKED(vertex) = 0;
    degree_weigted = 0;
    for (j=edge_p[i]; j<edge_p[i+1]; j++)
    { neighbors[j] = &(vertices[edge[j]]);
      degree_weigted += ((edge_w)?abs(edge_w[j]):1);
    };
    if (degree_weigted > maxdegree)
      maxdegree = degree_weigted;
  };
  if (bucket_calloc(&(B[0]),-maxdegree, maxdegree)  ||
      bucket_calloc(&(B[1]),-maxdegree, maxdegree)  )
    FAILED ("LOCAL_KL", "bucket_calloc");

  if (Output > 1)
  { printf("KL Cluster-sizes:");
    for (i=0; i<p; i++)
      printf(" %d:%.3f",cluster[i].part, cluster[i].weight);
    puts("");
  };

  construct_cluster_edges (cluster, p);

  for (i=0; i<p; i++)
    if (cluster[i].weight >= max_cluster_weight)
    { balance_cluster (&(cluster[i]), cluster, max_cluster_weight, max_vertex_weight, p, B[0],Output);
      printf("graph with %d vertices saved in 'error'\n",n);
      if(graph_save("error",NULL,n,vertex_w,NULL,NULL,NULL,edge_p,edge,edge_w))
        FAILED ("LOCAL_KL", "graph_save");
      printf("New cutsize is %d\n",cut(cluster,p));
    };
		      
  ADD_NEW_TIME(t_pre);
  if (Output > 0)
  { float max_weight = 0.0;
    for (i=0; i<p; i++)
      if (cluster[i].weight > max_weight)
        max_weight = cluster[i].weight;
    printf("KL START... max. weight: %.3f (%.3f)  cutsize: %3d\n", max_weight, max_cluster_weight, cut(cluster,p));
  };

  while (cluster_list)
  { vertex = cluster_list;
    cluster_list = NEXT(cluster_list);
    while (DEGREE(vertex) > 0)
    { ADD_NEW_TIME(t_comb);
      DEGREE(vertex) --;
      if (kl_direct(total_weight,2,vertex,NEIG(vertex)[DEGREE(vertex)],&cluster_list,B,max_cluster_weight,Output))
	FAILED ("LOCAL_KL", "kl_direct");
      ADD_NEW_TIME(t_bip_past);
    };
    if (Output > 2)
    { printf("CL: ");
      FOR_ALL_VERTICES(cluster_list,ver,
      { printf(" %d:", PART(ver));
        FOR_ALL_NEIGHBORS(ver, neighbor,
        { printf("%d,",PART(neighbor));
        });
      });
      puts("");
    };
  };
  ADD_NEW_TIME(t_comb);

  for (i=0; i<n; i++)
    part[i] = vertices[i].part;
  if (Output > 0)
  { float max_weight = 0.0;
      for (i=0; i<p; i++)
        if (cluster[i].weight > max_weight)
          max_weight = cluster[i].weight;
    printf("KL END  ... max. weight: %.3f (%.3f)  cutsize: %3d \n", max_weight, max_cluster_weight, cut(cluster,p));
  };
  bucket_free (B[0]);
  bucket_free (B[1]);
  for (i=0; i<p; i++)
  { FREE(cluster[i].neighbor,VERTEX*,p-1);
    FREE(cluster[i].neighbor_w,int,p-1);
  };
  FREE(vertices,VERTEX,n);
  FREE(neighbors,VERTEX*,edge_p[n]);
  FREE(cluster,VERTEX,p);
  FREE(bucket_element,BUCKET_ELE,n);

  ADD_NEW_TIME(t_post);
  return 0;
}
