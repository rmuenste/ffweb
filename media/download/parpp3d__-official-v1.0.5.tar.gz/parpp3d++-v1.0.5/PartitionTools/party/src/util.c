/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY            util.c
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <values.h>
#include <math.h>
#include "alloc.h"
#include <string.h>
#include "error.h"
#include "party_lib.h"

#define MAX_CLUSTER_WEIGHT(MCW,N,VW,ADD,R,P) \
	{ float mvw=1.0; \
	  MCW=(float)N; \
	  if (VW) \
	  { int i; \
	    MCW=mvw=0.0; \
	    for (i=0; i<N; i++) \
	    { MCW += VW[i]; \
	      if (VW[i] > mvw) \
	        mvw = VW[i]; \
	    }; \
	  }; \
	  if (R) \
	    MCW = MCW/P + 2*mvw + 2*ADD; \
	  else \
	    MCW = MCW/P + mvw + ADD; \
	}

static int graph_check (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w)
{ int	i, j, k, error=0;

  for (i=0; i<n; i++)
  { for (j=edge_p[i]; j<edge_p[i+1]; j++)
    { /* check range */
      if (edge[j]<0 || edge[j]>=n)
      { printf("GRAPH_CHECK ERROR...neighbor %d of vertex %d is out of range [%d,%d]\n",edge[j],i,0,n-1);
	error=1;
      };
      /* check if edge is selfloop */
      if (edge[j] == i)
      { printf("GRAPH_CHECK ERROR...selfloop of %d\n",i);
	error=1;
      };
      /* check if edge is double */
      for (k=j+1; k<edge_p[i+1]; k++)
	if (edge[j]==edge[k])
	{ printf("GRAPH_CHECK ERROR...double edge from %d to %d\n",i,edge[j]);
          error=1;
        };
      /* check if edge has no other direction */
      for (k=edge_p[edge[j]]; k<edge_p[(edge[j])+1] && edge[k]!=i; k++);
      if (k == edge_p[(edge[j])+1])
      { printf("GRAPH_CHECK ERROR...single directed edge from %d to %d\n",i,edge[j]);
        error=1;
      }
      else if (edge_w && edge_w[j] != edge_w[k])
      { printf("GRAPH_CHECK ERROR...weighted edge from %d to %d has different weights %d and %d\n",i,edge[j],edge_w[j], edge_w[k]);
        error=1;
      }
    };
  };

  if (vertex_w)
    for (i=0; i<n; i++)
      if (vertex_w[i]<0)
      { printf("GRAPH_CHECK ERROR...vertex %d has a negative weight of %d\n",i,edge_w[i]);
	error=1;
      };
  if (edge_w)
    for (i=0; i<edge_p[n]; i++)
      if (edge_w[i]<0)
      { printf("GRAPH_CHECK ERROR...edge %d has a negative weight of %d\n",i,edge_w[i]);
        error=1;
      };

  return error;
}

int graph_check_and_info (int n, float *vertex_w, float *x, float *y, float *z, int *edge_p, int *edge, int *edge_w, int Output)
{ int  	i, j, *locked, *queue, components,
	edge_w_min=MAXINT, edge_w_max=0, edge_w_tot=0, 
	degree_min=MAXINT, degree_max=0, degree_tot=0,
	degree_w_min=MAXINT, degree_w_max=0, degree_w_tot=0,
	edge_weight, degree, degree_weighted;
  float	vertex_weight, vertex_w_min=MAXINT, vertex_w_max=0.0, vertex_w_tot=0.0;

  if (graph_check(n,vertex_w,edge_p,edge,edge_w))
    FAILED ("GRAPH_CHECK_AND_INFO", "graph_check");

  if (Output <= 0)
    return 0;
  puts("---------- Graph Information --------------------------------------");

  if ( n<= 0)
  { printf("Graph empty (n=%d)!\n",n);
    return 0;
  };

  for (i=0; i<n; i++)
  { vertex_weight = vertex_w?vertex_w[i]:1.0;
    degree = edge_p[i+1] - edge_p[i];
  
    vertex_w_tot += vertex_weight;
    if (vertex_weight < vertex_w_min)
      vertex_w_min = vertex_weight;
    if (vertex_weight > vertex_w_max)
      vertex_w_max = vertex_weight;

    degree_tot += degree;
    if (degree < degree_min)
      degree_min = degree;
    if (degree > degree_max)
      degree_max = degree;

    degree_weighted = 0;
    for (j=edge_p[i]; j<edge_p[i+1]; j++)
    { edge_weight = edge_w?edge_w[j]:1;
      degree_weighted += edge_weight;
      if (edge_weight < edge_w_min)
        edge_w_min = edge_weight;
      if (edge_weight > edge_w_max)
        edge_w_max = edge_weight;
    };
    edge_w_tot += degree_weighted;

    degree_w_tot += degree_weighted;
    if (degree_weighted < degree_w_min)
      degree_w_min = degree_weighted;
    if (degree_weighted > degree_w_max)
      degree_w_max = degree_weighted;
  };
 
  printf("# Vertices/Edges    : %d / %d\n",n,degree_tot/2);
  if (vertex_w_min != 1.0  ||  vertex_w_max != 1.0)
    printf("Node weights  (min/ave/max/tot) %5.2f %7.2f %5.2f %9.2f\n",vertex_w_min,vertex_w_tot/n,vertex_w_max,vertex_w_tot);
  if (edge_w_min != 1  ||  edge_w_max != 1)
    printf("Edge weights  (min/ave/max/tot) %5d %7.2f %5d %9d\n",edge_w_min,(float)edge_w_tot/degree_tot,edge_w_max,edge_w_tot/2);
  printf("Degree        (min/ave/max/tot) %5d %7.2f %5d %9d\n",degree_min,(float) degree_tot/n,degree_max,degree_tot);
  if (edge_w_min != 1  ||  edge_w_max != 1)
    printf("Degree weights(min/ave/max/tot) %5d %7.2f %5d %9d\n",degree_w_min,(float)degree_w_tot/n,degree_w_max,degree_w_tot);

  if (x)
  { float min=x[0], max=x[0];
    for (i=0; i<n; i++)
    { if (x[i] < min)
	min = x[i];
      if (x[i] > max)
	max = x[i];
    };
    printf("Interval of X coordinates: [%f,%f]\n",min,max);
  };
  if (y)
  { float min=y[0], max=y[0];
    for (i=0; i<n; i++)
    { if (y[i] < min)
        min = y[i];
      if (y[i] > max)
	max = y[i];
    };
    printf("Interval of Y coordinates: [%f,%f]\n",min,max);
  };
  if (z)
  { float min=z[0], max=z[0];
    for (i=0; i<n; i++)
    { if (z[i] < min)
	min = z[i];
      if (z[i] > max)
	max = z[i];
    };
    printf("Interval of Z coordinates: [%f,%f]\n",min,max);
  };

  /* Girth */
  if (Output > 1)
  { int *stack, girth, length;
    CALLOC ("GRAPH_CHECK_AND_INFO",locked,int,n);
    CALLOC ("GRAPH_CHECK_AND_INFO",stack,int,edge_p[n]);
    i = 0;
    girth = n;
    while (i<n && girth > 3)
    { int j=0, k, size=1, stack_top=0, vertex;
      while (locked[j])
        j++;
      stack[0] = j;
      stack_top = 0;
      locked[j] = -1;
      while (stack_top >= 0)
      { vertex = stack[stack_top--];
        if (locked[vertex] < 0)
        { for (k=edge_p[vertex]; k<edge_p[vertex+1]; k++)
  	    if (locked[edge[k]] <= 0)
	    { size++;
	      stack[++stack_top] = edge[k];
	      locked[edge[k]] = locked[vertex]-1;
            }
	    else
	    { length = -locked[vertex]-locked[edge[k]]+1;
	      if (length>2 && length<girth)
	        girth = length;
	    };
          locked[vertex] *= -1;
        };
      };
      i += size;
    };
    printf("Girth               : %d\n",girth);
    FREE(locked,int,n);
    FREE(stack,int,edge_p[n]);
  };

  /* Components */
  CALLOC ("GRAPH_CHECK_AND_INFO",locked,int,n);
  CALLOC ("GRAPH_CHECK_AND_INFO",queue,int,edge_p[n]);
  i = components = 0;
  while (i<n)
  { int j=0, k, size=1, queue_head=0, queue_tail=1, vertex;
    components++;
    while (locked[j])
      j++;
    queue[0] = j;
    locked[j] = 1;
    while (queue_head < queue_tail)
    { vertex = queue[queue_head++];
      for (k=edge_p[vertex]; k<edge_p[vertex+1]; k++)
        if (!(locked[edge[k]]))
        { size++;
	  locked[edge[k]] = 1;
          queue[queue_tail++] = edge[k]; 
        }
    };
    if (Output > 1)
      printf ("Component %d with size: %d\n", components, size);
    i += size;
  };
  printf("Components          : %d\n",components);
  FREE(locked,int,n);
  FREE(queue,int,edge_p[n]);

  puts("-------------------------------------------------------------------");
  return 0;
}

int cut_size (int n, int *edge_p, int *edge, int *edge_w, int *part)
{ int   i, j, cuts=0;

  if (edge_w)
  { for (i=0; i<n; i++)
      for (j=edge_p[i]; j<edge_p[i+1]; j++)
        if (part[i] != part[edge[j]])
          cuts += (edge_w[j]);
  }
  else
  { for (i=0; i<n; i++)
      for (j=edge_p[i]; j<edge_p[i+1]; j++)
        if (part[i] != part[edge[j]])
          cuts++;
  };
  return cuts/2;
}

int part_check (int n, float *vertex_w, int p, float add_bal, int recursive, int *part, int Output)
{ int            i;
  float          *weight, total_weight=0.0, max_cluster_weight=0.0,
                 min_weight=(float)MAXINT, max_weight=0.0;

  MAX_CLUSTER_WEIGHT(max_cluster_weight,n,vertex_w,add_bal,recursive,p);
  CALLOC ("MAX_LOAD",weight,float,p);

  if (vertex_w)
    for (i=0; i<n; i++)
      weight[part[i]] += (vertex_w[i]);
  else
    for (i=0; i<n; i++)
      weight[part[i]] += 1.0;

  if (Output > 0)
    printf("load:");
  for (i=0; i<p; i++)
  { total_weight += weight[i];
    if (weight[i] < min_weight)
      min_weight = weight[i];
    if (weight[i] > max_weight)
      max_weight = weight[i];
    if (Output > 1) 
      printf(" %d:%.3f",i, weight[i]);
  };
  FREE(weight,float,p);

  if (Output > 0)
    printf(" [%.3f,%.3f] (ave.: %.3f)\n",min_weight,max_weight, total_weight/p);
  if (max_weight >= max_cluster_weight)
  { fprintf(stderr, "MAX_LOAD ERROR...cluster weight of %.3f too high, limit is %.3f!\n",max_weight, max_cluster_weight);
  };
  return 0;
}

static void min_max_int (int P, int *l, int Output)
{ int i, values[3];

  if (P > 0)
  { values[0] = MAXINT;
    values[1] = values[2] = 0;
    for (i=0; i<P; i++)
    { if (Output > 1)
        printf ("%4d ",l[i]);
      values[2] += l[i];
      if (l[i] < values[0])
        values[0] = l[i];
      if (l[i] > values[1])
        values[1] = l[i];
    };
    if (Output > 0)
      printf("min/ave/max/tot:%5d %7.2f %5d %9d\n",values[0],(float)values[2]/P,values[1],values[2]);
  };
}

static void min_max_float (int P, float *l, int Output)
{ int   i;
  float values[3];

  if (P > 0)
  { values[0] = (float)MAXINT;
    values[1] = values[2] = 0.0;
    for (i=0; i<P; i++)
    { if (Output > 1)
        printf ("%4.1f ",l[i]);
      values[2] += l[i];
      if (l[i] < values[0])
        values[0] = l[i];
      if (l[i] > values[1])
        values[1] = l[i];
    };
    if (Output > 0)
      printf("min/ave/max/tot:%5.1f %7.2f %5.1f %9.1f\n",values[0],values[2]/P,values[1],values[2]);
  };
}

int part_info (int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, int p, int *part, int Output)
{ int	i, j, is_internal, *size, *internal, *neig, *cut, *cut_w, *channel, 
        total_cut_size=0, total_cut_size_w=0;

  if (Output <= 0)
    return 0;
  puts("---------- Partition Information ----------------------------------");

  CALLOC ("PART_INFO",size,int,p);
  CALLOC ("PART_INFO",internal,int,p);
  CALLOC ("PART_INFO",neig,int,p);
  CALLOC ("PART_INFO",cut,int,p);
  CALLOC ("PART_INFO",channel,int,p*(p-1)/2);
  CALLOC ("PART_INFO",cut_w,int,p);

  for (i=0; i<n; i++)
  { if (part[i]<0 || part[i]>=p)
    { fprintf(stderr, "PART_INFO ERROR...wrong part number of vertex %d: %d\n",i,part[i]);
      return 1;
    };
    size[part[i]]++;
    is_internal = 1;
    for (j=edge_p[i]; j<edge_p[i+1]; j++)
    { if (part[i] != part[edge[j]])
      { is_internal = 0;
	cut[part[i]] ++;
	cut_w[part[i]] += (edge_w?edge_w[j]:1);
	if (part[i] > part[edge[j]])
	  channel[(part[i])*((part[i])-1)/2+part[edge[j]]] = 1;
      };
    };
    internal[part[i]] += is_internal;
  }; 
  for (i=0; i<p; i++)
  { total_cut_size += cut[i];
    total_cut_size_w += cut_w[i]; 
    for (j=0; j<i; j++)
      if (channel[i*(i-1)/2+j])
      { neig[i]++;
        neig[j]++;
      };
  };

  printf ("VERTEX-based:\n");
  printf (" Size       "); min_max_int (p, size, Output);
  printf (" Internal   "); min_max_int (p, internal, Output);
  FREE(size,int,p); 
  FREE(internal,int,p); 

  if (vertex_w)
  { float *size_w, *internal_w;
   
    CALLOC ("PART_INFO",size_w,float,p);
    CALLOC ("PART_INFO",internal_w,float,p);

    for (i=0; i<n; i++)
    { size_w[part[i]] += (vertex_w[i]);
      for (j=edge_p[i]; j<edge_p[i+1] && part[edge[j]]==part[i]; j++);
      if (j == edge_p[i+1])
	internal_w[part[i]] += (vertex_w[i]);
    }; 
    printf (" Size w.    "); min_max_float (p, size_w, Output);
    printf (" Internal w."); min_max_float (p, internal_w, Output);
    FREE(size_w,float,p); 
    FREE(internal_w,float,p); 
  };

  printf ("EDGE-based:\n");
  printf (" Part Deg.  "); min_max_int (p, neig, Output);
  printf (" External   "); min_max_int (p, cut, Output);
  printf (" Total cut size is %d\n", total_cut_size/2);
  if (edge_w)
  { printf (" External w."); min_max_int (p, cut_w, Output);
    printf (" Total weighted cut size is %d\n", total_cut_size_w/2);
  };
  FREE(neig,int,p);
  FREE(cut,int,p); 
  FREE(channel,int,p*(p-1)/2);
  FREE(cut_w,int,p); 
  puts("-------------------------------------------------------------------");
  return 0;
}

