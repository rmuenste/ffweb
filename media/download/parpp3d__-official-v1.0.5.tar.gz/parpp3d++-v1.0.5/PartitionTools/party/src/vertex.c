/**********************************************************\
* 
*  PARTY PARTITIONING LIBRARY           vertex.c 
*   
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany        
*  preis@hni.uni-paderborn.de              
*
\**********************************************************/
#include <stdio.h>
#include <values.h>
#include <math.h>
#include "bucket.h"
#include "vertex.h"

void construct_cluster_edges (VERTEX *cluster, int p)
{ int           i, j;
  VERTEX     *c;

  for (i=0; i<p; i++)
  { c = &(cluster[i]);
    DEGREE(c) = 0;
    FOR_ALL_VERTICES( SET(c), vertex,
    { FOR_ALL_NEIGHBORS(vertex, neighbor,
      { if (PART(vertex)!=PART(neighbor)  &&  (W(c)>W(SET(neighbor)) || (W(c)==W(SET(neighbor))&&PART(vertex)<PART(neighbor))))
        { for (j=0; j<DEGREE(c) && NEIG(c)[j]!=SET(neighbor); j++);
          if (j == DEGREE(c))
          { DEGREE(c) = j+1;
            NEIG(c)[j] = SET(neighbor);
          };
        };
      });
    });
  };
}

void change_cluster_edge (VERTEX *vertex, VERTEX *orig_cluster, VERTEX *to, VERTEX **cluster_list)
{ int           deg_c, deg_n;
  VERTEX        *neighbor_cluster;

  FOR_ALL_NEIGHBORS(vertex, neighbor,
  { neighbor_cluster = SET(neighbor);
    if (neighbor_cluster!=SET(vertex) && neighbor_cluster!=to)
    { for (deg_c=0; deg_c<DEGREE(to) && neighbor_cluster!=NEIG(to)[deg_c]; deg_c++);
      for (deg_n=0; deg_n<DEGREE(neighbor_cluster) && to!=NEIG(neighbor_cluster)[deg_n]; deg_n++);

      if (deg_c == DEGREE(to)  &&  deg_n == DEGREE(neighbor_cluster))
      { DEGREE(to) = deg_c+1;
        NEIG(to)[deg_c] = neighbor_cluster;
        orig_cluster=(PART(vertex)<PART(to)?SET(vertex):to);
        if (deg_c == 0  &&  to != orig_cluster)
          FRONT_NEXT (to, *cluster_list);
      };
    };
  });
  SET(vertex) = to;
}

void balance_cluster (VERTEX *c, VERTEX *cluster, float	max_cluster_weight, 
	float max_vertex_weight, int p, BUCKETS *B, int Output)
{ VERTEX	*vertex, *min_neighbor;
  int           i, number_in_list, max_in_bucket;

  printf ("BALANCE_CLUSTER WARNING...Cluster %d weight of %f too high (%f)!\n",PART(c), W(c), max_cluster_weight);

  while (W(c)>=max_cluster_weight)
  { min_neighbor = c;
    FOR_ALL_NEIGHBORS(c, neighbor,
    { if (W(neighbor) < W(min_neighbor))
        min_neighbor = neighbor;
    });
    if (W(min_neighbor)+max_vertex_weight >= max_cluster_weight)
    { for (i=0; i<p; i++)
        if (cluster[i].weight < W(min_neighbor))
          min_neighbor = &(cluster[i]);
      NEIG(c)[DEGREE(c)] = min_neighbor;
      DEGREE(c) = DEGREE(c)+1;
    };
    FOR_ALL_VERTICES (SET(c), vertex,
    { H(vertex) = 0;
      FOR_ALL_NEIGHBORS_W (vertex, neighbor, weight,
      { if (PART(neighbor) == PART(min_neighbor))
          H(vertex) += weight;
        else if (PART(neighbor) == PART(vertex))
	  H(vertex) -= weight;
      });
      bucket_insert(B, BE(vertex), H(vertex));
    });
    while (W(c)>=max_cluster_weight && W(min_neighbor)+W(BUCKET_MAX(B))<max_cluster_weight)
    { max_in_bucket = bucket_max_key(B);
      if (Output > 0)
	printf ("Max in Bucket: %d...",max_in_bucket);
      number_in_list = 0;
      while (W(c)>=max_cluster_weight && W(min_neighbor)+W(BUCKET_MAX(B))<max_cluster_weight && bucket_max_key(B)==max_in_bucket)
      { vertex = BUCKET_MAX(B);
        bucket_delete (BE(vertex));
        W(c) -= W(vertex);
	W(min_neighbor) += W(vertex);
	PART(vertex) = PART(min_neighbor);
        SET(vertex) = min_neighbor;
	FRONT_NEXT(vertex, SET(min_neighbor));
	FOR_ALL_NEIGHBORS_W (vertex, neighbor, weight,
	{ if (PART(neighbor) == PART(c))
	    bucket_new_key(BE(neighbor), H(neighbor)+=(2*weight));
	});
        number_in_list++; 
      };
      if (Output > 0)
        printf("%d vertices moved...\n", number_in_list);
    };
    SET(c) = NULL;
    while (bucket_not_empty(B))
    { vertex = BUCKET_MAX(B);
      bucket_delete (BE(vertex));
      FRONT_NEXT(vertex, SET(c));
    };
  };
}

int cut (VERTEX *cluster, int p)
{ int i, cut=0;

  for (i=0; i<p; i++)
    FOR_ALL_VERTICES( cluster[i].set, vertex,
    { FOR_ALL_NEIGHBORS_W(vertex, neighbor, weight,
      { if (PART(vertex)!=PART(neighbor))
          cut += weight;
      });
    });
  return cut/2;
}

