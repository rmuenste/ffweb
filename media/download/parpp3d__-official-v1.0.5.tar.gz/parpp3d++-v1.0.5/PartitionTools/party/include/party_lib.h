/**********************************************************\
*
*  PARTY PARTITIONING LIBRARY            party_lib.h
*
*  Robert Preis
*  HEINZ NIXDORF INSTITUT
*  Universit\"at Paderborn, Germany
*  preis@hni.uni-paderborn.de
*
\**********************************************************/
#define VERSION "PARTY Version 1.1, 16 September 1996"

#ifdef WORK
extern int party_lib (
	char *Global, char *Local, int runs,
	int n, int *id, float *vertex_w, float *x, float *y, float *z,
	int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int recursive, 
	int *part, int *cutsize,
	int Output, int Xpart);
#else
extern int party_lib (
	char *Global, char *Local, int runs,
	int n, float *vertex_w, float *x, float *y, float *z,
	int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int recursive,
	int *part, int *cutsize,
	int Output);
#endif

extern int global_opt (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int *part,
	int *locked, int Output);
extern int global_linear (
	int n, float *vertex_w,
	int p, float add_bal, int *part);
extern int global_scattered (
	int n, float *vertex_w,
	int p, float add_bal, int *part);
extern int global_random (
	int n, float *vertex_w,
	int p, float add_bal, int *part);
extern int global_gain (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int *part);
extern int global_farhat (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int *part);
extern int global_coordinate (
	int n, float *vertex_w, float *x, float *y, float *z,
	int p, float add_bal, int *part);
extern int global_file (
	int n,
	char *filename,
	int p, int *part);

#ifdef CHACO
extern int global_multilevel (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int *part);
extern int global_spectral_m (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int *part);
extern int global_spectral_l (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int *part);
extern int global_inertial (
	int n, float *vertex_w, float *x, float *y, float *z,  
	int p, float add_bal, int *part);
#endif

extern int local_kl (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int *part,
	int Output);
extern int local_hs (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w,
	int p, float add_bal, int *part,
	int Output);
#ifdef WORK
extern int local_skl (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w,
	int K, float add_bal, int *part,
	int Output);
#endif
#ifdef CHACO
extern int local_ckl (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, 
	int p, float add_bal, int *part);
#endif

extern int graph_load (
	char *graphfile, char *xyzfile, int *n, float **vertex_w, 
	float **x, float **y, float **z, 
	int **edge_p, int **edge, int **edge_w);
extern int graph_save (
	char *graphfile, char *xyzfile, int n, float *vertex_w, 
	float *x, float *y, float *z, int *edge_p, int *edge, int *edge_w);
extern int graph_free (
	int n, float *vertex_w, float *x, float *y, float *z,
	int *edge_p, int *edge, int *edge_w);
extern int graph_print (
	int n, float *vertex_w, float *x, float *y, float *z,
	int *edge_p, int *edge, int *edge_w);
extern int part_save (
	char *partfile, int n, int *part);

extern int graph_check_and_info (
	int n, float *vertex_w, float *x, float *y, float *z, 
	int *edge_p, int *edge, int *edge_w, 
	int Output);
extern int cut_size (
	int n, int *edge_p, int *edge, int *edge_w,
	int *part);
extern int part_check (
	int n, float *vertex_w, int p, float add_bal, int recursive, 
	int *part, int Output);
extern int part_info (
	int n, float *vertex_w, int *edge_p, int *edge, int *edge_w, 
	int p, int *part,
	int Output);

extern void print_alloc_statistics ();
extern void party_lib_times_start ();
extern void party_lib_times_output (
	int Times);

