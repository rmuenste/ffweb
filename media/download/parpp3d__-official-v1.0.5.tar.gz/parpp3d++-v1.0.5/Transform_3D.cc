#include "Task.h"

VOID Task::ConToRot(DoubleVector *vect1,DoubleVector *vect2,UNSIGNED level)
{

//   nicht konsistente Formulierung

//      int IEL,IADJ,IMID,IVE;
//      double DPH;

//      NeighElem=MNeighElem[level];
//      MidFaces=MMidFaces[level];
//      NumVertices=MNumVertices[level];
//      NumElements=MNumElements[level];

//      for(IEL=1;IEL<=NumElements;IEL++)
//      {
//          DPH=(*vect1)(IEL);
//          for(IVE=1;IVE<=6;IVE++)
//          {
//              IADJ=(*NeighElem)(IVE,IEL);
//              IMID=(*MidFaces)(IVE,IEL);

//              if(IADJ==0)
//              {
//                  (*vect2)(IMID)=DPH;
//              }
//              if(IADJ>IEL)
//                  (*vect2)(IMID)=0.5*(DPH+(*vect1)(IADJ));
//          }
//      }

//      //	Prot<<"ConToRot: vect2=\n"<<*vect2<<"\n";



//   konsistente Formulierung

//   old version

  int IEL,IADJ,IMID,IVE,savelevel;
  double DPH;

  if (Debug) {
      protocol << "DEBUG(" << MyProcID << "): Entering Task::ConToRot.\n";
      protocol.mFlush();
  }

  NeighElem=MNeighElem[level];
  MidFaces=MMidFaces[level];
  NumVertices=MNumVertices[level];
  NumElements=MNumElements[level];
  double ptemp;
  myElemBase=MmyElemBase[level];

  savelevel=ActiveLevel;
  ActiveLevel=level;
  SetElemBoundValues(vect1);
  CommunicateElem();
  ActiveLevel=savelevel;

  for(IEL=1;IEL<=NumElements;IEL++)
  {
      DPH=(*vect1)(IEL);
      for(IVE=1;IVE<=6;IVE++)
      {
	IADJ=(*NeighElem)(IVE,IEL);
	IMID=(*MidFaces)(IVE,IEL);

	if(IADJ==0)
	{
	   if(FindElem(IEL,IVE,ptemp,level)==true)
	   {
	      (*vect2)(IMID)=0.5*(DPH+ptemp);
	   } else {
	      (*vect2)(IMID)=DPH;
	   }
	}
	if(IADJ>IEL)
	  (*vect2)(IMID)=0.5*(DPH+(*vect1)(IADJ));
      }
  }

  if (Debug) {
      protocol << "DEBUG(" << MyProcID << "):  Leaving Task::ConToRot.\n";
      protocol.mFlush();
  }

//    int IEL,IADJ,IMID,IVE;
//    double DPH;

//    NeighElem=MNeighElem[level];
//    MidFaces=MMidFaces[level];
//    NumVertices=MNumVertices[level];
//    NumElements=MNumElements[level];
//    double ptemp;
//    myElemBase=MmyElemBase[level];

//    SetElemBoundValues(vect1);
//    CommunicateElem();

//    for(IEL=1;IEL<=NumElements;IEL++)
//    {
//        DPH=(*vect1)(IEL);
//        for(IVE=1;IVE<=6;IVE++)
//        {
//            IADJ=(*NeighElem)(IVE,IEL);
//            IMID=(*MidFaces)(IVE,IEL);

//            if(IADJ==0)
//            {
//                (*vect2)(IMID)=DPH;
//            }
//            if(IADJ>IEL)
//                (*vect2)(IMID)=0.5*(DPH+(*vect1)(IADJ));
//        }
//    }

//    RecvFaceBound=MRecvFaceBound[level];
//    RecvElemBound=MRecvElemBound[level];
//    RecvElemBoundData=MRecvElemBoundData[level];
//    IntArray *Ptr,*Ptr2;
//    DoubleVector *Data;
//    DVector_blink *temp_vectlist;
//    IntArray_blink *temp_elemlist,*temp_facelist;
//    int i,len;

//    for(temp_elemlist=RecvElemBound->get_first(),
//            temp_facelist=RecvFaceBound->get_first(),
//            temp_vectlist=RecvElemBoundData->get_first();
//        temp_elemlist;
//        temp_elemlist=RecvElemBound->get_next(temp_elemlist),
//            temp_facelist=RecvFaceBound->get_next(temp_facelist),
//            temp_vectlist=RecvElemBoundData->get_next(temp_vectlist))
//    {
//        Ptr=temp_elemlist->ptr;
//        len=Ptr->GetLen();
//        Ptr2=temp_facelist->ptr;
//        Data=temp_vectlist->ptr;

//        for(i=1;i<=len;i++)
//        {
//            (*vect2)((*MidFaces)((*Ptr2)(i),(*Ptr)(i)))=0.5*((*vect1)((*Ptr)(i))+(*Data)(i));
//        }
//    }
}

VOID Task::RotToCon(DoubleVector *vect1,DoubleVector *vect2,UNSIGNED level)
{
  int IEL;
  if (Debug) {
      protocol << "DEBUG(" << MyProcID << "): Entering Task::RotToCon.\n";
      protocol.mFlush();
  }
  MidFaces=MMidFaces[level];
  NumVertices=MNumVertices[level];
  NumElements=MNumElements[level];

  for(IEL=1;IEL<=NumElements;IEL++)
    {
      (*vect2)(IEL)=0.166666666666*((*vect1)((*MidFaces)(1,IEL))
				    +(*vect1)((*MidFaces)(2,IEL))
				    +(*vect1)((*MidFaces)(3,IEL))
				    +(*vect1)((*MidFaces)(4,IEL))
				    +(*vect1)((*MidFaces)(5,IEL))
				    +(*vect1)((*MidFaces)(6,IEL)));
    }
  //	Prot<<"RotToCon: vect2=\n"<<*vect2<<"\n";
  if (Debug) {
      protocol << "DEBUG(" << MyProcID << "):  Leaving Task::RotToCon.\n";
      protocol.mFlush();
  }
}




