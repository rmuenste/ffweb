#include "Task.h"

//#define CONTROL_MSG

DoubleArray2D* Task::GetPostProcInfo(int level)
{
  DoubleArray2D *temp;
//   blink *link;
  int i,j,iel,IVT1,IVT2,IVT3,IVT4,face;

  VertCoord=MVertCoord[level];
  VertElem=MVertElem[level];
  MidFaceCoord=MMidFaceCoord[level];
  MidFaces=MMidFaces[level];
  NumVertices=MNumVertices[level];
  NumElements=MNumElements[level];
  TotNumFaces=MTotNumFaces[level];

  IntArray2D KIAD(4,6);
  KIAD(1,1) = 1;  KIAD(1,2) = 1;  KIAD(1,3) = 2;  KIAD(1,4) = 3;  KIAD(1,5) = 4;  KIAD(1,6) = 5;
  KIAD(2,1) = 2;  KIAD(2,2) = 2;  KIAD(2,3) = 3;  KIAD(2,4) = 4;  KIAD(2,5) = 1;  KIAD(2,6) = 6;
  KIAD(3,1) = 3;  KIAD(3,2) = 6;  KIAD(3,3) = 7;  KIAD(3,4) = 8;  KIAD(3,5) = 5;  KIAD(3,6) = 7;
  KIAD(4,1) = 4;  KIAD(4,2) = 5;  KIAD(4,3) = 6;  KIAD(4,4) = 7;  KIAD(4,5) = 8;  KIAD(4,6) = 8;

  if (Param->ElemType==1) {
    temp = new DoubleArray2D(3,NumVertices);
    for(i=1;i<=NumVertices;i++)
    {
      (*temp)(1,i)=(*VertCoord)(1,i);
      (*temp)(2,i)=(*VertCoord)(2,i);
      (*temp)(3,i)=(*VertCoord)(3,i);
    }
#ifdef CONTROL_MSG
    Prot<<"GetPostProcessInfo : temp=\n"<<*temp<<"\n\n";
#endif
  } else if(Param->ElemType==2) {
    temp=new DoubleArray2D(3,TotNumFaces);
    for(iel=1;iel<=NumElements;iel++)
    {
      for(j=1;j<=6;j++)
      {
	IVT1=(*VertElem)(KIAD(1,j),iel);
	IVT2=(*VertElem)(KIAD(2,j),iel);
	IVT3=(*VertElem)(KIAD(3,j),iel);
	IVT4=(*VertElem)(KIAD(4,j),iel);
	face=(*MidFaces)(j,iel);
	(*temp)(1,face)=0.25*((*VertCoord)(1,IVT1)
					  +(*VertCoord)(1,IVT2)
					  +(*VertCoord)(1,IVT3)
					  +(*VertCoord)(1,IVT4));
	(*temp)(2,face)=0.25*((*VertCoord)(2,IVT1)
					    +(*VertCoord)(2,IVT2)
					    +(*VertCoord)(2,IVT3)
					    +(*VertCoord)(2,IVT4));
	(*temp)(3,face)=0.25*((*VertCoord)(3,IVT1)
					    +(*VertCoord)(3,IVT2)
					    +(*VertCoord)(3,IVT3)
					    +(*VertCoord)(3,IVT4));
      }
    }
#ifdef CONTROL_MSG
    Prot<<"GetPostProcessInfo MidCoord: temp=\n"<<*temp<<"\n\n";
#endif
  }
  return temp;
}

DoubleArray2D* Task::GetPostProcInfoConst(int level)
{
  DoubleArray2D *temp;
//   blink *link;
  int i,k;
//   int j,iel,IVT1,IVT2,IVT3,IVT4,face;

  VertCoord=MVertCoord[level];
  VertElem=MVertElem[level];
  MidFaceCoord=MMidFaceCoord[level];
  MidFaces=MMidFaces[level];
  NumVertices=MNumVertices[level];
  NumElements=MNumElements[level];
  TotNumFaces=MTotNumFaces[level];

  temp=new DoubleArray2D(24,NumElements);
  for(i=1;i<=NumElements;i++)
    {
      for(k=0;k<=7;k++)
	{
	  (*temp)(k*3+1,i)=(*VertCoord)(1,(*VertElem)(k+1,i));
	  (*temp)(k*3+2,i)=(*VertCoord)(2,(*VertElem)(k+1,i));
	  (*temp)(k*3+3,i)=(*VertCoord)(3,(*VertElem)(k+1,i));
	}
    }
#ifdef CONTROL_MSG
    Prot<<"GetPostProcessInfo : temp=\n"<<*temp<<"\n\n";
#endif

  return temp;
}

VOID Task::CommunicatePostProcessInfo()
{
  INTEGER i,len,send;
  DoubleArray2D *ptr;
//   DoubleArray2D *ptr2;

  if(MyProcID+1!=MASTER)
  {
    for(int level=1;level<=TotalLevel;level++)
    {
      ptr=GetPostProcInfo(level);
      send=ptr->GetLen();
      MyCom->SyncSend(MASTER,send);
      MyCom->SyncSend(MASTER,ptr);
      delete ptr;
    }
  } else {
    for(int level=1;level<=TotalLevel;level++)
    {
      for(i=1;i<=nProcs;i++)
      {
	if(i!=MASTER) {
	  //Prot<<"Wait PostProcessInfo from "<<i<<" level="<<level<<"\n";
	  //Prot.Flush();

	  MyCom->SyncRecieve(i,&len);
	  ptr=new DoubleArray2D(3,len/3);
	  MyCom->SyncRecieve(i,ptr);

	  //Prot<<"Got PostProcessInfo from "<<i<<" level="<<level<<"\n";
	  //Prot.Flush();

	  GlobalGrid->SetPostProcessInfo(ptr,i,level);
	  delete ptr;
	}
      }
      ptr=GetPostProcInfo(level);
      GlobalGrid->SetPostProcessInfo(ptr,MASTER,level);
      delete ptr;
    }
  }

// for const element

  if(MyProcID+1!=MASTER)
  {
    for(int level=1;level<=TotalLevel;level++)
    {
      ptr=GetPostProcInfoConst(level);
      send=ptr->GetLen();
      MyCom->SyncSend(MASTER,send);
      MyCom->SyncSend(MASTER,ptr);
      delete ptr;
    }
  } else {
    for(int level=1;level<=TotalLevel;level++)
    {
      for(i=1;i<=nProcs;i++)
      {
	if(i!=MASTER) {
	  //Prot<<"Wait PostProcessInfo(Const) from "<<i<<" level="<<level<<"\n";
	  //Prot.Flush();

	  MyCom->SyncRecieve(i,&len);
	  ptr=new DoubleArray2D(24,len/24);
	  MyCom->SyncRecieve(i,ptr);

	  //Prot<<"Got PostProcessInfo(Const) from "<<i<<" level="<<level<<"\n";
	  //Prot.Flush();

	  GlobalGrid->SetPostProcessInfoConst(ptr,i,level);
	  delete ptr;
	}
      }
      ptr=GetPostProcInfoConst(level);
      GlobalGrid->SetPostProcessInfoConst(ptr,MASTER,level);
      delete ptr;
    }
  }
}

VOID Task::OutputVector(DoubleVector *ptr, int level)
{
    int i, len, send;
    DoubleVector *arr;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::OutputVector.\n";
	protocol.mFlush();
    }

    if ((MyProcID + 1) != MASTER) {
	send = ptr->GetLen();
	MyCom->SyncSend(MASTER,send);
	MyCom->SyncSend(MASTER,ptr);
    } else {
	for (i = 1;  i <= nProcs; i++) {
	    if (i != MASTER) {
		MyCom->SyncRecieve(i, &len);
		arr = new DoubleVector(len);
		MyCom->SyncRecieve(i, arr);

		if (GlobalGrid) {
		    GlobalGrid->SetVector(arr, i, level);
		}

		delete arr;
	    }
	}

	if (GlobalGrid) {
	    GlobalGrid->SetVector(ptr, MASTER, level);
	    GlobalGrid->OutputVector(level);
	} else {
	    std::string message
		= progname + " (process " + int_to_string(MyProcID) + "):\n"
		+ "  Warning in Task::OutputVector:\n"
		+ "    No global grid has been initialized.\n"
		+ "    OutputVector is skipped.\n";

	    STD_CERR << message;
	    protocol  << message;
	}

    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::OutputVector.\n";
	protocol.mFlush();
    }

    return;
}

VOID Task::OutputConstVector(DoubleVector *ptr,int level)
{
  INTEGER i,len,send;
  DoubleVector *arr;

  if((MyProcID+1)!=MASTER)
  {
    send=ptr->GetLen();
    MyCom->SyncSend(MASTER,send);
    MyCom->SyncSend(MASTER,ptr);
  } else {
    for(i=1;i<=nProcs;i++)
    {
      if(i!=MASTER) {
	MyCom->SyncRecieve(i,&len);
	arr=new DoubleVector(len);
	MyCom->SyncRecieve(i,arr);

	GlobalGrid->SetConstVector(arr,i,level);
	delete arr;
      }
    }
    GlobalGrid->SetConstVector(ptr,MASTER,level);
    GlobalGrid->OutputConstVector(level);
  }
}

