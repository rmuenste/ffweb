#include "Task.h"

extern Output CW;
extern Output CA;
extern DateTime *GlobalTime;

extern DateTime Clock;
extern DateTime ClockDefect;
extern DateTime ClockNorm;
extern DateTime ClockMatrix;
extern DateTime ClockSolving;

extern double TMoment;
extern double TPressure;
extern double TSolving;
extern double TMatrix;				  // time needed to compute and update matrices
extern double TDefect;				  // time spent computing defect

void Task::L2Projection(ParFiniteElement_3D& Elem,
            DoubleVector* LumpM,
            DoubleVector*& vnew,
            unsigned ICUB)
{
    IntArray  RightSide(1);

    Prot << "L2 - Projection\n";
    DTime = 0;
    RightSide(1) = 1;
    CalcRightSide(Elem, vnew, FALSE, RightSide, 1, ICUB, TRUE, 2);
//      for (int IEQ = 1; IEQ <= vnew->GetLen(); IEQ++)
//          (*vnew)(IEQ) /= (*LumpM)(IEQ);
//      SetBoundRightU(vnew);

//      double X, Y;
//      MidCoord = MMidCoord[MaxLevel];
//      for (int IEQ = 1; IEQ <= vnew->GetLen(); IEQ++) {
//          X = (*MidCoord)(1, IEQ);
//          Y = (*MidCoord)(2, IEQ);
//          (*vnew)(IEQ) = Solution(X, Y);
//      }
    return;
}

void Task::L2ProjectionNonLinear(ParFiniteElement_3D& Elem,
				 DoubleCompactMatrix* M,
				 DoubleVector*& vnew1,
				 DoubleVector*& vnew2,
				 double EpsCG,
				 double OmegaCG, unsigned MaxItCG,
				 unsigned ICUB)
{
    DoubleVector  *f;
    IntArray  RightSide(1);

    Prot << "L2 - Projection\n";
    DTime = 0;
    f = 0;
    RightSide(1) = 1;
    CoeffL2V1();
    CalcRightSide(Elem, f, FALSE, RightSide, 1, ICUB, TRUE, 2);
    SetBoundRightF(f, DTime);
    M->CG(*vnew1, *f, MaxItCG, EpsCG, OmegaCG);
    CoeffRHS();

    f = 0;
    RightSide(1) = 1;
    CoeffL2V2();
    Elem.CalcRightSide(f, FALSE, RightSide, 1, ICUB, TRUE, 2);
    SetBoundRightF(f, DTime);
    (*M).CG(*vnew2, *f, MaxItCG, EpsCG, OmegaCG);
    CoeffRHS();

    delete f;
}


double Task::Norm(DoubleVector& vnew, DoubleVector& vold, int NEQ)
//              ________________________________________
//             / || v_{new} - v_{old} ||_{euklid.}^{2} |
// Compute _  /  -----------------------
//          \/   ||      v_{old}      ||_{euklid.}^{2}
{
    double Aux1 = 0, Aux2 = 0;
    ParVector tempv(NEQ);

    for (int i = 1;  i <= NEQ; i++) {
        tempv(i) = vnew(i) - vold(i);
    }

    Aux1 = tempv.ScalProd(tempv, this);
    Aux2 = ((ParVector&)vold).ScalProd(vold, this);

    // Aux2 == 0
    if (fabs(Aux2 - 0.0) < FLOAT_EPS)
        Aux2 = 1;

    return sqrt(Aux1 / Aux2);
}


double Task::L2NormDiff(DoubleVector& vnew, DoubleVector& vold)
//           ________________________________________________________________
// Compute \/ (u_{1} - v_{1})^{2} + (u_{2} - v_{2})^{2} + (u_{3} - v_{3})^{2}|
{
    double Aux1 = 0;
    ParVector tempv(vnew.GetLen());

    for (unsigned int i = 1;  i <= vnew.GetLen(); i++) {
        tempv(i) = vnew(i) - vold(i);
    }

    Aux1 = tempv.ScalProd(tempv, this);

    return sqrt(Aux1);
}


double Task::L2Norm(DoubleVector& vnew)
//           _________________________________________
// Compute \/ v_{1}^{2} + v_{2}^{2} + v_{3}^{2} + ... |
{
    double Aux = sqrt(((ParVector&)vnew).ScalProd(vnew, this));

    return Aux;
}


double Task::Divergenz(DoubleVector *v1, DoubleVector *v2, DoubleVector *v3)
{
    DoubleVector vhelp(MNumElements[MaxLevel]);

    SetLevel(MaxLevel);
    BT_Mult(*v1, *v2, *v3, vhelp, 1.);

    return constl2norm(&vhelp);
}



void Task::CalcChorMatrixStart(ParFiniteElement_3D& RotElem,
                   MultiCompactMatrix *A,
                   MultiCompactMatrix *M,
                   MultiVector        *LumpM,
                   MultiVector        *PureLump,
                   DoubleVector       *vold1,
                   DoubleVector       *vold2,
                   DoubleVector       *vold3,
                   DoubleVector       *P,
                   DoubleVector       *f1,
                   DoubleVector       *f2,
                   DoubleVector       *f3,
                   double             k)
{
    IntArray   RightSide(1);
    int ISYMM,ICLEAR;
    IntArray2D StreamA2(2,3);
    RightSide(1)=1;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CalcChorMatrixStart.\n";
        protocol.mFlush();
    }

//      if (Param->Func != 4  &&  Param->Func != 5  &&
//  	Param->Func != 6  &&  Param->Func != 7 ) {
//          CoeffRHSV1();
//          CalcRightSide(RotElem,f1,FALSE,RightSide,1,Param->ICUB,TRUE,2);

//          CoeffRHSV2();
//          CalcRightSide(RotElem,f2,FALSE,RightSide,1,Param->ICUB,TRUE,2);

//          CoeffRHSV3();
//          CalcRightSide(RotElem,f3,FALSE,RightSide,1,Param->ICUB,TRUE,2);
//      } else {
        *f1 = 0.0;
        *f2 = 0.0;
        *f3 = 0.0;
//      }

    // Laplace-Matrix A
    StreamA2(1,1)=2;
    StreamA2(2,1)=2;
    StreamA2(1,2)=3;
    StreamA2(2,2)=3;
    StreamA2(1,3)=4;
    StreamA2(2,3)=4;
    ISYMM=0;
    ICLEAR=TRUE;
    CoeffA1();

    AssembleMatrices(RotElem,A,TRUE,StreamA2,3,Param->ICUB,ISYMM,ICLEAR,0);

    UpWind(RotElem,*A,*vold1,*vold2,*vold3,Param->UpSam);

    A->AddMultConst(*M,k,1.0);      //  A=k*A+M

//  *A*=k;
//  A->AddMultiVector(*PureLumpM); // A=M+k*A

    SetMultiBound(A);
    UpdateDiagonal();
    ILU(A,E,0.0);

    SetLevel(MaxLevel);
    // f = k * f  +  M * vold
    ((ParCompactMatrix*)(*M)[MaxLevel])->ParVectMult(*vold1,*f1,1.0,k,this);
    ((ParCompactMatrix*)(*M)[MaxLevel])->ParVectMult(*vold2,*f2,1.0,k,this);
    ((ParCompactMatrix*)(*M)[MaxLevel])->ParVectMult(*vold3,*f3,1.0,k,this);

//      DoubleVector *lump=(*PureLumpM)[MaxLevel];
//      for (int i=1;i<=lump->GetLen();i++) {
//          (*f1)(i)=(*lump)(i)*(*vold1)(i);
//          (*f2)(i)=(*lump)(i)*(*vold2)(i);
//          (*f3)(i)=(*lump)(i)*(*vold3)(i);
//      }

    CoarseGrid->SetTimeMatrix(k);

    CoeffRHSV1();
    SetBoundRightF(f1, DTime);
    SetBoundRightU(vold1, DTime);

    CoeffRHSV2();
    SetBoundRightF(f2, DTime);
    SetBoundRightU(vold2, DTime);

    CoeffRHSV3();
    SetBoundRightF(f3, DTime);
    SetBoundRightU(vold3, DTime);

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CalcChorMatrixStart.\n";
        protocol.mFlush();
    }

    return;
}

void Task::CalcChorMatrix(ParFiniteElement_3D& RotElem,
                   MultiCompactMatrix *A,
                   MultiCompactMatrix *M,
                   MultiVector        *LumpM,
                   MultiVector        *PureLump,
                   DoubleVector       *vold1,
                   DoubleVector       *vold2,
                   DoubleVector       *vold3,
                   DoubleVector       *P,
                   DoubleVector       *f1,
                   DoubleVector       *f2,
                   DoubleVector       *f3,
                   double             k)
{
    IntArray   RightSide(1);
    IntArray2D StreamA2(2,3);
    int ISYMM,ICLEAR;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CalcChorMatrix.\n";
        protocol.mFlush();
    }

    StreamA2(1, 1) = 2;
    StreamA2(2, 1) = 2;
    StreamA2(1, 2) = 3;
    StreamA2(2, 2) = 3;
    StreamA2(1, 3) = 4;
    StreamA2(2, 3) = 4;
    ISYMM = 0;
    ICLEAR = TRUE;
    CoeffA1();

    AssembleMatrices(RotElem, A, TRUE, StreamA2, 3, Param->ICUB, ISYMM, ICLEAR, 0);

    UpWind(RotElem, *A, *vold1, *vold2, *vold3, Param->UpSam);

    A->AddMultConst(*M, k, 1.0);      //  A = k * A+M

//  *A *= k;
//  A->AddMultiVector(*PureLumpM); // A = M + k*A

    SetMultiBound(A);
    UpdateDiagonal();
    ILU(A, E, 0.0);

    CoarseGrid->SetTimeMatrix(k);

    CoeffRHSV1();
    SetBoundRightF(f1, DTime);
    SetBoundRightU(vold1, DTime);

    CoeffRHSV2();
    SetBoundRightF(f2, DTime);
    SetBoundRightU(vold2, DTime);

    CoeffRHSV3();
    SetBoundRightF(f3, DTime);
    SetBoundRightU(vold3, DTime);

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CalcChorMatrix.\n";
	protocol.mFlush();
    }

    return;
}

//
// M: Laplace-Matrix
//
// (LumpM - theta1 * N(u(n+1))) u(n+1) = (LumpM - theta2 * N(u(n))) * u(n) + theta3 * f
//
// N = Laplace + Konvektion
//
void Task::CalcFracMatrixStart(ParFiniteElement_3D& RotElem,
                   MultiCompactMatrix *A,
                   MultiCompactMatrix *M,
                   MultiVector        *LumpM,
                   MultiVector        *PureLumpM,
                   DoubleVector       *vold1,
                   DoubleVector       *vold2,
                   DoubleVector       *vold3,
                   DoubleVector       *P,
                   DoubleVector       *f1,
                   DoubleVector       *f2,
                   DoubleVector       *f3,
                   double             theta1,
                   double             theta2,
                   double             theta3,
                   double             theta4)
{
    IntArray RightSide(1);
//    int ISYMM,ICLEAR;
//      DoubleVector *vect=new DoubleVector(f1->GetLen());// Kann wahrscheinlich weg!!

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CalcFracMatrixStart.\n";
        protocol.mFlush();
    }

    RightSide(1) = 1;
//      if (Param->Func != 4  &&  Param->Func != 5  &&
//  	Param->Func != 6  &&  Param->Func != 7) {
	CoeffRHSV1();
	CalcRightSide(RotElem,f1,FALSE,RightSide,1,Param->ICUB,TRUE,2);

	CoeffRHSV2();
	CalcRightSide(RotElem,f2,FALSE,RightSide,1,Param->ICUB,TRUE,2);

	CoeffRHSV3();
	CalcRightSide(RotElem,f3,FALSE,RightSide,1,Param->ICUB,TRUE,2);
//      } else {
//      *f1 = 0.0;
//      *f2 = 0.0;
//      *f3 = 0.0;
//      }

    // Laplace-Matrix A
    *A = *M;

    UpWind(RotElem, *A, *vold1, *vold2, *vold3, Param->UpSam);

    SetLevel(MaxLevel);

    //
    //  (M - theta2 * A) * vold + theta3 * f
    //
    DoubleVector *lump = (*PureLumpM)[MaxLevel];
    ParCompactMatrix *AMatrix = (ParCompactMatrix*)(*A)[MaxLevel];
    AMatrix->ParTimeMult(*lump, *vold1, *f1, -theta2, theta3, this);
    AMatrix->ParTimeMult(*lump, *vold2, *f2, -theta2, theta3, this);
    AMatrix->ParTimeMult(*lump, *vold3, *f3, -theta2, theta3, this);

    SetLevel(MaxLevel);
    B_Mult(*P, *f1, *f2, *f3, -theta4, 1.0);

    // SB: Bouss einfuegen
#ifdef INCLUDE_TEMPERATURE
    // f1 += conc
#endif

    *A *= theta1;
    A->AddMultiVector(*PureLumpM); // A=M+theta1*A

    SetMultiBound(A);
    UpdateDiagonal();
    CoarseGrid->SetTimeMatrix(theta1);
    ILU(A,E,0.0);

    CoeffRHSV1();
    SetBoundRightF(f1, DTime);
    SetBoundRightU(vold1, DTime);

    CoeffRHSV2();
    SetBoundRightF(f2, DTime);
    SetBoundRightU(vold2, DTime);

    CoeffRHSV3();
    SetBoundRightF(f3, DTime);
    SetBoundRightU(vold3, DTime);

//      delete vect;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CalcFracMatrixStart.\n";
        protocol.mFlush();
    }

    return;
}


#ifdef INCLUDE_TEMPERATURE
//
// M: Laplace-Matrix
//
// (LumpM - theta1 * N(u(n+1))) conc(n+1) = (M-theta2*A)*conc(n) +theta3*f
//
// N = Laplace + Konvektion
//
void Task::CalcBoussMatrixStart(ParFiniteElement_3D& RotElem,
                MultiCompactMatrix *A,
                MultiCompactMatrix *M,
                MultiVector        *PureLumpM,
                DoubleVector       *vold1,
                DoubleVector       *vold2,
                DoubleVector       *vold3,
                DoubleVector       *Conc,
                DoubleVector       *f1,
                double             theta1,
                double             theta2,
                double             theta3,
                double             theta4)
{
    IntArray   RightSide(1);
//    int ISYMM,ICLEAR;
    DoubleVector *lump;
    RightSide(1)=1;
    DoubleVector *vect=new DoubleVector(f1->GetLen());

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CalcBoussMatrixStart.\n";
        protocol.mFlush();
    }


    *f1=0.;

  // Laplace-Matrix A
    *A=*M;
    *A*=1e-4;

    UpWind(RotElem,*A,*vold1,*vold2,*vold3,Param->UpSam);

    SetLevel(MaxLevel);

//
//  (M-theta2*A)*vold+theta3*f
//
    lump = (*PureLumpM)[MaxLevel];
    ParCompactMatrix *AMatrix = (ParCompactMatrix*)(*A)[MaxLevel];
    AMatrix->ParTimeMult(*lump, *Conc, *f1, -theta2, theta3, this);

    *A *= theta1;
    A->AddMultiVector(*PureLumpM); // A = M + theta1 * A

    SetMultiBound(A);
    UpdateDiagonal();
    CoarseGrid->SetTimeMatrix(theta1);
    ILU(A, E, 0.0);

    CoeffRHSV1();
    SetBoundRightBouss(f1);
    SetBoundRightBouss(Conc);

    delete vect;


    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CalcBoussMatrixStart.\n";
        protocol.mFlush();
    }

    return;
}
#endif


void Task::CalcFracMatrix(ParFiniteElement_3D& RotElem,
              MultiCompactMatrix *A,
              MultiCompactMatrix *M,
              MultiVector        *LumpM,
              MultiVector        *PureLumpM,
              DoubleVector       *vold1,
              DoubleVector       *vold2,
              DoubleVector       *vold3,
              DoubleVector       *P,
              DoubleVector       *f1,
              DoubleVector       *f2,
              DoubleVector       *f3,
              double             theta1,
              double             theta2,
              double             theta3,
              double             theta4)
{
    IntArray   RightSide(1);
//  int ISYMM,ICLEAR;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CalcFracMatrix.\n";
        protocol.mFlush();
    }

    *A = *M;

    UpWind(RotElem, *A, *vold1, *vold2, *vold3, Param->UpSam);

    *A *= theta1;
    A->AddMultiVector(*PureLumpM);

    SetMultiBound(A);
    UpdateDiagonal();
    CoarseGrid->SetTimeMatrix(theta1);
    ILU(A, E, 0.0);

    CoeffRHSV1();
    SetBoundRightF(f1, DTime);
    SetBoundRightU(vold1, DTime);

    CoeffRHSV2();
    SetBoundRightF(f2, DTime);
    SetBoundRightU(vold2, DTime);

    CoeffRHSV3();
    SetBoundRightF(f3, DTime);
    SetBoundRightU(vold3, DTime);

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CalcFracMatrix.\n";
        protocol.mFlush();
    }

    return;
}

void Task::Chorin(ParFiniteElement_3D& RotElem, FiniteElement_3D& ConElem,
		  MultiCompactMatrix *A,
		  MultiCompactMatrix *M,
		  MultiCompactMatrix *C,
		  MultiVector        *LumpM,
		  MultiVector        *PureLumpM,
		  DoubleVector *vold1,   DoubleVector *vold2,   DoubleVector *vold3, DoubleVector *P,
		  DoubleVector *f1,      DoubleVector *f2,      DoubleVector *f3,
		  DoubleVector *defect1, DoubleVector *defect2, DoubleVector *defect3,
		  DoubleVector *w1,
		  DoubleVector *neumann1,
		  DoubleVector *q,
		  double        K)
{
    DoubleVector *lump;
    DoubleVector *temp_residuum = new DoubleVector(defect1->GetLen());
    MG_Info       mgInfo1 = { -100, -100, 0, 0, 0, -100 };
    MG_Info       mgInfo2 = { -100, -100, 0, 0, 0, -100 };
    MG_Info       mgInfo3 = { -100, -100, 0, 0, 0, -100 }; // convergence rates and number of iterations in multigrid
    double        residuum0, residuum;			  // sqrt(sum(defects^2))
    double        l2defect1, l2defect2, l2defect3;
    double        tmp;
    double        div, div2;
//    double        TimeMatrix, TimeMoment, TimePressure;
    DateTime      ClockCurrentTimeStep, ClockSingleEquation;
    double        tempTimeValue;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::Chorin.\n";
        protocol.mFlush();
    }

    // Initialization
    l2defect1 = l2defect2 = l2defect3 = 0;
    residuum0 = residuum = 1;
//    TimeMatrix = TimeMoment = TimePressure = 0;

    ClockCurrentTimeStep.SetTime();
    ClockSingleEquation.SetTime();

    ClockMatrix.SetTime();
    CalcChorMatrixStart(RotElem, A, M, LumpM, PureLumpM, vold1, vold2, vold3, P, f1, f2, f3, K);
    TMatrix += ClockMatrix.GetTimeDiff();

    // Calculate start defects for u_{i}:
    // defect_{i} = f_{i} - A * vold_{i}
    if (Param->MaxFixpItU >= 1) {
        SetLevel(MaxLevel);

	ClockDefect.SetTime();
        ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold1, *defect1, 1, 0, this);
        (*defect1) *= -1;
        (*defect1) += (*f1);
        SetBoundDefekt(defect1);

        ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold2, *defect2, 1, 0, this);
        (*defect2) *= -1;
        (*defect2) += (*f2);
        SetBoundDefekt(defect2);

        ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold3, *defect3, 1, 0, this);
        (*defect3) *= -1;
        (*defect3) += (*f3);
        SetBoundDefekt(defect3);
	TDefect += ClockDefect.GetTimeDiff();

        (*temp_residuum)  = (*defect1);
	(*temp_residuum) += (*defect2);
	(*temp_residuum) += (*defect3);
	residuum0 = L2Norm(*temp_residuum);

	l2defect1 = L2Norm(*defect1);
	l2defect2 = L2Norm(*defect2);
	l2defect3 = L2Norm(*defect3);
    }

    if (fabs(residuum0) < 1e-8) {
	protocol << progname
		 << " (process " << int_to_string(MyProcID)
		 << "):\n"
		 << "  Warning in Task::Chorin:\n"
		 << "    Initial residuum is zero.\n"
		 << "    No solving needed.\n";

	if (Debug) {
	    protocol << "DEBUG(" << MyProcID << "):  Leaving Task::Chorin.\n";
	    protocol.mFlush();
	}
	delete temp_residuum;
	return;
    }


    // Initial statistics
    protocol << "        |      relative change       |     defect in velocity     |   conv.rate in multigrid   | mg-steps | nonlinear\n"
	     << "    it. |    u1       u2       u3    |    u1       u2       u3    |    u1       u2       u3    | u1 u2 u3 | conv.rate\n"
	     << "   -----+----------------------------+----------------------------+----------------------------+----------+-----------\n"
	     << "        |                            |"
	     << norm_to_string(l2defect1, "e", 2, sqrt(GlobalDOF))
	     << norm_to_string(l2defect2, "e", 2, sqrt(GlobalDOF))
	     << norm_to_string(l2defect3, "e", 2, sqrt(GlobalDOF))
	     << " |                            |          |\n";

    for (unsigned int FIXITE = 1;  FIXITE <= Param->MaxFixpItU;  FIXITE++) {
	ClockSolving.SetTime();
        SetMGBurgers();
	Prot << "  multigrid [";

	// Perform defect correction for u_{1}:
	// Solve  A * w1 = defect1  with multigrid
        (*w1) = 0;
        //((ParCompactMatrix*)((*A)[MaxLevel]))->ParBiCGStab(*w1, *defect1, 100, Param->EpsUDefect, this);
        mgInfo1 = MultiDriver(RotElem, A, w1, defect1, L2Norm(*Sol1),
			      Param->MinIItU, Param->MaxIItU,
			      Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
			      Param->AMinU, Param->AMaxU);
        //OutputVector(w1, MaxLevel);
        //((ParCompactMatrix*)((*A)[MaxLevel]))->ILUSmooth(*w1, *defect1, 10, 0.1, this);

	// Add correction term to u_{1} solution and adjust boundary points.
        (*Sol1) += (*w1);
        CoeffRHSV1(); SetBoundRightU(Sol1, DTime);
	tmp = L2Norm(*Sol1);
	if (fabs(tmp) < 1e-16) {	  // Sol1 == 0 ?
	    mgInfo1.relChange = 0;
	} else {
	    mgInfo1.relChange = L2Norm(*w1) / tmp;
	}


	// Perform defect correction for u_{2}:
	// Solve  A * w1 = defect2  with multigrid
        (*w1) = 0;
        //((ParCompactMatrix*)((*A)[MaxLevel]))->ParBiCGStab(*w1, *defect2, 100, Param->EpsUDefect, this);
        mgInfo2 = MultiDriver(RotElem, A, w1, defect2, L2Norm(*Sol2),
			      Param->MinIItU, Param->MaxIItU,
			      Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
			      Param->AMinU, Param->AMaxU);

	// Add correction term to u_{2} solution and adjust boundary points.
        (*Sol2) += (*w1);
        CoeffRHSV2(); SetBoundRightU(Sol2, DTime);
	tmp = L2Norm(*Sol2);
	if (fabs(tmp) < 1e-16) {	  // Sol1 == 0 ?
	    mgInfo2.relChange = 0;
	} else {
	    mgInfo2.relChange = L2Norm(*w1) / tmp;
	}


	// Perform defect correction for u_{3}:
	// Solve  A * w1 = defect3  with multigrid
	(*w1) = 0;
        //((ParCompactMatrix*)((*A)[MaxLevel]))->ParBiCGStab(*w1, *defect3, 100, Param->EpsUDefect, this);
        mgInfo3 = MultiDriver(RotElem, A, w1, defect3, L2Norm(*Sol3),
			      Param->MinIItU, Param->MaxIItU,
			      Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
			      Param->AMinU, Param->AMaxU);

	// Add correction term to u_{3} solution and adjust boundary points.
        (*Sol3) += (*w1);
        CoeffRHSV3(); SetBoundRightU(Sol3, DTime);
	tmp = L2Norm(*Sol3);
	if (fabs(tmp) < 1e-16) {	  // Sol1 == 0 ?
	    mgInfo3.relChange = 0;
	} else {
	    mgInfo3.relChange = L2Norm(*w1) / tmp;
	}
	TSolving += ClockSolving.GetTimeDiff();


	// Calculate new matrix.
	ClockMatrix.SetTime();
        CalcChorMatrix(RotElem, A, M, LumpM, PureLumpM, Sol1, Sol2, Sol3, P, f1, f2, f3, K);
	TMatrix += ClockMatrix.GetTimeDiff();

	// Prepare for the next iteration...
        (*vold1) = (*Sol1);
        (*vold2) = (*Sol2);
        (*vold3) = (*Sol3);

	// Calculate current defects.
        SetLevel(MaxLevel);
	ClockDefect.SetTime();
        ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold1, *defect1, 1, 0, this);
        (*defect1) *= -1;
        (*defect1) += (*f1);
        SetBoundDefekt(defect1);

        ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold2, *defect2, 1, 0, this);
        (*defect2) *= -1;
        (*defect2) += (*f2);
        SetBoundDefekt(defect2);

        ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold3, *defect3, 1, 0, this);
        (*defect3) *= -1;
        (*defect3) += (*f3);
        SetBoundDefekt(defect3);
	TDefect += ClockDefect.GetTimeDiff();

	// Compute convergence rate
	(*temp_residuum)  = (*defect1);
	(*temp_residuum) += (*defect2);
	(*temp_residuum) += (*defect3);
	residuum = L2Norm(*temp_residuum);

	l2defect1 = L2Norm(*defect1);
	l2defect2 = L2Norm(*defect2);
	l2defect3 = L2Norm(*defect3);

	// Some statistics
	protocol << "    " << int_to_string(FIXITE, " ", 2) << "  |"
		 << double_to_string(mgInfo1.relChange, "e", 2)
		 << double_to_string(mgInfo2.relChange, "e", 2)
		 << double_to_string(mgInfo3.relChange, "e", 2) << " |"
		 << norm_to_string(l2defect1, "e", 2, sqrt(GlobalDOF))
		 << norm_to_string(l2defect2, "e", 2, sqrt(GlobalDOF))
		 << norm_to_string(l2defect3, "e", 2, sqrt(GlobalDOF)) << " |"
		 << double_to_string(mgInfo1.convRate, "e", 2)
		 << double_to_string(mgInfo2.convRate, "e", 2)
		 << double_to_string(mgInfo3.convRate, "e", 2) << " |"
		 << int_to_string(mgInfo1.steps, " ", 3)
		 << int_to_string(mgInfo2.steps, " ", 3)
		 << int_to_string(mgInfo3.steps, " ", 3) << " | "
		 << double_to_string(pow(residuum / residuum0, 1.0 / FIXITE), "e" , 2) << "\n";

	Prot << "]\n";
	Prot << "****************************\n";
	Prot << "\n   ****  Fixpoint-Iteration " << FIXITE << " ***  !!Error1!! = ";
	Prot << mgInfo1.relChange << " \n                                  ***  !!Error2!! = ";
	Prot << mgInfo2.relChange << " \n                                  ***  !!Error3!! = ";
	Prot << mgInfo3.relChange << " *****\n\n";
	Prot.Flush();

	// Stop criterions
	// (For those who know pp3d, this is equal to nsdef.f:
	//   IF ((DELU.LE.EPSUR).AND.(RES.LE.EPSUD).AND.(RES.LE.EPSRES).AND.(INL.GE.INLMIN))
        if (FIXITE                  >= Param->MinFixpItU  &&
	    l2defect1               <= Param->EpsUDefect  &&
	    l2defect2               <= Param->EpsUDefect  &&
	    l2defect3               <= Param->EpsUDefect  &&
	    mgInfo1.relChange       <= Param->EpsUChange  &&
	    mgInfo2.relChange       <= Param->EpsUChange  &&
	    mgInfo3.relChange       <= Param->EpsUChange  &&
  	    mgInfo1.defectReduction <= Param->DampUMG     &&
  	    mgInfo2.defectReduction <= Param->DampUMG     &&
  	    mgInfo3.defectReduction <= Param->DampUMG)
            break;

	if (FIXITE    >= Param->MinFixpItU  &&
	    l2defect1 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	    l2defect2 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	    l2defect3 / sqrt(GlobalDOF) <= 100*MACHINE_EPS)
	    break;

	// If we did not actually solve within the last iteration
	// the next won't be better. Stop.
	if (mgInfo1.convRate > 1  &&  mgInfo2.convRate > 1  &&  mgInfo3.convRate > 1) {
	    break;
	}
    }

    protocol << "   (Stop criterion for burgers equation has ";
    if (l2defect1               <= Param->EpsUDefect  &&
	l2defect2               <= Param->EpsUDefect  &&
	l2defect3               <= Param->EpsUDefect  &&
	mgInfo1.relChange       <= Param->EpsUChange  &&
	mgInfo2.relChange       <= Param->EpsUChange  &&
	mgInfo3.relChange       <= Param->EpsUChange  &&
  	mgInfo1.defectReduction <= Param->DampUMG     &&
  	mgInfo2.defectReduction <= Param->DampUMG     &&
  	mgInfo3.defectReduction <= Param->DampUMG     ||
	l2defect1 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	l2defect2 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	l2defect3 / sqrt(GlobalDOF) <= 100*MACHINE_EPS)
	protocol << "been fulfilled.)\n";
    else
	protocol << "not been fulfilled.)\n";
#ifdef MG_DEBUG
    protocol << "MG_DEBUG:       defect u1  ?<? EpsUDefect                 defect u2  ?<? EpsUDefect          defect u3  ?<? EpsUDefect\n"
	     << "MG_DEBUG: " << l2defect1 / sqrt(GlobalDOF) << " ?<? " << Param->EpsUDefect / sqrt(GlobalDOF) << "  "
	                     << l2defect2 / sqrt(GlobalDOF) << " ?<? " << Param->EpsUDefect / sqrt(GlobalDOF) << "  "
	                     << l2defect3 / sqrt(GlobalDOF) << " ?<? " << Param->EpsUDefect / sqrt(GlobalDOF) << "\n"
	     << "MG_DEBUG:    relChange u1  ?<? EpsUChange       relChange u2  ?<? EpsUChange       relChange u3  ?<? EpsUChange\n"
	     << "MG_DEBUG: " << mgInfo1.relChange << " ?<? " << Param->EpsUChange << "  "
	                     << mgInfo2.relChange << " ?<? " << Param->EpsUChange << "  "
                             << mgInfo3.relChange << " ?<? " << Param->EpsUChange << "\n"
	     << "MG_DEBUG:  defectReduct.u1 ?<? DampUMG        defectReduct.u2 ?<? DampUMG        defectReduct.u3 ?<? DampUMG\n"
	     << "MG_DEBUG: " << mgInfo1.defectReduction << " ?<? " << Param->DampUMG << "  "
	                     << mgInfo2.defectReduction << " ?<? " << Param->DampUMG << "  "
	                     << mgInfo3.defectReduction << " ?<? " << Param->DampUMG << "\n";
#endif

    // Time statistics
    tempTimeValue = ClockSingleEquation.GetTimeDiff();
    TMoment += tempTimeValue;
    protocol << "\n   Time needed for solving burgers equation: "
	     << timeval_to_string(tempTimeValue) << "\n";


    //  We have solved S \tilde{u} = f - k B p^{n}
    // Now compute:
    //       P q = 1/k B^{T} \tilde{u}   (P.1)
    // and update u via:
    //        u  = \tilde{u} - k M^{-1} B q
    // This means, that, if we want
    //    div(u) = 0
    // which is
    //   B^{T} u = 0,
    // we have to control
    //   B^{T} u = B^{T} \tilde{u} - k B^{T} M^{-1} B q
    //           = B^{T} \tilde{u} - k        P       q
    //           = k ( 1/k B^{T} \tilde{u} - P q )
    // thus we have to warrant that
    //  defect(q) <= EpsDivergence / k

    // Projection step
    protocol << "\n   Projection step ";
    div = Divergenz(vold1, vold2, vold3) / sqrt(ConstGlobalDOF);
    Prot << "\n   *********  Projektionsschritt: **********\n"
	 << "        Divergenz der Loesung vor Projektion: " << div << "\n";

    ClockSingleEquation.SetTime();
    SetLevel(MaxLevel);

    // Compute right hand side for equation (P.1)
    // neumann1 = 1/k * B^{T} * v_{old}
    ClockSolving.SetTime();
    BT_Mult(*vold1, *vold2, *vold3, *neumann1, 1.0 / K);

    SetMGPressure();
    *q = 0.0;

    // Pressure problems with plain Neumann boundary conditions (i.e. plain Dirichlet for
    // velocity require a special solver (to ensure mean pressure equal 1, the missing d.o.f.)
    // Routines have an additional -Neumann- component in their name.
    switch(Param->Func) {
    case 0:					  // unit cube
    case 2:					  // ASMO
    case 4:					  // two consecutive cylinders
    case 5:					  // DFG Benchmark 3D-2Z
	// Configurations with mixed boundary condition in pressure poisson equation.
	// Use plain cg method, plain multi grid method or
	// cg method which is preconditioned by multiplicative
	// or additive multi grid

	if (Param->SolverType_press == 0) {
	    protocol << "using plain cg method:\n";
	    mgInfo1.defect = 0;
	    mgInfo1.defectReduction = 0;
	    mgInfo1.relChange = 0;
	    mgInfo1.convRate = 0;
	    mgInfo1.steps = 0;
	    mgInfo1.omega = 0;

	    ((ParCompactMatrix*)((*C)[MaxLevel]))->ParCG(*q, *neumann1, Param->SolverMaxIt_press, (double)1e-9, this);
	} else if (Param->SolverType_press == 1) {
	    protocol << "using multi grid:\n";
	    mgInfo1 =
		ProjMultiDriver(RotElem, ConElem, C, q, neumann1, constl2norm(q),
				Param->MinIItP, Param->MaxIItP, Param->ProlType_press,
				Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
				Param->AMinP, Param->AMaxP);

	} else if (Param->SolverType_press == 2) {
	    protocol << "using cg method preconditioned with 1 additive multigrid step:\n";
	    mgInfo1 =
		((ParCompactMatrix*)((*C)[MaxLevel]))->ParProjPrecondCG(*q, *neumann1, constl2norm(q),
									Param->MinIItP, Param->MaxIItP, Param->ProlType_press,
									Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
									Param->AMinP, Param->AMaxP,
									1, RotElem, ConElem, C, this);
	} else {
	    protocol << "using cg method preconditioned with 1 multiplicative multigrid step:\n";
	    mgInfo1 =
		((ParCompactMatrix*)((*C)[MaxLevel]))->ParProjPrecondCG(*q, *neumann1, constl2norm(q),
									Param->MinIItP, Param->MaxIItP, Param->ProlType_press,
									Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
									Param->AMinP, Param->AMaxP,
									2, RotElem, ConElem, C, this);
	    // ((ParCompactMatrix*)((*C)[MaxLevel]))->ParProjCG(*q,*neumann1,Param->MaxIItP,Param->EpsDivergence / K,this);
	}
	break;

    case 3:					  // driven cavity
	// Configuration with plain Neumann boundary condition in pressure poisson equation

	if (Param->SolverType_press == 1) {
	    protocol << "using multi grid:\n";
	    mgInfo1 =
		ProjNeumannMultiDriver(RotElem, C, q, neumann1, constl2norm(q),
				       Param->MinIItP, Param->MaxIItP,
				       Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
				       Param->AMinP, Param->AMaxP);
	} else {
	    protocol << "using multi grid:\n"
		     << "   (multi grid preconditioned cg not implemented for pure Neumann boundary conditions, sorry.)\n";
	    mgInfo1 =
		ProjNeumannMultiDriver(RotElem, C, q, neumann1, constl2norm(q),
				       Param->MinIItP, Param->MaxIItP,
				       Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
				       Param->AMinP, Param->AMaxP);
	}
//          // ((ParCompactMatrix*)((*C)[MaxLevel]))->ParProjNeumannCG(*p,*neumann1,Param->MaxIItP,Param->EpsDivergence / K,this);
//          ProjNeumannMultiDriver(RotElem,C,q,neumann1,Param->MaxIItP,Param->EpsDivergence / K);
	break;

    default:
	protocol << progname
		 << " (process " << int_to_string(MyProcID)
		 << "):\n"
		 << "  Warning in Task::Chorin:\n"
		 << "    Unhandled configuration in switch-case.\n";
	break;
    }

    // Update pressure solution ...
    *P = *q;

    // ... and velocity via
    //        u  = \tilde{u} - k M^{-1} B q
    *f1 = 0.0;
    *f2 = 0.0;
    *f3 = 0.0;
    SetLevel(MaxLevel);
    B_Mult(*q, *f1, *f2, *f3, 1.0, 0.0);
    TSolving += ClockSolving.GetTimeDiff();

    // Update u_{1}
    *w1 = *f1;
    lump = (*LumpM)[MaxLevel];
    for (unsigned int i = 1;  i <= lump->GetLen(); i++)
        (*w1)(i) /= (*lump)(i);
    (*w1) *= (- K);

    (*vold1) += (*w1);
    CoeffRHSV1(); SetBoundRightU(vold1, DTime);
    (*Sol1) = (*vold1);

    // Update u_{2}
    *w1 = *f2;
    for (unsigned int i = 1;  i <= lump->GetLen(); i++)
        (*w1)(i) /= (*lump)(i);
    (*w1) *= (- K);

    (*vold2) += (*w1);
    CoeffRHSV2(); SetBoundRightU(vold2, DTime);
    (*Sol2) = (*vold2);

    // Update u_{3}
    *w1 = *f3;
    for (unsigned int i = 1;  i <= lump->GetLen(); i++)
        (*w1)(i) /= (*lump)(i);
    (*w1) *= (- K);

    (*vold3) += (*w1);
    CoeffRHSV3(); SetBoundRightU(vold3, DTime);
    (*Sol3) = (*vold3);

    // Time statistics
    tempTimeValue = ClockSingleEquation.GetTimeDiff();
    TPressure += tempTimeValue;

    // Compute new divergence
    div2 = Divergenz(Sol1, Sol2, Sol3) / sqrt(ConstGlobalDOF);


    // Some statistics
    protocol << "\n    divergence (l2) | conv.rate in mg | mg-steps\n"
	     << "   -----------------+-----------------+----------\n";
    protocol << "       "
	     << double_to_string(div2, "e", 2) << "    |    "
	     << double_to_string(mgInfo1.convRate, "e", 2) << "    |    "
	     << int_to_string(mgInfo1.steps, " ", 3)
	     << "\n";

    protocol << "   (Stop criterion for pressure poisson equation has ";
    if (mgInfo1.defect          <= Param->EpsDivergence / K  &&
	mgInfo1.relChange       <= Param->EpsPChange  &&
	mgInfo1.defectReduction <= Param->DampPMG) {
	protocol << "been fulfilled.)\n";
    } else {
	protocol << "not been fulfilled.)\n";
    }
#ifdef MG_DEBUG
    protocol << "MG_DEBUG:       defect p  ?<? EpsDivergence / K     relChange p ?<? EpsPChange       defectReduct.p ?<? DampPMG\n"
	     << "MG_DEBUG: " << mgInfo1.defect / ConstGlobalDOF << "?<=?" << Param->EpsDivergence / K  / ConstGlobalDOF  << "  "
	                     << mgInfo1.relChange << "?<=?" << Param->EpsPChange  << "  "
	                     << mgInfo1.defectReduction << "?<=?" << Param->DampPMG << "\n";
#endif

    protocol << "\n   Time needed for solving pressure poisson equation: "
	     << timeval_to_string(tempTimeValue) << "\n";
    protocol << "   Time needed for current time step: "
	     << timeval_to_string(ClockCurrentTimeStep.GetTimeDiff()) << "\n";

    Prot<<"  div ("<<div<<" "<<div2<<")\n";

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::Chorin.\n";
        protocol.mFlush();
    }
    delete temp_residuum;
    return;
}

void Task::Fractional(ParFiniteElement_3D& RotElem, FiniteElement_3D& ConElem,
		      MultiCompactMatrix *A,
		      MultiCompactMatrix *M,
		      MultiCompactMatrix *C,
		      MultiVector  *LumpM,
		      MultiVector  *PureLumpM,
		      DoubleVector *vold1,   DoubleVector *vold2,   DoubleVector *vold3, DoubleVector *P,
		      DoubleVector *f1,      DoubleVector *f2,      DoubleVector *f3,
		      DoubleVector *defect1, DoubleVector *defect2, DoubleVector *defect3,
		      DoubleVector *w1,
		      DoubleVector *neumann1,
		      DoubleVector *q,
		      const double  K)
{
    DoubleVector *lump;
    DoubleVector *temp_residuum = new DoubleVector(defect1->GetLen());
    double        theta1, theta2, theta3, theta4;
    double        theta, thetas, alpha, beta;
    MG_Info       mgInfo1 = { -100, -100, -100, -100, 0, -100 };
    MG_Info       mgInfo2 = { -100, -100, -100, -100, 0, -100 };
    MG_Info       mgInfo3 = { -100, -100, -100, -100, 0, -100 }; // convergence rates and number of iterations in multigrid
    double        residuum0, residuum;			         // sqrt(sum(defects^2))
    double        l2defect1, l2defect2, l2defect3;
    double        l2f1, l2f2, l2f3, l2f;
    double        div, div2;
//      double        TimeMatrix, TimeMoment, TimePressure;
    DateTime      ClockCurrentTimeStep, ClockSingleEquation;
    double        tempTimeValue;
    double        Omega = Param->OmgIni;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::Fractional.\n";
        protocol.mFlush();
    }

    // Initialization
    l2defect1 = l2defect2 = l2defect3 = 0;
    theta1    = theta2    = theta3    = theta4 = 0;
//      TimeMatrix = TimeMoment = TimePressure = 0;

    // Choose theta such that the scheme is of second order. See Turek book, page 167.
    theta  = 1.0 - sqrt(2.0) / 2.0;
    thetas = 1.0 - 2.0 * theta;			  // thetas stands for \theta'
    alpha  = (1.0 - 2.0 * theta) / (1.0 - theta); // => all coefficient matrices will be the same in all substeps.
    beta   = 1.0 - alpha;

    for (unsigned int ITE_Proj = 1; ITE_Proj <= 3; ITE_Proj++) {
	protocol << "\n";
	if (ITE_Proj > 1)
	    protocol << "   ---------------------------------------------------------------\n\n";
	protocol << "   Fractional step theta scheme (step " << ITE_Proj << ")\n";
        Prot << "MACRO - STEP (" << ITE_Proj << ")\n";
	ClockCurrentTimeStep.SetTime();

        switch (ITE_Proj) {
        case 1:
            theta1 = alpha * theta * K;
            theta2 = beta  * theta * K;
            theta3 = theta * K;      // right side
            theta4 = theta * K;      // pressure
            break;
        case 2:
            theta1 = beta * thetas * K;
            theta2 = alpha * thetas * K;
            theta3 = thetas * K;
            theta4 = thetas * K;
            break;
        case 3:
            theta1 = alpha * theta * K;
            theta2 = beta * theta * K;
            theta3 = theta * K;
            theta4 = theta * K;
            break;
        }
	protocol << "   with time step" << double_to_string(theta3, "e", 4) << ":\n\n";

	// Build ...
	ClockSingleEquation.SetTime();
	ClockMatrix.SetTime();
        CalcFracMatrixStart(RotElem, A, M, LumpM, PureLumpM,
			    vold1, vold2, vold3, P, f1, f2, f3,
			    theta1, theta2, theta3, theta4);
	TMatrix += ClockMatrix.GetTimeDiff();

	// Calculate start defects for u_{i}:
	// defect_{i} = f_{i} - A * vold_{i}
	if (Param->MaxFixpItU >= 1) {
	    SetLevel(MaxLevel);

//  Prot << *((ParCompactMatrix*)((*A)[MinLevel])) << "\n";
//  	    protocol << "Ausgabe Matrix\n";
//  	    protocol << "Anzahl Eintr�ge: " << ((*A)[MinLevel])->GetLen() << "\n";
//  	    double *sss= (double*) (*A)[MinLevel];
//  	    for (int sb=1; sb < ((*A)[MinLevel])->GetLen(); sb++) {
//  //((ParCompactMatrix*)((*A)[MinLevel]))->GetLen(); sb++) {
//  //		protocol << (* ((DoubleArray*)( (*A)[MaxLevel]) )) (0) << "\n";
//  		protocol << *sss << "\n";
//  		sss++;
//  	    }
//  	    protocol << "Fertig."; protocol.mFlush();

	    ClockDefect.SetTime();
	    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold1, *defect1, 1, 0, this);
	    (*defect1) *= -1;
	    (*defect1) += (*f1);
	    SetBoundDefekt(defect1);

	    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold2, *defect2, 1, 0, this);
	    (*defect2) *= -1;
	    (*defect2) += (*f2);
	    SetBoundDefekt(defect2);

	    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold3, *defect3, 1, 0, this);
	    (*defect3) *= -1;
	    (*defect3) += (*f3);
	    SetBoundDefekt(defect3);
	    TDefect += ClockDefect.GetTimeDiff();

	    (*temp_residuum)  = (*defect1);
	    (*temp_residuum) += (*defect2);
	    (*temp_residuum) += (*defect3);
	    residuum0 = L2Norm(*temp_residuum);

	    l2f1 = L2Norm(*f1);
	    l2f2 = L2Norm(*f2);
	    l2f3 = L2Norm(*f3);
//  protocol << "l2f1: " << double_to_string(l2f1, "e", 11) << "\n";
//  protocol << "l2f2: " << double_to_string(l2f2, "e", 11) << "\n";
//  protocol << "l2f3: " << double_to_string(l2f3, "e", 11) << "\n";
//  protocol << "l2def1: " << double_to_string(L2Norm(*defect1), "e", 11) << "\n";
//  protocol << "l2def2: " << double_to_string(L2Norm(*defect2), "e", 11) << "\n";
//  protocol << "l2def3: " << double_to_string(L2Norm(*defect3), "e", 11) << "\n";
	    l2f  = MAX(l2f1, l2f2);
	    l2f  = MAX(l2f, l2f3);
	    if (fabs(l2f) < 1e-8) l2f = 1.0;

	    // Relative l2 norm of defect
	    l2defect1 = L2Norm(*defect1) / l2f;
	    l2defect2 = L2Norm(*defect2) / l2f;
	    l2defect3 = L2Norm(*defect3) / l2f;
	}

	// Initial statistics
        protocol << "        |      relative change       |     defect in velocity     |   conv.rate in multigrid   | mg-steps | nonlinear\n"
		 << "    it. |    u1       u2       u3    |    u1       u2       u3    |    u1       u2       u3    | u1 u2 u3 | conv.rate\n"
		 << "   -----+----------------------------+----------------------------+----------------------------+----------+-----------\n"
		 << "        |                            |"
		 << double_to_string(l2defect1, "e", 2)
		 << double_to_string(l2defect2, "e", 2)
		 << double_to_string(l2defect3, "e", 2)
		 << " |                            |          |\n";
	protocol.mFlush();

        for (unsigned int FIXITE = 1;  FIXITE <= Param->MaxFixpItU;  FIXITE++) {
	    ClockSolving.SetTime();
	    SetMGBurgers();
            Prot<<"  multigrid [";

	    // Perform defect correction for u_{1}:
	    // Solve  A * w1 = defect1  with multigrid
            (*w1) = 0;
            //((ParCompactMatrix*)((*A)[MaxLevel]))->ParBiCGStab(*w1, *defect1, Param->MaxIItU, Param->EpsUDefect, this);
	    mgInfo1 = MultiDriver(RotElem, A, w1, defect1, L2Norm(*Sol1),
				  Param->MinIItU, Param->MaxIItU,
				  Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
				  Param->AMinU, Param->AMaxU);

	    // Add correction term to u_{1} solution and adjust boundary points.
	    (*Sol1).AddMultConst((*w1), Omega);
//          (*Sol1) += (*w1);
            CoeffRHSV1(); SetBoundRightU(Sol1, DTime);


	    // Perform defect correction for u_{2}:
	    // Solve  A * w1 = defect2  with multigrid
	    (*w1) = 0;
            //((ParCompactMatrix*)((*A)[MaxLevel]))->ParBiCGStab(*w1, *defect2, Param->MaxIItU, Param->EpsUDefect, this);
            mgInfo2 = MultiDriver(RotElem, A, w1, defect2, L2Norm(*Sol2),
				  Param->MinIItU, Param->MaxIItU,
				  Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
				  Param->AMinU, Param->AMaxU);

	    // Add correction term to u_{2} solution and adjust boundary points.
	    (*Sol2).AddMultConst((*w1), Omega);
//          (*Sol2) += (*w1);
            CoeffRHSV2(); SetBoundRightU(Sol2, DTime);


	    // Perform defect correction for u_{3}:
	    // Solve  A * w1 = defect3  with multigrid
	    (*w1) = 0;
            //((ParCompactMatrix*)((*A)[MaxLevel]))->ParBiCGStab(*w1, *defect3, Param->MaxIItU, Param->EpsUDefect, this);
            mgInfo3 = MultiDriver(RotElem, A, w1, defect3, L2Norm(*Sol3),
				  Param->MinIItU, Param->MaxIItU,
				  Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
				  Param->AMinU, Param->AMaxU);

	    // Add correction term to u_{3} solution and adjust boundary points.
	    (*Sol3).AddMultConst((*w1), Omega);
//          (*Sol3) += (*w1);
            CoeffRHSV3(); SetBoundRightU(Sol3, DTime);
	    TSolving += ClockSolving.GetTimeDiff();


	    // Calculate new matrix.
	    ClockMatrix.SetTime();
            CalcFracMatrix(RotElem, A, M, LumpM, PureLumpM, Sol1, Sol2, Sol3,
                           P, f1, f2, f3, theta1, theta2, theta3, theta4);
	    TMatrix += ClockMatrix.GetTimeDiff();

	    // Prepare for the next iteration...
	    (*vold1) = (*Sol1);
	    (*vold2) = (*Sol2);
	    (*vold3) = (*Sol3);

	    // Calculate current defects.
	    SetLevel(MaxLevel);
	    ClockDefect.SetTime();
	    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold1, *defect1, 1, 0, this);
	    (*defect1) *= -1;
	    (*defect1) += (*f1);
	    SetBoundDefekt(defect1);

	    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold2, *defect2, 1, 0, this);
	    (*defect2) *= -1;
	    (*defect2) += (*f2);
	    SetBoundDefekt(defect2);

	    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold3, *defect3, 1, 0, this);
	    (*defect3) *= -1;
	    (*defect3) += (*f3);
	    SetBoundDefekt(defect3);
	    TDefect += ClockDefect.GetTimeDiff();

	    // Compute convergence rate
	    (*temp_residuum)  = (*defect1);
	    (*temp_residuum) += (*defect2);
	    (*temp_residuum) += (*defect3);
	    residuum = L2Norm(*temp_residuum);

	    l2f1 = L2Norm(*f1);
	    l2f2 = L2Norm(*f2);
	    l2f3 = L2Norm(*f3);
	    l2f  = MAX(l2f1, l2f2);
	    l2f  = MAX(l2f, l2f3);
	    if (fabs(l2f) < 1e-8) l2f = 1.0;

	    // Relative l2 norm of defect
	    l2defect1 = L2Norm(*defect1) / l2f;
	    l2defect2 = L2Norm(*defect2) / l2f;
	    l2defect3 = L2Norm(*defect3) / l2f;

	    // Some statistics
	    protocol << "    " << int_to_string(FIXITE, " ", 2) << "  |"
		     << double_to_string(mgInfo1.relChange, "e", 2)
		     << double_to_string(mgInfo2.relChange, "e", 2)
		     << double_to_string(mgInfo3.relChange, "e", 2) << " |"
		     << double_to_string(l2defect1, "e", 2)
		     << double_to_string(l2defect2, "e", 2)
		     << double_to_string(l2defect3, "e", 2) << " |"
		     << double_to_string(mgInfo1.convRate, "e", 2)
		     << double_to_string(mgInfo2.convRate, "e", 2)
		     << double_to_string(mgInfo3.convRate, "e", 2) << " |"
		     << int_to_string(mgInfo1.steps, " ", 3)
		     << int_to_string(mgInfo2.steps, " ", 3)
		     << int_to_string(mgInfo3.steps, " ", 3) << " | "
		     << double_to_string(pow(residuum / residuum0, 1.0 / FIXITE), "e" , 2) << "\n";
	    protocol.mFlush();

            Prot << "] ";
	    Prot << "****************************\n";
	    Prot << "\n   ****  Fixpoint-Iteration " << FIXITE << " ***  !!Error1!! = ";
	    Prot << mgInfo1.relChange << " \n                                  ***  !!Error2!! = ";
	    Prot << mgInfo2.relChange << " \n                                  ***  !!Error3!! = ";
	    Prot << mgInfo3.relChange << " *****\n\n";
            Prot.Flush();

	    // Stop criterions
	    // (For those who know pp3d, this is equal to nsdef.f:
	    //   IF ((DELU.LE.EPSUR).AND.(RES.LE.EPSUD).AND.(RES.LE.EPSRES).AND.(INL.GE.INLMIN))
	    if (FIXITE                  >= Param->MinFixpItU  &&
		l2defect1               <= Param->EpsUDefect  &&
		l2defect2               <= Param->EpsUDefect  &&
		l2defect3               <= Param->EpsUDefect  &&
		mgInfo1.relChange       <= Param->EpsUChange  &&
		mgInfo2.relChange       <= Param->EpsUChange  &&
		mgInfo3.relChange       <= Param->EpsUChange  &&
  		mgInfo1.defectReduction <= Param->DampUMG     &&
  		mgInfo2.defectReduction <= Param->DampUMG     &&
  		mgInfo3.defectReduction <= Param->DampUMG)
                break;

	    if (FIXITE    >= Param->MinFixpItU  &&
		l2defect1 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
		l2defect2 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
		l2defect3 / sqrt(GlobalDOF) <= 100*MACHINE_EPS)
		break;

	    // If we did not actually solve within the last iteration
	    // the next won't be better. Stop.
	    if (mgInfo1.convRate > 1  &&  mgInfo2.convRate > 1  &&  mgInfo3.convRate > 1) {
		break;
	    }
	} // end non-linear iteration

	protocol << "   (Stop criterion for burgers equation has ";
	if (l2defect1               <= Param->EpsUDefect  &&
	    l2defect2               <= Param->EpsUDefect  &&
	    l2defect3               <= Param->EpsUDefect  &&
	    mgInfo1.relChange       <= Param->EpsUChange  &&
	    mgInfo2.relChange       <= Param->EpsUChange  &&
	    mgInfo3.relChange       <= Param->EpsUChange  &&
  	    mgInfo1.defectReduction <= Param->DampUMG     &&
  	    mgInfo2.defectReduction <= Param->DampUMG     &&
  	    mgInfo3.defectReduction <= Param->DampUMG     ||
	    l2defect1 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	    l2defect2 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	    l2defect3 / sqrt(GlobalDOF) <= 100*MACHINE_EPS)
	    protocol << "been fulfilled.)\n";
	else
	    protocol << "not been fulfilled.)\n";
#ifdef MG_DEBUG
    protocol << "MG_DEBUG:       defect u1  ?<? EpsUDefect          defect u2  ?<? EpsUDefect          defect u3  ?<? EpsUDefect\n"
	     << "MG_DEBUG: " << l2defect1 / sqrt(GlobalDOF) << " ?<? " << Param->EpsUDefect / sqrt(GlobalDOF) << "  "
	                     << l2defect2 / sqrt(GlobalDOF) << " ?<? " << Param->EpsUDefect / sqrt(GlobalDOF) << "  "
	                     << l2defect3 / sqrt(GlobalDOF) << " ?<? " << Param->EpsUDefect / sqrt(GlobalDOF) << "\n"
	     << "MG_DEBUG:    relChange u1  ?<? EpsUChange       relChange u2  ?<? EpsUChange       relChange u3  ?<? EpsUChange\n"
	     << "MG_DEBUG: " << mgInfo1.relChange << " ?<? " << Param->EpsUChange << "  "
	                     << mgInfo2.relChange << " ?<? " << Param->EpsUChange << "  "
                             << mgInfo3.relChange << " ?<? " << Param->EpsUChange << "\n"
	     << "MG_DEBUG:  defectReduct.u1 ?<? DampUMG        defectReduct.u2 ?<? DampUMG        defectReduct.u3 ?<? DampUMG\n"
	     << "MG_DEBUG: " << mgInfo1.defectReduction << " ?<? " << Param->DampUMG << "  "
	                     << mgInfo2.defectReduction << " ?<? " << Param->DampUMG << "  "
	                     << mgInfo3.defectReduction << " ?<? " << Param->DampUMG << "\n";
#endif

	// Time statistics
	tempTimeValue = ClockSingleEquation.GetTimeDiff();
	TMoment += tempTimeValue;
	protocol << "\n   Time needed for solving burgers equation: "
		 << timeval_to_string(tempTimeValue) << "\n";

	//  We have solved S \tilde{u} = f - k B p^{n}
	// Now compute:
	//       P q = 1/k B^{T} \tilde{u}    (P.1)
	// and update u via:
	//        u  = \tilde{u} - k M^{-1} B q
	// This means, that, if we want
	//    div(u) = 0
	// which is
	//   B^{T} u = 0,
	// we have to control
	//   B^{T} u = B^{T} \tilde{u} - k B^{T} M^{-1} B q
	//           = B^{T} \tilde{u} - k        P       q
	//           = k ( 1/k B^{T} \tilde{u} - P q )
	// thus we have to warrant that
	//  defect(q) <= EpsDivergence / k

        // Perform projection step
        Prot << "  projection: multigrid ";
	protocol << "\n   Projection step ";
        div = Divergenz(vold1, vold2, vold3) / sqrt(ConstGlobalDOF);

	ClockSingleEquation.SetTime();
        SetLevel(MaxLevel);

	// Compute right hand side for equation (P.1)
	// neumann1 = 1/k * B^{T} * v_{old}
	ClockSolving.SetTime();
        BT_Mult(*vold1, *vold2, *vold3, *neumann1, 1.0 / K);

        SetMGPressure();
	*q = 0.0;

	// Pressure problems with plain Neumann boundary conditions (i.e. plain Dirichlet for
	// velocity require a special solver (to ensure mean pressure equal 1, the missing d.o.f.)
	// Routines have an additional -Neumann- component in their name.
	switch(Param->Func) {
	case 0:					  // unit cube
	case 2:					  // ASMO
	case 4:					  // two consecutive cylinders
	case 5:					  // DFG Benchmark 3D-2Z
	    // Configurations with mixed boundary condition in pressure poisson equation.
	    // Use plain cg method, plain multi grid method or
	    // cg method which is preconditioned by multiplicative
	    // or additive multi grid

	    if (Param->SolverType_press == 0) {
		protocol << "using plain cg method:\n";
		mgInfo1.defect = 0;
		mgInfo1.defectReduction = 0;
		mgInfo1.relChange = 0;
		mgInfo1.convRate = 0;
		mgInfo1.steps = 0;
		mgInfo1.omega = 0;

		((ParCompactMatrix*)((*C)[MaxLevel]))->ParCG(*q, *neumann1, Param->SolverMaxIt_press, (double)1e-9, this);
	    } else if (Param->SolverType_press == 1) {
		protocol << "using multi grid:\n";
		mgInfo1 =
		    ProjMultiDriver(RotElem, ConElem, C, q, neumann1, constl2norm(q),
				    Param->MinIItP, Param->MaxIItP, Param->ProlType_press,
				    Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
				    Param->AMinP, Param->AMaxP);
	    } else if (Param->SolverType_press == 2) {
		protocol << "using cg method preconditioned with 1 additive multigrid step:\n";
		mgInfo1 =
		    ((ParCompactMatrix*)((*C)[MaxLevel]))->ParProjPrecondCG(*q, *neumann1, constl2norm(q),
									    Param->MinIItP, Param->MaxIItP, Param->ProlType_press,
									    Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
									    Param->AMinP, Param->AMaxP,
									    1, RotElem, ConElem, C, this);
	    } else {
		protocol << "using cg method preconditioned with 1 multiplicative multigrid step:\n";
		mgInfo1 =
		    ((ParCompactMatrix*)((*C)[MaxLevel]))->ParProjPrecondCG(*q, *neumann1, constl2norm(q),
									    Param->MinIItP, Param->MaxIItP, Param->ProlType_press,
									    Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
									    Param->AMinP, Param->AMaxP,
									    2, RotElem, ConElem, C, this);
	    }
	break;

    case 3:					  // driven cavity
	// Configuration with plain Neumann boundary condition in pressure poisson equation

	if (Param->SolverType_press == 1) {
	    protocol << "using multi grid:\n";
	    mgInfo1 =
		ProjNeumannMultiDriver(RotElem, C, q, neumann1, constl2norm(q),
				       Param->MinIItP, Param->MaxIItP,
				       Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
				       Param->AMinP, Param->AMaxP);
	} else {
	    protocol << "using multi grid:\n"
		     << "   (multi grid preconditioned cg not implemented for pure Neumann boundary conditions, sorry.)\n";
	    mgInfo1 =
		ProjNeumannMultiDriver(RotElem, C, q, neumann1, constl2norm(q),
				       Param->MinIItP, Param->MaxIItP,
				       Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
				       Param->AMinP, Param->AMaxP);
	}
//          // ((ParCompactMatrix*)((*C)[MaxLevel]))->ParProjNeumannCG(*p,*neumann1,Param->MaxIItP,Param->EpsDivergence / K,this);
//          ProjNeumannMultiDriver(RotElem,C,q,neumann1,Param->MaxIItP,Param->EpsDivergence / K);
	break;

	default:
	    protocol << progname
		     << " (process " << int_to_string(MyProcID)
		     << "):\n"
		     << "  Warning in Task::Fractional:\n"
		     << "    Unhandled configuration in switch-case.\n";
	    break;
	}

	// Update pressure solution ...
	*P += *q;


	// ... and velocity via
	//        u  = \tilde{u} - k M^{-1} B q
        SetLevel(MaxLevel);
        B_Mult(*q, *f1, *f2, *f3, 1.0, 0.0);
	TSolving += ClockSolving.GetTimeDiff();

	// Update u_{1}
        *w1 = *f1;
        lump = (*LumpM)[MaxLevel];
	for (unsigned int i = 1;  i <= lump->GetLen(); i++)
            (*w1)(i) /= (*lump)(i);
        (*w1) *= (- K);

        (*vold1) += (*w1);
        CoeffRHSV1(); SetBoundRightU(vold1, DTime);
        (*Sol1) = (*vold1);

	// Update u_{2}
        *w1 = *f2;
	for (unsigned int i = 1;  i <= lump->GetLen(); i++)
            (*w1)(i) /= (*lump)(i);
        (*w1) *= (- K);

        (*vold2) += (*w1);
        CoeffRHSV2(); SetBoundRightU(vold2, DTime);
        (*Sol2) = (*vold2);

	// Update u_{3}
        *w1 = *f3;
	for (unsigned int i = 1;  i <= lump->GetLen(); i++)
            (*w1)(i) /= (*lump)(i);
        (*w1) *= (- K);

        (*vold3) += (*w1);
        CoeffRHSV3(); SetBoundRightU(vold3, DTime);
        (*Sol3) = (*vold3);

	// Time statistics
	tempTimeValue = ClockSingleEquation.GetTimeDiff();
	TPressure += tempTimeValue;

	// Compute new divergence
        div2 = Divergenz(Sol1, Sol2, Sol3) / sqrt(ConstGlobalDOF);

	// Some statistics
	protocol << "\n    divergence (l2) | conv.rate in mg | mg-steps\n"
		 << "   -----------------+-----------------+----------\n";
	protocol << "       "
  		 << double_to_string(div2, "e", 2) << "    |    "
  		 << double_to_string(mgInfo1.convRate, "e", 2) << "    |    "
  		 << int_to_string(mgInfo1.steps, " ", 3)
		 << "\n";

	protocol << "   (Stop criterion for pressure poisson equation has ";
	if (mgInfo1.defect          <= Param->EpsDivergence / K  &&
	    mgInfo1.relChange       <= Param->EpsPChange  &&
	    mgInfo1.defectReduction <= Param->DampPMG) {
	    protocol << "been fulfilled.)\n";
	} else {
	    protocol << "not been fulfilled.)\n";
	}
#ifdef MG_DEBUG
    protocol << "MG_DEBUG:       defect p  ?<? EpsDivergence / K     relChange p ?<? EpsPChange       defectReduct.p ?<? DampPMG\n"
	     << "MG_DEBUG: " << mgInfo1.defect  / ConstGlobalDOF << "?<=?" << Param->EpsDivergence / K  / ConstGlobalDOF  << "  "
	                     << mgInfo1.relChange << "?<=?" << Param->EpsPChange  << "  "
	                     << mgInfo1.defectReduction << "?<=?" << Param->DampPMG << "\n";
#endif

	protocol << "\n   Time needed for solving pressure poisson equation: "
		 << timeval_to_string(tempTimeValue) << "\n";
	protocol << "   Time needed for current time step: "
		 << timeval_to_string(ClockCurrentTimeStep.GetTimeDiff()) << "\n";
	protocol.mFlush();

        Prot<<"  div: ("<<div<<" "<<div2<<")\n";
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::Fractional.\n";
        protocol.mFlush();
    }
    delete temp_residuum;

    return;
}

void Task::CrankNicolson(ParFiniteElement_3D& RotElem,
			 FiniteElement_3D& ConElem,
			 MultiCompactMatrix *A,
			 MultiCompactMatrix *M,
			 MultiCompactMatrix *C,
			 MultiVector *LumpM,
			 MultiVector *PureLumpM,
			 DoubleVector *vold1,   DoubleVector *vold2,   DoubleVector *vold3, DoubleVector *P,
			 DoubleVector *f1,      DoubleVector *f2,      DoubleVector *f3,
			 DoubleVector *defect1, DoubleVector *defect2, DoubleVector *defect3,
			 DoubleVector *w1,
			 DoubleVector *neumann1,
			 DoubleVector *q,
			 const double  K)
{
    DoubleVector *lump;
    DoubleVector *temp_residuum = new DoubleVector(defect1->GetLen());
    double theta1, theta2, theta3, theta4;
    MG_Info       mgInfo1 = { -100, -100, -100, -100, 0, -100 };
    MG_Info       mgInfo2 = { -100, -100, -100, -100, 0, -100 };
    MG_Info       mgInfo3 = { -100, -100, -100, -100, 0, -100 }; // convergence rates and number of iterations in multigrid
    double        residuum0, residuum;		  // sqrt(sum(defects^2))
    double        l2defect1, l2defect2, l2defect3;
    double        div, div2;
    DateTime      ClockCurrentTimeStep, ClockSingleEquation;
    double        tempTimeValue;
    double        Omega = Param->OmgIni;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CrankNicolson.\n";
        protocol.mFlush();
    }

    // Initialization
    theta1 = 0.5 * K;
    theta2 = 0.5 * K;
    theta3 = K;      // right side
    theta4 = K;      // pressure
    l2defect1 = l2defect2 = l2defect3 = 0;

    Prot<<"  C-N step\n";
    protocol << "\n   ---------------------------------------------------------------\n\n"
	     << "   Crank-Nicolson step\n"
	     << "   with time step" << double_to_string(theta3, "e", 4) << ":\n\n";

    ClockCurrentTimeStep.SetTime();
    ClockSingleEquation.SetTime();

    ClockMatrix.SetTime();
    CalcFracMatrixStart(RotElem, A, M, LumpM, PureLumpM, vold1, vold2, vold3, CP,
			f1, f2, f3, theta1, theta2, theta3, theta4);
    TMatrix += ClockMatrix.GetTimeDiff();

    // Calculate start defects for u_{i}:
    // defect_{i} = f_{i} - A * vold_{i}
    if (Param->MaxFixpItU >= 1) {
	SetLevel(MaxLevel);

	ClockDefect.SetTime();
	((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold1, *defect1, 1, 0, this);
	(*defect1) *= -1;
	(*defect1) += (*f1);
	SetBoundDefekt(defect1);

	((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold2, *defect2, 1, 0, this);
	(*defect2) *= -1;
	(*defect2) += (*f2);
	SetBoundDefekt(defect2);

	((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold3, *defect3, 1, 0, this);
	(*defect3) *= -1;
	(*defect3) += (*f3);
	SetBoundDefekt(defect3);
	TDefect += ClockDefect.GetTimeDiff();

        (*temp_residuum)  = (*defect1);
	(*temp_residuum) += (*defect2);
	(*temp_residuum) += (*defect3);
	residuum0 = L2Norm(*temp_residuum);

	l2defect1 = L2Norm(*defect1);
	l2defect2 = L2Norm(*defect2);
	l2defect3 = L2Norm(*defect3);
    }

    // Initial statistics
    protocol << "        |      relative change       |     defect in velocity     |   conv.rate in multigrid   | mg-steps | nonlinear\n"
	     << "    it. |    u1       u2       u3    |    u1       u2       u3    |    u1       u2       u3    | u1 u2 u3 | conv.rate\n"
	     << "   -----+----------------------------+----------------------------+----------------------------+----------+-----------\n"
	     << "        |                            |"
	     << norm_to_string(l2defect1, "e", 2, sqrt(GlobalDOF))
	     << norm_to_string(l2defect2, "e", 2, sqrt(GlobalDOF))
	     << norm_to_string(l2defect3, "e", 2, sqrt(GlobalDOF))
	     << " |                            |          |\n";
    protocol.mFlush();

    for (unsigned int FIXITE = 1;  FIXITE <= Param->MaxFixpItU;  FIXITE++) {
	ClockSolving.SetTime();
	SetMGBurgers();
	Prot << "multigrid [";

	// Perform defect correction for u_{1}:
	// Solve  A * w1 = defect1  with multigrid
	(*w1) = 0;
	//((ParCompactMatrix*)((*A)[MaxLevel]))->ParBiCGStab(*w1, *defect1, Param->MaxIItU, Param->EpsUDefect, this);
	mgInfo1 = MultiDriver(RotElem, A, w1, defect1, L2Norm(*CN1),
			      Param->MinIItU, Param->MaxIItU,
			      Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
			      Param->AMinU, Param->AMaxU);

	// Add correction term to u_{1} solution and adjust boundary points.
	(*CN1).AddMultConst((*w1), Omega);
//	(*CN1) += (*w1);
	CoeffRHSV1(); SetBoundRightU(CN1, DTime);


	// Perform defect correction for u_{2}:
	// Solve  A * w1 = defect2  with multigrid
	(*w1) = 0;
	//((ParCompactMatrix*)((*A)[MaxLevel]))->ParBiCGStab(*w1, *defect2, Param->MaxIItU, Param->EpsUDefect, this);
	mgInfo2 = MultiDriver(RotElem, A, w1, defect2, L2Norm(*CN2),
			      Param->MinIItU, Param->MaxIItU,
			      Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
			      Param->AMinU, Param->AMaxU);

	// Add correction term to u_{2} solution and adjust boundary points.
	(*CN2).AddMultConst((*w1), Omega);
//	(*CN2) += (*w1);
	CoeffRHSV2(); SetBoundRightU(CN2, DTime);


	// Perform defect correction for u_{3}:
	// Solve  A * w1 = defect3  with multigrid
	(*w1) = 0;
	//((ParCompactMatrix*)((*A)[MaxLevel]))->ParBiCGStab(*w1, *defect3, Param->MaxIItU, Param->EpsUDefect, this);
	mgInfo3 = MultiDriver(RotElem, A, w1, defect3, L2Norm(*CN3),
			      Param->MinIItU, Param->MaxIItU,
			      Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
			      Param->AMinU, Param->AMaxU);

	// Add correction term to u_{3} solution and adjust boundary points.
	(*CN3).AddMultConst((*w1), Omega);
//  	(*CN3) += (*w1);
	CoeffRHSV3(); SetBoundRightU(CN3, DTime);
	TSolving += ClockSolving.GetTimeDiff();


	// Calculate new matrix.
	ClockMatrix.SetTime();
	CalcFracMatrix(RotElem, A, M, LumpM, PureLumpM, CN1, CN2, CN3,
		       CP, f1, f2, f3, theta1, theta2, theta3, theta4);
	TMatrix += ClockMatrix.GetTimeDiff();

	// Prepare for the next iteration...
        (*vold1) = (*CN1);
        (*vold2) = (*CN2);
        (*vold3) = (*CN3);

	// Calculate current defects.
 	SetLevel(MaxLevel);
	ClockDefect.SetTime();
	((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold1, *defect1, 1, 0, this);
	(*defect1) *= -1;
	(*defect1) += (*f1);
	SetBoundDefekt(defect1);

	((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold2, *defect2, 1, 0, this);
	(*defect2) *= -1;
	(*defect2) += (*f2);
	SetBoundDefekt(defect2);

	((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*vold3, *defect3, 1, 0, this);
	(*defect3) *= -1;
	(*defect3) += (*f3);
	SetBoundDefekt(defect3);
	TDefect += ClockDefect.GetTimeDiff();

	// Compute convergence rate
	(*temp_residuum)  = (*defect1);
	(*temp_residuum) += (*defect2);
	(*temp_residuum) += (*defect3);
	residuum = L2Norm(*temp_residuum);

	l2defect1 = L2Norm(*defect1);
	l2defect2 = L2Norm(*defect2);
	l2defect3 = L2Norm(*defect3);

	// Some statistics
	protocol << "    " << int_to_string(FIXITE, " ", 2) << "  |"
		 << double_to_string(mgInfo1.relChange, "e", 2)
		 << double_to_string(mgInfo2.relChange, "e", 2)
		 << double_to_string(mgInfo3.relChange, "e", 2) << " |"
		 << norm_to_string(l2defect1, "e", 2, sqrt(GlobalDOF))
		 << norm_to_string(l2defect2, "e", 2, sqrt(GlobalDOF))
		 << norm_to_string(l2defect3, "e", 2, sqrt(GlobalDOF)) << " |"
		 << double_to_string(mgInfo1.convRate, "e", 2)
		 << double_to_string(mgInfo2.convRate, "e", 2)
		 << double_to_string(mgInfo3.convRate, "e", 2) << " |"
		 << int_to_string(mgInfo1.steps, " ", 3)
		 << int_to_string(mgInfo2.steps, " ", 3)
		 << int_to_string(mgInfo3.steps, " ", 3) << " | "
		 << double_to_string(pow(residuum / residuum0, 1.0 / FIXITE), "e" , 2) << "\n";
	protocol.mFlush();

	Prot << "] ";
	Prot << "****************************\n";
	Prot << "\n   ****  Fixpoint-Iteration " << FIXITE << " ***  !!Error1!! = ";
	Prot << mgInfo1.relChange << " \n                                  ***  !!Error2!! = ";
	Prot << mgInfo2.relChange << " \n                                  ***  !!Error3!! = ";
	Prot << mgInfo3.relChange << " *****\n\n";
	Prot.Flush();


	// Stop criterions
	// (For those who know pp3d, this is equal to nsdef.f:
	//   IF ((DELU.LE.EPSUR).AND.(RES.LE.EPSUD).AND.(RES.LE.EPSRES).AND.(INL.GE.INLMIN))    <-- stimmt nicht mehr
	if (FIXITE                  >= Param->MinFixpItU  &&
	    l2defect1               <= Param->EpsUDefect  &&
	    l2defect2               <= Param->EpsUDefect  &&
	    l2defect3               <= Param->EpsUDefect  &&
	    mgInfo1.relChange       <= Param->EpsUChange  &&
	    mgInfo2.relChange       <= Param->EpsUChange  &&
	    mgInfo3.relChange       <= Param->EpsUChange  &&
  	    mgInfo1.defectReduction <= Param->DampUMG     &&
  	    mgInfo2.defectReduction <= Param->DampUMG     &&
  	    mgInfo3.defectReduction <= Param->DampUMG)
	    break;

	if (FIXITE    >= Param->MinFixpItU  &&
	    l2defect1 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	    l2defect2 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	    l2defect3 / sqrt(GlobalDOF) <= 100*MACHINE_EPS)
	    break;

	// If we did not actually solve within the last iteration
	// the next won't be better. Stop.
	if (mgInfo1.convRate > 1  &&  mgInfo2.convRate > 1  &&  mgInfo3.convRate > 1) {
	    break;
	}
    } // end non-linear iteration

    protocol << "   (Stop criterion for burgers equation has ";
    if (l2defect1               <= Param->EpsUDefect  &&
	l2defect2               <= Param->EpsUDefect  &&
	l2defect3               <= Param->EpsUDefect  &&
	mgInfo1.relChange       <= Param->EpsUChange  &&
	mgInfo2.relChange       <= Param->EpsUChange  &&
	mgInfo3.relChange       <= Param->EpsUChange  &&
  	mgInfo1.defectReduction <= Param->DampUMG     &&
  	mgInfo2.defectReduction <= Param->DampUMG     &&
  	mgInfo3.defectReduction <= Param->DampUMG     ||
	l2defect1 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	l2defect2 / sqrt(GlobalDOF) <= 100*MACHINE_EPS  &&
	l2defect3 / sqrt(GlobalDOF) <= 100*MACHINE_EPS)
	protocol << "been fulfilled.)\n";
    else
	protocol << "not been fulfilled:\n";
#ifdef MG_DEBUG
    protocol << "MG_DEBUG:       defect u1  ?<? EpsUDefect          defect u2  ?<? EpsUDefect          defect u3  ?<? EpsUDefect\n"
	     << "MG_DEBUG: " << l2defect1 / sqrt(GlobalDOF) << " ?<? " << Param->EpsUDefect / sqrt(GlobalDOF) << "  "
	                     << l2defect2 / sqrt(GlobalDOF) << " ?<? " << Param->EpsUDefect / sqrt(GlobalDOF) << "  "
	                     << l2defect3 / sqrt(GlobalDOF) << " ?<? " << Param->EpsUDefect / sqrt(GlobalDOF) << "\n"
	     << "MG_DEBUG:    relChange u1  ?<? EpsUChange       relChange u2  ?<? EpsUChange       relChange u3  ?<? EpsUChange\n"
	     << "MG_DEBUG: " << mgInfo1.relChange << " ?<? " << Param->EpsUChange << "  "
	                     << mgInfo2.relChange << " ?<? " << Param->EpsUChange << "  "
                             << mgInfo3.relChange << " ?<? " << Param->EpsUChange << "\n"
	     << "MG_DEBUG:  defectReduct.u1 ?<? DampUMG        defectReduct.u2 ?<? DampUMG        defectReduct.u3 ?<? DampUMG\n"
	     << "MG_DEBUG: " << mgInfo1.defectReduction << " ?<? " << Param->DampUMG << "  "
	                     << mgInfo2.defectReduction << " ?<? " << Param->DampUMG << "  "
	                     << mgInfo3.defectReduction << " ?<? " << Param->DampUMG << "\n";
#endif

    // Time statistics
    tempTimeValue = ClockSingleEquation.GetTimeDiff();
    TMoment += tempTimeValue;
    protocol << "\n   Time needed for solving burgers equation: "
		 << timeval_to_string(tempTimeValue) << "\n";

    //  We have solved S \tilde{u} = f - k B p^{n}
    // Now compute:
    //       P q = 1/k B^{T} \tilde{u}
    // and update u via:
    //        u  = \tilde{u} - k M^{-1} B q
    // This means, that, if we want
    //    div(u) = 0
    // which is
    //   B^{T} u = 0,
    // we have to control
    //   B^{T} u = B^{T} \tilde{u} - k B^{T} M^{-1} B q
    //           = B^{T} \tilde{u} - k        P       q
    //           = k ( 1/k B^{T} \tilde{u} - P q )
    // thus we have to warrant that
    //  defect(q) <= EpsDivergence / k

    // Perform projection step
    Prot << "  Projektionstep: ";
    protocol << "\n   Projection step ";
    div = Divergenz(vold1, vold2, vold3) / sqrt(ConstGlobalDOF);

    ClockSingleEquation.SetTime();
    SetLevel(MaxLevel);

    // Compute right hand side for equation (P.1)
    // neumann1 = 1/k * B^{T} * v_{old}
    ClockSolving.SetTime();
    BT_Mult(*vold1, *vold2, *vold3, *neumann1, 1.0 / K);

    SetMGPressure();
    *q = 0.0;

    // Pressure problems with plain Neumann boundary conditions (i.e. plain Dirichlet for
    // velocity require a special solver (to ensure mean pressure equal 1, the missing d.o.f.)
    // Routines have an additional -Neumann- component in their name.
    switch(Param->Func) {
    case 0:					  // unit cube
    case 2:					  // ASMO
    case 4:					  // two consecutive cylinders
    case 5:					  // DFG Benchmark 3D-2Z
	// Configurations with mixed boundary condition in pressure poisson equation.
	// Use plain cg method, plain multi grid method or
	// cg method which is preconditioned by multiplicative
	// or additive multi grid

	if (Param->SolverType_press == 0) {
	    protocol << "using plain cg method:\n";
	    mgInfo1.defect = 0;
	    mgInfo1.defectReduction = 0;
	    mgInfo1.relChange = 0;
	    mgInfo1.convRate = 0;
	    mgInfo1.steps = 0;
	    mgInfo1.omega = 0;
	    ((ParCompactMatrix*)((*C)[MaxLevel]))->ParCG(*q, *neumann1, Param->SolverMaxIt_press, (double)1e-9, this);
	} else if (Param->SolverType_press == 1) {
	    protocol << "using multi grid:\n";
	    mgInfo1 =
		ProjMultiDriver(RotElem, ConElem, C, q, neumann1, constl2norm(q),
				Param->MinIItP, Param->MaxIItP, Param->ProlType_press,
				Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
				Param->AMinP, Param->AMaxP);
	} else if (Param->SolverType_press == 2) {
	    protocol << "using cg method preconditioned with 1 additive multigrid step:\n";
	    mgInfo1 =
		((ParCompactMatrix*)((*C)[MaxLevel]))->ParProjPrecondCG(*q, *neumann1, constl2norm(q),
									Param->MinIItP, Param->MaxIItP, Param->ProlType_press,
									Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
									Param->AMinP, Param->AMaxP,
									1, RotElem, ConElem, C, this);
	} else {
	    protocol << "using cg method preconditioned with 1 multiplicative multigrid step:\n";
	    mgInfo1 =
		((ParCompactMatrix*)((*C)[MaxLevel]))->ParProjPrecondCG(*q, *neumann1, constl2norm(q),
									Param->MinIItP, Param->MaxIItP, Param->ProlType_press,
									Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
									Param->AMinP, Param->AMaxP,
									2, RotElem, ConElem, C, this);
	}
	break;

    case 3:					  // driven cavity
	// Configuration with plain Neumann boundary condition in pressure poisson equation

	if (Param->SolverType_press == 1) {
	    protocol << "using multi grid:\n";
	    mgInfo1 =
		ProjNeumannMultiDriver(RotElem, C, q, neumann1, constl2norm(q),
				       Param->MinIItP, Param->MaxIItP,
				       Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
				       Param->AMinP, Param->AMaxP);
	} else {
	    protocol << "using multi grid:\n"
		     << "   (multi grid preconditioned cg not implemented for pure Neumann boundary conditions, sorry.)\n";
	    mgInfo1 =
		ProjNeumannMultiDriver(RotElem, C, q, neumann1, constl2norm(q),
				       Param->MinIItP, Param->MaxIItP,
				       Param->EpsPChange, Param->EpsDivergence / K, Param->DampPMG,
				       Param->AMinP, Param->AMaxP);
	}
//      //      (*C)[MaxLevel]->NeumannCG(*q,*neumann1,Param->MaxIItP,
//      //                Param->EpsDivergence / K,-1.0);
//      ProjNeumannMultiDriver(RotElem, C, q, neumann1, Param->MaxIItP, Param->EpsDivergence / K);
	break;

    default:
	protocol << progname
		 << " (process " << int_to_string(MyProcID)
		 << "):\n"
		 << "  Warning in Task::CrankNicolson:\n"
		 << "    Unhandled configuration in switch-case.\n";
	break;
    }

    // Update pressure solution ...
    *CP += *q;


    // ... and velocity via
    //        u  = \tilde{u} - k M^{-1} B q
    SetLevel(MaxLevel);
    B_Mult(*q, *f1, *f2, *f3, 1.0, 0.0);
    TSolving += ClockSolving.GetTimeDiff();

    // Update u_{1}
    *w1 = *f1;
    lump = (*LumpM)[MaxLevel];
    for (unsigned int i = 1;  i <= lump->GetLen(); i++)
	(*w1)(i) /= (*lump)(i);
    (*w1) *= (- K);

    (*CN1) += (*w1);
    CoeffRHSV1(); SetBoundRightU(CN1, DTime);

    // Update u_{2}
    *w1 = *f2;
    for (unsigned int i = 1;  i <= lump->GetLen(); i++)
	(*w1)(i) /= (*lump)(i);
    (*w1) *= (- K);

    (*CN2) += (*w1);
    CoeffRHSV2(); SetBoundRightU(CN2, DTime);

    // Update u_{3}
    *w1 = *f3;
    for (unsigned int i = 1;  i <= lump->GetLen(); i++)
	(*w1)(i) /= (*lump)(i);
    (*w1) *= (- K);

    (*CN3) += (*w1);
    CoeffRHSV3(); SetBoundRightU(CN3, DTime);


    // Time statistics
    tempTimeValue = ClockSingleEquation.GetTimeDiff();
    TPressure += tempTimeValue;

    // Compute new divergence
    div2 = Divergenz(CN1, CN2, CN3) / sqrt(ConstGlobalDOF);

    // Some statistics
    protocol << "\n    divergence (l2) | conv.rate in mg | mg-steps\n"
	     << "   -----------------+-----------------+----------\n";
    protocol << "       "
	     << double_to_string(div2, "e", 2) << "    |    "
	     << double_to_string(mgInfo1.convRate, "e", 2) << "    |    "
	     << int_to_string(mgInfo1.steps, " ", 3)
	     << "\n";

    protocol << "   (Stop criterion for pressure poisson equation has ";
    if (mgInfo1.defect          <= Param->EpsDivergence / K  &&
	mgInfo1.relChange       <= Param->EpsPChange  &&
	mgInfo1.defectReduction <= Param->DampPMG) {
	protocol << "been fulfilled.)\n";
    } else {
	protocol << "not been fulfilled.)\n";
    }
#ifdef MG_DEBUG
    protocol << "MG_DEBUG:       defect p  ?<? EpsDivergence / K     relChange p ?<? EpsPChange       defectReduct.p ?<? DampPMG\n"
	     << "MG_DEBUG: " << mgInfo1.defect  / ConstGlobalDOF  << "?<=?" << Param->EpsDivergence / K  / ConstGlobalDOF  << "  "
	                     << mgInfo1.relChange << "?<=?" << Param->EpsPChange  << "  "
	                     << mgInfo1.defectReduction << "?<=?" << Param->DampPMG << "\n";
#endif

    protocol << "\n   Time needed for solving pressure poisson equation: "
	     << timeval_to_string(tempTimeValue) << "\n";
    protocol << "   Time needed for current time step: "
	     << timeval_to_string(ClockCurrentTimeStep.GetTimeDiff()) << "\n";
    protocol.mFlush();

    Prot<<"  div: ("<<div<<" "<<div2<<")\n";

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CrankNicolson.\n";
        protocol.mFlush();
    }
    delete temp_residuum;
    return;
}

#ifdef INCLUDE_TEMPERATURE
void Task::Bouss(ParFiniteElement_3D& RotElem,
		 MultiCompactMatrix *A,
		 MultiCompactMatrix *M,
		 MultiVector  *PureLumpM,
		 DoubleVector *vold1,   DoubleVector *vold2,   DoubleVector *vold3,
		 DoubleVector *Conc,
		 DoubleVector *f1,
		 double        K)
{
    double theta1, theta2, theta3, theta4;
//    double theta;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::Bouss.\n";
        protocol.mFlush();
    }

    theta1 = 0.5 * K;
    theta2 = 0.5 * K;
    theta3 = K;      // right side
    theta4 = K;      // pressure

    CalcBoussMatrixStart(RotElem, A, M, PureLumpM, vold1, vold2, vold3, Conc,
			 f1, theta1, theta2, theta3, theta4);

    Prot << "CONCENTRATION - Step: multigrid [";
    SetLevel(MaxLevel);
    SetMGBurgers();
    MultiDriver(RotElem, A, Conc, f1, L2Norm(*Conc),
		Param->MinIItU, Param->MaxIItU,
		Param->EpsUChange, Param->EpsUDefect, Param->DampUMG,
		Param->AMinU, Param->AMaxU);
    Prot << "]\n";

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::Bouss.\n";
        protocol.mFlush();
    }

    return;
}
#endif


short int Task::ErrorControl(MultiVector* LumpM, double K, double eps, double currentTime, double endTime)
{
    double Rel, Scal;
    double estK, newK;
    double oldK = K / 3.0;
    short int returnvalue = 0;

    // Compute ||u_{fracstep} - u_{cn}||_{L_{2}} / ||u_{fracstep}||_{L_{2}}
    Rel   = L2NormDiff(*CN1, *Sol1);
    Rel  += L2NormDiff(*CN2, *Sol2);
    Rel  += L2NormDiff(*CN3, *Sol3);
    Scal  = L2Norm(*Sol1);
    Scal += L2Norm(*Sol2);
    Scal += L2Norm(*Sol3);

//  protocol << "K " << K << "   eps " << eps << "\n"
// 	     << "||CN-FS|| " << Rel  << "   ||CN-FS||/sqrt(GlobalDOF) "  << Rel / sqrt(GlobalDOF * 3.0) << "\n"
// 	     << "||FS|| " << Scal << "   ||FS||/sqrt(GlobalDOF) " << Scal / sqrt(GlobalDOF * 3.0) << "\n";

    // Scale such that a vector that contains nothing but 1 has norm 1.
    Rel  /= sqrt(GlobalDOF * 3.0);
    Scal /= sqrt(GlobalDOF * 3.0);

    if (Scal < 1)
	Scal = 1.0;

    Rel /= Scal;
    estK = newK = oldK * sqrt(8.0 * eps * 1.0 / Rel);

    // Is change in time step too large compared to previous time step?
    if (newK * 1.6 < oldK) {
	if (newK < Param->DtMin) {
	    newK = Param->DtMin;
	    // Time step change even now too large?
	    if (newK * 1.6 < oldK)
		returnvalue = TIMESTEP_HAS_BEEN_TOO_LARGE;
	} else
	    returnvalue = TIMESTEP_HAS_BEEN_TOO_LARGE;
    }
//      if (newK > Param->Dt * 1.5)
//          Param->Dt *= 1.5;
//      else
//          Param->Dt = newK;
//      if (newK < Param->Dt * 0.75)
//          Param->Dt *= 0.75;
//      else
//          Param->Dt = newK;


    // Additional tests if time step guess has been approved
    // having compared Crank-Nicolson and Fractional Step solutions.
    if (returnvalue == 0) {
	// Consider minimal und maximal time step
	if (newK < Param->DtMin) {
	    newK = Param->DtMin;
	} else if (newK > Param->DtMax) {
	    newK = Param->DtMax;
	}

	// We want to stop at the specified endpoint in time.
	// Maybe we have to adjust the final time step to
	// achieve this.
	// Case 1: new time step is too large
	// Case 2: new time step is a little bit to small to reach the endpoint.
	//         (prevent a last time step which is very small)
	double timeRemaining = endTime - (currentTime + 3 * newK);
	if (timeRemaining <= 1e-6)
	    newK += timeRemaining / 3.0;
    }

//  protocol << "       ||u_{fix} - u_{cn}||_{L_{2}} / ||u_{fix}||_{L_{2}} : " << Rel << "\n";
    protocol << "\n   Error control:\n"
             << "   - old (micro) time step                 : " << double_to_string(oldK, "e", 4) << "\n"
             << "   - estimatation for new (micro) time step: " << double_to_string(estK, "e", 4) << "\n"
	     << "   - new (micro) time step will be         : " << double_to_string(newK, "e", 4) << "\n";
    Prot << "--> rel=" << Rel
	 << " scal=" << Scal
	 << " est. time step=" << estK
	 << " new time step=" << newK << "\n";
//  Prot << "Rel=" << Rel << " est. Time Step=" << sqrt(8 * eps * K*K * 1/Rel) / 3 << "\n";

    Param->Dt = newK;
    return returnvalue;
}

//  Projektions-Verfahren 2.Ordnung
void Task::DiscreteProjection(ParFiniteElement_3D& RotElem,
                       FiniteElement_3D& ConElem,
                       MultiCompactMatrix* A,
                       MultiCompactMatrix* M,
                       MultiVector* LumpM,
                       MultiVector* PureLumpM,
                       MultiCompactMatrix* C,
                       DoubleVector *vold1,
                       DoubleVector *vold2,
                       DoubleVector *vold3)
{
    DoubleVector *f1, *f2, *f3;
    DoubleVector *neumann1, *q, *Cq, *Ptemp;
    DoubleVector *w1;
    DoubleVector *defect1, *defect2, *defect3;
    DoubleVector *vtemp1,  *vtemp2,  *vtemp3;

    IntArray2D   StreamA2(2,3);
    int          ISYMM, ICLEAR;
    double       K = 0.0;
    double       TimeEPS;
    int          outfileCounterAVS;		  // hold the index for the next output files
    int          outfileCounterGMV;
    double       timeLastAVSOutput;		  // When did we write avs/gmv output the last time?
    double       timeLastGMVOutput;
    unsigned int currentSolFileNr = 0;            // Which index has the current solution file?
                                                  // (We use a ring of filenames for restart files!)
    bool         matricesComputed;
    double       timederivate = 0.0;
    DateTime     ClockMacroTimestep;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::DiscreteProjection.\n";
        protocol.mFlush();
    }

    // Initialization
    SetLevel(MaxLevel);

    Sol1     = GetRightSideVector(RotElem);
    Sol2     = GetRightSideVector(RotElem);
    Sol3     = GetRightSideVector(RotElem);
    Conc     = GetRightSideVector(RotElem);
    *Conc    = 0.;
#ifdef INCLUDE_TEMPERATURE
    SetBoundRightBouss(Conc);
#endif
    vtemp1   = GetRightSideVector(RotElem);
    vtemp2   = GetRightSideVector(RotElem);
    vtemp3   = GetRightSideVector(RotElem);
    CN1      = GetRightSideVector(RotElem);
    CN2      = GetRightSideVector(RotElem);
    CN3      = GetRightSideVector(RotElem);
    f1       = GetRightSideVector(RotElem);
    f2       = GetRightSideVector(RotElem);
    f3       = GetRightSideVector(RotElem);
    w1       = GetRightSideVector(RotElem);
    defect1  = GetRightSideVector(RotElem);
    defect2  = GetRightSideVector(RotElem);
    defect3  = GetRightSideVector(RotElem);

    neumann1 = GetRightSideVector(ConElem);
    P        = GetRightSideVector(ConElem);  *P    = 0.0;
    q        = GetRightSideVector(ConElem);  *q    = 0.0;
    CP       = GetRightSideVector(ConElem); *CP    = 0.0;
    Cq       = GetRightSideVector(ConElem); *Cq    = 0.0;
    Ptemp    = GetRightSideVector(ConElem); *Ptemp = 0.0;

    // How many unknows do we have?
    *q  = 1.0;
    ConstGlobalDOF = ((ParVector*)q)->ConstScalProd(*q,this);
    *q = 0.0;
    *w1 = 1.0;
    GlobalDOF = ((ParVector*)w1)->ScalProd(*w1, this);
    Prot << "ConstGlobalDegreeOfFreedom=" << ConstGlobalDOF << "\n";
    Prot << "GlobalDegreeOfFreedom=" << GlobalDOF << "\n";
    protocol << "\n Degrees of freedom for"
	     << "\n * burgers equation               : " << int_to_string(int(GlobalDOF) * 3, " ", 9)
	     << "\n * pressure poisson equation      : " << int_to_string(int(ConstGlobalDOF), " ", 9)
	     << "\n Total number of unknowns in space: " << int_to_string(int(GlobalDOF) * 3 + int(ConstGlobalDOF), " ", 9) << "\n";

    // If we have a velocity vector that only contains '1' entries,
    // l2 norm is not 1, but sqrt((DOUBLE)RotElem.GetNumEquations()).
    // Thus, change the prescribed tolerances to reflect this numerical fact.
//      Param->EpsUChange    *= sqrt((double)RotElem.GetNumEquations());
//      Param->EpsUDefect    *= sqrt((double)RotElem.GetNumEquations());
//      Param->EpsPChange    *= sqrt((double)ConElem.GetNumEquations());
//      Param->EpsDivergence *= sqrt((double)ConElem.GetTotalDOF());
    Param->EpsUChange    *= sqrt(GlobalDOF);
    Param->EpsUDefect    *= sqrt(GlobalDOF);
    Param->EpsPChange    *= sqrt(ConstGlobalDOF);
    Param->EpsDivergence *= sqrt(ConstGlobalDOF);

    // Initialize solution vectors
    (*Sol1) = (*vold1);
    (*Sol2) = (*vold2);
    (*Sol3) = (*vold3);

    // Right hand side.
    *f1 = 0;
    *f2 = 0;
    *f3 = 0;

    // Counter for visualization output files.
    outfileCounterAVS = 0;   outfileCounterGMV = 0;
    timeLastAVSOutput = 0.0; timeLastGMVOutput = 0.0;

//  *M=*A;

    SetLevel(MaxLevel);

    // Handle different start methods
    switch (Param->Restart) {
        double abstime, timestep;

    case 0:
	DTime     = 0.0;
	Param->Dt = Param->DtStart;
        CoeffRHSV1();  SetBoundRightU(Sol1, DTime);
        CoeffRHSV2();  SetBoundRightU(Sol2, DTime);
        CoeffRHSV3();  SetBoundRightU(Sol3, DTime);

	outfileCounterAVS = Param->RestartITE;
	outfileCounterGMV = Param->RestartITE;
	break;

    case 1:
        // Restart on same level:
        // read solution from file.
#ifdef INCLUDE_TEMPERATURE
        //ReadSolutionBouss(abstime,timestep);
#endif
        protocol << "\n Reading solution from disk. "; protocol.mFlush();
	if (Debug) protocol << '\n';
        ReadSolution(abstime, timestep);
	if (Debug) protocol << ' ';
	protocol << "Done.\n"; protocol.mFlush();

	// * If we continue a simulation (RestartITE > 1) use elapsed
	//   simulated time (abstime) and timestep (timestep) from file
	// * Otherwise reset these two values to default.
	if (Param->RestartITE > 1) {
	    DTime     = abstime;
	    Param->Dt = timestep;
	} else {
	    DTime     = 0.0;
	    Param->Dt = Param->DtStart;
	}

	// Override a time step that's too small
	if (Param->Dt < Param->DtMin) {
	    Param->Dt = Param->DtMin;
	}

        CoeffRHSV1();  SetBoundRightU(Sol1, DTime);
        CoeffRHSV2();  SetBoundRightU(Sol2, DTime);
        CoeffRHSV3();  SetBoundRightU(Sol3, DTime);
        (*vold1) = (*Sol1);
        (*vold2) = (*Sol2);
        (*vold3) = (*Sol3);
        (*q)     = (*P);

	outfileCounterAVS = Param->RestartITE;
	outfileCounterGMV = Param->RestartITE;

	break;
    case 2:
        // Restart on coarser level:
        // read solution from file (is automatically prolongated one level),
        protocol << "\n Reading solution from disk and prolongating it one level. "; protocol.mFlush();
        ReadCoarseSolution(abstime, timestep, &RotElem, &ConElem);
	protocol << "Done.\n"; protocol.mFlush();

	// * If we continue a simulation (RestartITE > 0) use elapsed
	//   simulated time (abstime) and timestep (timestep) from file
	// * Otherwise reset these two values to default.
	if (Param->RestartITE > 1) {
	    DTime     = abstime;
	    Param->Dt = timestep;
	} else {
	    DTime     = 0.0;
	    Param->Dt = Param->DtStart;
	}
	// Override a time step that's too small
	if (Param->Dt < Param->DtMin) {
	    Param->Dt = Param->DtMin;
	}

        CoeffRHSV1();  SetBoundRightU(Sol1, DTime);
        CoeffRHSV2();  SetBoundRightU(Sol2, DTime);
        CoeffRHSV3();  SetBoundRightU(Sol3, DTime);
        (*vold1) = (*Sol1);
        (*vold2) = (*Sol2);
        (*vold3) = (*Sol3);
        (*q)     = (*P);

	outfileCounterAVS = Param->RestartITE;
	outfileCounterGMV = Param->RestartITE;

	break;
    }


    // Finally start the time iteration.
    matricesComputed = false;
    protocol << "\n Elapsed computing time: "
	     << timeval_to_string(GlobalTime->GetTimeDiff()) << "\n\n\n"
	     << " Computing progress:\n";
    if (MyProcID != 0) {
        protocol.mDeactivate();                   // Don't write multiple computing information to file
    }
    for (unsigned int ITE = (Param->Restart) ? Param->RestartITE : 1;
	 ITE <= Param->MaxTimeIterations;
	 ITE++) {
	// Acceptance accuracy
	if (DTime < Param->TInitPhase) {
	    TimeEPS = Param->EPSADI;		  // low accuracy in the beginning
	} else {
	    TimeEPS = Param->EPSADL;		  // handle a finer accuracy later
	}

	// We want to stop at the specified endpoint in time.
	// Maybe we have to adjust the final time step to
	// achieve this.
	// (1) Normally, this adjustment is done in function ErrorControl.
	// But, if a time step has been too large and 3 Fractional
	// Step steps with a smaller macro time step have been done,
	// this macro time step is chosen as the new time step without
	// calling the function ErrorControl.
	// (2) If we do a restart, the time step read from file can be too large, too.
	double timeRemaining = Param->TEnd - (DTime + 3 * Param->Dt);
	if (timeRemaining <= 1e-6)
	    Param->Dt += timeRemaining / 3.0;


        ClockMacroTimestep.SetTime();

	// Store solution from previous time step
	// (for computation of time derivate and in case the time step has been chosen too large)
	*vtemp1 = *vold1;
	*vtemp2 = *vold2;
	*vtemp3 = *vold3;

        if (Param->Restart == 0) {
            // Compute session from scratch
            if (Param->Method < 0  &&  ITE <= abs(Param->Method)) {
                K = Param->Dt;
		DTime += K;
		protocol << " * Time iteration no. " << ITE << " at " << DTime << " sec:\n";

		Prot<<"----------- TimeStep ("<<DTime<<","<<ITE<<") -----------\n";
		Prot.Flush();

                // Do first x time steps with Chorin method if parameter Method is set to -x.
		protocol << "   Performing step with Chorin method.\n";
		protocol << "   Current macro time step: " << double_to_string(K, "e", 4) << "\n";
		protocol.mFlush();
                Chorin(RotElem, ConElem, A, M, C, LumpM, PureLumpM, vold1, vold2, vold3, P,
                       f1, f2, f3, defect1, defect2, defect3, w1, neumann1, q, Param->Dt);
            } else {
		K = Param->Dt * 3;
		DTime += K;
		protocol << " * Time iteration no. " << ITE << " at " << DTime << " sec:\n";

		Prot<<"----------- TimeStep ("<<DTime<<","<<ITE<<") -----------\n";
		Prot.Flush();

                // All further steps with Van Kan method.
		protocol << "   Performing step with Van Kan method.\n";

                if (! matricesComputed) {
                    // Laplace-Matrix A
                    StreamA2(1, 1) = 2;
                    StreamA2(2, 1) = 2;
                    StreamA2(1, 2) = 3;
                    StreamA2(2, 2) = 3;
                    StreamA2(1, 3) = 4;
                    StreamA2(2, 3) = 4;
                    ISYMM = 0;
                    ICLEAR = TRUE;
                    CoeffA1();

                    AssembleMatrices(RotElem, M, TRUE, StreamA2, 3, Param->ICUB, ISYMM, ICLEAR, 0);
		    matricesComputed = true;
                }

		protocol << "   Current macro time step: " << double_to_string(K, "e", 4) << "\n";
		protocol.mFlush();

                if (ITE % Param->TStepControlITE == 0) {
                    // timestep control: Compare solution computed with fractional step
		    // theta scheme against Crank-Nicolson solution.
                    *CN1    = *vold1;
                    *CN2    = *vold2;
                    *CN3    = *vold3;
                    *Ptemp  = *P;
                    *CP     = *P;
                    *Cq     = *q;
                    Fractional(RotElem, ConElem, A, M, C, LumpM, PureLumpM,
                               vold1, vold2, vold3, P,
                               f1, f2, f3, defect1, defect2, defect3, w1, neumann1, q, K);
                    *vold1 = *CN1;
                    *vold2 = *CN2;
                    *vold3 = *CN3;
                    CrankNicolson(RotElem, ConElem, A, M, C, LumpM, PureLumpM,
				  vold1, vold2, vold3, CP,
				  f1, f2, f3, defect1, defect2, defect3, w1, neumann1, Cq, K);
                    if (ErrorControl(LumpM, K, TimeEPS, DTime, Param->TEnd) == TIMESTEP_HAS_BEEN_TOO_LARGE) {
                        // repeat time step with smaller timestep
			K = Param->Dt * 3;
			protocol << "   Time step has been too large!\n"
				 << "   Doing computation once again with macro time step " << double_to_string(K, "e", 4) << ".\n";

                        *vold1 = *vtemp1;
                        *vold2 = *vtemp2;
                        *vold3 = *vtemp3;
                        *P     = *Ptemp;
                        *Sol1  = *vtemp1;
                        *Sol2  = *vtemp2;
                        *Sol3  = *vtemp3;
                        Fractional(RotElem, ConElem, A, M, C, LumpM, PureLumpM,
                                   vold1, vold2, vold3, P,
                                   f1, f2, f3, defect1, defect2, defect3, w1, neumann1, q, K);
                    } else {
			// Extrapolation of Fractional Step and Crank-Nicolson solution
			*Sol1 *= 9/8;
			*Sol2 *= 9/8;
			*Sol3 *= 9/8;
			(*Sol1).AddMultConst((*CN1), -1/8);
			(*Sol2).AddMultConst((*CN2), -1/8);
			(*Sol3).AddMultConst((*CN3), -1/8);
		    }
                } else {
                    Fractional(RotElem, ConElem, A, M, C, LumpM, PureLumpM,
                               vold1, vold2, vold3, P,
                               f1, f2, f3, defect1, defect2, defect3, w1, neumann1, q, K);
                }
#ifdef INCLUDE_TEMPERATURE
                //  Bouss(RotElem,A,M,PureLumpM,vold1,vold2,vold3,Conc,f1,K);
#endif
            }

        } else {
	    K = Param->Dt * 3;
	    DTime += K;
	    protocol << " * Time iteration no. " << ITE << " at " << DTime << " sec:\n";

	    Prot<<"----------- TimeStep ("<<DTime<<","<<ITE<<") -----------\n";
	    Prot.Flush();

	    // All steps with Van Kan method.
	    protocol << "   Performing step with Van Kan method.\n";

            // Compute session with restart
            if (! matricesComputed) {
                // Laplace-Matrix A
                StreamA2(1, 1) = 2;
                StreamA2(2, 1) = 2;
                StreamA2(1, 2) = 3;
                StreamA2(2, 2) = 3;
                StreamA2(1, 3) = 4;
                StreamA2(2, 3) = 4;
                ISYMM = 0;
                ICLEAR = TRUE;
                CoeffA1();

                AssembleMatrices(RotElem, M, TRUE, StreamA2, 3, Param->ICUB, ISYMM, ICLEAR, 0);
		matricesComputed = true;
            }

	    protocol << "   Current macro time step: " << double_to_string(K, "e", 4) << "\n";
	    protocol.mFlush();

            if (ITE % Param->TStepControlITE == 0) {
                *CN1    = *vold1;
                *CN2    = *vold2;
                *CN3    = *vold3;
                *CP     = *P;
                *Cq     = *q;
                Fractional(RotElem, ConElem, A, M, C, LumpM, PureLumpM,
                           vold1, vold2, vold3, P,
                           f1, f2, f3, defect1, defect2, defect3, w1, neumann1, q, K);
                *vold1 = *CN1;
                *vold2 = *CN2;
                *vold3 = *CN3;
                CrankNicolson(RotElem, ConElem, A, M, C, LumpM, PureLumpM,
			      vold1, vold2, vold3, CP,
			      f1, f2, f3, defect1, defect2, defect3, w1, neumann1, Cq, K);

                if (ErrorControl(LumpM, K, TimeEPS, DTime, Param->TEnd) == TIMESTEP_HAS_BEEN_TOO_LARGE) {
                    // repeat time step with smaller timestep
		    K = Param->Dt * 3;
		    protocol << "   Time step has been too large!\n"
			     << "   Doing computation once again with macro time step " << double_to_string(K, "e", 4) << ".\n";

                    *vold1 = *vtemp1;
                    *vold2 = *vtemp2;
                    *vold3 = *vtemp3;
                    *Sol1  = *vtemp1;
                    *Sol2  = *vtemp2;
                    *Sol3  = *vtemp3;
                    Fractional(RotElem, ConElem, A, M, C, LumpM, PureLumpM, vold1, vold2, vold3, P,
                               f1, f2, f3, defect1, defect2, defect3, w1, neumann1, q, K);
		} else {
		    // Extrapolation of Fractional Step and Crank-Nicolson solution
		    *Sol1 *= 9/8;
		    *Sol2 *= 9/8;
		    *Sol3 *= 9/8;
		    (*Sol1).AddMultConst((*CN1), -1/8);
		    (*Sol2).AddMultConst((*CN2), -1/8);
		    (*Sol3).AddMultConst((*CN3), -1/8);
                }
            } else {
                Fractional(RotElem, ConElem, A, M, C, LumpM, PureLumpM, vold1, vold2, vold3, P,
                           f1, f2, f3, defect1, defect2, defect3, w1, neumann1, q, K);
            }
#ifdef INCLUDE_TEMPERATURE
            //      Bouss(RotElem,A,M,PureLumpM,vold1,vold2,vold3,Conc,f1,K);
#endif
        }

	protocol << "\n   Time needed for current macro time step: "
		 << timeval_to_string(ClockMacroTimestep.GetTimeDiff()) << "\n";

	timederivate  = L2NormDiff(*Sol1, *vtemp1);
	timederivate += L2NormDiff(*Sol2, *vtemp2);
	timederivate += L2NormDiff(*Sol3, *vtemp3);
	timederivate /= sqrt(GlobalDOF * 3.0) * K;
	protocol << "\n   Time derivate of u (l2norm, problem size scaled): " << double_to_string(timederivate, "e", 4) << "\n\n";

        *vold1 = *Sol1;
        *vold2 = *Sol2;
        *vold3 = *Sol3;

	// Compute drag and lift for some of the hard-coded simulations
        if (Param->Func == 2  ||  Param->Func == 4  ||  Param->Func == 5) {
	    double dfw1 = 0, daw1 = 0;
	    double dfw2 = 0, daw2 = 0;
	    protocol << "   Calculating lift and drag. "; protocol.mFlush();
	    if (Debug) protocol << '\n';
            CalcLiftDrag(Sol1, Sol2, Sol3, P, &RotElem, dfw1, daw1, dfw2, daw2);
	    if (Debug) protocol << "   ";
	    protocol << "Done.\n"; protocol.mFlush();

	    CW << DTime << " " << dfw1 << "\n";
            CW.Flush();
            CA << DTime << " " << daw1 << "\n";
            CA.Flush();
            Prot << "--> cw= " << dfw1 << " ca=" << daw1 << "\n";

	    if (Param->Func == 4) {
		protocol << "   Drag and lift coefficients at first cylinder are:\n";
		protocol << "     c_d: " << std::setprecision(12) << dfw1 << "\n";
		protocol << "     c_l: " << std::setprecision(12) << daw1 << "\n\n";
		protocol << "   Drag and lift coefficients at second cylinder are:\n";
		protocol << "     c_d: " << std::setprecision(12) << dfw2 << "\n";
		protocol << "     c_l: " << std::setprecision(12) << daw2 << "\n\n";
	    } else if (Param->Func == 2) {
		protocol << "   Drag and lift coefficients at car contour:\n";
		protocol << "     c_d: " << std::setprecision(12) << dfw1 << "\n";
		protocol << "     c_l: " << std::setprecision(12) << daw1 << "\n\n";
	    } else if (Param->Func == 5) {
		protocol << "   Drag and lift coefficients at cylinder are:\n";
		protocol << "     c_d: " << std::setprecision(12) << dfw1 << "\n";
		protocol << "     c_l: " << std::setprecision(12) << daw1 << "\n\n";
	    } else {
		protocol << "   Drag and lift coefficients are:\n";
		protocol << "     c_d: " << std::setprecision(12) << dfw1 << "\n";
		protocol << "     c_l: " << std::setprecision(12) << daw1 << "\n\n";
	    }
        }

        // Write solution for restart purposes to file.
	// Within the last iteration force writing a solution file.
        if (ITE % Param->SolFileFrequency == 0  ||
	    DTime >= Param->TEnd                ||
	    ITE == Param->MaxTimeIterations) {
            currentSolFileNr = currentSolFileNr % Param->SolFileNumber + 1;
	    protocol << "   Writing solution (in raw format for restart purposes) to disk. "; protocol.mFlush();
	    if (Debug) protocol << '\n';
            WriteSolution(currentSolFileNr, DTime, Param->Dt);
#ifdef INCLUDE_TEMPERATURE
            //WriteSolutionBouss(DTime,Param->Dt,ITE);
#endif
	    if (Debug) protocol << "   ";
	    protocol << "Done.\n\n"; protocol.mFlush();
        }

        // Compute and print time statistics
	protocol << "   Elapsed simulated time: "
		 << timeval_to_string(DTime);
	if (DTime  <  0.1) {
	    protocol << "  (" << double_to_string(DTime, "e", 4) << "s)";
	}
        protocol << "\n   Elapsed computing time: "
		 << timeval_to_string(GlobalTime->GetTimeDiff()) << "\n";

        // Write every xx seconds (absolute time) a solution to disk.
        if (Param->AVSOutputLevel > 0  &&  (DTime - timeLastAVSOutput) >= Param->DtAVS) {
	    protocol << "   Writing solution (in avs format) to disk. "; protocol.mFlush();
	    if (Debug) protocol << '\n';
            AVSOutput(Sol1, Sol2, Sol3, P, Conc, &RotElem, Param->AVSOutputLevel, outfileCounterAVS);
	    if (Debug) protocol << "   ";
	    protocol << "Done.\n"; protocol.mFlush();
            timeLastAVSOutput = DTime;
            outfileCounterAVS++;
        }
        if (Param->GMVOutputLevel > 0  &&  (DTime - timeLastGMVOutput) >= Param->DtGMV) {
	    protocol << "   Writing solution (in gmv format) to disk. "; protocol.mFlush();
	    if (Debug) protocol << '\n';
            GMVOutput(Sol1, Sol2, Sol3, P, Conc, &RotElem, Param->GMVOutputLevel, outfileCounterGMV, DTime);
	    if (Debug) protocol << "   ";
	    protocol << "Done.\n"; protocol.mFlush();
            timeLastGMVOutput = DTime;
            outfileCounterGMV++;
        }

        Prot << "timeITE="<< DTime <<"\n";

	// Endpoint in time reached? 
	// Or very low time derivate (i.e. stationary limit reached)?
  	if (Param->TEnd - DTime < 1e-10  ||  timederivate < Param->EpsNS)
	    break;

        Prot.Flush();
        protocol << "\n\n";

	// Print timings every 10 iterations
	if (ITE % 2 == 0) {
    	    PrintTimeStatistics();
	    protocol << "\n\n";
	}
    } // end time iteration loop

    delete Sol1;
    delete Sol2;
    delete Sol3;
    delete f1;
    delete f2;
    delete f3;
    delete w1;
    delete defect1;
    delete neumann1;
    delete q;
    delete P;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::DiscreteProjection.\n";
        protocol.mFlush();
    }

   return;
}
