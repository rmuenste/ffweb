#include "Task.h"

double PHIP(double x) {return (0.5+x)/(1.0+x);}
double PHIM(double x) {return 0.5/(1.0-x);}

extern Output PDIFF;

VOID Task::UpWind(FiniteElement_3D& Elem,MultiCompactMatrix& A,
                  DoubleVector& u1,
                  DoubleVector& u2,DoubleVector& u3,
                  double UPSAM)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::UpWind.\n";
        protocol.mFlush();
    }

    INTEGER 	ILEV;
    DoubleCompactMatrix *LA;

    DoubleVector *w1[MAXARRAY];
    DoubleVector *w2[MAXARRAY];
    DoubleVector *w3[MAXARRAY];

    w1[MaxLevel]=&u1;
    w2[MaxLevel]=&u2;
    w3[MaxLevel]=&u3;

    for (ILEV = MaxLevel; ILEV >= MinLevel; ILEV--) {
        SetLevel(ILEV);

//    SetBoundRight(w1[ILEV]);
//    SetBoundRight(w2[ILEV]);
//    SetBoundRight(w3[ILEV]);

        LA=A[ILEV];
        UpWind(*LA,*(w1[ILEV]),*(w2[ILEV]),*(w3[ILEV]), UPSAM);

        if (ILEV == MinLevel)
            CommunicateUpwind(w1[ILEV],w2[ILEV],w3[ILEV]);

        if (ILEV != MinLevel) {
            w1[ILEV - 1] = new DoubleVector(MNumEquations[ILEV - 1]);
            w2[ILEV - 1] = new DoubleVector(MNumEquations[ILEV - 1]);
            w3[ILEV - 1] = new DoubleVector(MNumEquations[ILEV - 1]);

            Elem.Restrict(w1[ILEV],w1[ILEV-1],
                          MVertElem[ILEV],MVertElem[ILEV-1],
                          MMidFaces[ILEV],MMidFaces[ILEV-1],
                          MNeighElem[ILEV],MNeighElem[ILEV-1],
                          MNumVertices[ILEV],MNumVertices[ILEV-1],
                          MNumElements[ILEV],MNumElements[ILEV-1]);
            Elem.Restrict(w2[ILEV],w2[ILEV-1],
                          MVertElem[ILEV],MVertElem[ILEV-1],
                          MMidFaces[ILEV],MMidFaces[ILEV-1],
                          MNeighElem[ILEV],MNeighElem[ILEV-1],
                          MNumVertices[ILEV],MNumVertices[ILEV-1],
                          MNumElements[ILEV],MNumElements[ILEV-1]);
            Elem.Restrict(w3[ILEV],w3[ILEV-1],
                          MVertElem[ILEV],MVertElem[ILEV-1],
                          MMidFaces[ILEV],MMidFaces[ILEV-1],
                          MNeighElem[ILEV],MNeighElem[ILEV-1],
                          MNumVertices[ILEV],MNumVertices[ILEV-1],
                          MNumElements[ILEV],MNumElements[ILEV-1]);
            if (ILEV != MaxLevel) {
                delete w1[ILEV];
                delete w2[ILEV];
                delete w3[ILEV];
            }
        }
    }
    delete w1[MinLevel];
    delete w2[MinLevel];
    delete w3[MinLevel];

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::UpWind.\n";
        protocol.mFlush();
    }
}

VOID Task::UpWind(DoubleCompactMatrix& LA,DoubleVector& u1,DoubleVector& u2,DoubleVector& u3,
                  double UPSAM)
{
    double RE=1.0/Param->EpsEqu;

    int IEL,II,IVT,IAR,IV1,IV2,IV3,IV4,IA1,IA2,IA,JJ,JAR,IM0,I;
    double XE,YE,ZE,XNHH,YNHH,ZNHH,DINN,DNFACT,DMEAN;
    DoubleArray2D XN(4,6),YN(4,6),ZN(4,6),DLEN(4,6),UMEAN1(4,6),UMEAN2(4,6),UMEAN3(4,6);
    double XV[9],YV[9],ZV[9],H1,H2,H3,H4,ELMH,XA[7],YA[7],ZA[7];
    double XVE[9],YVE[9],ZVE[9],FLUX[5],DLAM[5],UU1[7],UU2[7],UU3[7];
    int IAREA[7],IM[5];
    IntArray2D ISTORE(6,6);
    DoubleArray2D ELMA(6,6);

    for (IEL=1;IEL<=NumElements;IEL++) {
// *** XE,YE,ZE will be coordinates of the center of the element
        XE=0.0;
        YE=0.0;
        ZE=0.0;
//-----------------------------------------------------------------------
// *** 1. Loop over all 8 vertices
//
        for (II=1;II<=8;II++) {
            IVT=(*VertElem)(II,IEL);
            XV[II]=(*VertCoord)(1,IVT);
            YV[II]=(*VertCoord)(2,IVT);
            ZV[II]=(*VertCoord)(3,IVT);
            XE=XE+XV[II];
            YE=YE+YV[II];
            ZE=ZE+ZV[II];
        }

        XE=0.125*XE;
        YE=0.125*YE;
        ZE=0.125*ZE;

        for (II=1;II<=8;II++) {
            XVE[II]=XV[II]-XE;
            YVE[II]=YV[II]-YE;
            ZVE[II]=ZV[II]-ZE;
        }
//
//-----------------------------------------------------------------------
// *** 2. Loop over all 6 U-nodes
//
        for (II=1;II<=6;II++) {
            IAR=(*MidFaces)(II,IEL);
            IAREA[II]=IAR;

            if (II == 1) {
                IV1 = 1;
                IV2 = 2;
                IV3 = 3;
                IV4 = 4;
                XA[II] = (XV[IV1] + XV[IV2] + XV[IV3] + XV[IV4]) * 0.25;
                YA[II] = (YV[IV1] + YV[IV2] + YV[IV3] + YV[IV4]) * 0.25;
                ZA[II] = (ZV[IV1] + ZV[IV2] + ZV[IV3] + ZV[IV4]) * 0.25;
            }

            if (II == 2) {
                IV1 = 1;
                IV2 = 2;
                IV3 = 6;
                IV4 = 5;
                XA[II] = (XV[IV1] + XV[IV2] + XV[IV3] + XV[IV4]) * 0.25;
                YA[II] = (YV[IV1] + YV[IV2] + YV[IV3] + YV[IV4]) * 0.25;
                ZA[II] = (ZV[IV1] + ZV[IV2] + ZV[IV3] + ZV[IV4]) * 0.25;
            }

            UU1[II] = u1(IAR);
            UU2[II] = u2(IAR);
            UU3[II] = u3(IAR);
        }

//-----------------------------------------------------------------------
// *** 3. Loop over all 6 U-nodes
//
        for (II=1;II<=6;II++) {
            IAR=IAREA[II];
            IA1=LA.Diag(IAR);
            IA2=LA.Diag(IAR+1)-1;

            for (JJ=1;JJ<=6;JJ++) {
                JAR=IAREA[JJ];

                for (IA=IA1;IA<=IA2;IA++) {
                    if (LA.Col(IA)==JAR)
                        break;
                }
                if (IA > IA2) {
		    protocol << progname << " (process " << MyProcID << "):\n"
			     << "  Error in Task::UpWind.\n"
			     << "  entry index IA not found !! IA="<<IA<<" IA1="<<IA1<<" IA2="<<IA2<<" JAR="<<JAR<<" IAR="<<IAR<<"\n";
//                      for (int i=1;i<=LA.GetNumDiag();i++) {
//                          Err<<"LA.Diag("<<i<<")="<<LA.Diag(i)<<"\n";
//                      }
                    protocol << "  LA.Diag("<<IAR<<")="<<LA.Diag(IAR)<<"\n";
                    protocol << "  LA.Diag("<<IAR+1<<")="<<LA.Diag(IAR+1)<<"\n"
			     << "  Program aborted in Task::Upwind\n";
		    MPI_Abort(MPI_COMM_WORLD, IA_NOT_FOUND);
                } else {
                    ISTORE(II,JJ)=IA;
                    ELMA(II,JJ)=0.0;
                }
            }
        }

        XN(1, 1) = YVE[1] * ZVE[2] - ZVE[1] * YVE[2];
        YN(1, 1) = ZVE[1] * XVE[2] - XVE[1] * ZVE[2];
        ZN(1, 1) = XVE[1] * YVE[2] - YVE[1] * XVE[2];

        XNHH = XA[2] - XA[1];
        YNHH = YA[2] - YA[1];
        ZNHH = ZA[2] - ZA[1];
        DINN = XN(1, 1) * XNHH + YN(1, 1) * YNHH + ZN(1, 1) * ZNHH;
        if (DINN < 0.0)
            DNFACT = -1.0;
        else
            DNFACT= 1.0;

        if (DNFACT < 0.0) {
            XN(1, 1) = -XN(1, 1);
            YN(1, 1) = -YN(1, 1);
            ZN(1, 1) = -ZN(1, 1);
        }

        XN(2,1)=DNFACT*(YVE[2]*ZVE[3]-ZVE[2]*YVE[3]);
        YN(2,1)=DNFACT*(ZVE[2]*XVE[3]-XVE[2]*ZVE[3]);
        ZN(2,1)=DNFACT*(XVE[2]*YVE[3]-YVE[2]*XVE[3]);

        XN(3,1)= DNFACT*(YVE[3]*ZVE[4]-ZVE[3]*YVE[4]);
        YN(3,1)= DNFACT*(ZVE[3]*XVE[4]-XVE[3]*ZVE[4]);
        ZN(3,1)= DNFACT*(XVE[3]*YVE[4]-YVE[3]*XVE[4]);

        XN(4,1)= DNFACT*(YVE[4]*ZVE[1]-ZVE[4]*YVE[1]);
        YN(4,1)= DNFACT*(ZVE[4]*XVE[1]-XVE[4]*ZVE[1]);
        ZN(4,1)= DNFACT*(XVE[4]*YVE[1]-YVE[4]*XVE[1]);

        XN(1,2)=-XN(1,1);
        YN(1,2)=-YN(1,1);
        ZN(1,2)=-ZN(1,1);

        XN(2,2)=-DNFACT*(YVE[2]*ZVE[6]-ZVE[2]*YVE[6]);
        YN(2,2)=-DNFACT*(ZVE[2]*XVE[6]-XVE[2]*ZVE[6]);
        ZN(2,2)=-DNFACT*(XVE[2]*YVE[6]-YVE[2]*XVE[6]);

        XN(3,2)=-DNFACT*(YVE[6]*ZVE[5]-ZVE[6]*YVE[5]);
        YN(3,2)=-DNFACT*(ZVE[6]*XVE[5]-XVE[6]*ZVE[5]);
        ZN(3,2)=-DNFACT*(XVE[6]*YVE[5]-YVE[6]*XVE[5]);

        XN(4,2)=-DNFACT*(YVE[5]*ZVE[1]-ZVE[5]*YVE[1]);
        YN(4,2)=-DNFACT*(ZVE[5]*XVE[1]-XVE[5]*ZVE[1]);
        ZN(4,2)=-DNFACT*(XVE[5]*YVE[1]-YVE[5]*XVE[1]);

        XN(1,3)=-XN(2,1);
        YN(1,3)=-YN(2,1);
        ZN(1,3)=-ZN(2,1);

        XN(2,3)=-DNFACT*(YVE[3]*ZVE[7]-ZVE[3]*YVE[7]);
        YN(2,3)=-DNFACT*(ZVE[3]*XVE[7]-XVE[3]*ZVE[7]);
        ZN(2,3)=-DNFACT*(XVE[3]*YVE[7]-YVE[3]*XVE[7]);

        XN(3,3)=-DNFACT*(YVE[7]*ZVE[6]-ZVE[7]*YVE[6]);
        YN(3,3)=-DNFACT*(ZVE[7]*XVE[6]-XVE[7]*ZVE[6]);
        ZN(3,3)=-DNFACT*(XVE[7]*YVE[6]-YVE[7]*XVE[6]);

        XN(4,3)=-XN(2,2);
        YN(4,3)=-YN(2,2);
        ZN(4,3)=-ZN(2,2);

        XN(1,4)=-XN(3,1);
        YN(1,4)=-YN(3,1);
        ZN(1,4)=-ZN(3,1);

        XN(2,4)=-DNFACT*(YVE[4]*ZVE[8]-ZVE[4]*YVE[8]);
        YN(2,4)=-DNFACT*(ZVE[4]*XVE[8]-XVE[4]*ZVE[8]);
        ZN(2,4)=-DNFACT*(XVE[4]*YVE[8]-YVE[4]*XVE[8]);

        XN(3,4)=-DNFACT*(YVE[8]*ZVE[7]-ZVE[8]*YVE[7]);
        YN(3,4)=-DNFACT*(ZVE[8]*XVE[7]-XVE[8]*ZVE[7]);
        ZN(3,4)=-DNFACT*(XVE[8]*YVE[7]-YVE[8]*XVE[7]);

        XN(4,4)=-XN(2,3);
        YN(4,4)=-YN(2,3);
        ZN(4,4)=-ZN(2,3);

        XN(1,5)=-XN(4,1);
        YN(1,5)=-YN(4,1);
        ZN(1,5)=-ZN(4,1);

        XN(2,5)=-XN(4,2);
        YN(2,5)=-YN(4,2);
        ZN(2,5)=-ZN(4,2);

        XN(3,5)=-DNFACT*(YVE[5]*ZVE[8]-ZVE[5]*YVE[8]);
        YN(3,5)=-DNFACT*(ZVE[5]*XVE[8]-XVE[5]*ZVE[8]);
        ZN(3,5)=-DNFACT*(XVE[5]*YVE[8]-YVE[5]*XVE[8]);

        XN(4,5)=-XN(2,4);
        YN(4,5)=-YN(2,4);
        ZN(4,5)=-ZN(2,4);

        XN(1,6)=-XN(3,2);
        YN(1,6)=-YN(3,2);
        ZN(1,6)=-ZN(3,2);

        XN(2,6)=-XN(3,5);
        YN(2,6)=-YN(3,5);
        ZN(2,6)=-ZN(3,5);

        XN(3,6)=-XN(3,4);
        YN(3,6)=-YN(3,4);
        ZN(3,6)=-ZN(3,4);

        XN(4,6)=-XN(3,3);
        YN(4,6)=-YN(3,3);
        ZN(4,6)=-ZN(3,3);

        DLEN(1,1)=sqrt(pow(XN(1,1),2)+pow(YN(1,1),2)+pow(ZN(1,1),2));
        DLEN(2,1)=sqrt(pow(XN(2,1),2)+pow(YN(2,1),2)+pow(ZN(2,1),2));
        DLEN(3,1)=sqrt(pow(XN(3,1),2)+pow(YN(3,1),2)+pow(ZN(3,1),2));
        DLEN(4,1)=sqrt(pow(XN(4,1),2)+pow(YN(4,1),2)+pow(ZN(4,1),2));

        DLEN(1,2)=DLEN(1,1);
        DLEN(2,2)=sqrt(pow(XN(2,2),2)+pow(YN(2,2),2)+pow(ZN(2,2),2));
        DLEN(3,2)=sqrt(pow(XN(3,2),2)+pow(YN(3,2),2)+pow(ZN(3,2),2));
        DLEN(4,2)=sqrt(pow(XN(4,2),2)+pow(YN(4,2),2)+pow(ZN(4,2),2));

        DLEN(1,3)=DLEN(2,1);
        DLEN(2,3)=sqrt(pow(XN(2,3),2)+pow(YN(2,3),2)+pow(ZN(2,3),2));
        DLEN(3,3)=sqrt(pow(XN(3,3),2)+pow(YN(3,3),2)+pow(ZN(3,3),2));
        DLEN(4,3)=DLEN(2,2);

        DLEN(1,4)=DLEN(3,1);
        DLEN(2,4)=sqrt(pow(XN(2,4),2)+pow(YN(2,4),2)+pow(ZN(2,4),2));
        DLEN(3,4)=sqrt(pow(XN(3,4),2)+pow(YN(3,4),2)+pow(ZN(3,4),2));
        DLEN(4,4)=DLEN(2,3);

        DLEN(1,5)=DLEN(4,1);
        DLEN(2,5)=DLEN(4,2);
        DLEN(3,5)=sqrt(pow(XN(3,5),2)+pow(YN(3,5),2)+pow(ZN(3,5),2));
        DLEN(4,5)=DLEN(4,4);

        DLEN(1,6)=DLEN(3,2);
        DLEN(2,6)=DLEN(3,5);
        DLEN(3,6)=DLEN(3,4);
        DLEN(4,6)=DLEN(3,3);


        DMEAN=0.5;

        UMEAN1(1,1)=DMEAN*(UU1[2]+UU1[1]);
        UMEAN2(1,1)=DMEAN*(UU2[2]+UU2[1]);
        UMEAN3(1,1)=DMEAN*(UU3[2]+UU3[1]);

        UMEAN1(2,1)=DMEAN*(UU1[3]+UU1[1]);
        UMEAN2(2,1)=DMEAN*(UU2[3]+UU2[1]);
        UMEAN3(2,1)=DMEAN*(UU3[3]+UU3[1]);

        UMEAN1(3,1)=DMEAN*(UU1[4]+UU1[1]);
        UMEAN2(3,1)=DMEAN*(UU2[4]+UU2[1]);
        UMEAN3(3,1)=DMEAN*(UU3[4]+UU3[1]);

        UMEAN1(4,1)=DMEAN*(UU1[5]+UU1[1]);
        UMEAN2(4,1)=DMEAN*(UU2[5]+UU2[1]);
        UMEAN3(4,1)=DMEAN*(UU3[5]+UU3[1]);

        UMEAN1(1,2)=UMEAN1(1,1);
        UMEAN2(1,2)=UMEAN2(1,1);
        UMEAN3(1,2)=UMEAN3(1,1);

        UMEAN1(2,2)=DMEAN*(UU1[3]+UU1[2]);
        UMEAN2(2,2)=DMEAN*(UU2[3]+UU2[2]);
        UMEAN3(2,2)=DMEAN*(UU3[3]+UU3[2]);

        UMEAN1(3,2)=DMEAN*(UU1[6]+UU1[2]);
        UMEAN2(3,2)=DMEAN*(UU2[6]+UU2[2]);
        UMEAN3(3,2)=DMEAN*(UU3[6]+UU3[2]);

        UMEAN1(4,2)=DMEAN*(UU1[5]+UU1[2]);
        UMEAN2(4,2)=DMEAN*(UU2[5]+UU2[2]);
        UMEAN3(4,2)=DMEAN*(UU3[5]+UU3[2]);

        UMEAN1(1,3)=UMEAN1(2,1);
        UMEAN2(1,3)=UMEAN2(2,1);
        UMEAN3(1,3)=UMEAN3(2,1);

        UMEAN1(2,3)=DMEAN*(UU1[4]+UU1[3]);
        UMEAN2(2,3)=DMEAN*(UU2[4]+UU2[3]);
        UMEAN3(2,3)=DMEAN*(UU3[4]+UU3[3]);

        UMEAN1(3,3)=DMEAN*(UU1[6]+UU1[3]);
        UMEAN2(3,3)=DMEAN*(UU2[6]+UU2[3]);
        UMEAN3(3,3)=DMEAN*(UU3[6]+UU3[3]);

        UMEAN1(4,3)=UMEAN1(2,2);
        UMEAN2(4,3)=UMEAN2(2,2);
        UMEAN3(4,3)=UMEAN3(2,2);

        UMEAN1(1,4)=UMEAN1(3,1);
        UMEAN2(1,4)=UMEAN2(3,1);
        UMEAN3(1,4)=UMEAN3(3,1);

        UMEAN1(2,4)=DMEAN*(UU1[5]+UU1[4]);
        UMEAN2(2,4)=DMEAN*(UU2[5]+UU2[4]);
        UMEAN3(2,4)=DMEAN*(UU3[5]+UU3[4]);

        UMEAN1(3,4)=DMEAN*(UU1[6]+UU1[4]);
        UMEAN2(3,4)=DMEAN*(UU2[6]+UU2[4]);
        UMEAN3(3,4)=DMEAN*(UU3[6]+UU3[4]);

        UMEAN1(4,4)=UMEAN1(2,3);
        UMEAN2(4,4)=UMEAN2(2,3);
        UMEAN3(4,4)=UMEAN3(2,3);

        UMEAN1(1,5)=UMEAN1(4,1);
        UMEAN2(1,5)=UMEAN2(4,1);
        UMEAN3(1,5)=UMEAN3(4,1);

        UMEAN1(2,5)=UMEAN1(4,2);
        UMEAN2(2,5)=UMEAN2(4,2);
        UMEAN3(2,5)=UMEAN3(4,2);

        UMEAN1(3,5)=DMEAN*(UU1[6]+UU1[5]);
        UMEAN2(3,5)=DMEAN*(UU2[6]+UU2[5]);
        UMEAN3(3,5)=DMEAN*(UU3[6]+UU3[5]);

        UMEAN1(4,5)=UMEAN1(2,4);
        UMEAN2(4,5)=UMEAN2(2,4);
        UMEAN3(4,5)=UMEAN3(2,4);

        UMEAN1(1,6)=UMEAN1(3,2);
        UMEAN2(1,6)=UMEAN2(3,2);
        UMEAN3(1,6)=UMEAN3(3,2);

        UMEAN1(2,6)=UMEAN1(3,5);
        UMEAN2(2,6)=UMEAN2(3,5);
        UMEAN3(2,6)=UMEAN3(3,5);

        UMEAN1(3,6)=UMEAN1(3,4);
        UMEAN2(3,6)=UMEAN2(3,4);
        UMEAN3(3,6)=UMEAN3(3,4);

        UMEAN1(4,6)=UMEAN1(3,3);
        UMEAN2(4,6)=UMEAN2(3,3);
        UMEAN3(4,6)=UMEAN3(3,3);

        for (II=1;II<=6;II++) {
            IM0=II;
            if (II==1) {
                IM[1]=2;
                IM[2]=3;
                IM[3]=4;
                IM[4]=5;
            }

            if (II==2) {
                IM[1]=1;
                IM[2]=3;
                IM[3]=6;
                IM[4]=5;
            }

            if (II==3) {
                IM[1]=1;
                IM[2]=4;
                IM[3]=6;
                IM[4]=2;
            }

            if (II==4) {
                IM[1]=1;
                IM[2]=5;
                IM[3]=6;
                IM[4]=3;
            }

            if (II==5) {
                IM[1]=1;
                IM[2]=2;
                IM[3]=6;
                IM[4]=4;
            }

            if (II==6) {
                IM[1]=2;
                IM[2]=5;
                IM[3]=4;
                IM[4]=3;
            }

            for (I=1;I<=4;I++) {
                FLUX[I]=0.5*(XN(I,II)*UMEAN1(I,II)+YN(I,II)*UMEAN2(I,II)+ZN(I,II)*UMEAN3(I,II));

                if (UPSAM>=0.0) {
                    if (FLUX[I]>=0.0)
                        DLAM[I]=PHIP(UPSAM*RE*FLUX[I]/sqrt(DLEN(I,II)));
                    else
                        DLAM[I]=PHIM(UPSAM*RE*FLUX[I]/sqrt(DLEN(I,II)));
                } else {
                    DLAM[I]=0.0;
                    if (FLUX[I]>=0.0)
                        DLAM[I]=1.0;
                }
            }
            H1=FLUX[1]*(1.0-DLAM[1]);
            H2=FLUX[2]*(1.0-DLAM[2]);
            H3=FLUX[3]*(1.0-DLAM[3]);
            H4=FLUX[4]*(1.0-DLAM[4]);
            ELMA(IM0,IM0)  =-H1-H2-H3-H4;
            ELMA(IM0,IM[1])= H1;
            ELMA(IM0,IM[2])= H2;
            ELMA(IM0,IM[3])= H3;
            ELMA(IM0,IM[4])= H4;
        }

//-----------------------------------------------------------------------
// *** 4. Loop over all 4 U-nodes:  Addding ELMA(.,.) to matrix A
//
        for (II=1;II<=6;II++) {
            for (JJ=1;JJ<=6;JJ++) {
                ELMH=ELMA(II,JJ);
                if (fabs(ELMH)>1e-15) {
                    IA=ISTORE(II,JJ);
                    LA.Data(IA)+=ELMH;
                }
            }
        }
    }
}


void Task::CalcAspectRatio()
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CalcAspectRatio.\n";
        protocol.mFlush();
    }

    int    I1,I2,I3,I4,I5,I6,I7,I8;
    double X1,X2,X3,X4,X5,X6,X7,X8;
    double Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8;
    double Z1,Z2,Z3,Z4,Z5,Z6,Z7,Z8;

    double XM1,XM2,XM3,XM4,XM5,XM6;
    double YM1,YM2,YM3,YM4,YM5,YM6;
    double ZM1,ZM2,ZM3,ZM4,ZM5,ZM6;
    double length1, length2, length3;
    double ar, ar_min, ar_max, ar_sum;

    ar = ar_sum = 0;
    ar_min = DBL_MAX;
    ar_max = DBL_MIN;

    protocol << "\n Calculating aspect ratios:\n\n";
    protocol << "    level |    max     |    min     |    mean  \n";
    protocol << "   -------+------------+------------+------------\n";
    protocol.mFlush();

//      for (unsigned int ILEV = MaxLevel;  ILEV >= MinLevel;  ILEV--) {
    for (unsigned int ILEV = MinLevel;  ILEV <= MaxLevel;  ILEV++) {
        SetLevel(ILEV);

//  	protocol << "\n Level " <<  ILEV << ":\n";
	ar = ar_sum = 0;
	for (unsigned int IEL = 1;  IEL <= NumElements;  IEL++) {
	    I1 = (*VertElem)(1, IEL);
	    I2 = (*VertElem)(2, IEL);
	    I3 = (*VertElem)(3, IEL);
	    I4 = (*VertElem)(4, IEL);
	    I5 = (*VertElem)(5, IEL);
	    I6 = (*VertElem)(6, IEL);
	    I7 = (*VertElem)(7, IEL);
	    I8 = (*VertElem)(8, IEL);

	    // x-, y- and z-coordinates of all vertices of current element
	    X1 = (*VertCoord)(1, I1);
	    X2 = (*VertCoord)(1, I2);
	    X3 = (*VertCoord)(1, I3);
	    X4 = (*VertCoord)(1, I4);
	    X5 = (*VertCoord)(1, I5);
	    X6 = (*VertCoord)(1, I6);
	    X7 = (*VertCoord)(1, I7);
	    X8 = (*VertCoord)(1, I8);

            Y1 = (*VertCoord)(2, I1);
            Y2 = (*VertCoord)(2, I2);
            Y3 = (*VertCoord)(2, I3);
            Y4 = (*VertCoord)(2, I4);
            Y5 = (*VertCoord)(2, I5);
            Y6 = (*VertCoord)(2, I6);
            Y7 = (*VertCoord)(2, I7);
            Y8 = (*VertCoord)(2, I8);

            Z1 = (*VertCoord)(3, I1);
            Z2 = (*VertCoord)(3, I2);
            Z3 = (*VertCoord)(3, I3);
            Z4 = (*VertCoord)(3, I4);
            Z5 = (*VertCoord)(3, I5);
            Z6 = (*VertCoord)(3, I6);
            Z7 = (*VertCoord)(3, I7);
            Z8 = (*VertCoord)(3, I8);

	    // x-, y- and z-coordinates of midpoints of each face
	    XM1 = (X1 + X2 + X5 + X6) / 4;
	    YM1 = (Y1 + Y2 + Y5 + Y6) / 4;
	    ZM1 = (Z1 + Z2 + Z5 + Z6) / 4;
	    XM2 = (X3 + X4 + X7 + X8) / 4;
	    YM2 = (Y3 + Y4 + Y7 + Y8) / 4;
	    ZM2 = (Z3 + Z4 + Z7 + Z8) / 4;
	    XM3 = (X4 + X1 + X8 + X5) / 4;
	    YM3 = (Y4 + Y1 + Y8 + Y5) / 4;
	    ZM3 = (Z4 + Z1 + Z8 + Z5) / 4;
	    XM4 = (X2 + X3 + X6 + X7) / 4;
	    YM4 = (Y2 + Y3 + Y6 + Y7) / 4;
	    ZM4 = (Z2 + Z3 + Z6 + Z7) / 4;
	    XM5 = (X8 + X5 + X7 + X6) / 4;
	    YM5 = (Y8 + Y5 + Y7 + Y6) / 4;
	    ZM5 = (Z8 + Z5 + Z7 + Z6) / 4;
	    XM6 = (X3 + X2 + X4 + X1) / 4;
	    YM6 = (Y3 + Y2 + Y4 + Y1) / 4;
	    ZM6 = (Z3 + Z2 + Z4 + Z1) / 4;

	    length1 = (XM1 - XM2)*(XM1 - XM2) + (YM1 - YM2)*(YM1 - YM2) + (ZM1 - ZM2)*(ZM1 - ZM2);
	    length2 = (XM3 - XM4)*(XM3 - XM4) + (YM3 - YM4)*(YM3 - YM4) + (ZM3 - ZM4)*(ZM3 - ZM4);
	    length3 = (XM5 - XM6)*(XM5 - XM6) + (YM5 - YM6)*(YM5 - YM6) + (ZM5 - ZM6)*(ZM5 - ZM6);

	    ar = sqrt(MAX3(length1, length2, length3) / MIN3(length1, length2, length3));

	    ar_min = MIN(ar, ar_min);
	    ar_max = MAX(ar, ar_max);
	    ar_sum += ar;
	} // end loop over all elements

        protocol << "    " << std::setw(3) << std::setfill(' ') << ILEV << "   |"
                 << " "    << std::setw(3) << double_to_string(ar_max, "e", 2) << "  |"
                 << " "    << std::setw(3) << double_to_string(ar_min, "e", 2) << "  |"
                 << " "    << std::setw(3) << double_to_string(ar_sum / NumElements, "e", 2) << "\n";
        protocol.mFlush();
    } // end loop over grid hierarchy

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CalcAspectRatio.\n";
        protocol.mFlush();
    }
}

void Task::CalcAnisotropyDegree()
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CalcAnisotropyDegree.\n";
        protocol.mFlush();
    }

    int    I1,I2,I3,I4,I5,I6,I7,I8;
    double X1,X2,X3,X4,X5,X6,X7,X8;
    double Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8;
    double Z1,Z2,Z3,Z4,Z5,Z6,Z7,Z8;

    double XM1,XM2,XM3,XM4,XM5,XM6;
    double YM1,YM2,YM3,YM4,YM5,YM6;
    double ZM1,ZM2,ZM3,ZM4,ZM5,ZM6;
    double length1, length2, length3;
    double ar, ar_max, ar_sum;
//  double ar_min;

    int    IVT1, IVT2, IVT3, IVT4;
    double PX1, PX2, PX3, PX4;
    double PY1, PY2, PY3, PY4;
    double PZ1, PZ2, PZ3, PZ4;
    double a, b, c, h1, h2, g;
    double sv, sv_max, sv_sum;
    double kv1, kv2, kv_max, kv_sum;
    double k_max, k_min, ar_rannacher_max;	  // l�ngste und k�rzeste Kante, Rannacher-Definition von Aspect ratio

    // Which number have the four vertices of a face?
    IntArray2D KIAD(4,6);
    KIAD(1, 1) = 1;
    KIAD(2, 1) = 2;
    KIAD(3, 1) = 3;
    KIAD(4, 1) = 4;
    KIAD(1, 2) = 1;
    KIAD(2, 2) = 2;
    KIAD(3, 2) = 6;
    KIAD(4, 2) = 5;
    KIAD(1, 3) = 2;
    KIAD(2, 3) = 3;
    KIAD(3, 3) = 7;
    KIAD(4, 3) = 6;
    KIAD(1, 4) = 3;
    KIAD(2, 4) = 4;
    KIAD(3, 4) = 8;
    KIAD(4, 4) = 7;
    KIAD(1, 5) = 4;
    KIAD(2, 5) = 1;
    KIAD(3, 5) = 5;
    KIAD(4, 5) = 8;
    KIAD(1, 6) = 5;
    KIAD(2, 6) = 6;
    KIAD(3, 6) = 7;
    KIAD(4, 6) = 8;
    DoubleArray area(6);

    protocol << "\n Calculating anisotropy degree:\n\n";
    protocol << "    level |   ar_max   |   sv_max   |   kv_max          ar_mean   |  sv_mean   |  kv_mean\n";
    protocol << "   -------+------------+------------+------------     ------------+------------+-----------\n";
    protocol.mFlush();

    for (unsigned int ILEV = MinLevel;  ILEV <= MaxLevel;  ILEV++) {
//      for (unsigned int ILEV = MinLevel;  ILEV <= MinLevel;  ILEV++) {
        SetLevel(ILEV);

	ar = ar_sum = 0;
	sv = sv_sum = 0;
	kv1 = kv2 = kv_sum = 0;
	ar_max = DBL_MIN; // ar_min = DBL_MAX;
	sv_max = DBL_MIN;
	kv_max = DBL_MIN;
	ar_rannacher_max = DBL_MIN;

  	for (unsigned int IEL = 1;  IEL <= NumElements;  IEL++) {
//  	    protocol << "    " << std::setw(3) << setfill(' ') << ILEV << "   |";

	    // ==============================
	    // Start calculating aspect ratio
	    I1 = (*VertElem)(1, IEL);
	    I2 = (*VertElem)(2, IEL);
	    I3 = (*VertElem)(3, IEL);
	    I4 = (*VertElem)(4, IEL);
	    I5 = (*VertElem)(5, IEL);
	    I6 = (*VertElem)(6, IEL);
	    I7 = (*VertElem)(7, IEL);
	    I8 = (*VertElem)(8, IEL);

	    // x-, y- and z-coordinates of all vertices of current element
	    X1 = (*VertCoord)(1, I1);
	    X2 = (*VertCoord)(1, I2);
	    X3 = (*VertCoord)(1, I3);
	    X4 = (*VertCoord)(1, I4);
	    X5 = (*VertCoord)(1, I5);
	    X6 = (*VertCoord)(1, I6);
	    X7 = (*VertCoord)(1, I7);
	    X8 = (*VertCoord)(1, I8);

            Y1 = (*VertCoord)(2, I1);
            Y2 = (*VertCoord)(2, I2);
            Y3 = (*VertCoord)(2, I3);
            Y4 = (*VertCoord)(2, I4);
            Y5 = (*VertCoord)(2, I5);
            Y6 = (*VertCoord)(2, I6);
            Y7 = (*VertCoord)(2, I7);
            Y8 = (*VertCoord)(2, I8);

            Z1 = (*VertCoord)(3, I1);
            Z2 = (*VertCoord)(3, I2);
            Z3 = (*VertCoord)(3, I3);
            Z4 = (*VertCoord)(3, I4);
            Z5 = (*VertCoord)(3, I5);
            Z6 = (*VertCoord)(3, I6);
            Z7 = (*VertCoord)(3, I7);
            Z8 = (*VertCoord)(3, I8);

	    // x-, y- and z-coordinates of midpoints of each face
	    XM1 = (X1 + X2 + X5 + X6) / 4;
	    YM1 = (Y1 + Y2 + Y5 + Y6) / 4;
	    ZM1 = (Z1 + Z2 + Z5 + Z6) / 4;
	    XM2 = (X3 + X4 + X7 + X8) / 4;
	    YM2 = (Y3 + Y4 + Y7 + Y8) / 4;
	    ZM2 = (Z3 + Z4 + Z7 + Z8) / 4;
	    XM3 = (X4 + X1 + X8 + X5) / 4;
	    YM3 = (Y4 + Y1 + Y8 + Y5) / 4;
	    ZM3 = (Z4 + Z1 + Z8 + Z5) / 4;
	    XM4 = (X2 + X3 + X6 + X7) / 4;
	    YM4 = (Y2 + Y3 + Y6 + Y7) / 4;
	    ZM4 = (Z2 + Z3 + Z6 + Z7) / 4;
	    XM5 = (X8 + X5 + X7 + X6) / 4;
	    YM5 = (Y8 + Y5 + Y7 + Y6) / 4;
	    ZM5 = (Z8 + Z5 + Z7 + Z6) / 4;
	    XM6 = (X3 + X2 + X4 + X1) / 4;
	    YM6 = (Y3 + Y2 + Y4 + Y1) / 4;
	    ZM6 = (Z3 + Z2 + Z4 + Z1) / 4;

	    length1 = (XM1 - XM2)*(XM1 - XM2) + (YM1 - YM2)*(YM1 - YM2) + (ZM1 - ZM2)*(ZM1 - ZM2);
	    length2 = (XM3 - XM4)*(XM3 - XM4) + (YM3 - YM4)*(YM3 - YM4) + (ZM3 - ZM4)*(ZM3 - ZM4);
	    length3 = (XM5 - XM6)*(XM5 - XM6) + (YM5 - YM6)*(YM5 - YM6) + (ZM5 - ZM6)*(ZM5 - ZM6);

	    ar = sqrt(MAX3(length1, length2, length3) / MIN3(length1, length2, length3));

//  	    ar_min = MIN(ar, ar_min);
	    ar_max = MAX(ar, ar_max);
//  	    if (ar_max < ar) {
//  		ar_max = ar;
//  		protocol << "AR_max:   Element " << IEL << '\n';
//  	    }
	    ar_sum += ar;
	    // End calculating aspect ratio
	    // ============================
	    

	    // =====================================
	    // Start calculating area and side ratio
	    k_max = DBL_MIN;			  // l�ngste und k�rzeste Kante initialisieren
	    k_min = DBL_MAX;
	    for (unsigned int IAR = 1;  IAR <= NumFaceElem;  IAR++) {
		// Those four nodes of a face.
		// Numbered in counterclockwise sense,
		// starting with node in the lower left corner of a face.
		IVT1 = (*VertElem)(KIAD(1, IAR), IEL);
		IVT2 = (*VertElem)(KIAD(2, IAR), IEL);
		IVT3 = (*VertElem)(KIAD(3, IAR), IEL);
		IVT4 = (*VertElem)(KIAD(4, IAR), IEL);

		// Their coordinates
		PX1 = (*VertCoord)(1, IVT1);
		PY1 = (*VertCoord)(2, IVT1);
		PZ1 = (*VertCoord)(3, IVT1);
		PX2 = (*VertCoord)(1, IVT2);
		PY2 = (*VertCoord)(2, IVT2);
		PZ2 = (*VertCoord)(3, IVT2);
		PX3 = (*VertCoord)(1, IVT3);
		PY3 = (*VertCoord)(2, IVT3);
		PZ3 = (*VertCoord)(3, IVT3);
		PX4 = (*VertCoord)(1, IVT4);
		PY4 = (*VertCoord)(2, IVT4);
		PZ4 = (*VertCoord)(3, IVT4);

		// Divide quadrilateral into two triangels,
		// compute their area and add them.
		// (Seiteninhaltsverh�ltnis)
		a = PX3 - PX1;
		b = PY3 - PY1;
		c = PZ3 - PZ1;
		h1 = pow( (PX2 - PX1) * b - (PY2 - PY1) * a, 2.0) +
		     pow( (PY2 - PY1) * c - (PZ2 - PZ1) * b, 2.0) +
		     pow( (PZ2 - PZ1) * a - (PX2 - PX1) * c, 2.0);
		h2 = pow( (PX4 - PX1) * b - (PY4 - PY1) * a, 2.0) +
		     pow( (PY4 - PY1) * c - (PZ4 - PZ1) * b, 2.0) +
		     pow( (PZ4 - PZ1) * a - (PX4 - PX1) * c, 2.0);
		area(IAR) = 0.5 * (sqrt(h1) + sqrt(h2));


		// Side ratio (Kantenverh�ltnis)
		a = PX2 - PX1;
		b = PY2 - PY1;
		c = PZ2 - PZ1;
		h1 = sqrt(a*a + b*b + c*c);
		a = PX4 - PX3;
		b = PY4 - PY3;
		c = PZ4 - PZ3;
		h2 = sqrt(a*a + b*b + c*c);
		kv1 = MAX(h1, h2) / MIN(h1, h2);
		k_max = MAX3(h1, h2, k_max);
		k_min = MIN3(h1, h2, k_min);

		a = PX4 - PX1;
		b = PY4 - PY1;
		c = PZ4 - PZ1;
		h1 = sqrt(a*a + b*b + c*c);
		a = PX2 - PX3;
		b = PY2 - PY3;
		c = PZ2 - PZ3;
		h2 = sqrt(a*a + b*b + c*c);
		kv2 = MAX(h1, h2) / MIN(h1, h2);
		k_max = MAX3(h1, h2, k_max);
		k_min = MIN3(h1, h2, k_min);

		kv_max = MAX3(kv1, kv2, kv_max);
		kv_sum += kv1 + kv2;
	    } // end loop over all faces of a single element
	    // End calculating area and side ratio
	    // ===================================

	    sv = MAX3( MAX(area(1), area(6)) / MIN(area(1), area(6)),
		       MAX(area(2), area(4)) / MIN(area(2), area(4)),
		       MAX(area(3), area(5)) / MIN(area(3), area(5)) );
	    sv_max = MAX(sv, sv_max);
	    sv_sum += MAX(area(1), area(6)) / MIN(area(1), area(6)) +
		      MAX(area(2), area(4)) / MIN(area(2), area(4)) +
		      MAX(area(3), area(5)) / MIN(area(3), area(5));

	    // Rannacher Definition von ar:
	    ar_rannacher_max = MAX(k_max / k_min, ar_rannacher_max);
	} // end loop over all elements

        protocol << "    " << std::setw(3) << std::setfill(' ') << ILEV << "   |"
                 << " "    << std::setw(3) << double_to_string(ar_max, "e", 2) << "  |"
                 << " "    << std::setw(3) << double_to_string(sv_max, "e", 2) << "  |"
		 << " "    << std::setw(3) << double_to_string(kv_max, "e", 2) << "       "
                 << " "    << std::setw(3) << double_to_string(ar_sum / NumElements, "e", 2) << "  |"
                 << " "    << std::setw(3) << double_to_string(sv_sum / (NumElements * 3), "e", 2) << "  |"
		 << " "    << std::setw(3) << double_to_string(kv_sum / (NumElements * 12), "e", 2);

	// aspect ratio as Prof. R. Rannacher defines it
// 	protocol << "       "
// 		 << " "    << std::setw(3) << double_to_string(ar_rannacher_max, "e", 2);

	protocol << "\n";
        protocol.mFlush();
    } // end loop over grid hierarchy

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CalcAnisotropyDegree.\n";
        protocol.mFlush();
    }
}

VOID Task::CalcVolumes()
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CalcVolumes.\n";
        protocol.mFlush();
    }

    unsigned int IEL,ILEV;
    int    I1,I2,I3,I4,I5,I6,I7,I8;
    double X1,X2,X3,X4,X5,X6,X7,X8;
    double Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8;
    double Z1,Z2,Z3,Z4,Z5,Z6,Z7,Z8,AAA;
    double A1=1.0/6.0;
    double av, av_min, av_max, av_sum, av_counter;

    av = av_sum = av_counter = 0 ;
    av_min = DBL_MAX;
    av_max = DBL_MIN;

    protocol << "\n Calculating anisotropy variation (while calculating volumes):\n\n";
    protocol << "    level |   av_max   |   av_min   |  av_mean\n";
    protocol << "   -------+------------+------------+------------\n";
    protocol.mFlush();

//      for (ILEV = MaxLevel; ILEV >= MinLevel; ILEV--) {
    for (ILEV = MinLevel; ILEV <= MaxLevel; ILEV++) {
        SetLevel(ILEV);

        Volumes = new DoubleVector(NumElements);
        MVolumes[ILEV] = Volumes;

        SumVolumes = 0.0;
	// Calculating volume for each element
        for (IEL = 1; IEL <= NumElements; IEL++) {
            I1 = (*VertElem)(1, IEL);
            I2 = (*VertElem)(2, IEL);
            I3 = (*VertElem)(3, IEL);
            I4 = (*VertElem)(4, IEL);
            I5 = (*VertElem)(5, IEL);
            I6 = (*VertElem)(6, IEL);
            I7 = (*VertElem)(7, IEL);
            I8 = (*VertElem)(8, IEL);

            X1 = (*VertCoord)(1, I1);
            X2 = (*VertCoord)(1, I2);
            X3 = (*VertCoord)(1, I3);
            X4 = (*VertCoord)(1, I4);
            X5 = (*VertCoord)(1, I5);
            X6 = (*VertCoord)(1, I6);
            X7 = (*VertCoord)(1, I7);
            X8 = (*VertCoord)(1, I8);

            Y1 = (*VertCoord)(2, I1);
            Y2 = (*VertCoord)(2, I2);
            Y3 = (*VertCoord)(2, I3);
            Y4 = (*VertCoord)(2, I4);
            Y5 = (*VertCoord)(2, I5);
            Y6 = (*VertCoord)(2, I6);
            Y7 = (*VertCoord)(2, I7);
            Y8 = (*VertCoord)(2, I8);

            Z1 = (*VertCoord)(3, I1);
            Z2 = (*VertCoord)(3, I2);
            Z3 = (*VertCoord)(3, I3);
            Z4 = (*VertCoord)(3, I4);
            Z5 = (*VertCoord)(3, I5);
            Z6 = (*VertCoord)(3, I6);
            Z7 = (*VertCoord)(3, I7);
            Z8 = (*VertCoord)(3, I8);

            AAA = A1 * ((fabs((X4 - X1) * (Y4 - Y3) * (Z4 - Z8) + (Y4 - Y1) *
			      (Z4 - Z3) * (X4 - X8) + (Z4 - Z1) * (X4 - X3) * (Y4 - Y8) -
			      (X4 - X8) * (Y4 - Y3) * (Z4 - Z1) - (Y4 - Y8) * (Z4 - Z3) *
			      (X4 - X1) - (Z4 - Z8) * (X4 - X3) * (Y4 - Y1))) +
			(fabs((X2 - X3) * (Y2 - Y1) * (Z2 - Z6) + (Y2 - Y3) *
			      (Z2 - Z1) * (X2 - X6) + (Z2 - Z3) * (X2 - X1) * (Y2 - Y6) -
			      (X2 - X6) * (Y2 - Y1) * (Z2 - Z3) - (Y2 - Y6) * (Z2 - Z1) *
			      (X2 - X3) - (Z2 - Z6) * (X2 - X1) * (Y2 - Y3))) +
			(fabs((X5 - X8) * (Y5 - Y6) * (Z5 - Z1) + (Y5 - Y8) *
			      (Z5 - Z6) * (X5 - X1) + (Z5 - Z8) * (X5 - X6) * (Y5 - Y1) -
			      (X5 - X1) * (Y5 - Y6) * (Z5 - Z8) - (Y5 - Y1) * (Z5 - Z6) *
			      (X5 - X8) - (Z5 - Z1) * (X5 - X6) * (Y5 - Y8))) +
			(fabs((X7 - X6) * (Y7 - Y8) * (Z7 - Z3) + (Y7 - Y6) *
			      (Z7 - Z8) * (X7 - X3) + (Z7 - Z6) * (X7 - X8) * (Y7 - Y3) -
			      (X7 - X3) * (Y7 - Y8) * (Z7 - Z6) - (Y7 - Y3) * (Z7 - Z8) *
			      (X7 - X6) - (Z7 - Z3) * (X7 - X8) * (Y7 - Y6))) +
			(fabs((X1 - X3) * (Y1 - Y8) * (Z1 - Z6) + (Y1 - Y3) *
			      (Z1 - Z8) * (X1 - X6) + (Z1 - Z3) * (X1 - X8) * (Y1 - Y6) -
			      (X1 - X6) * (Y1 - Y8) * (Z1 - Z3) - (Y1 - Y6) * (Z1 - Z8) *
			      (X1 - X3) - (Z1 - Z6) * (X1 - X8) * (Y1 - Y3))));
            (*Volumes)(IEL) = AAA;
            SumVolumes += AAA;
	} // end loop over all elements
        MSumVolumes[ILEV]=SumVolumes;

	// Comparing volumes of neighbouring elements
	av = av_sum = av_counter = 0;
	av_min = DBL_MAX;
	av_max = DBL_MIN;
  	for (unsigned int IAT = 1; IAT <= TotNumFaces; IAT++) {
	    I1 = (*ElemMeetFace)(1, IAT);
	    I2 = (*ElemMeetFace)(2, IAT);

	    // Compare volumes only if face is not a boundary face.
	    if (I1 != 0  &&  I2 != 0) {
		av_counter++;
		X1 = (*Volumes)(I1);
		X2 = (*Volumes)(I2);

		av = MAX(X1, X2) / MIN(X1, X2);

		av_min = MIN(av, av_min);
		av_max = MAX(av, av_max);
//  		if (av_min > av) {
//  		    av_min = av;
//  		    protocol << "AV_min:   Element " << I1
//  			     << " + Element " << I2 << "\n";
//  		}
//  		if (av_max < av) {
//  		    av_max = av;
//  		    protocol << "AV_max:   Element " << I1
//  			     << " + Element " << I2 << "\n";
//  		}
		av_sum += av;
	    }
	} // end loop over all faces

        protocol << "    " << std::setw(3) << std::setfill(' ') << ILEV << "   |"
                 << " "    << std::setw(3) << double_to_string(av_max, "e", 2) << "  |"
                 << " "    << std::setw(3) << double_to_string(av_min, "e", 2) << "  |";
	// av_counter != 0
	if (fabs(av_counter - 0.0) > FLOAT_EPS) {
	    protocol << " "    << std::setw(3) << double_to_string(av_sum / av_counter, "e", 2) << "\n";
	} else {
	    protocol << "    -\n";
	}

        protocol.mFlush();
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CalcVolumes.\n";
        protocol.mFlush();
    }
}

VOID Task::IntpolNonToKon(DoubleVector *u1,DoubleVector *u2,DoubleVector *u3,
                          DoubleVector *u4,DoubleVector *u5,
                          DoubleVector *v1,DoubleVector *v2,DoubleVector *v3,
                          DoubleVector *v4,DoubleVector *v5,
                          int Level)
{
    int IV,IEL;
    double A1=2.0/3.0;
    double A2=1.0/3.0;
    int IV1,IV2,IV3,IV4,IV5,IV6,IV7,IV8,IA1,IA2,IA3,IA4,IA5,IA6,INPR;
    double DUH1,DUH2,DUH3,DUH4,DUH5,DUH6;
    double DVH1,DVH2,DVH3,DVH4,DVH5,DVH6;
    double DWH1,DWH2,DWH3,DWH4,DWH5,DWH6;
    double DPH1,DPH2,DPH3,DPH4,DPH5,DPH6;
    double DCH1,DCH2,DCH3,DCH4,DCH5,DCH6;
    double P1,P2,P3,P4,P5,P6,P7,P8;
    double C1,C2,C3,C4,C5,C6,C7,C8;
    double R1,R2,R3,R4,R5,R6,R7,R8;
    double S1,S2,S3,S4,S5,S6,S7,S8;
    double T1,T2,T3,T4,T5,T6,T7,T8,X,Y,Z;

    SetLevel(Level);

    DoubleVector DAUX(NumVertices);

    *v1=0.0;
    *v2=0.0;
    *v3=0.0;
    *v4=0.0;
    *v5=0.0;
    DAUX=0.0;

    for (IEL=1;IEL<=NumElements;IEL++) {
        IA1=(*MidFaces)(1,IEL);
        IA2=(*MidFaces)(2,IEL);
        IA3=(*MidFaces)(3,IEL);
        IA4=(*MidFaces)(4,IEL);
        IA5=(*MidFaces)(5,IEL);
        IA6=(*MidFaces)(6,IEL);

        IV1=(*VertElem)(1,IEL);
        IV2=(*VertElem)(2,IEL);
        IV3=(*VertElem)(3,IEL);
        IV4=(*VertElem)(4,IEL);
        IV5=(*VertElem)(5,IEL);
        IV6=(*VertElem)(6,IEL);
        IV7=(*VertElem)(7,IEL);
        IV8=(*VertElem)(8,IEL);

        DUH1=(*u1)(IA1);
        DUH2=(*u1)(IA2);
        DUH3=(*u1)(IA3);
        DUH4=(*u1)(IA4);
        DUH5=(*u1)(IA5);
        DUH6=(*u1)(IA6);

        DVH1=(*u2)(IA1);
        DVH2=(*u2)(IA2);
        DVH3=(*u2)(IA3);
        DVH4=(*u2)(IA4);
        DVH5=(*u2)(IA5);
        DVH6=(*u2)(IA6);

        DWH1=(*u3)(IA1);
        DWH2=(*u3)(IA2);
        DWH3=(*u3)(IA3);
        DWH4=(*u3)(IA4);
        DWH5=(*u3)(IA5);
        DWH6=(*u3)(IA6);

        DPH1=(*u4)(IA1);
        DPH2=(*u4)(IA2);
        DPH3=(*u4)(IA3);
        DPH4=(*u4)(IA4);
        DPH5=(*u4)(IA5);
        DPH6=(*u4)(IA6);

        DCH1=(*u5)(IA1);
        DCH2=(*u5)(IA2);
        DCH3=(*u5)(IA3);
        DCH4=(*u5)(IA4);
        DCH5=(*u5)(IA5);
        DCH6=(*u5)(IA6);

        DAUX(IV1)=DAUX(IV1)+1.0;
        DAUX(IV2)=DAUX(IV2)+1.0;
        DAUX(IV3)=DAUX(IV3)+1.0;
        DAUX(IV4)=DAUX(IV4)+1.0;
        DAUX(IV5)=DAUX(IV5)+1.0;
        DAUX(IV6)=DAUX(IV6)+1.0;
        DAUX(IV7)=DAUX(IV7)+1.0;
        DAUX(IV8)=DAUX(IV8)+1.0;

        R1=DUH1+DUH2+DUH3;
        R2=DUH1+DUH2+DUH5;
        R3=DUH1+DUH3+DUH4;
        R4=DUH1+DUH4+DUH5;
        R5=DUH2+DUH3+DUH6;
        R6=DUH2+DUH5+DUH6;
        R7=DUH3+DUH4+DUH6;
        R8=DUH4+DUH5+DUH6;

        (*v1)(IV1)+=A1*R2 - A2*R7;
        (*v1)(IV2)+=A1*R1 - A2*R8;
        (*v1)(IV3)+=A1*R3 - A2*R6;
        (*v1)(IV4)+=A1*R4 - A2*R5;
        (*v1)(IV5)+=A1*R6 - A2*R3;
        (*v1)(IV6)+=A1*R5 - A2*R4;
        (*v1)(IV7)+=A1*R7 - A2*R2;
        (*v1)(IV8)+=A1*R8 - A2*R1;

        S1=DVH1+DVH2+DVH3;
        S2=DVH1+DVH2+DVH5;
        S3=DVH1+DVH3+DVH4;
        S4=DVH1+DVH4+DVH5;
        S5=DVH2+DVH3+DVH6;
        S6=DVH2+DVH5+DVH6;
        S7=DVH3+DVH4+DVH6;
        S8=DVH4+DVH5+DVH6;

        (*v2)(IV1)+=A1*S2 - A2*S7;
        (*v2)(IV2)+=A1*S1 - A2*S8;
        (*v2)(IV3)+=A1*S3 - A2*S6;
        (*v2)(IV4)+=A1*S4 - A2*S5;
        (*v2)(IV5)+=A1*S6 - A2*S3;
        (*v2)(IV6)+=A1*S5 - A2*S4;
        (*v2)(IV7)+=A1*S7 - A2*S2;
        (*v2)(IV8)+=A1*S8 - A2*S1;

        T1=DWH1+DWH2+DWH3;
        T2=DWH1+DWH2+DWH5;
        T3=DWH1+DWH3+DWH4;
        T4=DWH1+DWH4+DWH5;
        T5=DWH2+DWH3+DWH6;
        T6=DWH2+DWH5+DWH6;
        T7=DWH3+DWH4+DWH6;
        T8=DWH4+DWH5+DWH6;

        (*v3)(IV1)+=A1*T2 - A2*T7;
        (*v3)(IV2)+=A1*T1 - A2*T8;
        (*v3)(IV3)+=A1*T3 - A2*T6;
        (*v3)(IV4)+=A1*T4 - A2*T5;
        (*v3)(IV5)+=A1*T6 - A2*T3;
        (*v3)(IV6)+=A1*T5 - A2*T4;
        (*v3)(IV7)+=A1*T7 - A2*T2;
        (*v3)(IV8)+=A1*T8 - A2*T1;

        P1=DPH1+DPH2+DPH3;
        P2=DPH1+DPH2+DPH5;
        P3=DPH1+DPH3+DPH4;
        P4=DPH1+DPH4+DPH5;
        P5=DPH2+DPH3+DPH6;
        P6=DPH2+DPH5+DPH6;
        P7=DPH3+DPH4+DPH6;
        P8=DPH4+DPH5+DPH6;

        (*v4)(IV1)+=A1*P2 - A2*P7;
        (*v4)(IV2)+=A1*P1 - A2*P8;
        (*v4)(IV3)+=A1*P3 - A2*P6;
        (*v4)(IV4)+=A1*P4 - A2*P5;
        (*v4)(IV5)+=A1*P6 - A2*P3;
        (*v4)(IV6)+=A1*P5 - A2*P4;
        (*v4)(IV7)+=A1*P7 - A2*P2;
        (*v4)(IV8)+=A1*P8 - A2*P1;

        C1=DCH1+DCH2+DCH3;
        C2=DCH1+DCH2+DCH5;
        C3=DCH1+DCH3+DCH4;
        C4=DCH1+DCH4+DCH5;
        C5=DCH2+DCH3+DCH6;
        C6=DCH2+DCH5+DCH6;
        C7=DCH3+DCH4+DCH6;
        C8=DCH4+DCH5+DCH6;

        (*v5)(IV1)+=A1*C2 - A2*C7;
        (*v5)(IV2)+=A1*C1 - A2*C8;
        (*v5)(IV3)+=A1*C3 - A2*C6;
        (*v5)(IV4)+=A1*C4 - A2*C5;
        (*v5)(IV5)+=A1*C6 - A2*C3;
        (*v5)(IV6)+=A1*C5 - A2*C4;
        (*v5)(IV7)+=A1*C7 - A2*C2;
        (*v5)(IV8)+=A1*C8 - A2*C1;
    }

    for (IV=1;IV<=NumVertices;IV++) {
        (*v1)(IV)=(*v1)(IV)/DAUX(IV);
        (*v2)(IV)=(*v2)(IV)/DAUX(IV);
        (*v3)(IV)=(*v3)(IV)/DAUX(IV);
        (*v4)(IV)=(*v4)(IV)/DAUX(IV);
        (*v5)(IV)=(*v5)(IV)/DAUX(IV);
    }

    for (IV=1;IV<=NumVertices;IV++) {
        INPR=GetKonRealNodeType(IV);
        if (INPR==REAL_BOUND) {
            X=(*VertCoord)(1,IV);
            Y=(*VertCoord)(2,IV);
            Z=(*VertCoord)(3,IV);
//          Prot<<"SetRealBound X="<<X<<" Y="<<Y<<" Z="<<Z<<"\n";
            CoeffRHSV1();
            (*v1)(IV)=Solution(X,Y,Z, DTime);
            CoeffRHSV2();
            (*v2)(IV)=Solution(X,Y,Z, DTime);
            CoeffRHSV3();
            (*v3)(IV)=Solution(X,Y,Z, DTime);
        }
    }
}

void Task::IntpolConToKon(DoubleVector& p,DoubleVector& lp)
{
    //    Purpose:  - Interpolates the solution pressure DP to
    //                the (REAL) vector VPL of dimension NVT with
    //                values in the vertices

    DoubleVector DAUX(lp.GetLen());
    double DPIEL,DAVOL,ptemp;
    int IV1,IV2,IV3,IV4,IV5,IV6,IV7,IV8,IADJ;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::IntpolConToKon.\n";
        protocol.mFlush();
    }

    DAUX=0.;
    lp=0.;


    SetElemBoundValues(&p);
    CommunicateElem();

    for (int IEL=1;IEL<=NumElements;IEL++) {
        DPIEL=p(IEL);
        DAVOL=(*Volumes)(IEL);

        IV1=(*VertElem)(1,IEL);
        IV2=(*VertElem)(2,IEL);
        IV3=(*VertElem)(3,IEL);
        IV4=(*VertElem)(4,IEL);
        IV5=(*VertElem)(5,IEL);
        IV6=(*VertElem)(6,IEL);
        IV7=(*VertElem)(7,IEL);
        IV8=(*VertElem)(8,IEL);

        lp(IV1)+=0.125*DAVOL*DPIEL;
        lp(IV2)+=0.125*DAVOL*DPIEL;
        lp(IV3)+=0.125*DAVOL*DPIEL;
        lp(IV4)+=0.125*DAVOL*DPIEL;
        lp(IV5)+=0.125*DAVOL*DPIEL;
        lp(IV6)+=0.125*DAVOL*DPIEL;
        lp(IV7)+=0.125*DAVOL*DPIEL;
        lp(IV8)+=0.125*DAVOL*DPIEL;

        DAUX(IV1)+=0.125*DAVOL;
        DAUX(IV2)+=0.125*DAVOL;
        DAUX(IV3)+=0.125*DAVOL;
        DAUX(IV4)+=0.125*DAVOL;
        DAUX(IV5)+=0.125*DAVOL;
        DAUX(IV6)+=0.125*DAVOL;
        DAUX(IV7)+=0.125*DAVOL;
        DAUX(IV8)+=0.125*DAVOL;

        for (int IVE=1;IVE<=6;IVE++) {
            IADJ=(*NeighElem)(IVE,IEL);
            if (IADJ==0) {
                if (FindElem(IEL,IVE,ptemp,ActiveLevel)==true) {
                    switch(IVE) {
                    case 1:
                        lp(IV1)+=0.125*DAVOL*ptemp;
                        DAUX(IV1)+=0.125*DAVOL;
                        lp(IV2)+=0.125*DAVOL*ptemp;
                        DAUX(IV2)+=0.125*DAVOL;
                        lp(IV3)+=0.125*DAVOL*ptemp;
                        DAUX(IV3)+=0.125*DAVOL;
                        lp(IV4)+=0.125*DAVOL*ptemp;
                        DAUX(IV4)+=0.125*DAVOL;
                        break;
                    case 2:
                        lp(IV1)+=0.125*DAVOL*ptemp;
                        DAUX(IV1)+=0.125*DAVOL;
                        lp(IV2)+=0.125*DAVOL*ptemp;
                        DAUX(IV2)+=0.125*DAVOL;
                        lp(IV6)+=0.125*DAVOL*ptemp;
                        DAUX(IV6)+=0.125*DAVOL;
                        lp(IV5)+=0.125*DAVOL*ptemp;
                        DAUX(IV5)+=0.125*DAVOL;
                        break;
                    case 3:
                        lp(IV2)+=0.125*DAVOL*ptemp;
                        DAUX(IV2)+=0.125*DAVOL;
                        lp(IV3)+=0.125*DAVOL*ptemp;
                        DAUX(IV3)+=0.125*DAVOL;
                        lp(IV7)+=0.125*DAVOL*ptemp;
                        DAUX(IV7)+=0.125*DAVOL;
                        lp(IV6)+=0.125*DAVOL*ptemp;
                        DAUX(IV6)+=0.125*DAVOL;
                        break;
                    case 4:
                        lp(IV3)+=0.125*DAVOL*ptemp;
                        DAUX(IV3)+=0.125*DAVOL;
                        lp(IV4)+=0.125*DAVOL*ptemp;
                        DAUX(IV4)+=0.125*DAVOL;
                        lp(IV8)+=0.125*DAVOL*ptemp;
                        DAUX(IV8)+=0.125*DAVOL;
                        lp(IV7)+=0.125*DAVOL*ptemp;
                        DAUX(IV7)+=0.125*DAVOL;
                        break;
                    case 5:
                        lp(IV4)+=0.125*DAVOL*ptemp;
                        DAUX(IV4)+=0.125*DAVOL;
                        lp(IV1)+=0.125*DAVOL*ptemp;
                        DAUX(IV1)+=0.125*DAVOL;
                        lp(IV5)+=0.125*DAVOL*ptemp;
                        DAUX(IV5)+=0.125*DAVOL;
                        lp(IV8)+=0.125*DAVOL*ptemp;
                        DAUX(IV8)+=0.125*DAVOL;
                        break;
                    case 6:
                        lp(IV5)+=0.125*DAVOL*ptemp;
                        DAUX(IV5)+=0.125*DAVOL;
                        lp(IV6)+=0.125*DAVOL*ptemp;
                        DAUX(IV6)+=0.125*DAVOL;
                        lp(IV7)+=0.125*DAVOL*ptemp;
                        DAUX(IV7)+=0.125*DAVOL;
                        lp(IV8)+=0.125*DAVOL*ptemp;
                        DAUX(IV8)+=0.125*DAVOL;
                        break;
                    }
                }
            }

        }
    }

    for (int IVT=1;IVT<=NumVertices;IVT++)
        lp(IVT)/=DAUX(IVT);

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::IntpolConToKon.\n";
        protocol.mFlush();
    }

    return;
}


VOID Task::Info()
{
//    int i;
//
//    for (i=1;i<=NumElements;i++)
//    Prot<<"Element: "<<i<<" n1="<<(*VertElem)(1,i)<<" n2="<<(*VertElem)(2,i)<<" n3="<<(*VertElem)(3,i)<<" n4="<<(*VertElem)(4,i)<<" n5="<<(*VertElem)(5,i)<<" n6="<<(*VertElem)(6,i)<<" n7="<<(*VertElem)(7,i)<<" n8="<<(*VertElem)(8,i)<<"\n";
//    for (i=1;i<=NumVertices;i++)
//    Prot<<"v: "<<i<<" X="<<(*VertCoord)(1,i)<<" Y="<<(*VertCoord)(2,i)<<" Z="<<(*VertCoord)(3,i)<<"\n";
//    for (i=1;i<=TotNumFaces;i++)
//    Prot<<"v: "<<i<<" X="<<(*MidFaceCoord)(1,i)<<" Y="<<(*MidFaceCoord)(2,i)<<" Z="<<(*MidFaceCoord)(3,i)<<"\n";
    Prot<<"NumVertices="<<NumVertices<<"\n";
//  Prot<<"VertCoord="<<*VertCoord<<"\n";
    Prot<<"NumEdges="<<NumEdges<<"\n";
    Prot<<"TotNumFaces="<<TotNumFaces<<"\n";
//  Prot<<"MidCoord="<<*MidCoord<<"\n";
//  Prot<<"MidEdges="<<*MidEdges<<"\n";
    Prot<<"NumElements="<<NumElements<<"\n";
//  Prot<<"NeighElem="<<*NeighElem<<"\n";
//  Prot<<"VertElem="<<*VertElem<<"\n";
//  Prot<<"NumVertBound="<<NumVertBound<<"\n";
//  Prot<<"VertBound="<<*VertBound<<"\n";
}


VOID Task::CleanUp()
{
    for (INTEGER ILEV=1;ILEV<=TotalLevel;ILEV++) {
        if (MElemVert[ILEV]) {
            delete MElemVert[ILEV];
            MElemVert[ILEV]=0;
        }
        if (MMidEdges[ILEV]) {
            delete MMidEdges[ILEV];
            MMidEdges[ILEV]=0;
        }
        if (MMidFaceCoord[ILEV]) {
            delete MMidFaceCoord[ILEV];
            MMidFaceCoord[ILEV]=0;
        }
        if (MInfoVertEdge[ILEV]) {
            delete MInfoVertEdge[ILEV];
            MInfoVertEdge[ILEV]=0;
        }

    }

    if (konBase)
        delete konBase;
//  if (konreal_nodeBase)
//    delete konreal_nodeBase;

//      int vert;
//      presselem1=0;presselem2=0;
//      for (int i=1;i<=MNumElements[MaxLevel];i++) {
//          for (int j=1;j<=8;j++) {
//              vert=(*MVertElem[MaxLevel])(j,i);
//              if ((MyProcID==12 && vert==6) ||
//                  (MyProcID==17 && vert==5) ||
//                  (MyProcID==36 && vert==2) ||
//                  (MyProcID==41 && vert==1)) {
//  //	Prot<<"elem vor Zylinder="<<i<<"\n";
//  //	Prot<<"vert= "<<vert<<" X="<<(*MVertCoord[MaxLevel])(1,vert)<<" Y="<<(*MVertCoord[MaxLevel])(2,vert)<<" Z="<<(*MVertCoord[MaxLevel])(3,vert)<<"\n";
//                  PressElem[presselem1++]=i;
//              }
//              if ((MyProcID==14 && vert==6) ||
//                  (MyProcID==15 && vert==5) ||
//                  (MyProcID==38 && vert==2) ||
//                  (MyProcID==39 && vert==1)) {
//  //	Prot<<"elem hinter Zylinder="<<i<<"\n";
//  //	Prot<<"vert= "<<vert<<" X="<<(*MVertCoord[MaxLevel])(1,vert)<<" Y="<<(*MVertCoord[MaxLevel])(2,vert)<<" Z="<<(*MVertCoord[MaxLevel])(3,vert)<<"\n";
//                  PressElem2[presselem2++]=i;
//              }
//          }
//      }

//  Prot<<" afterinit presselem1="<<presselem1<<" presselem2="<<presselem2<<"\n";
}

void Task::PostProcess(DoubleVector *p, double time)
{
    double press1=0.;
    double press2=0.;

//      if (presselem1>0) {
//          for (int i=0;i<presselem1;i++) {
//              Prot<<"Druck vor dem Zylinder in "<<PressElem[i]<<" = "<<(*p)(PressElem[i])<<"\n";
//              StdOut<<"Druck vor dem Zylinder in "<<PressElem[i]<<" = "<<(*p)(PressElem[i])<<"\n";
//              press1+=(*p)(PressElem[i]);
//          }
//          press1/=4.;
//      }
//      CommunicateSP(press1);

//      if (presselem2>0) {
//          for (int i=0;i<presselem2;i++) {
//              Prot<<"Druck hinter dem Zylinder in "<<PressElem2[i]<<" = "<<(*p)(PressElem2[i])<<"\n";
//              StdOut<<"Druck hinter dem Zylinder in "<<PressElem2[i]<<" = "<<(*p)(PressElem2[i])<<"\n";
//              press2+=(*p)(PressElem2[i]);
//          }
//          press2/=4.;
//      }
//      CommunicateSP(press2);

//      Prot<<"Druckdifferenz p="<<press1-press2<<"\n";
//      PDIFF<<time<<" "<<press1-press2<<"\n";
//      PDIFF.Flush();
}

//  void Task::get_seq()
//  {
//    char  *ptr,*ptr1;
//    int   i=0;

//    ptr=file+(strlen(file)-1);

//    while((*ptr !='.'))
//      if ( (*ptr == '/') || (ptr == file) )
//         return;
//       else ptr--;
//    ptr--;
//    ptr1=ptr;
//    ptr1++;

//    for (i=0; (*ptr !='.') && (isdigit(*ptr)) ; i++,--ptr)
//      if (ptr==file) return;
//    if (*ptr=='.'){
//      first_step=atoi(++ptr);
//      nr_digits=i;
//      strcpy(end_string,ptr1);
//      //     printf("end_string: %s\n",end_string);
//    }

//    fileseq=ptr;
//  }


char *Task::get_filename(int num)
{
    char *ptr1,*ptr;

    ptr=fileseq;

    format[0]='%';
    format[1]='0';
    sprintf(aString,"%d",nr_digits);
    strcpy(&format[2], aString);
    ptr1=format+ strlen(format);
    *ptr1='d';
    *++ptr1='\0';

    sprintf(ptr,format,num-1+first_step);
    ptr1=ptr+strlen(ptr);
    strcpy(ptr1,end_string);
//  printf("filename: %s\n",line);

    return line;
}


void Task::WriteSolution(const unsigned int currentSolFileNr, const double DTime, const double Dt)
{
    int i;
    std::string filename = Param->RestartBaseDir + Param->SolFilePrefix;

    // Append current file index to filename ('r': ring)
    filename += ".r" + int_to_string(currentSolFileNr, "0", int(log10(Param->SolFileNumber + 0.1)) + 1);

    // Append current processor id to filename ('p': processor)
    filename += ".p" + int_to_string(MyProcID, "0", 3);

    // Append gmv extension
    filename += ".sol";

    // Finally get write handle for this very file.
    COutput outfile(filename.c_str(), ACTIVE);
//  outfile.mStatus();

    Prot<<"Write Solution !!\n";


    NumElements=MNumElements[MaxLevel];
    TotNumFaces=MTotNumFaces[MaxLevel];
    NumVertices=MNumVertices[MaxLevel];

    // Write elapsed simulated time and current time step.
    outfile << DTime << " " << Dt << "\n";

    // Write total number of faces and elements.
    outfile << TotNumFaces << " " << NumElements << "\n";

    // Write velocity data.
    for (i = 1;  i <= TotNumFaces;  i++)
        outfile << (*Sol1)(i) << " " << (*Sol2)(i) << " " << (*Sol3)(i) << "\n";

    // Write pressure data.
    for (i = 1;  i <= NumElements;  i++)
        outfile << (*P)(i) << "\n";

    return;
} // end of WriteSolution


#ifdef INCLUDE_TEMPERATURE
void Task::WriteSolutionBouss(double DTime,double Dt,int ITE)
{
    int i;
    String filename="Solution/sol.";
    filename += MyProcID;
    filename += ".inp";

    Prot<<"Write Solution !!\n";

    Output	  file(filename,YES);
    //COutput          time("/hwwt3e_tmp/rus/lhd/oswal/time",YES);
    COutput          time("Solution/time", ACTIVE);

    NumElements=MNumElements[MaxLevel];
    TotNumFaces=MTotNumFaces[MaxLevel];
    NumVertices=MNumVertices[MaxLevel];

    file<<TotNumFaces<<" "<<NumElements<<"\n";

    for (i=1; i<=TotNumFaces; i++)
        file<<(*Sol1)(i)<<" "<<(*Sol2)(i)<<" "<<(*Sol3)(i)<<" "<<(*Conc)(i)<<"\n";

    for (i=1; i<=NumElements; i++)
        file<<(*P)(i)<<"\n";

    time<<DTime<<" "<<Dt<<"\n";
}
#endif


void Task::ReadSolVector(int level,ParFiniteElement_3D *elem)
{
    int i, alevel;                                // loop counter

    NumElements=MNumElements[level];
    TotNumFaces=MTotNumFaces[level];
    NumVertices=MNumVertices[level];

    Prot<<"ReadSolution filename: "<<get_filename(MyProcID+1)<<"\n";
    CInput  inp(get_filename(MyProcID+1));

    DoubleVector *LT1[MAXARRAY],*v1;
    DoubleVector *LT2[MAXARRAY],*v2;
    DoubleVector *LT3[MAXARRAY],*v3;
    LT1[MaxLevel]=Sol1;
    LT2[MaxLevel]=Sol2;
    LT3[MaxLevel]=Sol3;

    for (alevel=level;alevel<MaxLevel;alevel++) {
        LT1[alevel]=new DoubleVector(MTotNumFaces[alevel]);
        LT2[alevel]=new DoubleVector(MTotNumFaces[alevel]);
        LT3[alevel]=new DoubleVector(MTotNumFaces[alevel]);
    }

    v1=LT1[level];
    v2=LT2[level];
    v3=LT3[level];

    for (i=1;i<=TotNumFaces;i++) {
        inp>>(*v1)(i);
        inp>>(*v2)(i);
        inp>>(*v3)(i);
        inp.GoToNextLine();
    }

    for (alevel=level+1;alevel<=MaxLevel;alevel++) {
        ActiveLevel=alevel;
        elem->ParProl(LT1[alevel-1],LT1[alevel],
                      MVertElem[alevel],MVertElem[alevel-1],
                      MMidFaces[alevel],MMidFaces[alevel-1],
                      MNeighElem[alevel],MNeighElem[alevel-1],
                      MNumVertices[alevel],MNumVertices[alevel-1],
                      MNumElements[alevel],MNumElements[alevel-1],
                      this);
        elem->ParProl(LT2[alevel-1],LT2[alevel],
                      MVertElem[alevel],MVertElem[alevel-1],
                      MMidFaces[alevel],MMidFaces[alevel-1],
                      MNeighElem[alevel],MNeighElem[alevel-1],
                      MNumVertices[alevel],MNumVertices[alevel-1],
                      MNumElements[alevel],MNumElements[alevel-1],
                      this);
        elem->ParProl(LT3[alevel-1],LT3[alevel],
                      MVertElem[alevel],MVertElem[alevel-1],
                      MMidFaces[alevel],MMidFaces[alevel-1],
                      MNeighElem[alevel],MNeighElem[alevel-1],
                      MNumVertices[alevel],MNumVertices[alevel-1],
                      MNumElements[alevel],MNumElements[alevel-1],
                      this);
    }
    for (alevel=level; alevel<MaxLevel; alevel++) {
        delete LT1[alevel];
        delete LT2[alevel];
        delete LT3[alevel];
    }
}

void Task::ReadSolution(double& DTime, double& Dt)
{
    int i;                                        // loop counter
    int faces, elements;                          // number of faces resp. elements in file
    std::string filename = Param->RestartBaseDir + Param->RestartSolFile;

    // Append current processor id to filename ('p': processor)
    filename += ".p" + int_to_string (MyProcID, "0", 3);

    // Append gmv extension
    filename += ".sol";

    // Finally get read handle for this very file.
    CInput infile(filename.c_str());
//  infile.mStatus();


    NumElements = MNumElements[MaxLevel];
    TotNumFaces = MTotNumFaces[MaxLevel];
    NumVertices = MNumVertices[MaxLevel];

    infile >> DTime;                              // read elapsed simulated time
    infile >> Dt;                                 // read current time step

    infile >> faces;
    infile >> elements;
    infile.GoToNextLine();

    if (faces != TotNumFaces  ||  elements != NumElements) {
	protocol << "\n WARNING: Solution file contains more velocity and pressure\n"
		 << "          values than we have on level 3. Skipping excessive\n"
		 << "          values.\n ";
        Prot << "faces   =" << faces    << "  !=  TotNumFaces=" << TotNumFaces <<"\n";
        Prot << "elements=" << elements << "  !=  NumElements=" << NumElements <<"\n";
        Prot.Flush();
    } else {
        // Read velocities from file.
        for (i = 1; i <= TotNumFaces; i++) {
            infile >> (*Sol1)(i);
            infile >> (*Sol2)(i);
            infile >> (*Sol3)(i);
            infile.GoToNextLine();
        }
	// Skip remaining velocities, e.g. when reading a solution
	// file from level 5 while the current computation is on
	// level 4.
        for (i = TotNumFaces + 1; i <= faces; i++) {
            infile.GoToNextLine();
	}

        // Read pressure information from file.
        for (i = 1; i <= NumElements; i++) {
            infile >> (*P)(i);
            infile.GoToNextLine();
        }
    }
    infile.mCloseFile();

    return;
} // End of ReadSolution


#ifdef INCLUDE_TEMPERATURE
VOID Task::ReadSolutionBouss(double& DTime,double& Dt)
{
    int i,faces,elements;

    //String filename="/hwwt3e_tmp/rus/lhd/oswal/Solution/sol.";
    String filename="/nfs/hwwfs1/rus/lhd/oswal/Solution/sol.";
    //String filename="Solution/sol.";
    //  filename+="t";
    //  filename+=ITE;
    //  filename+=".";
    filename+=MyProcID;
    filename+=".inp";

    NumElements=MNumElements[MaxLevel];
    TotNumFaces=MTotNumFaces[MaxLevel];
    NumVertices=MNumVertices[MaxLevel];

    Prot<<"ReadSolution filename: "<<filename<<"\n";
    CInput  inp(filename);
    //CInput  time("/hwwt3e_tmp/rus/lhd/oswal/time");
    CInput  time("Solution/time");

    time>>DTime;
    time>>Dt;

    inp>>faces;
    inp>>elements;
    inp.GoToNextLine();

    if (faces!=TotNumFaces || elements!=NumElements) {
        Prot<<"faces="<<faces<<" != TotNumFaces="<<TotNumFaces<<"\n";
        Prot<<"elements="<<elements<<" != NumElements="<<NumElements<<"\n";
    } else {
        for (i=1; i<=TotNumFaces; i++) {
            inp>>(*Sol1)(i);
            inp>>(*Sol2)(i);
            inp>>(*Sol3)(i);
            inp>>(*Conc)(i);
            inp.GoToNextLine();
        }
        for (i=1; i<=NumElements; i++) {
            inp>>(*P)(i);
            inp.GoToNextLine();
        }
    }

    return;
}
#endif


void Task::ReadCoarseSolution(double& DTime, double& Dt,
                              ParFiniteElement_3D *elem, FiniteElement_3D *conelem)
{
    int i;                                        // loop counter
    int faces, elements;                          // number of faces resp. elements in file
    std::string filename = Param->RestartBaseDir + Param->RestartSolFile;

    // Append current processor id to filename ('p': processor)
    filename += ".p" + int_to_string (MyProcID, "0", 3);

    // Append gmv extension
    filename += ".sol";

    // Finally get write handle for this very file.
    CInput infile(filename.c_str());
//  infile.mStatus();

    Prot << "ReadCoarseSolution filename: " << (char *) filename.c_str() << "\n";

    infile >> DTime;                              // read elapsed simulated time
    infile >> Dt;                                 // read current time step

    infile >> faces;
    infile >> elements;
    infile.GoToNextLine();

    // Allocate temporary vectors that will record the data from the file.
    // This data will then be prolongated in a next step.
    SetLevel(MaxLevel-1);
    DoubleVector *v1;
    DoubleVector *v2;
    DoubleVector *v3;
    DoubleVector *p;

    v1 = new DoubleVector(TotNumFaces);
    v2 = new DoubleVector(TotNumFaces);
    v3 = new DoubleVector(TotNumFaces);
    p  = new DoubleVector(NumElements);

    // Read data from file.
    if (faces != TotNumFaces  ||  elements != NumElements) {
        Prot << "faces   =" << faces    << "  !=  TotNumFaces=" << TotNumFaces <<"\n";
        Prot << "elements=" << elements << "  !=  NumElements=" << NumElements <<"\n";
        Prot.Flush();
    } else {
        // Read velocities from file.
        for (i = 1; i <= TotNumFaces; i++) {
            infile >> (*v1)(i);
            infile >> (*v2)(i);
            infile >> (*v3)(i);
            infile.GoToNextLine();
        }

        // Read pressure information from file.
        for (i = 1; i <= NumElements; i++) {
            infile >> (*p)(i);
            infile.GoToNextLine();
        }

        // Prolongation to the next finer grid.
        ActiveLevel++;
        *Sol1 = 0.0;
        *Sol2 = 0.0;
        *Sol3 = 0.0;
        *P    = 0.0;

        elem->ParProl(v1, Sol1,
                      MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
                      MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
                      MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
                      MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
                      MNumElements[ActiveLevel], MNumElements[ActiveLevel-1],
                      this);
        elem->ParProl(v2, Sol2,
                      MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
                      MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
                      MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
                      MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
                      MNumElements[ActiveLevel], MNumElements[ActiveLevel-1],
                      this);
        elem->ParProl(v3, Sol3,
                      MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
                      MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
                      MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
                      MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
                      MNumElements[ActiveLevel], MNumElements[ActiveLevel-1],
                      this);
// Hubi: Warum hier keine parallele Prolongation??
        conelem->Prol(p, P,
                      MVertElem[ActiveLevel],    MVertElem[ActiveLevel-1],
                      MMidFaces[ActiveLevel],    MMidFaces[ActiveLevel-1],
                      MNeighElem[ActiveLevel],   MNeighElem[ActiveLevel-1],
                      MNumVertices[ActiveLevel], MNumVertices[ActiveLevel-1],
                      MNumElements[ActiveLevel], MNumElements[ActiveLevel-1]);
    }

    delete v1;
    delete v2;
    delete v3;
    delete p;

    return;
}

void Task::SetMGBurgers()
{
    Param->PreSteps   = Param->PreSteps_burg;
    Param->PostSteps  = Param->PostSteps_burg;
    Param->Solver     = Param->Solver_burg;
    Param->Smoother   = Param->Smoother_burg;
    Param->Cycle      = Param->Cycle_burg;
    Param->MGOmega    = Param->MGOmega_burg;
    Param->SolverType = Param->SolverType_burg;
    Param->EqType     = BURGERS;

    SetPreSteps(Param->PreSteps);
    SetPostSteps(Param->PostSteps);
    SetSmoother(Param->Smoother);
    SetSolver(Param->Solver);
    SetCycle(Param->Cycle);
}

void Task::SetMGPressure()
{
    Param->PreSteps   = Param->PreSteps_press;
    Param->PostSteps  = Param->PostSteps_press;
    Param->Solver     = Param->Solver_press;
    Param->Smoother   = Param->Smoother_press;
    Param->Cycle      = Param->Cycle_press;
    Param->MGOmega    = Param->MGOmega_press;
    Param->SolverType = Param->SolverType_press;
    Param->EqType     = PRESSURE;

    SetPreSteps(Param->PreSteps);
    SetPostSteps(Param->PostSteps);
    SetSmoother(Param->Smoother);
    SetSolver(Param->Solver);
    SetCycle(Param->Cycle);
}


#ifdef INCLUDE_VORTICITY
// this routine has been submitted by Chui-Jie WU, cjwu@jlonline.com
void Task::Vorticity(DoubleVector& u1,DoubleVector& u2,DoubleVector& u3,
		     DoubleVector& px,DoubleVector& py,DoubleVector& pz,
		     double a1)
// Compute  px = du3/dy - du2/dz
//          py = du1/dz - du3/dx
//          pz = du2/dx - du1/dy
{
    int    ILD, IEL, IAT, IAREA, IVT1, IVT2, IVT3, IVT4, IADJ, IVE, IVT;
    double P1X, P1Y, P1Z, P2X, P2Y, P2Z, P3X, P3Y, P3Z, P4X, P4Y, P4Z, DNX, DNY, DNZ;
    double AX1, AX2, AX3, AX4, AY1, AY2, AY3, AY4, AZ1, AZ2, AZ3, AZ4, AX, AY, AZ, DHN;
    double PXC, PYC, PZC, PXA, PYA, PZA, DNAR1, DNAR2, DFAC;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::Vorticity.\n";
	protocol.mFlush();
    }

   
   for (IEL = 1; IEL <= NumElements ; IEL++) {
	PXC = 0.;
	PYC = 0.;
	PZC = 0.;

	for (IVE = 1; IVE <= 8; IVE++) {
	    IVT = (*VertElem)(IVE, IEL);
	    PXC += (*VertCoord)(1, IVT);
	    PYC += (*VertCoord)(2, IVT);
	    PZC += (*VertCoord)(3, IVT);
	}

	PXC *= 0.125;
	PYC *= 0.125;
	PZC *= 0.125;

	px(IEL) = 0;
	py(IEL) = 0;
	pz(IEL) = 0;
	for (IAT = 1; IAT <= 6; IAT++) {
	    if (IAT == 1) {
		IVT1 = (*VertElem)(1,IEL);
		IVT2 = (*VertElem)(2,IEL);
		IVT3 = (*VertElem)(3,IEL);
		IVT4 = (*VertElem)(4,IEL);
	    }
	    if (IAT == 2) {
		IVT1 = (*VertElem)(1,IEL);
		IVT2 = (*VertElem)(2,IEL);
		IVT3 = (*VertElem)(6,IEL);
		IVT4 = (*VertElem)(5,IEL);
	    }
	    if (IAT == 3) {
		IVT1 = (*VertElem)(2,IEL);
		IVT2 = (*VertElem)(3,IEL);
		IVT3 = (*VertElem)(6,IEL);
		IVT4 = (*VertElem)(7,IEL);
	    }
	    if (IAT == 4) {
		IVT1 = (*VertElem)(3,IEL);
		IVT2 = (*VertElem)(4,IEL);
		IVT3 = (*VertElem)(8,IEL);
		IVT4 = (*VertElem)(7,IEL);
	    }
	    if (IAT == 5) {
		IVT1 = (*VertElem)(4,IEL);
		IVT2 = (*VertElem)(1,IEL);
		IVT3 = (*VertElem)(5,IEL);
		IVT4 = (*VertElem)(8,IEL);
	    }
	    if (IAT == 6) {
		IVT1 = (*VertElem)(5,IEL);
		IVT2 = (*VertElem)(6,IEL);
		IVT3 = (*VertElem)(7,IEL);
		IVT4 = (*VertElem)(8,IEL);
	    }
	    P1X=(*VertCoord)(1,IVT1);
	    P1Y=(*VertCoord)(2,IVT1);
	    P1Z=(*VertCoord)(3,IVT1);
	    P2X=(*VertCoord)(1,IVT2);
	    P2Y=(*VertCoord)(2,IVT2);
	    P2Z=(*VertCoord)(3,IVT2);
	    P3X=(*VertCoord)(1,IVT3);
	    P3Y=(*VertCoord)(2,IVT3);
	    P3Z=(*VertCoord)(3,IVT3);
	    P4X=(*VertCoord)(1,IVT4);
	    P4Y=(*VertCoord)(2,IVT4);
	    P4Z=(*VertCoord)(3,IVT4);

	    PXA=(P1X+P2X+P3X+P4X)*0.25;
	    PYA=(P1Y+P2Y+P3Y+P4Y)*0.25;
	    PZA=(P1Z+P2Z+P3Z+P4Z)*0.25;

	    AX2=P2X-P1X;
	    AY2=P2Y-P1Y;
	    AZ2=P2Z-P1Z;
	    AY3=P3Y-P1Y;
	    AX3=P3X-P1X;
	    AZ3=P3Z-P1Z;
	    AY4=P4Y-P1Y;
	    AX4=P4X-P1X;
	    AZ4=P4Z-P1Z;

	    AX =PXC-PXA;
	    AY =PYC-PYA;
	    AZ =PZC-PZA;

	    DNX=(AY3*AZ2)-(AZ3*AY2);
	    DNY=(AZ3*AX2)-(AX3*AZ2);
	    DNZ=(AX3*AY2)-(AY3*AX2);
	    DNAR1=sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

	    DNX=(AY4*AZ3)-(AZ4*AY3);
	    DNY=(AZ4*AX3)-(AX4*AZ3);
	    DNZ=(AX4*AY3)-(AY4*AX3);
	    DNAR2=sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

	    DFAC=0.5*(DNAR1+DNAR2)/DNAR2;
	    DNX =DFAC*DNX;
	    DNY =DFAC*DNY;
	    DNZ =DFAC*DNZ;

	    DHN=DNX*AX+DNY*AY+DNZ*AZ;
	    if (DHN < 0.) {
		DNX=-DNX;
		DNY=-DNY;
		DNZ=-DNZ;
	    }

	    IAREA=(*MidFaces)(IAT,IEL);
// 	    std::cout << "IAREA "<< IAREA <<" "<<IEL<<" "<<IAT<<"\n";

	    px(IEL) += a1 * (DNY * u3(IAREA) - DNZ * u2(IAREA));
	    py(IEL) += a1 * (DNZ * u1(IAREA) - DNX * u3(IAREA));
	    pz(IEL) += a1 * (DNX * u2(IAREA) - DNY * u1(IAREA));
	}
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::Vorticity.\n";
	protocol.mFlush();
    }

    return;
} // end Vorticity
#endif
