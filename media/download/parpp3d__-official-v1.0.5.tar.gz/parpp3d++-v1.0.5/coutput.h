#ifndef COUTPUTH

#define COUTPUTH
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>				  // for string type
#include <mpi.h>				  // for MPI_Finalize()
#include "Errorcodes.h"				  // for error codes
#include <typecasts.h>

#define SCREEN_FLAG 1
#define FILE_FLAG   2
//#define DOC_FLAG    3

#define ACTIVE     1
#define NONACTIVE  0
#define ON         1
#define OFF        0

#ifdef NO_NAMESPACE_STD_USAGE
# define STD_CIN   cin
# define STD_COUT  cout
# define STD_CERR  cerr
#else
# define STD_CIN   std::cin
# define STD_COUT  std::cout
# define STD_CERR  std::cerr
#endif

// It's good to know which process reports error messages
extern int         MyProcID;
// ... and where to write error messages to.
extern std::string progname;


class COutput
{
private:
    std::ofstream *outfile;
    int	           mediatype;
    bool           active;
    std::string    filename;
    char           strbuf[1024];

public:
    COutput():            mediatype(SCREEN_FLAG), active(ACTIVE)  {}
    COutput(bool aFlag) : mediatype(SCREEN_FLAG), active(aFlag) {}
    COutput(const char* aName, bool aFlag);
    ~COutput();

    void mCloseFile   ();
    void mSetFile     (const char* Name);
    void mToggleFileOutput  (bool aSwitch);
    void mToggleScreenOutput(bool aSwitch);
    void mActivate    ();
    void mDeactivate  ();
    void mStatus      ();
    void mFlush       ();
    void mAbortProgram(const std::string errorMessage, const int errorNumber);

    // Define output operator << for each type used in this program
#ifndef gcc_2_8_1
    inline COutput& operator<<(std::string& bezeichner)
#else
    inline COutput& operator<<(std::string  bezeichner)
#endif
    {
        if (active == ACTIVE) {
            if (mediatype & SCREEN_FLAG) {
                STD_COUT << bezeichner;
            }
            if (mediatype & FILE_FLAG) {
                if (outfile->good()) {
                    *outfile << bezeichner;
                } else {
                    COutput::mAbortProgram("Could not write to file '" + filename + "'", FILE_WRITE_ERROR);
                }
            }
        }

        return *this;
    }


#ifndef gcc_2_8_1
    template<class T> inline COutput& operator<<(const T& bezeichner)
#else
    template<class T> inline COutput& COutput::operator<<(const T bezeichner)
#endif
    {
        if (active == ACTIVE) {
            if (mediatype & SCREEN_FLAG) {
                STD_COUT << bezeichner;
            }
            if (mediatype & FILE_FLAG) {
                if (outfile->good()) {
                    *outfile << bezeichner;
                } else {
                    COutput::mAbortProgram("Could not write to file '" + filename + "'", FILE_WRITE_ERROR);
                }
            }
        }

        return *this;
    }
};

#endif
