#ifndef CONST_H
#define CONST_H

#define NUM_BOUND		4
#define NUM_BOUNDCOMP		8
#define NUM_BOUNDINFO		12
#define REALBOUNDCOMP		5

#define STARTNODE	 1
#define ENDNODE		 2
#define NODESTEP	 3
#define VECLEN		 4
#define TYPE		 5
#define START_2_NODE	 5
#define END_2_NODE	 6
#define NODE_2_STEP	 7
#define VEC_2_LEN	 8
#define NORMALE_X        9
#define NORMALE_Y       10
#define NORMALE_2_X     11
#define NORMALE_2_Y     12

#define REAL_BOUND		101
#define ART_BOUND		102
#define NOT_FOUND               103
#define NEUMANN_BOUND           104

#define DOWN_NEIGH		1
#define RIGHT_NEIGH		2
#define UP_NEIGH		3
#define LEFT_NEIGH		4
#define DOWNRIGHT_NEIGH		5
#define UPRIGHT_NEIGH		6
#define UPLEFT_NEIGH		7
#define DOWNLEFT_NEIGH		8

#define DOWN_BOUND		1
#define RIGHT_BOUND		2
#define UP_BOUND		3
#define LEFT_BOUND		4
#define DOWNRIGHT_BOUND		5
#define UPRIGHT_BOUND		6
#define UPLEFT_BOUND		7
#define DOWNLEFT_BOUND		8

#define XSTART		1
#define XSTEP		2
#define XNUM		3
#define YSTEP		4
#define YNUM		5

#define MASTER          1   

#define WRITE_DATA	1
#define READ_DATA	2

#define OK_TASK      1
#define BREAK_TASK   2
#define MAX_LEN      10000

#define COEFFA1	1
#define COEFFA2 2
#define COEFFA3 3
#define COEFFA4 4
#define COEFFM	5
#define COEFFP1 6
#define COEFFP2 7
#define COEFFN  8

#define COEFF_RHS	1
#define COEFF_L2	2
#define COEFF_RHSV1     3
#define COEFF_RHSV2     4
#define COEFF_RHSV3     7
#define COEFF_L2V1      5
#define COEFF_L2V2      6
#define COEFF_L2V3      8

#define LINEAR  1
#define NON_LINEAR 2

#endif
