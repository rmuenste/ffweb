#include "Task.h"

void Task::GMVOutput(DoubleVector *sol1, DoubleVector *sol2, DoubleVector *sol3,
                     DoubleVector *p,    DoubleVector *conc, ParFiniteElement_3D *elem,
                     int level,          unsigned int ITE,   double time)
{
    int i, j;
    std::string filename = Param->OutputBaseDir + Param->GMVSolutionFile;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::GMVOutput.\n";
        protocol.mFlush();
    }

    //  Append current timestep to filename ('t': timestep)
    filename += ".t" + int_to_string (ITE, "0", 3);

    // Append current processor id to filename ('p': processor)
    filename += ".p" + int_to_string (MyProcID, "0", 3);

    // Append gmv extension
    filename += ".gmv";

    // Finally get write handle for this very file.
    COutput outfile(filename.c_str(), ACTIVE);

    level = MIN(level, Param->NFine);

    // Determine the values on the current multigrid level.
    NumElements = MNumElements[level];
    NumVertices = MNumVertices[level];
    VertCoord   = MVertCoord[level];
    VertElem    = MVertElem[level];


    // Begin to fill the file.
    outfile << "gmvinput ascii\n";

    // No. of nodes
    outfile << "nodes " << NumVertices << "\n";

    // x coordinates
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << (*VertCoord)(1,i);
    outfile << "\n";

    // y coordinates
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << (*VertCoord)(2,i);
    outfile << "\n";

    // z coordinates
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << (*VertCoord)(3,i);
    outfile << "\n";

    // No. of cells
    outfile << "cells " << NumElements << "\n";

    // all hexaeder cells
    switch (NUMOFVERT) {
    case 8:
        for (i = 1;  i <= NumElements;  i++) {
            outfile << "hex " << NUMOFVERT << "\n";
            for (j = 1;  j <= NUMOFVERT;  j++)
                outfile << " " << (*VertElem)(j, i);
            outfile << "\n";
        }

        break;

    default:
        std::string message = progname + " (process " + int_to_string(MyProcID) + "):\n"
                            + "  No routine for exporting cells with " + int_to_string(NUMOFVERT) + "nodes available.\n" 
                            + "  Grid file will be empty.\n";

        STD_CERR << message;
	protocol  << message;

        break;
    }

    DoubleVector *LT1[MAXARRAY];
    DoubleVector *LT2[MAXARRAY];
    DoubleVector *LT3[MAXARRAY];
    DoubleVector *LT4[MAXARRAY];
    DoubleVector *LT5[MAXARRAY];

    LT1[MaxLevel] = sol1;
    LT2[MaxLevel] = sol2;
    LT3[MaxLevel] = sol3;
    DoubleVector rot_p(TotNumFaces);
    ConToRot(p, &rot_p, MaxLevel);
    LT4[MaxLevel] = &rot_p;
    LT5[MaxLevel] = conc;

//      for (int alevel = MaxLevel-1;  alevel >= level;  alevel--) {
//          LT1[alevel] = new DoubleVector(MTotNumFaces[alevel]);
//          LT2[alevel] = new DoubleVector(MTotNumFaces[alevel]);
//          LT3[alevel] = new DoubleVector(MTotNumFaces[alevel]);
//          LT4[alevel] = new DoubleVector(MTotNumFaces[alevel]);
//          LT5[alevel] = new DoubleVector(MTotNumFaces[alevel]);
//      }

//      for (int alevel = MaxLevel-1;  alevel >= level;  alevel--) {
//          ActiveLevel = alevel;
//          elem->ParRestrict(LT1[alevel+1],          LT1[alevel],
//                            MVertElem[alevel+1],    MVertElem[alevel],
//                            MMidFaces[alevel+1],    MMidFaces[alevel],
//                            MNeighElem[alevel+1],   MNeighElem[alevel],
//                            MNumVertices[alevel+1], MNumVertices[alevel],
//                            MNumElements[alevel+1], MNumElements[alevel], this);
//          elem->ParRestrict(LT2[alevel+1],          LT2[alevel],
//                            MVertElem[alevel+1],    MVertElem[alevel],
//                            MMidFaces[alevel+1],    MMidFaces[alevel],
//                            MNeighElem[alevel+1],   MNeighElem[alevel],
//                            MNumVertices[alevel+1], MNumVertices[alevel],
//                            MNumElements[alevel+1], MNumElements[alevel], this);
//          elem->ParRestrict(LT3[alevel+1],          LT3[alevel],
//                            MVertElem[alevel+1],    MVertElem[alevel],
//                            MMidFaces[alevel+1],    MMidFaces[alevel],
//                            MNeighElem[alevel+1],   MNeighElem[alevel],
//                            MNumVertices[alevel+1], MNumVertices[alevel],
//                            MNumElements[alevel+1], MNumElements[alevel], this);
//          elem->ParRestrict(LT4[alevel+1],          LT4[alevel],
//                            MVertElem[alevel+1],    MVertElem[alevel],
//                            MMidFaces[alevel+1],    MMidFaces[alevel],
//                            MNeighElem[alevel+1],   MNeighElem[alevel],
//                            MNumVertices[alevel+1], MNumVertices[alevel],
//                            MNumElements[alevel+1], MNumElements[alevel], this);
//          elem->ParRestrict(LT5[alevel+1],          LT5[alevel],
//                            MVertElem[alevel+1],    MVertElem[alevel],
//                            MMidFaces[alevel+1],    MMidFaces[alevel],
//                            MNeighElem[alevel+1],   MNeighElem[alevel],
//                            MNumVertices[alevel+1], MNumVertices[alevel],
//                            MNumElements[alevel+1], MNumElements[alevel], this);
//      }


    // Ausgabe der Einstroemrandwerte.
//     double X,Y,Z;
//     blink* temp;
//     real_nodeBase=Mreal_nodeBase[level];
//     VertCoord=MVertCoord[level];

//     protocol.mToggleScreenOutput(ON);
//     if(Param->ElemType == 2) {
//         for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp)) {
//             if(temp->type==REAL_BOUND) {
//                 X=0.25*((*VertCoord)(1,temp->node1)+(*VertCoord)(1,temp->node2)
//                         +(*VertCoord)(1,temp->node3)+(*VertCoord)(1,temp->node4));
//                 Y=0.25*((*VertCoord)(2,temp->node1)+(*VertCoord)(2,temp->node2)
//                         +(*VertCoord)(2,temp->node3)+(*VertCoord)(2,temp->node4));
//                 Z=0.25*((*VertCoord)(3,temp->node1)+(*VertCoord)(3,temp->node2)
//                         +(*VertCoord)(3,temp->node3)+(*VertCoord)(3,temp->node4));
//                 if (X < 1e-8) {
//                     protocol << "(" << X << "/" << Y << "/" << Z << "): "
//                              << ": (" << (*LT1[level])(temp->node) << "/" << (*LT2[level])(temp->node) << "/" << (*LT3[level])(temp->node) << ")\n";
//                 }
//             }
//         }
//     }

//      for (int alevel = MaxLevel-1;  alevel >= level;  alevel--) {
//          delete LT1[alevel];
//          delete LT2[alevel];
//          delete LT3[alevel];
//          delete LT4[alevel];
//          delete LT5[alevel];
//      }

    // Interpolate non-conforme solution to conform.
    DoubleVector v1(MNumVertices[MaxLevel]);      // velocity in x direction
    DoubleVector v2(MNumVertices[MaxLevel]);      // velocity in y direction
    DoubleVector v3(MNumVertices[MaxLevel]);      // velocity in z direction
    DoubleVector v4(MNumVertices[MaxLevel]);      // pressure
    DoubleVector v5(MNumVertices[MaxLevel]);      // temperature

    SetLevel(MaxLevel);
    IntpolNonToKon(LT1[MaxLevel], LT2[MaxLevel], LT3[MaxLevel], LT4[MaxLevel], LT5[MaxLevel], &v1, &v2, &v3, &v4, &v5, MaxLevel);

#ifdef INCLUDE_VORTICITY
    // calculate vorticity
    DoubleVector vorx(MNumElements[MaxLevel]);
    DoubleVector vory(MNumElements[MaxLevel]);
    DoubleVector vorz(MNumElements[MaxLevel]);
    Vorticity(*sol1, *sol2, *sol3, vorx, vory, vorz, -1.);

    // some space for vorticity output fields
    DoubleVector v6(MNumVertices[MaxLevel]);      // vorx
    DoubleVector v7(MNumVertices[MaxLevel]);      // vory
    DoubleVector v8(MNumVertices[MaxLevel]);      // vorz

    SetLevel(MaxLevel);
    IntpolConToKon(vorx,v6);  // Interpolate from element to corner
    IntpolConToKon(vory,v7);	
    IntpolConToKon(vorz,v8);	
#endif

    // Back again: writing to file.
    // Determine the values on the current multigrid level.
    NumVertices = MNumVertices[level];

    // velocity, given in each vertex:        velocity 1
    // (velocity given in each cell would be: velocity 0)
    outfile << "velocity 1\n";

    // velocity in x direction
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << v1(i);
    outfile << "\n";

    // velocity in y direction
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << v2(i);
    outfile << "\n";

    // velocity in z direction
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << v3(i);
    outfile << "\n";

    // Pressure values
    outfile << "variable\n";
    outfile << "pressure 1\n";
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << v4(i);
    outfile << "\n";

#ifdef INCLUDE_TEMPERATURE
    // temperature values
    outfile << "temperature 1\n";
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << v5(i);
    outfile << "\n";
#endif

#ifdef INCLUDE_VORTICITY
    // vorticity values (x, y, z, total)
    outfile << "vorticity_x 1\n";
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << v6(i);
    outfile << "\n";
    outfile << "vorticity_y 1\n";
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << v7(i);
    outfile << "\n";
    outfile << "vorticity_z 1\n";
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << v8(i);
    outfile << "\n";
    outfile << "vorticity_total 1\n";
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << 
	    sqrt(v6(i)*v6(i) + v7(i)*v7(i) + v8(i)*v8(i));
    outfile << "\n";
#endif

    // We are done.
    outfile << "endvars\n";

    // Finally write elapsed simulated time into file.
    outfile << "probtime " << time << '\n';

    outfile << "endgmv\n";
    outfile.mCloseFile();

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::GMVOutput.\n";
        protocol.mFlush();
    }

    return;
} // end GMVOutput


void Task::GMVGridOutput(int level)
{
    int i, j;
    std::string filename = Param->OutputBaseDir + Param->GMVGridFile;
//    int NumElements, NumVertices, VertCoord, VertElem;

    // Don't write a grid file with a finer grid than the maximum
    // output level.
    if (level > Param->GMVOutputLevel)
        return;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::GMVGridOutput.\n";
        protocol.mFlush();
    }

    // Append current processor id to filename ('p': processor)
    filename += ".p" + int_to_string (MyProcID, "0", 3) + ".gmv";
    COutput outfile(filename.c_str(), ACTIVE);

    // Determine the values on the current multigrid level.
//    NumElements = MNumElements[level];
//    NumVertices = MNumVertices[level];
//    VertCoord   = MVertCoord[level];
//    VertElem    = MVertElem[level];

    // Begin to fill the file.
    outfile << "gmvinput ascii\n";

    // No. of nodes
    outfile << "nodes " << NumVertices << "\n";

    // x coordinates
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << (*VertCoord)(1,i);
    outfile << "\n";

    // y coordinates
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << (*VertCoord)(2,i);
    outfile << "\n";

    // z coordinates
    for (i = 1;  i <= NumVertices;  i++)
        outfile << "  " << (*VertCoord)(3,i);
    outfile << "\n";

    // No. of cells
    outfile << "cells " << NumElements << "\n";

    // all hexaeder cells
    switch (NUMOFVERT) {
    case 8:
        for (i = 1;  i <= NumElements;  i++) {
            outfile << "hex " << NUMOFVERT << "\n";
            for (j = 1;  j <= NUMOFVERT;  j++)
                outfile << " " << (*VertElem)(j, i);
            outfile << "\n";
        }

        break;

    default:
        std::string message = progname + " (process " + int_to_string(MyProcID) + "):\n"
                            + "  No routine for exporting cells with " + int_to_string(NUMOFVERT) + "nodes available.\n" 
                            + "  Grid file will be empty.\n";

        STD_CERR << message;
	protocol  << message;

        break;
    }

    outfile << "endgmv\n";
    outfile.mCloseFile();

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::GMVGridOutput.\n";
        protocol.mFlush();
    }

    return;
} // end GMVGridOutput
