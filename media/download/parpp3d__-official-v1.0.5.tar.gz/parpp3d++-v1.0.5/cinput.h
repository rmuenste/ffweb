#ifndef CINPUTH

#define CINPUTH

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>				  // for string type
#include <mpi.h>				  // for MPI_Finalize()
#include "coutput.h"				  // for definition of COutput
#include "Errorcodes.h"				  // for error codes
#include <typecasts.h>

// It's good to know which process reports error messages
extern int         MyProcID;
// ... and where to write error messages to.
extern COutput     protocol;
extern std::string progname;

class CInput
{
private:
    std::ifstream    *infile;
    std::string  filename;
  
public:
    CInput(const char *aName);
    ~CInput();

    void mCloseFile   ();
    void GoToNextLine (void);
    void mStatus      ();
    void mAbortProgram(const std::string errorMessage, const int errorNumber);
  
    // Define output operator << for each type used in this program
    template<class T> inline CInput& operator>>(T& bezeichner)
    {
        if (infile->good()) {
            *infile >> bezeichner;
        } else if (infile->eof()) {
            CInput::mAbortProgram("Reached end of file '" + filename + "'\n  Can not read further.", FILE_READ_ERROR);
        } else {
            CInput::mAbortProgram("Could not read from file '" + filename + "'", FILE_READ_ERROR);
        }

        return *this;
    }    
};		

#endif
