#include "ParGrid.h"

void ParGrid::ReadCoarseGrid(const char* name) 
{
    if (CoarseGrid == NULL) 
        CoarseGrid = new CCoarseGrid(this);
    CoarseGrid->ReadCoarseGrid(name);
}

void ParGrid::PrintCoarseNeigh(void) 
{
    if (CoarseGrid) 
        CoarseGrid->PrintNeighElem();
}
  
void ParGrid::PrintCoarseCoord(void) 
{
    if (CoarseGrid) 
        CoarseGrid->PrintVertCoord();
}

void ParGrid::PrintCoarseElem(void) 
{
  if (CoarseGrid) 
      CoarseGrid->PrintVertElem();
}

int ParGrid::GetMakroInfo(unsigned mnum, MComTool *MyCom)
{
  return CoarseGrid->GetMakroInfo(mnum,NumElements,NumVertices,
				  NumEdges,NumVertElem,
				  NumEdgeElem,NumFaceElem,
				  NumBound,NumVertBound,VertCoord,VertElem,
				  InfoVertEdge,InfoVertBound,RealBound,
				  myBase,real_nodeBase,
				  myMidBase,myMidNeighBase,real_midnodeBase,
				  InfoList,NumCoarseElements,Param,MyCom);
}
  
