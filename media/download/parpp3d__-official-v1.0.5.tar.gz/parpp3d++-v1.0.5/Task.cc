#include "Task.h"

//#define CONTROL_MSG

DateTime TotalClock;
DateTime Clock;
DateTime ClockMVMult, ClockMVMultCom;
DateTime ClockDefect;
DateTime ClockNorm;
DateTime ClockMatrix;
DateTime ClockSolving;

double TCommNetwork = 0;			  // time needed to set up communication network
double TRefine = 0, TRefineCom = 0;		  // time spent in refining routines
double TMVMult = 0, TMVMultCom = 0;         	  // time spent in matrix vector multiplication routines
double TMoment = 0;
double TPressure = 0;
double TSolving = 0;
double TMatrix = 0, TMatrixCom = 0;		  // time needed to compute and update matrices
double TSmooth = 0, TSmoothCom = 0;		  // time spent in smoothing routines
double TDefect = 0, TDefectCom = 0;		  // time spent computing defect
double TRest = 0, TRestCom = 0;			  // time spent in restriction routines
double TProl = 0, TProlCom = 0;			  // time spent in prolongation routines
double TCoarse = 0, TCoarseCom = 0;		  // time needed for solving coarse grid problem
double TNorm = 0, TNormCom = 0;			  // time needed for calculating norms
double TEvalue = 0;				  // ?


Task::Task(Daten *mParam)
{
    MyCom = new MComTool();
    SendBoundData = NULL;
    RecvBoundData = NULL;
    SPInfo = NULL;
    SPCoord = NULL;

    Param = mParam;

    MyProtFile = 0;
    A = 0;
    RotElement = 0;
    ConElement = 0;
    CoarseGrid = 0;
    for (unsigned int ILEV = 0; ILEV <= Param->NFine; ILEV++) {
        E[ILEV] = 0;
        EConst[ILEV] = 0;
    }

//  SetDirNames(XStep,Dt);
}

Task::~Task(VOID)
{
    if (RotElement)
        delete RotElement;
    if (ConElement)
        delete ConElement;
    if (A)
        delete A;

//  if (MyProtFile)
//      Prot.CloseFile(MyProtFile);
    if (MyCom)
        delete MyCom;

//  StdOut<<"After delete MyCom !!\n";

//  Prot.SetScreen();

}


// void Task::SetDirNames(double h,double k)
// {
//     unsigned hint,kint;

//     hint=(int)(1/h+0.5);
//     kint=(int)(1/k+0.5);

// //  StdOut<<"ProtokollDirName:"<<ProtokollDirName<<"\n";
// }


void Task::InitMatrices(void)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::InitMatrices.\n";
        protocol.mFlush();
    }

    Prot<<"INIT MATRICES !!!  MyProcID="<<MyProcID<<"\n";

    if (Param->ElemType == 1) {
        Prot<<"Error: this version doesnot provide conforming elements !!\n";
        protocol << progname << " (process " << MyProcID << "):\n"
                 << "  Program aborted in Task::InitMatrices\n";
        MPI_Finalize();
        exit(0);
    } else {
        //      RotElement=new ParRotatedElement_3D(this);
        MassRotElement = new ParNonParamElement_3D(this);
        RotElement     = new ParNonParamMeanElement_3D(this);
        ConElement     = new ConstantElement_3D(this);
    }

    IntArray2D Laplace(2,3), Mass(2,1);
    IntArray   RightSide(1);
    unsigned   ICLEAR, ISYMM;

    DateTime AssembleClock;
    AssembleClock.SetTime();

    A = new MultiCompactMatrix(Param->NFine);
    C = new MultiCompactMatrix(Param->NFine);
//  M = new MultiCompactMatrix(Param->NFine);

    // Laplace-Matrix A
    protocol << "\n Assembling laplace matrix. "; protocol.mFlush();
    if (Debug) protocol << '\n';
    Laplace(1, 1) = 2;
    Laplace(2, 1) = 2;
    Laplace(1, 2) = 3;
    Laplace(2, 2) = 3;
    Laplace(1, 3) = 4;
    Laplace(2, 3) = 4;
    ISYMM  = 0;
    ICLEAR = TRUE;
    CoeffA1();

    AssembleMatrices(*RotElement, A, TRUE, Laplace, 3, Param->ICUB, ISYMM, ICLEAR, 0);
    UpdateDiagonal();
    InitILU(A);

    if (Debug) protocol << ' ';
    protocol << "Done.\n"; protocol.mFlush();
//      Prot<<"After assemble laplace matrix !!\n";
//      Prot.Flush();

    B1 = new MultiRectMatrix(Param->NFine);
    B2 = new MultiRectMatrix(Param->NFine);
    B3 = new MultiRectMatrix(Param->NFine);
    Build_B(*B1,*B2,*B3,*A);


    // Mass matrix M
    protocol << " Assembling mass matrix. "; protocol.mFlush();
    if (Debug) protocol << '\n';

    M = new MultiCompactMatrix(*A);
    Mass(1,1) = 1;
    Mass(2,1) = 1;
    CoeffM();
    ICLEAR = TRUE;
    // ICUB = 2
    AssembleMatrices(*MassRotElement, M, TRUE, Mass, 1, 2, ISYMM, ICLEAR, 0);
    SetMultiBound(M);
    PureLumpM = GetPureLumpedMassMat(*M);
    LumpM = GetLumpedMassMat(*M);
//  SetLumpBound(LumpM);

//  Prot<<"LumpM=\n";
//  OutputVector((*LumpM)[Param->NFine],Param->NFine);

    if (Debug) protocol << ' ';
    protocol << "Done.\n"; protocol.mFlush();
//      Prot<<"After assemble mass matrix !!\n";
//      Prot.Flush();


    // calc projection-matrix
    protocol << " Calculating projection matrix. "; protocol.mFlush();
    if (Debug) protocol << '\n';

    C=GetProjMatrix();
    *C = 0;
    BuildProjMatrix(*C, *LumpM, *B1, *B2, *B3);
    delete B1;
    delete B2;
    delete B3;
    if (Debug) protocol << ' ';
    protocol << "Done.\n"; protocol.mFlush();

    MinLevel=2;
    ConstUpdateDiagonal();
    InitILU(C);
    ILU(C,EConst,0.0);
    MinLevel=1;

//  Prot<<"C=\n"<<*(*C)[Param->NFine]<<"\n";

  //  delete M;
  //M=new MultiCompactMatrix(*A);
    Mass(1,1)=1;
    Mass(2,1)=1;
    CoeffM();
    ICLEAR=TRUE;
    AssembleMatrices(*RotElement, M, TRUE, Mass, 1, Param->ICUB, ISYMM, ICLEAR, 0);
    SetMultiBound(M);
//  LumpM=GetLumpedMassMat(*M);

//  Prot<<"LumpM=\n";
//  OutputVector((*LumpM)[Param->NFine],Param->NFine);
//      Prot<<"Time for assembling: "<<AssembleClock.GetTimeDiff()<<" seconds\n";
//      StdOut<<"After AssembleMatrix !!\n";
//      Prot.Flush();

    CoarseGrid->InitMatrices(Param,TRUE,Laplace,3,Param->ICUB,ISYMM,ICLEAR,0);

    protocol << "\n Time needed for assembling matrices: " << AssembleClock.GetTimeDiff() << "s\n";
    protocol.mFlush();
    Prot<<"After init matrices !!\n";
    Prot.Flush();

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::InitMatrices.\n";
        protocol.mFlush();
    }
} // end InitMatrices


int Task::ParMultiRefine(const char* grid)
{
//  int i,j;
//  unsigned ISCAD;
    unsigned ISE,ISA,ISEEL,ISAEL,ISVEL,IDISP;
    blink* temp;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::ParMultiRefine.\n";
        protocol.mFlush();
    }

    if (Param->ElemType==1) {
        ISA=0;
    } else {
        // ISA=2 No MidFaceCoord
        // ISA=3 MidFaceCoord
        ISA=2;
    }

//    ISCAD=0;
    ISE=1;
    ISEEL=0;
    ISAEL=1;					  // Build information about which elements meet at a face
    ISVEL=0;
    IDISP=0;

    protocol << " Reading grid file from disk. "; protocol.mFlush();
    if (Debug) protocol << '\n';
    ReadCoarseGrid(grid);
#ifdef CONTROL_MSG
    PrintCoarseCoord();
    PrintCoarseElem();
#endif
    if (Debug) protocol << ' ';
    protocol << "Done.\n"; protocol.mFlush();

    // Create or read partition, ... (?)
    if (GetMakroInfo(MyProcID,MyCom) == false)
        return false;                             // problems encountered, exit program

  //  Prot<<"After GetMakroInfo: \n";
  //for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp))
  //  {
  //    Prot<<"kon bound node: "<<temp->node<<" type="<<temp->type<<" X="<<(*VertCoord)(1,temp->node)<<" Y="<<(*VertCoord)(2,temp->node)<<" Z="<<(*VertCoord)(3,temp->node)<<"\n";
  //  }

    if (Param->ElemType==2)
        konBase=myBase;

    Clock.SetTime();
    if (Param->ElemType == 1) {
        Refine(0, 1, 1, 0, 0, 0, 0, 1);
    } else {
        Refine(0, 1, 1, 1, 0, 0, 0, 1);
    }
    TRefine += Clock.GetTimeDiff();

#ifdef CONTROL_MSG
    Prot<<"MyProcID="<<MyProcID<<"\n";
    Prot<<"NumElements="<<NumElements<<"\n";
    Prot<<"NumVertices="<<NumVertices<<"\n";
    Prot<<"NumEdges="<<NumEdges<<"\n";
    Prot<<"NumVertElem="<<NumVertElem<<"\n";
    Prot<<"NumBound="<<NumBound<<"\n";
    Prot<<"VertCoord=\n"<<*VertCoord<<"\n";
    Prot<<"VertElem=\n"<<*VertElem<<"\n";
    Prot<<"InfoVertEdge=\n"<<*InfoVertEdge<<"\n";
    Prot<<"BoundInfo=\n"<<*RealBound<<"\n";
#endif

    unsigned P_ISE;

    if (ISE < 1)
        P_ISE = 1;
    else
        P_ISE = ISE;

    // Print header of table containing information on the used grids.
    protocol << "\n";
    if (nProcs == 1) {
        protocol << " Information on grids used in multi grid:\n\n";
    } else {
        protocol << " Information on the grid process no. " << MyProcID << " uses in multi grid:\n\n";
    }
    protocol << "    level | #elements | #vertices | #faces \n";
    protocol << "   -------+-----------+-----------+---------\n";

    for (unsigned int ILEV = 1; ILEV <= TotalLevel; ILEV++) {
        if (Param->ElemType == 2) {
            myBase = konBase;

            // Information ueber die richtigen Randknoten aufbauen.
            if (ILEV > 1) {
                real_nodeBase = Mkonreal_nodeBase[ILEV-1];
            }
        }

        Prot<<"----> Refine Level : "<<ILEV<<"\n";
        Prot.Flush();

        Clock.SetTime();

        ActiveLevel = ILEV-1;

        if (ILEV == 1)
            Refine(0, 1, P_ISE, ISA, ISEEL, ISAEL, ISVEL, IDISP);
        else
            Refine(1, 0, P_ISE, ISA, ISEEL, ISAEL, ISVEL, IDISP);

        // Check whether we have used too much processes
        // (some processes might have been assigned no nodes/elements)
        if (NumElements == 0) {
            std::string message
                = progname + " (process " + int_to_string(MyProcID) + "):\n"
                + "  Unrecoverable error discovered:\n"
                + "    No elements were assigned to process " + int_to_string(MyProcID) + ".\n"
                + "  Solution:\n"
                + "    Either use another partition or less parallel processes.\n"
                + "  Program aborted in Task::ParMultiRefine.\n";

            protocol  << message;
            STD_CERR << message;

            MPI_Abort(MPI_COMM_WORLD, ILLEGAL_PARTITION_ERROR);
        }

        // Adjust grid
	ActiveLevel = ILEV-1;
	MInfoList[ActiveLevel + 1] = InfoList;
	BoundaryProjection();

        MemInfo Space;
        Prot<<"MemInfo after refine level="<<ILEV<<" :\n"<<Space<<"\n";
        Prot.Flush();

    //Check NeighElem
// - --------------------------------------------------// Activated for debugging purposes
//          int IEL,IAR,INEIGH,JAR,JNEIGH,flag;
//          for (IEL=1;IEL<=NumElements;IEL++)
//          {
//              for (IAR=1;IAR<=NumFaceElem;IAR++)
//              {
//                  INEIGH=(*NeighElem)(IAR,IEL);
//                  if (INEIGH>0) {
//                      flag=0;
//                      for (JAR=1;JAR<=NumFaceElem;JAR++)
//                      {
//                          JNEIGH=(*NeighElem)(JAR,INEIGH);
//                          if (JNEIGH==IEL)
//                          {
//                              flag=1;
//                              break;
//                          }
//                      }
//                      if (flag==0)
//                          Prot<<"!! Fehler in NeighElem elem="<<IEL<<" neigh="<<INEIGH<<"\n";
//                  }
//              }
//          }

//          for (int i=1;i<=TotNumFaces;i++) {
//              Prot<<"face="<<i<<" Y="<<(*MidFaceCoord)(1,i)<<" Y="<<(*MidFaceCoord)(2,i)<<" Z="<<(*MidFaceCoord)(3,i)<<"\n";
//          }

//          blink* temp;
//          double X,Y,Z;
//          int IEQ;
//          Prot<<"realnodeBase=\n";
//          for (temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp))
//          {
//              if (temp->type==REAL_BOUND)
//              {
//                  IEQ=temp->node;
//                  X=(*VertCoord)(1,IEQ);
//                  Y=(*VertCoord)(2,IEQ);
//                  Z=(*VertCoord)(3,IEQ);
//                  Prot<<"X="<<X<<" Y="<<Y<<" Z="<<Z<<"\n";;
//              }
//          }

//    if (ILEV==1)
        TRefine += Clock.GetTimeDiff();

        Prot<<"             Num. of Elements : "<<NumElements<<"\n";
        Prot<<"             Num. of Vertices : "<<NumVertices<<"\n";
        Prot<<"             Num. of Faces :    "<<TotNumFaces<<"\n";
        Prot.Flush();

        protocol << "     "  << std::setw(3) << std::setfill(' ') << ILEV << "  |"
                 << "  "     << std::setw(7) << std::setfill(' ') << NumElements << "  |"
                 << "  "     << std::setw(7) << std::setfill(' ') << NumVertices << "  |"
                 << " "      << std::setw(7) << TotNumFaces << "\n";
        protocol.mFlush();

        MNumElements[ILEV]   = NumElements;
        MNumVertices[ILEV]   = NumVertices;
        MNumEdges[ILEV]      = NumEdges;
        MNumVertElem[ILEV]   = NumVertElem;
        MNumElemVert[ILEV]   = NumElemVert;
        MNumElemVert[ILEV]   = NumElemVert;
        MNumVertBound[ILEV]  = NumVertBound;

        MTotNumEdges[ILEV]   = TotNumEdges;
        MTotNumFaces[ILEV]   = TotNumFaces;
        MNumEdgeElem[ILEV]   = NumEdgeElem;
        MNumFaceElem[ILEV]   = NumFaceElem;
        MNumElemEdge[ILEV]   = NumElemEdge;
        MNumEdgeVert[ILEV]   = NumEdgeVert;
        MNumFaceVert[ILEV]   = NumFaceVert;
        MNumFaceEdge[ILEV]   = NumFaceEdge;
        MNumEdgesBound[ILEV] = NumEdgesBound;
        MNumFacesBound[ILEV] = NumFacesBound;

        if (ILEV < TotalLevel) {
            if (VertCoord) {
                MVertCoord[ILEV] = new DoubleArray2D(*VertCoord);
            }
            if (MidCoord) {
                MMidCoord[ILEV] = new DoubleArray2D(*MidCoord);
            }
            if (VertElem) {
		MVertElem[ILEV] = new IntArray2D(*VertElem);
            }
            if (NeighElem) {
                MNeighElem[ILEV] = new IntArray2D(*NeighElem);
            }
            if (ElemVert) {
                MElemVert[ILEV] = new IntArray2D(*ElemVert);
            }
            if (ElemEdge) {
                Prot<<"ElemEdge-Array !!\n";
                MElemEdge[ILEV] = new IntArray2D(*ElemEdge);
            }
            if (InfoVertEdge) {
                MInfoVertEdge[ILEV] = new IntArray(*InfoVertEdge);
            }
            if (InfoVertBound) {
                MInfoVertBound[ILEV] = new IntArray2D(*InfoVertBound);
            }
            if (VertBound) {
                MVertBound[ILEV] = new IntArray(*VertBound);
            }
            if (ElemBound) {
                Prot<<"ElemBound-Array !!\n";
                MElemBound[ILEV] = new IntArray(*ElemBound);
            }
            if (PosBoundEntry) {
                Prot<<"PosBoundEntry-Array !!\n";
                MPosBoundEntry[ILEV] = new IntArray(*PosBoundEntry);
            }
            if (MidFaceCoord) {
                Prot<<"MidFaceCoord-Array !!\n";
                MMidFaceCoord[ILEV] = new DoubleArray2D(*MidFaceCoord);
            }
            if (MidEdges) {
                MMidEdges[ILEV] = new IntArray2D(*MidEdges);
            }
            if (MidFaces)
                MMidFaces[ILEV] = new IntArray2D(*MidFaces);
            if (ElemMeetEdge) {
                Prot<<"ElemMeetEdge-Array !!\n";
                MElemMeetEdge[ILEV] = new IntArray2D(*ElemMeetEdge);
            }
            if (ElemMeetFace) {
                Prot<<"ElemMeetFace-Array !!\n";
                MElemMeetFace[ILEV] = new IntArray2D(*ElemMeetFace);
            }
            if (VertMeetEdge) {
                Prot<<"VertMeetEdge-Array !!\n";
                MVertMeetEdge[ILEV] = new IntArray2D(*VertMeetEdge);
            }
            if (FaceMeetEdge) {
                Prot<<"FaceMeetEdge-Array !!\n";
                MFaceMeetEdge[ILEV] = new IntArray2D(*FaceMeetEdge);
            }
            if (VertMeetFace) {
                Prot<<"VertMeetFace-Array !!\n";
                MVertMeetFace[ILEV] = new IntArray2D(*VertMeetFace);
            }
            if (EdgeMeetFace) {
                Prot<<"EdgeMeetFace-Array !!\n";
                MEdgeMeetFace[ILEV] = new IntArray2D(*EdgeMeetFace);
            }
            if (ElemMeetVert) {
                Prot<<"ElemMeetVert-Array !!\n";
                MElemMeetVert[ILEV] = new IntArray2D(*ElemMeetVert);
            }
            if (FaceMeetVert) {
                Prot<<"FaceMeetVert-Array !!\n";
                MFaceMeetVert[ILEV] = new IntArray2D(*FaceMeetVert);
            }
            if (MidFacesBound) {
                Prot<<"MidFacesBound-Array !!\n";
                MMidFacesBound[ILEV] = new IntArray(*MidFacesBound);
            }
        } // end if (ILEV < TotalLevel)

        else {
            MVertCoord[ILEV]     = VertCoord;
            MMidCoord[ILEV]      = MidCoord;
            MVertElem[ILEV]      = VertElem;
            MMidEdges[ILEV]      = MidEdges;
            MNeighElem[ILEV]     = NeighElem;
            MElemVert[ILEV]      = ElemVert;
            MElemEdge[ILEV]      = ElemEdge;
            MInfoVertEdge[ILEV]  = InfoVertEdge;
            MInfoVertBound[ILEV] = InfoVertBound;
            MVertBound[ILEV]     = VertBound;
            MElemBound[ILEV]     = ElemBound;
            MPosBoundEntry[ILEV] = PosBoundEntry;

            MMidFaceCoord[ILEV]  = MidFaceCoord;
            MMidFaces[ILEV]      = MidFaces;
            MElemMeetEdge[ILEV]  = ElemMeetEdge;
            MElemMeetFace[ILEV]  = ElemMeetFace;
            MVertMeetEdge[ILEV]  = VertMeetEdge;
            MFaceMeetEdge[ILEV]  = FaceMeetEdge;
            MVertMeetFace[ILEV]  = VertMeetFace;
            MEdgeMeetFace[ILEV]  = EdgeMeetFace;
            MElemMeetVert[ILEV]  = ElemMeetVert;
            MFaceMeetVert[ILEV]  = FaceMeetVert;
            MMidFacesBound[ILEV] = MidFacesBound;
        } // end else (i.e. ILEV >= TotalLevel)

	// If you have a coarse grid that has too less elements to
	// be computed on many nodes, refine it once.
	// This function call will help you.
	// All you have to do is uncomment these lines, re-compile,
	// and run the program using one process.
//    	if (ILEV > 1) {
//    	    WriteGrid("3d_gitter.tri", ILEV);
//    	    protocol << "\nA refined coarse grid has been written to disk.\n"
//    		     << "It is called <3d_gitter.tri>\n"
//    		     << "Program will now exit.\n\n";

//    	    // Only write grid file when avs output is turend on.
//    	    if (ILEV == Param->AVSOutputLevel) {
//    		AVSGridOutput(ILEV);
//    	    }

//    	    // Only write grid file when gmv output is turend on.
//    	    if (ILEV == Param->GMVOutputLevel) {
//    		GMVGridOutput(ILEV);
//    	    }

//    	    exit(1);
//    	}

	// Only write grid file when avs output is turend on.
        if (ILEV == Param->AVSOutputLevel) {
	    AVSGridOutput(ILEV);
	}

	// Only write grid file when gmv output is turend on.
	if (ILEV == Param->GMVOutputLevel) {
	    GMVGridOutput(ILEV);
	}

//      Prot << "Level=" << ILEV << "\n";
//      Prot << "myBase=\n";
//      myBase->printNodes();
//      Prot << "myMidBase=\n";
//      myMidBase->printNodes();

        if (Param->ElemType == 2) {
            konBase          = myBase;
            myBase           = myMidBase;
            konreal_nodeBase = real_nodeBase;
            real_nodeBase    = real_midnodeBase;
        }

        if (ILEV==1)
            MyCom->SetCommunication(myBase->get_neighlist());


	// Set Neumann boundary for conforming boundary nodes
	for (temp = konreal_nodeBase->get_first();  temp;  temp = konreal_nodeBase->get_next(temp)) {
	    if (TestNeumann(temp->node) == 0) {
		temp->type = NEUMANN_BOUND;

// 		protocol << "Conforming node (" << temp->node << ") with coordinates "
// 			 << " X=" << (*VertCoord)(1,temp->node)
// 			 << " Y=" << (*VertCoord)(2,temp->node)
// 			 << " Z=" << (*VertCoord)(3,temp->node)
// 			 << " has Neumann boundary condition\n";
	    }
	}

	// Set Neumann boundary for non-conforming boundary nodes
	for (temp = real_nodeBase->get_first();  temp;  temp = real_nodeBase->get_next(temp)) {
	    if (TestNeumannMid(temp->node, temp->node1, temp->node2, temp->node3, temp->node4) == 0) {
		temp->type = NEUMANN_BOUND;

// 		double X = 0.25 * ((*VertCoord)(1, temp->node1) + (*VertCoord)(1, temp->node2)
// 				   + (*VertCoord)(1, temp->node3) + (*VertCoord)(1, temp->node4));
// 		double Y = 0.25 * ((*VertCoord)(2, temp->node1) + (*VertCoord)(2, temp->node2)
// 				   + (*VertCoord)(2, temp->node3) + (*VertCoord)(2, temp->node4));
// 		double Z = 0.25 * ((*VertCoord)(3, temp->node1) + (*VertCoord)(3, temp->node2)
// 				   + (*VertCoord)(3, temp->node3) + (*VertCoord)(3, temp->node4));
// 		protocol << "Non-conforming node (" << temp->node << ") with coordinates "
// 			 << " X=" << X
// 			 << " Y=" << Y
// 			 << " Z=" << Z
// 			 << " has Neumann boundary condition\n";
	    }
	}

        if (ILEV < TotalLevel) {
            MmyBase[ILEV]           = new node_base(myBase);
            MRealBound[ILEV]        = new IntArray(*RealBound);
            Mreal_nodeBase[ILEV]    = new blist_base(real_nodeBase);
            Mkonreal_nodeBase[ILEV] = new blist_base(konreal_nodeBase);
            MInfoList[ILEV]         = new blist_base(InfoList);
        } else {
            MmyBase[ILEV]           = myBase;
            MRealBound[ILEV]        = RealBound;
            Mreal_nodeBase[ILEV]    = real_nodeBase;
            Mkonreal_nodeBase[ILEV] = konreal_nodeBase;
            MInfoList[ILEV]         = InfoList;
        }

        if (Param->ElemType == 2) {
            myMidBase        = new node_base;
            real_midnodeBase = new blist_base;
            blist* temp_list;

            for (temp_list=MmyBase[ILEV]->get_neighlist()->get_first(); temp_list;
                 temp_list=MmyBase[ILEV]->get_neighlist()->get_next(temp_list)) {
                    myMidBase->new_neigh(temp_list->neigh,temp_list->spinfo);
            }
        }


        MmyBase[ILEV]->build_array(MSendBound[ILEV]);
        MmyBase[ILEV]->build_array(MRecvBound[ILEV]);
        SendBound=MSendBound[ILEV];
        RecvBound=MRecvBound[ILEV];

#ifdef CONTROL_MSG
        Prot<<"myBase=\n";
        MmyBase[ILEV]->printNodes();
        Prot<<"\nSendBound:\n";
        SendBound->print_list();
        Prot<<"\nRecvBound:\n";
        RecvBound->print_list();

        StdOut<<"\n\n!!!!!!!!  Before translate BoundInfo !!!!!!!!\n\n";
#endif

        Prot<<"Before communicate BoundInfo !!\n";
        Prot.Flush();

#ifdef CLOCK_MEASURE
        Clock.SetTime();
#endif
        CommunicateBoundInfo();
#ifdef CLOCK_MEASURE
	TCommNetwork += Clock.GetTimeDiff();
#endif
        InitDomainBound();

        Prot<<"After communicate BoundInfo !!\n";
        Prot.Flush();

        MSendBoundData[ILEV]=SendBoundData;
        MRecvBoundData[ILEV]=RecvBoundData;

#ifdef CONTROL_MSG
        StdOut<<"\n\n!!!!!!!!  After translate BoundInfo !!!!!!!!\n\n";

        Prot<<"\n!!!!! Send Bound !!!!\n";
        MSendBound[ILEV]->print_list();
        Prot<<"\n!!!!! Recieve Bound !!!!\n";
        MRecvBound[ILEV]->print_list();
#endif

//          MmyBase[ILEV]->build_neumann_array(MSendNeumannBound[ILEV]);
//          MmyBase[ILEV]->build_neumann_array(MRecvNeumannBound[ILEV]);
//          SendNeumannBound=MSendNeumannBound[ILEV];
//          RecvNeumannBound=MRecvNeumannBound[ILEV];

//  #ifdef CONTROL_MSG
//          MmyBase[ILEV]->printNodes();
//          Prot<<"\nSendNeumannBound:\n";
//          MSendNeumannBound[ILEV]->print_list();
//          Prot<<"\nRecvNeumannBound:\n";
//          MRecvNeumannBound[ILEV]->print_list();

//          StdOut<<"\n\n!!!!!!!!  Before translate NeumannBoundInfo !!!!!!!!\n\n";
//  #endif

//          CommunicateNeumannBoundInfo();
//          InitDomainNeumannBound();

//          MSendNeumannBoundData[ILEV]=SendNeumannBoundData;
//          MRecvNeumannBoundData[ILEV]=RecvNeumannBoundData;

//  #ifdef CONTROL_MSG
//          StdOut<<"\n\n!!!!!!!!  After translate NeumannBoundInfo !!!!!!!!\n\n";
//  #endif

        GetElemBoundInfo();
        MmyElemBase[ILEV]=myElemBase;
        myElemBase->build_array(MSendElemBound[ILEV],MSendFaceBound[ILEV]);
        myElemBase->build_array(MRecvElemBound[ILEV],MRecvFaceBound[ILEV]);
        SendElemBound=MSendElemBound[ILEV];
        RecvElemBound=MRecvElemBound[ILEV];
        SendFaceBound=MSendFaceBound[ILEV];
        RecvFaceBound=MRecvFaceBound[ILEV];

#ifdef CLOCK_MEASURE
        Clock.SetTime();
#endif
        CommunicateElemBoundInfo();
#ifdef CLOCK_MEASURE
	TCommNetwork += Clock.GetTimeDiff();
#endif
        InitDomainElemBound();

        Prot<<"After communicate ElemBoundInfo !!\n";
        Prot.Flush();

        MSendElemBoundData[ILEV]=SendElemBoundData;
        MRecvElemBoundData[ILEV]=RecvElemBoundData;

        SetFaceInfo(ILEV);
        SetElemInfo(ILEV);

	// Collect information to calculate drag & lift later faster
	SetCoeffInfo(ILEV);

        MPI_Barrier(MPI_COMM_WORLD);

        Prot<<"MemInfo after communicate info level="<<ILEV<<" :\n"<<Space<<"\n";
        Prot.Flush();

    }

    CleanUp();

//  DateTime SPClock;
//  CommunicateSPInfo();
//  Prot<<"Time for spinfo: "<<SPClock.GetTimeDiff()<<" seconds\n";

#ifdef CONTROL_MSG
    StdOut<<"\n\n!!!!!!!!  After translate SPInfo !!!!!!!!\n\n";
#endif

    // Init global grid for post-processing (or to be able to use method OutputVector)
//     if (Param->NFine <= 2) {
// 	Prot<<"Before init global grid !!\n";
// 	Prot.Flush();
// 	if ((MyProcID + 1) == MASTER) {
// 	    GlobalGrid = new PostGrid(TotalLevel,Param);
// 	    GlobalGrid->InitGrid(grid);
// 	}
// 	Prot<<"After InitGrid !!\n";
// 	Prot.Flush();
// 	CommunicatePostProcessInfo();
// 	Prot<<"After init global grid !!\n";
// 	Prot.Flush();
//     }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::ParMultiRefine.\n";
        protocol.mFlush();
    }

    return true;
} // end ParMultiRefine


VOID *Task::Run()
{
//     DoubleVector *sol,*temp;
    int      successfull;

    // Configuration for pipe configuration (no. 6)
//      Param->DiffRohr      = 0.04;
//      Param->Diff5         = 0.05;
//      Param->Diff4         = 0.05;
//      Param->Diff3         = 0.06;
//      Param->Diff2         = 0.1;
//      Param->Diff1         = 0.2;
//      Param->NumLagenZ     = 12;
//      Param->NumLagenRohrZ = 5;
//      Param->StartX = 0.;
//      Param->EndX   = 1.;
//      Param->StartY = 0.;
//      Param->EndY   = 1.;
//      Param->StartZ = 0.;
//      Param->StepZ  = 0.15;
//      double LENGTH = 0., STEP = Param->StepZ;
//      for (int i=1; i <= Param->NumLagenRohrZ + Param->NumLagenZ + 1; i++)
//          if (i > Param->NumLagenRohrZ + 3)
//              STEP *= 1.1;
//      LENGTH = Param->StartZ + STEP * (Param->NumLagenRohrZ + Param->NumLagenZ);
//      Param->RohrLength=LENGTH;

    SetTotalLevel(Param->NFine);

    // Initialize time measurement variables
    TotalClock.SetTime();
//      TRefine    = TMoment    = TPressure = TSolving = TMatrix    = 0.0;
//      TSmooth    = TDefect    = TRest     = TProl    = TCoarse    = TNorm    = TEvalue = 0.0;
//      TSmoothCom = TDefectCom = TRestCom  = TProlCom = TCoarseCom = TNormCom = 0.0;

    Prot << "nProcs=" << nProcs << "\n";

    // Read grid, compute/read partition, refine grid.
    successfull = ParMultiRefine(Param->GridFile.c_str());

    MPI_Barrier(MPI_COMM_WORLD);

//     TestGrid();
//     LaplaceTest();
//     return(NULL);

    // Grid successfully read and refined?
    if (successfull == true) {
        protocol << "\n"
                 << " Time needed for grid refining: " << timeval_to_string(TotalClock.GetTimeDiff()) << "\n"
                 << " Time needed for pure refining: " << timeval_to_string(TRefine) << "\n";

        MPI_Barrier(MPI_COMM_WORLD);

        // Initialize matrices
        Clock.SetTime();
	InitMatrices();
        TMatrix += Clock.GetTimeDiff();

	// Still more statistics about the grids used
//  	CalcAspectRatio();
	CalcAnisotropyDegree();
	CalcVolumes();

	protocol << "\n Creating structures containing information about\n"
		 << " Dirichlet, Neumann and artificial boundaries. "; protocol.mFlush();
	if (Debug) protocol << '\n';
        CreateBoundInfo();
	if (Debug) protocol << ' ';
	protocol << "Done.\n"; protocol.mFlush();

        MPI_Barrier(MPI_COMM_WORLD);

        SetPreSteps (Param->PreSteps);
        SetPostSteps(Param->PostSteps);
        SetSmoother (Param->Smoother);
        SetSolver   (Param->Solver);
        SetCycle    (Param->Cycle);

        vstart1    = GetRightSideVector(*RotElement);
        (*vstart1) = 0;
        CoeffL2V1();
        L2Projection(*RotElement, (*LumpM)[Param->NFine], vstart1, Param->ICUBRHS);
        SetBoundValues(vstart1);
        Communicate();
        GetBoundValuesMult(vstart1);

        vstart2    = GetRightSideVector(*RotElement);
        (*vstart2) = 0;
	CoeffL2V2();
	L2Projection(*RotElement,(*LumpM)[Param->NFine],vstart2, Param->ICUBRHS);
        SetBoundValues(vstart2);
        Communicate();
        GetBoundValuesMult(vstart2);

        vstart3    = GetRightSideVector(*RotElement);
        (*vstart3) = 0;
	CoeffL2V3();
	L2Projection(*RotElement,(*LumpM)[Param->NFine],vstart3, Param->ICUBRHS);
        SetBoundValues(vstart3);
        Communicate();
        GetBoundValuesMult(vstart3);

        // Chorin-Verfahren oder Van-Kan?
        if (Param->Method == 1) {
	    // Function "Chorin1" is not up-to-date. So, we use DiscreteProjection (which
	    // implemts VanKan method) with initial Chorin steps. We just tell the function
	    // that all time steps are initial time steps, i.e. are supposed to be done
	    // with Chorin method.
//              Chorin1(*RotElement, *ConElement, A, M, LumpM, C, vstart1, vstart2, vstart3);
	    Param->Method = - abs(int(Param->MaxTimeIterations));
            DiscreteProjection(*RotElement, *ConElement, A, M, LumpM, PureLumpM, C, vstart1, vstart2, vstart3);
        } else {
            DiscreteProjection(*RotElement, *ConElement, A, M, LumpM, PureLumpM, C, vstart1, vstart2, vstart3);
        }

    } else {
        std::string message
            = progname + " (process " + int_to_string(MyProcID) + "):\n"
            + "  Unrecoverable error discovered:\n"
            + "    Error while reading or refining the coarse grid.\n"
	    + "  Program aborted.\n";

	STD_CERR << message;
	protocol  << message;

	MPI_Abort(MPI_COMM_WORLD, ILLEGAL_PARTITION_ERROR);
    }

    protocol << "\n";
    PrintTimeStatistics();

    return(NULL);
}


void Task::PrintTimeStatistics(void) {
    double twoeqTimeValue = TMoment + TPressure;
    double totalTimeValue = TotalClock.GetTimeDiff();
    double value1,  value2,  value3,  value4,  value5;
    double value6,  value7,  value8,  value9,  value10;
    double value11, value12, value13;

    (fabs(twoeqTimeValue - 0.0) < FLOAT_EPS) ?  value1  = 0 : value1  = 100 * TMoment / twoeqTimeValue;
    (fabs(totalTimeValue - 0.0) < FLOAT_EPS) ?  value2  = 0 : value2  = 100 * TMoment / totalTimeValue;
    (fabs(twoeqTimeValue - 0.0) < FLOAT_EPS) ?  value3  = 0 : value3  = 100 * TPressure / twoeqTimeValue;
    (fabs(totalTimeValue - 0.0) < FLOAT_EPS) ?  value4  = 0 : value4  = 100 * TPressure / totalTimeValue;
    (fabs(TRefine - 0.0) < FLOAT_EPS)        ?  value5  = 0 : value5  = 100 * TRefineCom / TRefine;
    (fabs(TMatrix - 0.0) < FLOAT_EPS)        ?  value6  = 0 : value6  = 100 * TMatrixCom / TMatrix;
    (fabs(TMVMult - 0.0) < FLOAT_EPS)        ?  value7  = 0 : value7  = 100 * TMVMultCom / TMVMult;
    (fabs(TNorm   - 0.0) < FLOAT_EPS)        ?  value8  = 0 : value8  = 100 * TNormCom / TNorm;
    (fabs(TSmooth - 0.0) < FLOAT_EPS)        ?  value9  = 0 : value9  = 100 * TSmoothCom / TSmooth;
    (fabs(TDefect - 0.0) < FLOAT_EPS)        ?  value10 = 0 : value10 = 100 * TDefectCom / TDefect;
    (fabs(TRest   - 0.0) < FLOAT_EPS)        ?  value11 = 0 : value11 = 100 * TRestCom / TRest;
    (fabs(TProl   - 0.0) < FLOAT_EPS)        ?  value12 = 0 : value12 = 100 * TProlCom / TProl;
    (fabs(TCoarse - 0.0) < FLOAT_EPS)        ?  value13 = 0 : value13 = 100 * TCoarseCom / TCoarse;

    protocol << "--------------------------------------------------------------------------------------------\n"
	     << "  Time statistics:\n"
	     << " ==================\n\n"

	     << "Computational time so far: " << timeval_to_string(totalTimeValue) << "\n\n"

	     << "Time needed to solve the non-linear momentum and the pressure poisson problem:\n\n"
	     << "                           |    cpu time    | % of time solving equations | % of total time\n"
	     << "---------------------------+----------------+-----------------------------+-----------------\n"
	     << "momentum equations         | "
	     << timeval_to_string(TMoment) << " |           "
	     << double_to_string(value1, "f" , 2) << " %           |     "
	     << double_to_string(value2, "f" , 2) << " %    \n"
	     << "pressure poisson equations | "
	     << timeval_to_string(TPressure) << " |           "
	     << double_to_string(value3, "f" , 2) << " %           |     "
	     << double_to_string(value4, "f" , 2) << " %    \n\n\n"

	     << "Time distribution during this computation:\n\n"
	     << "                           |   total time   | comm. time \n"
	     << "---------------------------+----------------+------------\n"
	     << "grid refining              | "
	     << timeval_to_string(TRefine) << " | " << double_to_string(value5, "f", 2) << " %  \n"
	     << "matrix assemblation        | "
	     << timeval_to_string(TMatrix) << " | " << double_to_string(value6, "f", 2) << " %  \n"
	     << "equation solving           | "
	     << timeval_to_string(TSolving) << " |    n.a.    \n"
	     << "other (i/o etc.)           | "
	     << timeval_to_string(totalTimeValue - (TRefine + TMatrix + TSolving)) << " |\n"
	     << " - - - - - - - - - - - - - + - - - - - -+- - - - - - - - \n"
	     << "matrix-vector multipl.     | "
	     << timeval_to_string(TMVMult) << " | " << double_to_string(value7, "f", 2) << " %  \n"
	     << "computing norms            | "
	     << timeval_to_string(TNorm) << " | " << double_to_string(value8, "f", 2) << " %  \n"
	     << " - - - - - - - - - - - - - + - - - - - -+- - - - - - - - \n"
	     << "smoothing                  | "
	     << timeval_to_string(TSmooth) << " | " << double_to_string(value9, "f", 2) << " %  \n"
	     << "computing defects          | "
	     << timeval_to_string(TDefect) << " | " << double_to_string(value10, "f", 2) << " %  \n"
	     << "restriction                | "
	     << timeval_to_string(TRest) << " | " << double_to_string(value11, "f", 2) << " %  \n"
	     << "prolongation               | "
	     << timeval_to_string(TProl) << " | " << double_to_string(value12, "f", 2) << " %  \n"
	     << "solve coarse problem       | "
	     << timeval_to_string(TCoarse) << " | " << double_to_string(value13, "f", 2) << " %  \n"
//  	     << "?                          | "
//  	     << timeval_to_string(TEvalue) << " | " << double_to_string(100 * TEvalueCom / TEvalue, "f", 2) << " %  \n"
	     << "\n--------------------------------------------------------------------------------------------\n";

    return;
}

void Task::LaplaceTest()
{
    //  MultiCompactMatrix *A;
    //DoubleVector *f,*x;
    DoubleVector *x1, *x2, *x3;
    DoubleVector *f1, *f2, *f3;
    IntArray2D        Laplace(2,4);
    IntArray          RightSide(1);
    int ICLEAR,ISYMM;
    DateTime Bench;
    double BenchTime;
    //  double l2,h1,dnh1,dnl2;              // only needed for testing purposes

    RotElement=new ParNonParamMeanElement_3D(this);
    //RotElement=new ParNonParamElement_3D(this);

    Laplace(1,1)=2;
    Laplace(2,1)=2;
    Laplace(1,2)=3;
    Laplace(2,2)=3;
    Laplace(1,3)=4;
    Laplace(2,3)=4;
    Laplace(1,4)=1;
    Laplace(2,4)=1;
    ISYMM=0;
    ICLEAR=TRUE;
    ICLEAR=FALSE;
    Prot<<"AssembleMatrices !!\n";
    CoeffA1();
    A=new MultiCompactMatrix(Param->NFine);
    AssembleMatrices(*RotElement,A,TRUE,Laplace,4,Param->ICUB,ISYMM,ICLEAR,0);
    UpdateDiagonal();

    CoarseGrid->InitMatrices(Param,TRUE,Laplace,4,Param->ICUB,ISYMM,ICLEAR,0);
    //  myOverlapGrid->InitMatrices(Param,TRUE,Laplace,4,Param->ICUB,ISYMM,ICLEAR,0);

    x1=RotElement->GetRightSideVector();
    x2=RotElement->GetRightSideVector();
    x3=RotElement->GetRightSideVector();
    *x1=0;
    *x2=0;
    *x3=0;
    //    f=0;
    f1=RotElement->GetRightSideVector();
    f2=RotElement->GetRightSideVector();
    f3=RotElement->GetRightSideVector();

    *f1 = 1;
    GlobalDOF = ((ParVector*)f1)->ScalProd(*f1, this);

    *f1 = 1;
    protocol << "LaplaceTest (00): l2norm(f1):" << f1->l2Norm() << "\n";
    *f2 = 0.002;
    *f3 = 3e-8;
    //    (*f)(100) = 3000;
    //    (*f)(101) = 2;
    //    (*f)(102) = 200;
    //    (*f)(103) = 2;
    //    (*f)(104) = 2;
    //    protocol << l2norm(f) / l2norm(x) << "\n";

    RightSide(1)=1;
    Prot<<"CalcRightSide !!\n";
    CoeffRHSV1();
    CalcRightSide(*RotElement,f1,FALSE,RightSide,1,Param->ICUB,ICLEAR,0);
    protocol << "LaplaceTest (01): l2norm(f1):" << f1->l2Norm() << "\n";
    SetBoundValues(f1);
    protocol << "LaplaceTest (02): l2norm(f1):" << f1->l2Norm() << "\n";
    Communicate();
    protocol << "LaplaceTest (03): l2norm(f1):" << f1->l2Norm() << "\n";
    GetBoundValuesMult(f1);
    protocol << "LaplaceTest (04): l2norm(f1):" << f1->l2Norm() << "\n";

    CoeffRHSV2();
    CalcRightSide(*RotElement,f2,FALSE,RightSide,1,Param->ICUB,ICLEAR,0);
    SetBoundValues(f2);
    Communicate();
    GetBoundValuesMult(f2);

    CoeffRHSV3();
    CalcRightSide(*RotElement,f3,FALSE,RightSide,1,Param->ICUB,ICLEAR,0);
    SetBoundValues(f3);
    Communicate();
    GetBoundValuesMult(f3);

    CreateBoundInfo();
    SetMultiBound(A);
    SetBoundRightF(f1, 0);
    SetBoundRightF(f2, 0);
    SetBoundRightF(f3, 0);
    SetBoundRightU(x1, 0);
    SetBoundRightU(x2, 0);
    SetBoundRightU(x3, 0);

    // Compute defect = f - Ax
    MG_Info       mgInfo = { -100, -100, 0, 0, 0, -100 }; // convergence rates and number of iterations in multigrid
    DoubleVector *defect1, *defect2, *defect3;
    defect1 = GetRightSideVector(*RotElement);
    defect2 = GetRightSideVector(*RotElement);
    defect3 = GetRightSideVector(*RotElement);

    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*x1, *defect1, 1, 0, this);
    (*defect1) *= -1;
    (*defect1) += (*f1);
    SetBoundDefekt(defect1);

    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*x2, *defect2, 1, 0, this);
    (*defect2) *= -1;
    (*defect2) += (*f2);
    SetBoundDefekt(defect2);

    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*x3, *defect3, 1, 0, this);
    (*defect3) *= -1;
    (*defect3) += (*f3);
    SetBoundDefekt(defect3);

    protocol << "\n    it. | rel.change |  defect   | conv.rate in multigrid | mg-steps\n"
	     << "   -----+------------+-----------+------------------------+----------\n"
	     << "        |            | "
	     << norm_to_string(l2norm(defect1), "e", 2, GlobalDOF) << "  "
	     << norm_to_string(l2norm(defect2), "e", 2, GlobalDOF) << "  "
	     << norm_to_string(l2norm(defect3), "e", 2, GlobalDOF) << "  "
	     << " |                        |\n";


    // test
    //AdditiveSchwarz(x,f);
    //AdditiveSchwarzRichardson(x,f,200,1e-9);
    //RotElement->Error(*x,Param->ICUB,l2,h1,dnl2,dnh1,0);

    //Prot<<"Rel. L2-Error: "<<sqrt(l2/dnl2)<<"\n";
    //Prot<<"Rel. H1-Error: "<<sqrt(h1/dnh1)<<"\n";
    //return;
    // end test

    Prot<<"ILU Decomposition !!\n";
    Prot.Flush();
    InitILU(A);
    ILU(A,E,0.0);
    Prot<<"After ILU Decomposition !!\n";
    Prot.Flush();

    SetMGBurgers();
    Bench.SetTime();

    //    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParCG(*x,*f,Param->MaxIItU,Param->EpsUDefect,this);

    //  mgInfo = ((ParCompactMatrix*)((*A)[MaxLevel]))->ParPrecondCG(*x1, *f1, l2norm(x1), Param->MaxIItU, Param->EpsUDefect, Param->AMinU, Param->AMaxU, 0, *RotElement, A, this);
    mgInfo = MultiDriver(*RotElement, A, x1, f1, l2norm(x1), Param->MinIItU, 100, Param->EpsUChange, 1e-10, Param->DampUMG, Param->AMinU, Param->AMaxU);
    //             MultiDriver(*RotElement, A, x2, f2, l2norm(x2), Param->MinIItU, 100, Param->EpsUChange, 1e-10, Param->DampUMG, Param->AMinU, Param->AMaxU);
    //             MultiDriver(*RotElement, A, x3, f3, l2norm(x3), Param->MinIItU, 100, Param->EpsUChange, 1e-10, Param->DampUMG, Param->AMinU, Param->AMaxU);


    BenchTime=Bench.GetTimeDiff();
    Prot<<"\n";
    Prot<<"Elapsed Time: "<<BenchTime<<"\n";

    // Compute new defect
    ((ParCompactMatrix*)((*A)[MaxLevel]))->ParVectMult(*x1, *defect1, 1, 0, this);
    (*defect1) *= -1;
    (*defect1) += (*f1);
    SetBoundDefekt(defect1);
    protocol << "    " << int_to_string(1, " ", 2) << "  | "
	     << double_to_string(mgInfo.relChange, "e", 2)        << "  | "
	     << norm_to_string(l2norm(defect1), "e", 2, GlobalDOF) << " |        "
	     << double_to_string(mgInfo.convRate, "e", 2)         << "       |"
	     << int_to_string(mgInfo.steps, " ", 3)               << "\n";


    ConElement     = new ConstantElement_3D(this);
    DoubleVector *SBP;
    SBP = GetRightSideVector(*ConElement);
    *SBP = 1.0;


    // Write gmv solution
    GMVOutput(x1, x2, x3, SBP, x1, RotElement, 2, 0, 0);


    //RotElement->Error(*x,Param->ICUB,l2,h1,dnl2,dnh1,0);
    //  Prot<<"Rel. L2-Error: "<<sqrt(l2/dnl2)<<"\n";
    //Prot<<"Rel. H1-Error: "<<sqrt(h1/dnh1)<<"\n";

    Prot<<"\n";
}
