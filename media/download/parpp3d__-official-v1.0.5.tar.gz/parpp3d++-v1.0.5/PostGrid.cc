#include "PostGrid.h"

#define EPS 1e-4

PostGrid::PostGrid(UNSIGNED NFine,Daten *Pparam):MultiGrid_3D(NFine)
{
    Param=Pparam;
    for(int i=1;i<=NFine;i++) {
        MPostProcess[i]=new bIntArraylist_base;
        MPostProcessConst[i]=new bIntArraylist_base;
    }
}

void PostGrid::InitGrid(const char *name)
{
    ReadCoarseGrid(name);
	
    UNSIGNED ISCAD,ISE,ISA,ISEEL,ISAEL,ISVEL,IDISP;
    Refine(0,1,1,1,0,0,0,1);

    ISCAD=0;
    ISE=1;
    ISA=3;
    ISEEL=0;
    ISAEL=0;
    ISVEL=0;
    IDISP=0;
    MultiRefine(ISCAD,ISE,ISA,ISEEL,ISAEL,ISVEL,IDISP);

//  Prot<<"NeighElem[MaxLevel]=\n"<<*MNeighElem[Param->NFine]<<"\n";

    if(Param->ElemType==1) {
        for(int i=1;i<=Param->NFine;i++)
            MVector[i]=new DoubleVector(MNumVertices[i]);
    } else {
        for(int i=1;i<=Param->NFine;i++)
            MVector[i]=new DoubleVector(MTotNumFaces[i]);
    }
    for(int i=1;i<=Param->NFine;i++)
        MConstVector[i]=new DoubleVector(MNumElements[i]);

    return;
}

void PostGrid::SetPostProcessInfo(DoubleArray2D *arr,int neigh,int level)
{
    IntArray *target;
    DoubleArray2D *temp_coord;
    long i,j,len;
//    long k;
//    int temp;
    int IVT1,IVT2,IVT3,IVT4;
//    DOUBLE X,Y,Z;
//    blink *link;

    PostProcess=MPostProcess[level];
    PostProcessConst=MPostProcessConst[level];
    VertCoord=MVertCoord[level];
    VertElem=MVertElem[level];
    MidFaces=MMidFaces[level];
    NumVertices=MNumVertices[level];
    NumElements=MNumElements[level];
    TotNumFaces=MTotNumFaces[level];

    IntArray2D KIAD(4,6);
    KIAD(1,1)=1;
    KIAD(2,1)=2;
    KIAD(3,1)=3;
    KIAD(4,1)=4;
    KIAD(1,2)=1;
    KIAD(2,2)=2;
    KIAD(3,2)=6;
    KIAD(4,2)=5;
    KIAD(1,3)=2;
    KIAD(2,3)=3;
    KIAD(3,3)=7;
    KIAD(4,3)=6;
    KIAD(1,4)=3;
    KIAD(2,4)=4;
    KIAD(3,4)=8;
    KIAD(4,4)=7;
    KIAD(1,5)=4;
    KIAD(2,5)=1;
    KIAD(3,5)=5;
    KIAD(4,5)=8;
    KIAD(1,6)=5;
    KIAD(2,6)=6;
    KIAD(3,6)=7;
    KIAD(4,6)=8;

    IntArray_blink *temp_link;
	
    for(temp_link=PostProcess->get_first();
        temp_link;temp_link=PostProcess->get_next(temp_link))
        if(temp_link->neigh==neigh)
            break;
			
    if(temp_link==NULL) {
        target=new IntArray(arr->GetLen()/3);
        temp_link=new IntArray_blink(target,neigh);
        PostProcess->append(temp_link);
        temp_link->ptr=target;
    }
		
    target=temp_link->ptr;
    len=target->GetLen();

#ifdef CONTROL_MSG
    if(arr)
        Prot<<"SetPostProcessInfo : neigh="<<neigh<<" arr=\n"<<*arr<<"\n target=\n"<<*target<<"\n\n";
    else
        Prot<<"SetPostProcessInfo : neigh"<<neigh<<" arr==NULL !!\n\n";
#endif	

	
    if(Param->ElemType==1) {
        if(len==arr->GetCols()) {
            for(i=1;i<=len;i++) {
                for(j=1;j<=NumVertices;j++) {
                    if(fabs((*arr)(1,i)-(*VertCoord)(1,j))<EPS
                       && fabs((*arr)(2,i)-(*VertCoord)(2,j))<EPS
                       && fabs((*arr)(3,i)-(*VertCoord)(3,j))<EPS)
                    {
                        (*target)(i)=j;
                        break;
                    }
                }
            }
        }
    } else if(Param->ElemType==2) {
        if(len==arr->GetCols()) {
            temp_coord=new DoubleArray2D(3,TotNumFaces);
            for(i=1;i<=NumElements;i++) {
                for(j=1;j<=6;j++) {
                    IVT1=(*VertElem)(KIAD(1,j),i);
                    IVT2=(*VertElem)(KIAD(2,j),i);
                    IVT3=(*VertElem)(KIAD(3,j),i);
                    IVT4=(*VertElem)(KIAD(4,j),i);
                    (*temp_coord)(1,(*MidFaces)(j,i))=0.25*((*VertCoord)(1,IVT1)
                                                            +(*VertCoord)(1,IVT2)
                                                            +(*VertCoord)(1,IVT3)
                                                            +(*VertCoord)(1,IVT4));
                    (*temp_coord)(2,(*MidFaces)(j,i))=0.25*((*VertCoord)(2,IVT1)
                                                            +(*VertCoord)(2,IVT2)
                                                            +(*VertCoord)(2,IVT3)
                                                            +(*VertCoord)(2,IVT4));
                    (*temp_coord)(3,(*MidFaces)(j,i))=0.25*((*VertCoord)(3,IVT1)
                                                            +(*VertCoord)(3,IVT2)
                                                            +(*VertCoord)(3,IVT3)
                                                            +(*VertCoord)(3,IVT4));
                }
            }

            for(i=1;i<=len;i++) {
                for(j=1;j<=TotNumFaces;j++) {
                    if(fabs((*arr)(1,i)-(*temp_coord)(1,j))<EPS 
                       && fabs((*arr)(2,i)-(*temp_coord)(2,j))<EPS
                       && fabs((*arr)(3,i)-(*temp_coord)(3,j))<EPS)
                    {
                        (*target)(i)=j;
                        break;
                    }
                }
            }
        } else
            Prot<<"SetProcInfo len!=arr->GetCols() !!\n";
    } else {
        Prot<<"\n\n!!! SetPostProcessInfo : Arrays have different length !!!!!\n\n";
    }
}

void PostGrid::SetPostProcessInfoConst(DoubleArray2D *arr,int neigh,int level)
{
    IntArray *target;
//    DoubleArray2D *temp_coord;
    long i,j,len,k,l;
//    int temp,IVT1,IVT2,IVT3,IVT4;
//    DOUBLE X,Y,Z;
//    blink *link;
    int flag[8];

    PostProcess=MPostProcess[level];
    PostProcessConst=MPostProcessConst[level];
    VertCoord=MVertCoord[level];
    VertElem=MVertElem[level];
    MidFaces=MMidFaces[level];
    NumVertices=MNumVertices[level];
    NumElements=MNumElements[level];
    TotNumFaces=MTotNumFaces[level];

    IntArray_blink *temp_link;
	
    for(temp_link=PostProcessConst->get_first();
        temp_link;temp_link=PostProcessConst->get_next(temp_link))
        if(temp_link->neigh==neigh)
            break;
			
    if(temp_link==NULL) {
        target=new IntArray(arr->GetLen()/24);
        temp_link=new IntArray_blink(target,neigh);
        PostProcessConst->append(temp_link);
        temp_link->ptr=target;
    }
		
    target=temp_link->ptr;
    len=target->GetLen();

#ifdef CONTROL_MSG
    if(arr)
        Prot<<"SetPostProcessInfoConst : neigh="<<neigh<<" arr=\n"<<*arr<<"\n target=\n"<<*target<<"\n\n";
    else
        Prot<<"SetPostProcessInfoConst : neigh"<<neigh<<" arr==NULL !!\n\n";
#endif	

//  Prot<<"neigh="<<neigh<<"\n";

    if(len==arr->GetCols()) {
        for(i=1;i<=len;i++) {
            for(j=1;j<=NumElements;j++) {
                for(l=0;l<=7;l++) {
                    flag[l]=0;
                    for(k=0;k<=7;k++) {
                        if(fabs((*arr)(l*3+1,i)-(*VertCoord)(1,(*VertElem)(k+1,j)))<EPS
                           && fabs((*arr)(l*3+2,i)-(*VertCoord)(2,(*VertElem)(k+1,j)))<EPS
                           && fabs((*arr)(l*3+3,i)-(*VertCoord)(3,(*VertElem)(k+1,j)))<EPS)
                        {
                            flag[l]=1;
                        }
                    }
                    if(flag[l]==0)
                        break;
                }
                if(flag[0]==1 && flag[1]==1 && flag[2]==1 && flag[3]==1 &&
                   flag[4]==1 && flag[5]==1 && flag[6]==1 && flag[7]==1) {
                    (*target)(i)=j;
//		  Prot<<"target "<<j<<" <- "<<i<<"\n";
                }
            }
        }
//      Prot<<"neigh="<<neigh<<" target=\n"<<*target<<"\n";
    } else
        Prot<<"SetProcInfo len!=arr->GetCols() !!\n";
}

void PostGrid::SetVector(DoubleVector *ptr,int neigh,int level)
{
    IntArray_blink *temp_link;
    PostProcess=MPostProcess[level];
	
    for(temp_link=PostProcess->get_first();
        temp_link;temp_link=PostProcess->get_next(temp_link))
        if(temp_link->neigh==neigh)
            break;
			
    if(temp_link==NULL) {
        Prot<<"!!!!!!!!! PostProcess unknown neighbour :"<<neigh<<"\n";
        return;
    }
  	
    IntArray *target;
    target=temp_link->ptr;  
    int len=ptr->GetLen();
    DoubleVector *vect=MVector[level];

    for(int i=1;i<=len;i++) {
        (*vect)((*target)(i))=(*ptr)(i);
    }
}

void PostGrid::SetConstVector(DoubleVector *ptr,int neigh,int level)
{
    IntArray_blink *temp_link;
    PostProcessConst=MPostProcessConst[level];
	
    for(temp_link=PostProcessConst->get_first();
        temp_link;temp_link=PostProcessConst->get_next(temp_link))
        if(temp_link->neigh==neigh)
            break;
			
    if(temp_link==NULL) {
        Prot<<"!!!!!!!!! PostProcess unknown neighbour :"<<neigh<<"\n";
        return;
    }
  	
    IntArray *target;
    target=temp_link->ptr;  
    int len=ptr->GetLen();
    DoubleVector *vect=MConstVector[level];

    for(int i=1;i<=len;i++) {
        (*vect)((*target)(i))=(*ptr)(i);
    }
}

void PostGrid::OutputVector(int level)
{
    Output Temp("comp",YES);

    for(int i=1;i<=MVector[level]->GetLen();i++)
        Temp<<(*(MVector[level]))(i)<<"\n";
    Temp.Flush();
//  Prot<<"Vector level="<<level<<"\n"<<*(MVector[level])<<"\n";
}

void PostGrid::OutputConstVector(int level)
{
    Prot<<"Vector level="<<level<<"\n"<<*(MConstVector[level])<<"\n";
}


//  void PostGrid::BoundaryProjection()
//  {
//      int IVT,IEL,INPR;
//      double PXM,PYM,RAD,RADH,DL,PX,PY,PZ;

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "): Entering PostGrid::BoundaryProjection.\n";
//  	protocol.mFlush();
//      }

//      if (Param->Func == 1  ||  Param->Func == 5) {
//          for(IVT = 1; IVT <= NumVertices; IVT++) {
//              INPR = (*InfoVertEdge)(IVT);
//              if (INPR != 0) {
//                  IEL = (*ElemVert)(4,IVT);
//                  PX  = (*VertCoord)(1,IVT);
//                  PY  = (*VertCoord)(2,IVT);
//                  PZ  = (*VertCoord)(3,IVT);
	
//                  if ( (fabs(PX-0.) > 1e-8) && (fabs(PX-2.50) > 1e-8) &&
//                       (fabs(PY-0.) > 1e-8) && (fabs(PY-0.41) > 1e-8) && 
//                       (fabs(PZ-0.) > 1e-8) && (fabs(PZ-0.41) > 1e-8) ) {
//                      PXM=0.50;
//                      PYM=0.20;
//                      RAD=0.05;
//                      DL=sqrt(pow(PX-PXM,2)+pow(PY-PYM,2));
//                      (*VertCoord)(1,IVT)=PXM+RAD/DL*(PX-PXM);
//                      (*VertCoord)(2,IVT)=PYM+RAD/DL*(PY-PYM);
//                  } else if ((fabs(PZ-0.0) <= 1e-8) || (fabs(PZ-0.41) <= 1e-8)) {
//                      PXM=0.50;
//                      PYM=0.20;
//                      RAD=0.05;
//                      RADH=0.05+1e-8;
//                      if ((fabs(PX-PXM) <= RADH) &&
//                          (fabs(PY-PYM) <= RADH) &&
//                           IEL == 0) {
//                          DL=sqrt(pow(PX-PXM,2)+pow(PY-PYM,2));
//                          (*VertCoord)(1,IVT)=PXM+RAD/DL*(PX-PXM);
//                          (*VertCoord)(2,IVT)=PYM+RAD/DL*(PY-PYM);
//                      }
//                  }
//              }
//          }
//      }

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "):  Leaving PostGrid::BoundaryProjection.\n";
//  	protocol.mFlush();
//      }

//      return;
//  }
