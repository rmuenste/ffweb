
#ifndef CCOARSEGRIDH

#define CCOARSEGRIDH

#include <SquareGrid_3D.h>
#include <FiniteElement_3D.h>
#include <TrilinearElement_3D.h>
#include <RotatedElement_3D.h>
#include <NonParamElement_3D.h>
#include <math.h>
#include <ParCompactMatrix.h>
#include <MComTool.h>
#include "String.h"
#include "Const.h"
#include "blist.h"
#include "Daten.h"
#include "Errorcodes.h"			  // for error codes
#include <typecasts.h>				  // for int_to_string, double_to_string

extern "C" {
#include "PartitionTools/party/include/party_lib.h"
    void METIS_PartGraphRecursive(
	int *n, int *xadj, int *adjncy, int *vwgts, int *ewgts, int *wgtflag,
	int *numflag, int *nparts, int *options, int *edgecut, int *part);
    void METIS_PartGraphVKway    (
        int *n, int *xadj, int *adjncy, int *vwgt, int *vsize, int *wgtflag,
        int *numflag, int *nparts, int *options, int *volume, int *part);
}


#define MASTER    1

#define COEFFA1   1
#define COEFFA2   2
#define COEFFA3   3
#define COEFFA4   4
#define COEFFM    5
#define COEFFP1   6
#define COEFFP2   7
#define COEFFN    8

#define COEFF_RHS     1
#define COEFF_L2      2
#define COEFF_RHSV1   3
#define COEFF_RHSV2   4
#define COEFF_RHSV3   7
#define COEFF_L2V1    5
#define COEFF_L2V2    6
#define COEFF_L2V3    8

#define LINEAR     1
#define NON_LINEAR 2


#define UPWIND      1
#define STREAMLINE  2

extern Output StdOut;
extern int MyProcID,nProcs;

class CCoarseGrid:public SquareGrid_3D
{
 protected:
  // Globale Daten
  FiniteElement_3D      *Element;
  DoubleCompactMatrix   *A,*M,*A2;
  DoubleCompactMatrix   *C;
  DoubleRectMatrix      *B1,*B2,*B3;
  DoubleVector          *LumpM;
  DoubleVector          *f,*sol,*v1,*v2,*v3;
  DoubleVector          *const_f,*const_sol;
  unsigned int           ElemType;
  int                    Coeff,CoeffRhs;
  IntArray              *NeighMacro,*NeighCom;
  Daten                 *Param;

  IntArray              *CVertCount,*CElemCount,*CFaceCount;
  IntArray2D            *CVertMap,*CElemMap,*CFaceMap;
  
// Grid define exact solution
  SquareGrid_3D *sol_grid;
  
 public:
  CCoarseGrid(SquareGrid_3D *grid):sol_grid(grid) {}
  ~CCoarseGrid(void) {}
  
  double    Solution(double X,double Y,double Z, double T) 
	{return sol_grid->Solution(X,Y,Z, T);}
  double    SolutionDX(double X,double Y,double Z) 
	{return sol_grid->SolutionDX(X,Y,Z);}
  double    SolutionDY(double X,double Y,double Z) 
	{return sol_grid->SolutionDY(X,Y,Z);}
  double    SolutionDZ(double X,double Y,double Z) 
	{return sol_grid->SolutionDY(X,Y,Z);}
  double    CoeffBX(double X,double Y,double Z) {return 0;}
  double    CoeffBY(double X,double Y,double Z) {return 0;}
  double    CoeffBZ(double X,double Y,double Z) {return 0;}
  double    RightSideCoeff(double X,double Y,double Z,int IB,int BFIRST)
	{return sol_grid->RightSideCoeff(X,Y,Z,IB,BFIRST);}
  double    StiffCoeff(double X,double Y,double Z,
                       int IA,int IB,int BFIRST)
	{return sol_grid->StiffCoeff(X,Y,Z,IA,IB,BFIRST);}  
  void      CoeffA1(void) {sol_grid->CoeffA1();}
  void      CoeffM(void) {sol_grid->CoeffM();}
  int       CalcWeight(int iel,int neigh);
  void      CalcMidpoint(int iel,double& x,double& y,double& z);

  DoubleVector *GetVector(int mnum);
  void          SetVector(int mnum,DoubleVector *ptr);
  void          SolveExact(int solver);
  DoubleVector *GetConstVector(int mnum);
  void          SetConstVector(int mnum,DoubleVector *ptr);
  void          SolveConstExact(int solver);
  void          SetBound(DoubleCompactMatrix *LA);
  void          SetLumpedBound(DoubleVector& vect);
  void          InitMatrices(Daten *Param,unsigned int BCON,IntArray2D& KAB,
                             unsigned int KABN,unsigned int ICUB,
                             unsigned int ISYMM,unsigned int ICLEAR,unsigned int ILINT);
  void          SetTimeMatrix(double k);
  void          SetUpwindVec1(int mnum,DoubleVector *ptr);
  void          SetUpwindVec2(int mnum,DoubleVector *ptr);
  void          SetUpwindVec3(int mnum,DoubleVector *ptr);

  void          UpWind(DoubleCompactMatrix& LA,DoubleVector& u1,DoubleVector& u2,
                       DoubleVector& u3,double UPSAM);


  void          Build_B(DoubleRectMatrix*& B1,DoubleRectMatrix*& B2,
                        DoubleRectMatrix*& B3,DoubleCompactMatrix*& A);
  DoubleCompactMatrix* GetProjMatrix();
  void          BuildProjMatrix(DoubleCompactMatrix* mat,DoubleVector* Mvect,
                                DoubleRectMatrix* B,DoubleRectMatrix* BT,
                                DoubleRectMatrix* BTT);
  DoubleVector  *GetLumpedMassMat(DoubleCompactMatrix& M);
                        
  void      WritePartition  (IntArray& Partition);
  void      ReadPartition   (IntArray& Partition);

  int  GetMakroInfo(unsigned int mnum,int& pNumElements,int& pNumVertices,
                    int& pNumEdges,int& pNumVertElem,
                    int& pNumEdgeElem,int& pNumFaceElem,
                    int& pNumBound,int& NumVertBound,
                    DoubleArray2D*& pVertCoord,IntArray2D*& pVertElem,
                    IntArray*& pInfoVertEdge,IntArray2D*& pInfoVertBound,
                    IntArray*& pBoundInfo,node_base*& nodes,
                    blist_base*& real_b_nodes,
                    node_base*& midnodes,node_base*& midneighnodes,
                    blist_base*& real_b_midnodes,
                    blist_base*& info_list,int& pNumNeigh,Daten *PParam,MComTool *MyCom);
  
  void           CheckPartition(node_base* nodes,MComTool *MyCom,DoubleArray2D *arr2d);
  DoubleArray2D* GetBoundInfo(IntArray *arr,node_base* myBase,DoubleArray2D *arr2d);
  void           SetBoundInfo(DoubleArray2D *arr,int neigh,
                              bIntArraylist_base *RecvBound,node_base* myBase,
                              DoubleArray2D *arr2d); 

};

#endif
