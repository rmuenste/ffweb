#include "RealFullMatrix.h"

RealFullMatrix& RealFullMatrix::operator=(RealFullMatrix& aRealFullMatrix)
{
    if(aRealFullMatrix.GetRows()==GetRows() && aRealFullMatrix.GetCols()==GetCols())
    {
        for (unsigned int row = 1;row<=GetRows();row++)
            for (unsigned int col = 1;col<=GetRows();col++)
                (*this)(row,col)=aRealFullMatrix(row,col);
    }
    return *this;
}

RealFullMatrix& RealFullMatrix::operator=(REAL aNumber)
{
    for (unsigned int row = 1;row<=GetRows();row++)
        for (unsigned int col = 1;col<=GetRows();col++)
            (*this)(row,col)=aNumber;
    return *this;
}

RealVector& RealFullMatrix::VectMult(RealVector& aSrcVect,RealVector& aDestVect)
{
    REAL        sum=0;
    unsigned int cols=GetCols(),rows=GetRows();
        
    if (cols == aSrcVect.GetLen() && rows == aDestVect.GetLen()) {
        for (int index1 = 1; index1 <= rows; index1++) {
            for (int index2 = 1; index2 <= cols; index2++) {
                sum += ((*this)(index1, index2) * aSrcVect(index2)); 
            }
            aDestVect(index1) = sum; 
            sum = 0; 
        }
    }

    return aDestVect;
}

Output& operator<<(Output& o,RealFullMatrix& aMatrix)
{
    for (unsigned int row = 1;row<=aMatrix.GetRows();row++)
    {
        for (unsigned int col = 1;col<=aMatrix.GetCols();col++)
        {
            o<<"The value at row "<<row<<" ,column "<<col<<" = ";
            o<<aMatrix(row,col)<<"\n";
        }
    }
    return o;
}
