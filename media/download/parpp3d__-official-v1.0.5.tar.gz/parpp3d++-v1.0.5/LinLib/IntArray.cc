#include "IntArray.h"
#include "Protypes.h"
#include "Global.h"

IntArray::IntArray(unsigned int mySize)
{
    Name    = "IntArray";
    Len     = mySize;
    aHandle = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for(unsigned int index=0; index < mySize; index++)
	aHandle[index] = 0;
}

IntArray::IntArray(unsigned int mySize,BYTEPTR aName)
{
    Name    = aName;
    Len     = mySize;
    aHandle = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for(unsigned int index=0; index < mySize; index++)
	aHandle[index] = 0;
}

IntArray::IntArray(IntArray& anIntArray)
{
    unsigned int size = anIntArray.GetLen();
	
    Name    = anIntArray.Name;
    Len     = size;
    aHandle = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for(unsigned int index = 0; index < size; index++)
	aHandle[index] = anIntArray.aHandle[index];
}

IntArray& IntArray::operator=(IntArray& anIntArray)
{
    unsigned int size=anIntArray.GetLen();
	
    if(GetLen()>=size)
    {
	for (unsigned int index =1;index<=size;index++)
	    (*this)(index)=anIntArray(index);
    }
    return *this;
}

IntArray& IntArray::operator=(INTEGER aNumber)
{
    for (unsigned int index =1;index<=GetLen();index++) {
	(*this)(index)=aNumber;
    }
    return *this;
}

IntArray& operator+=(IntArray& a1,IntArray& a2)
{
    if(a1.GetLen()==a2.GetLen()) {
	for (unsigned int index =1;index<=a1.GetLen();index++)
	    a1(index)=a1(index)+a2(index);
    }
    return a1;
}

IntArray& operator-=(IntArray& a1,IntArray& a2)
{
    if(a1.GetLen()==a2.GetLen()) {
	for (unsigned int index =1;index<=a1.GetLen();index++)
	    a1(index)=a1(index)-a2(index);
    }
    return a1;
}

IntArray& operator*=(IntArray& a1,INTEGER aNumber)
{
    for (unsigned int index =1;index<=a1.GetLen();index++)
	a1(index)=a1(index)*aNumber;
    return a1;
}

Output& operator<<(Output& o,IntArray& anIntArray)
{
    for (unsigned int index =1;index<=anIntArray.GetLen();index++)
    {
	o<<"The value at index position "<<index<<"=";
	o<<anIntArray(index)<<"\n";
    }
    return o;
}

void IntArray::memtest(int *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for IntArray (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
