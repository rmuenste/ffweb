#include "MultiVector.h"

MultiVector::MultiVector(unsigned int aNum)
{	
    VectorPtr=new DoubleVector*[aNum];
    Num=aNum;
    for(INTEGER i=0;i<Num;i++)
	VectorPtr[i]=0;
}

MultiVector::~MultiVector(VOID)
{
    for(INTEGER i=0;i<Num;i++)
	if(VectorPtr[i])
	    delete VectorPtr[i];
}

DoubleVector*& MultiVector::operator[](unsigned int aNum)
{
#ifdef DEBUG
    if (aNum < 1  ||  aNum > Num) {
	Err<<"MultiVector: wrong access !!\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type MultiCompactMatrix.\n"
		 << "  Cause of error: ";
	if (aNum <= 0) {
	    protocol << "Trying to access array with too small row index: " << aNum << ".\n";
	} else {
	    protocol << "Trying to access array with too large row index: " << aNum << ". Maximum allowed: " << Num << ".\n";
	}
	protocol << "  Program aborted in MultiCompactMatrix::operator[].\n";
	exit(1);
    }
#endif
    return VectorPtr[aNum-1];
}

MultiVector& MultiVector::operator=(DOUBLE aNumber)
{
    for(INTEGER i=0;i<Num;i++)
	*(VectorPtr[i])=aNumber;
		
    return *this;
}

MultiVector& MultiVector::operator+=(MultiVector& aMultiVector)
{
    for(INTEGER i=0;i<Num;i++)
	*(VectorPtr[i])+=*(aMultiVector[i]);
	
    return *this;
}
