#include "DoubleCompactMatrix.h"

DoubleCompactMatrix::DoubleCompactMatrix(DoubleCompactMatrix& aMatrix):DoubleArray((DoubleArray&)aMatrix)
{
    NumData      = aMatrix.NumData;
    NumDiag      = aMatrix.NumDiag;
    Diagonal     = aMatrix.Diagonal;
    Column       = aMatrix.Column;
    ILUDiagonal  = aMatrix.ILUDiagonal;
    ILUDiagonal  = aMatrix.ILUDiagonal;
    ILUDataArray = aMatrix.ILUDataArray;
}

DoubleCompactMatrix::~DoubleCompactMatrix(void)
{
    if (Diagonal != (IntArray*)0)
	delete Diagonal;
    if (Column != (IntArray*)0)
	delete Column;
    if (ILUDiagonal != (IntArray*)0)
	delete ILUDiagonal;
    if (ILUColumn != (IntArray*)0)
	delete ILUColumn;
    if (ILUDataArray != (DoubleArray*)0)
	delete ILUDataArray;
}

void DoubleCompactMatrix::Delete(DoubleCompactMatrix  *aMatrix)
{
    if (Diagonal != (IntArray*)0)
	delete Diagonal;
    if (Column != (IntArray*)0)
	delete Column;
    if (ILUDiagonal != (IntArray*)0)
	delete ILUDiagonal;
    if (ILUColumn != (IntArray*)0)
	delete ILUColumn;
    if (ILUDataArray != (DoubleArray*)0)
	delete ILUDataArray;
    Diagonal=0;
    Column=0;
    ILUDiagonal=0;
    ILUColumn=0;
    aMatrix->Diagonal=0;
    aMatrix->Column=0;
    aMatrix->ILUDiagonal=0;
    aMatrix->ILUColumn=0;
    delete this;
    delete aMatrix;
}

DoubleCompactMatrix& DoubleCompactMatrix::operator=(DoubleCompactMatrix& aDoubleCompMatrix)
{
    if (aDoubleCompMatrix.NumData == NumData && aDoubleCompMatrix.NumDiag == NumDiag)
    {
	unsigned int index;
	for(index=1;index<=NumData;index++)
	    Data(index)=aDoubleCompMatrix.Data(index);
	for(index=1;index<=NumDiag;index++)
	    (*Diagonal)(index)=(*aDoubleCompMatrix.Diagonal)(index);
	for(index=1;index<=NumData;index++)
	    (*Column)(index)=(*aDoubleCompMatrix.Column)(index);
//    if (aDoubleCompMatrix.ILUColumn) {
//      ILUColumn=new IntArray(*aDoubleCompMatrix.ILUColumn);
//      ILUDiagonal=new IntArray(*aDoubleCompMatrix.ILUDiagonal);
//      ILUDataArray=new DoubleArray(*aDoubleCompMatrix.ILUDataArray);
//      for(index=1;index<=NumData;index++)
//	ILUData(index)=aDoubleCompMatrix.ILUData(index);
//      for(index=1;index<=NumDiag;index++)
//	(*ILUDiagonal)(index)=(*aDoubleCompMatrix.ILUDiagonal)(index);
//      for(index=1;index<=NumData;index++)
//	(*ILUColumn)(index)=(*aDoubleCompMatrix.ILUColumn)(index);
//    }
    }
    return *this;
}

DoubleCompactMatrix& DoubleCompactMatrix::operator=(double aNumber)
{
    for (unsigned int index =1;index<=NumData;index++)
	(*this).Data(index)=aNumber;

    return *this;
}

double& DoubleCompactMatrix::operator()(unsigned int aRow,unsigned int aCol)
{
    unsigned int end;

    if (aRow > 0  &&  aRow <= GetNumDiag()) {
	end = (*Diagonal)(aRow+1) - 1;
	for (int index = (*Diagonal)(aRow); index <= end; index++) {
	    if ((*Column)(index) == aCol)
		return (*this).Data(index);
	}

	// If we did not find the requested column, we have an illegal access
#ifdef DEBUG
	elementNotFound("DoubleCompactMatrix::operator()", GetName());
    } else {
	// Array access out of bound
	arraysizeViolation("DoubleCompactMatrix::operator()", GetName(), aRow, GetNumDiag());
#endif
	exit(ARRAY_LIMIT_ERROR);
    }
}

double& DoubleCompactMatrix::SetElement(unsigned int DiagPos, unsigned int DiagVal,
					unsigned int ColPos,  unsigned int ColVal, unsigned int DataPos)
{
    if (DiagPos >= 1  &&  DiagPos <= NumDiag) {
	(*Diagonal)(DiagPos) = DiagVal;
    } else {
	// Array access out of bound
#ifdef DEBUG
	arraysizeViolation("DoubleCompactMatrix::SetElement", GetName(), DiagPos, NumDiag);
#endif
	exit(ARRAY_LIMIT_ERROR);
    }

    if (ColPos >= 1  &&  ColPos <= NumData) {
	(*Column)(ColPos) = ColVal;
    } else {
	// Array access out of bound
#ifdef DEBUG
	arraysizeViolation("DoubleCompactMatrix::SetElement", GetName(), ColPos, NumData);
#endif
	exit(ARRAY_LIMIT_ERROR);
    }

    if (DataPos >= 1  &&  DataPos <= NumData)
	return (*this).Data(DataPos);
    else {
	// Array access out of bound
#ifdef DEBUG
	arraysizeViolation("DoubleCompactMatrix::SetElement", GetName(), DataPos, NumData);
#endif
	exit(ARRAY_LIMIT_ERROR);
    }
}

DoubleVector& DoubleCompactMatrix::VectMult(DoubleVector& aSrcVect, DoubleVector& aDestVect)
// Compute aDestVect = thisMatrix * aSrcVect
{
    if (aSrcVect.GetLen() == GetNumDiag() && aDestVect.GetLen() == GetNumDiag()) {
	int index;
	for (index = 1; index <= GetNumDiag(); index++)
	    aDestVect(index) = aSrcVect(index) * (*this).Data((*Diagonal)(index));
	for (index = 1; index <= GetNumDiag(); index++) {
	    for (int index2 = (*Diagonal)(index) + 1; index2 <= (*Diagonal)(index + 1) - 1; index2++) {
		aDestVect(index) += ((*this).Data(index2) * aSrcVect((*Column)(index2)));
	    }
	}
    }

    return aDestVect;
}

DoubleVector& DoubleCompactMatrix::VectMult(DoubleVector& aSrcVect, DoubleVector& aDestVect, double a1, double a2)
// Compute aDestVect = a2 * aDestVect  +  a1 * thisMatrix * aSrcVect
{
    double a;
    int index, index2;

    if (aSrcVect.GetLen() == GetNumDiag() && aDestVect.GetLen() == GetNumDiag()) {
	// a1 != 0
	if (fabs(a1 - 0.0) > FLOAT_EPS) {
	    // a2 == 0
	    if (fabs(a2 - 0.0) < FLOAT_EPS) {
		for (index = 1; index <= GetNumDiag(); index++)
		    aDestVect(index) = aSrcVect(index) * (*this).Data((*Diagonal)(index));
	    } else {
		a = a2 / a1;
		// a != 1
		if (fabs(a - 1.0) > FLOAT_EPS)
		    aDestVect *= a;
		for (index = 1; index <= GetNumDiag(); index++)
		    aDestVect(index) += aSrcVect(index) * (*this).Data((*Diagonal)(index));
	    }
	    for (index = 1; index <= GetNumDiag(); index++) {
		for (index2 = (*Diagonal)(index) + 1; index2 <= (*Diagonal)(index + 1) - 1; index2++) {
		    aDestVect(index) += ((*this).Data(index2) * aSrcVect((*Column)(index2)));
		}
	    }
	    // a1 != 1
	    if (fabs(a1 - 1.0) > FLOAT_EPS)
		aDestVect *= a1;
	} else {
	    aDestVect *= a2;
	}
    }

    return aDestVect;
}

DoubleVector& DoubleCompactMatrix::TimeMult(DoubleVector& aLump,DoubleVector& aSrcVect,
					    DoubleVector& aDestVect,
					    double a1,double a2)
// Compute aDestVect = a2 * aDestVect  +  (aLump  +  a1 * thisMatrix) * aSrcVect
{
    if (aSrcVect.GetLen() == GetNumDiag() && aDestVect.GetLen() == GetNumDiag()) {
	int index;
	aDestVect *= a2;
	for (index = 1; index <= GetNumDiag(); index++)
	    aDestVect(index) += aSrcVect(index) * (a1 * (*this).Data((*Diagonal)(index)) + aLump(index));
	for (index = 1; index <= GetNumDiag(); index++) {
	    for (int index2 = (*Diagonal)(index) + 1; index2 <= (*Diagonal)(index + 1) - 1; index2++)
		aDestVect(index) += (a1 * (*this).Data(index2) * aSrcVect((*Column)(index2)));
	}
    }

    return aDestVect;
}


DoubleCompactMatrix& DoubleCompactMatrix::AddMultConst(DoubleCompactMatrix& aMatrix,double a1,double a2)
{
    if (NumData == aMatrix.NumData) {
	// a1 != 1
	if (fabs(a1 - 1.0) > FLOAT_EPS) {
	    for(int i=1;i<=NumData;i++)
		Data(i)=a1*Data(i)+a2*aMatrix.Data(i);
	} else {
	    for(int i=1;i<=NumData;i++)
		Data(i)+=a2*aMatrix.Data(i);
	}
    }
    return *this;
}


Output& operator<<(Output& o,DoubleCompactMatrix& aMatrix)
{
    unsigned int end;

    for (unsigned int row = 1;row<=aMatrix.GetNumDiag();row++)
    {
	end=(*aMatrix.Diagonal)(row+1)-1;
	for (unsigned int col = (*aMatrix.Diagonal)(row);col<=end;col++)
	{
	    o<<"The value at row "<<row<<" ,column "<<(*aMatrix.Column)(col)<<" = ";
	    o<<aMatrix.Data(col)<<"\n";
	}
    }
    return o;
}

DoubleVector& DoubleCompactMatrix::Jacobi(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Eps,double Omega)
{
    int ITE,IEQ,ICOL;
    double Dm1,Dm2,MaxNorm;
    DoubleVector	CVector=b;

    if (GetNumDiag() != x.GetLen() || x.GetLen() != b.GetLen()) {
	protocol << "Warning (process " << MyProcID << "): Matrix and vector dimensions are not apt in DoubleCompactMatrix::Jacobi.\n";
	return x;
    }

    ProtAdd<<"Jacobi-Iteration\n";
    MaxNorm=b.MaxNorm();
//     if (MaxNorm == 0) {
// 	x=0;
// 	Prot<<"Warning zero right hand side !!\n";
// 	return x;
//     }

    for(ITE=1;ITE<=Nit;ITE++) {
	Dm1=Dm2=0;
	CVector=b;
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		CVector(IEQ)-=(Data(ICOL)*x(Col(ICOL)));
	    }
	}
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    CVector(IEQ)=(double)((1-Omega)*x(IEQ)+(Omega*CVector(IEQ)/Data(Diag(IEQ))));
	    Dm1=MAX(Dm1,ABS(CVector(IEQ)-x(IEQ)));
	    Dm2=MAX(Dm2,ABS(CVector(IEQ)));
	    x(IEQ)=CVector(IEQ);
	}
	if (Dm1<=Eps*Dm2) {
	    ProtAdd<<"  Iteration "<<ITE<<" Jacobi    Maximum of Correction = "<<Dm1/Dm2<<"\n";
	    return x;
	}
	ProtAdd<<"  Iteration "<<ITE<<"  Jacobi    !! CORR!! = "<<Dm1/Dm2<<"\n";
    }
    ProtAdd<<"Iteration "<<ITE<<"  Jacobi    !! CORR!! = "<<Dm1/Dm2<<"\n";
    return x;
}

DoubleVector& DoubleCompactMatrix::JacobiSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Omega)
{
    int ITE,IEQ,ICOL;
    DoubleVector	CVector=b;

    for(ITE=1;ITE<=Nit;ITE++) {

	// Build defect CVector = b - Ax
	CVector=b;
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		CVector(IEQ)-=(Data(ICOL)*x(Col(ICOL)));
	    }
	}
	// x = (1-omega)x + omega*D^{-1}(b-Ax)
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    x(IEQ)=(double)((1-Omega)*x(IEQ)+(Omega*CVector(IEQ)/Data(Diag(IEQ))));
	}
    }
    return x;
}

DoubleVector& DoubleCompactMatrix::GaussSeidel(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Eps)
{
    int ITE,IEQ,ICOL;
    double Dm1,Dm2,Aux,MaxNorm;

    if (GetNumDiag() != x.GetLen() || x.GetLen() != b.GetLen()) {
	protocol << "Warning (process " << MyProcID << "): Matrix and vector dimensions are not apt in DoubleCompactMatrix::GaussSeidel.\n";
	return x;
    }

    ProtAdd<<"Gau�-Seidel-Iteration\n";
    MaxNorm=b.MaxNorm();
    // MaxNorm == 0
    if (fabs(MaxNorm - 0.0) < FLOAT_EPS) {
	x=0;
	Prot<<"Warning zero right hand side !!\n";
	return x;
    }

    for(ITE=1;ITE<=Nit;ITE++) {
	Dm1=Dm2=0;
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    Aux=b(IEQ);
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		Aux-=(Data(ICOL)*x(Col(ICOL)));
	    }
	    Aux/=Data(Diag(IEQ));
	    Dm1=MAX(Dm1,ABS(Aux-x(IEQ)));
	    Dm2=MAX(Dm2,ABS(Aux));
	    x(IEQ)=(double)Aux;
	}
	if (Dm1<=Eps*Dm2) {
	    Prot<<"  Iteration "<<ITE<<" Gau�-Seidel    Maximum of Correction = "<<Dm1/Dm2<<"\n";
	    return x;
	}
	ProtAdd<<"  Iteration "<<ITE<<"  Gau�-Seidel    !! CORR!! = "<<Dm1/Dm2<<"\n";
    }
    Prot<<"Iteration "<<ITE<<"  Gau�-Seidel    !! CORR!! = "<<Dm1/Dm2<<"\n";
    Prot<<"Iteration "<<ITE<<"  Gau�-Seidel    Maximum of Correction = "<<Dm1/Dm2<<"\n";
    return x;
}

DoubleVector& DoubleCompactMatrix::GaussSeidelSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit)
{
    int ITE,IEQ,ICOL;
//      double Dm1,Dm2,MaxNorm;
    double Aux;

    for(ITE=1;ITE<=Nit;ITE++) {
//  	Dm1 = Dm2 = 0;
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    Aux = b(IEQ);
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		Aux -= (Data(ICOL)*x(Col(ICOL)));
	    }
	    Aux /= Data(Diag(IEQ));
	    x(IEQ)=(double)Aux;
	}
    }
    return x;
}

DoubleVector& DoubleCompactMatrix::SOR(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Eps,double Omega)
{
    int ITE,IEQ,ICOL;
    double Dm1,Dm2,Aux,MaxNorm;

    if (GetNumDiag() != x.GetLen() || x.GetLen() != b.GetLen()) {
	protocol << "Warning (process " << MyProcID << "): Matrix and vector dimensions are not apt in DoubleCompactMatrix::SOR.\n";
	return x;
    }

    ProtAdd<<"SOR-Iteration\n";
    MaxNorm=b.MaxNorm();
    // MaxNorm == 0
    if (fabs(MaxNorm - 0.0) < FLOAT_EPS) {
	x=0;
	Prot<<"Warning zero right hand side !!\n";
	return x;
    }

//  PrintRowSum();
//  PrintMaxRowSum();
//  ShowFullMatrix();
//  ShowSparseMatrix();

    for(ITE=1;ITE<=Nit;ITE++) {
	Dm1=Dm2=0;
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    Aux=b(IEQ);
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		Aux-=(Data(ICOL)*x(Col(ICOL)));
	    }
	    Aux=Omega*(Aux/Data(Diag(IEQ))-x(IEQ))+x(IEQ);
	    Dm1=MAX(Dm1,fabs(Aux-x(IEQ)));
	    Dm2=MAX(Dm2,fabs(Aux));
	    x(IEQ)=(double)Aux;
	}
     
	if (Dm1<=Eps*Dm2) {
	    Prot<<"  Iteration "<<ITE<<" SOR    Maximum of Correction = "<<Dm1/Dm2<<"\n";
	    return x;
	}
	ProtAdd<<"  Iteration "<<ITE<<"  SOR    !! CORR!! = "<<Dm1/Dm2<<"\n";
    }
    Prot<<"Iteration "<<ITE<<"  SOR    !! CORR!! = "<<Dm1/Dm2<<"\n";
    Prot<<"Iteration "<<ITE<<"  SOR    Maximum of Correction = "<<Dm1/Dm2<<"\n";
    return x;
}

DoubleVector& DoubleCompactMatrix::SORSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Omega)
{
    int ITE,IEQ,ICOL;
    double Aux;

    for(ITE=1;ITE<=Nit;ITE++) {
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    Aux=b(IEQ);
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		Aux-=(Data(ICOL)*x(Col(ICOL)));
	    }
	    x(IEQ)+=Omega*(Aux/Data(Diag(IEQ))-x(IEQ));
	}
    }
    return x;
}

DoubleVector& DoubleCompactMatrix::NeumannSORSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Omega)
{
    int ITE,IEQ,ICOL;
    double Aux;

    for(ITE=1;ITE<=Nit;ITE++) {
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    Aux=b(IEQ);
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		Aux-=(Data(ICOL)*x(Col(ICOL)));
	    }
	    x(IEQ)+=Omega*(Aux/Data(Diag(IEQ))-x(IEQ));
	}
	Filter(x);
    }
    return x;
}

DoubleVector& DoubleCompactMatrix::SSORSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Omega)
{
    int IEQ,ICOL,ILD;
    double Aux;

    for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	Aux=0;
	ILD=Diag(IEQ);
	for(ICOL=ILD+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    if (Col(ICOL)>=IEQ)
		break;
	    else
		Aux+=(Data(ICOL)*x(Col(ICOL)));
	}
	x(IEQ)=(x(IEQ)-Aux*Omega)/Data(ILD);
    }
    for(IEQ=GetNumDiag()-1;IEQ>=1;IEQ--) {
	Aux=0;
	ILD=Diag(IEQ);
	for(ICOL=ILD+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    if (Col(ICOL)>IEQ)
		Aux+=(Data(ICOL)*x(Col(ICOL)));
	}
	x(IEQ)=(x(IEQ)-Aux*Omega)/Data(ILD);
    }
    return x;
}

DoubleVector& DoubleCompactMatrix::PrecondSOR(DoubleVector& x,double Omega)
{
    int IEQ,ICOL,ILD;
    double Aux;

    if (GetNumDiag() != x.GetLen()) {
	protocol << "Warning (process " << MyProcID << "): Matrix and vector dimensions are not apt in DoubleCompactMatrix::PrecondSOR.\n";
	return x;
    }

    for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	Aux=0;
	ILD=Diag(IEQ);
	for(ICOL=ILD+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    if (Col(ICOL)>=IEQ)
		break;
	    else
		Aux+=(Data(ICOL)*x(Col(ICOL)));
	}
	x(IEQ)=(x(IEQ)-Aux*Omega)/Data(ILD);
    }
    for(IEQ=GetNumDiag()-1;IEQ>=1;IEQ--) {
	Aux=0;
	ILD=Diag(IEQ);
	for(ICOL=ILD+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    if (Col(ICOL)>IEQ)
		Aux+=(Data(ICOL)*x(Col(ICOL)));
	}
	x(IEQ)=(x(IEQ)-Aux*Omega)/Data(ILD);
    }
    return x;
}


DoubleVector& DoubleCompactMatrix::CG(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Eps,double Omega)
{
    int ITE,Flag;
    double Res,Fr,Sigma0,Alpha,Sigma1,Cappa,Gamma,MaxNorm;

    if (GetNumDiag() != x.GetLen() || x.GetLen() != b.GetLen()) {
	protocol << "Warning (process " << MyProcID << "): Matrix and vector dimensions are not apt in DoubleCompactMatrix::CG.\n";
	return x;
    }

    DoubleVector *dr=new DoubleVector(b.GetLen());
    DoubleVector *dd=new DoubleVector(b.GetLen());
    DoubleVector *dd1=new DoubleVector(b.GetLen());
    DoubleVector *dg=new DoubleVector(b.GetLen());

//  PrintMaxRowSum();

    Flag=Omega<0;
    if (!Flag)
	ProtAdd<<"PrecondILU !!\n";
    MaxNorm=b.MaxNorm();
    // MaxNorm == 0
    if (fabs(MaxNorm - 0.0) < FLOAT_EPS) {
	x=0;
	Prot << "Warning zero right hand side !!\n";
	delete dr;delete dg;delete dd1;delete dd;
	return x;
    }

    (*this).VectMult(x,*dr);
    *dr-=b;

    Res=dr->l2Norm();
//  protocol << "Iteration 0   Initial residuum: " << Res << "\n";
    if (Res <= Eps) {
	ITE=0;
	Fr=Res;
	Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
// 	protocol << "Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	delete dr;delete dg;delete dd1;delete dd;
	return x;
    } else {
	if (Flag) {
	    *dg=*dr;
	    Sigma0=Res*Res;
	} else {
	    *dg=*dr;
	    //(*this).PrecondSOR(*dg,Omega);
	    (*this).PrecondILU(*dg);
	    Sigma0=*dr*(*dg);
	}

	*dd=*dg;*dd*=-1;
	for(ITE=1;ITE<=Nit;ITE++) {
	    (*this).VectMult(*dd,*dd1);
	    Alpha=*dd*(*dd1);
	    Alpha=Sigma0/Alpha;

	    x.AddMultConst(*dd,Alpha);
	    dr->AddMultConst(*dd1,Alpha);

	    Fr=dr->l2Norm();
	    ProtAdd<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";
// 	    protocol << "  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";

	    if (Fr<=Eps) {
		if (Res>=1e-70)
		    Res=Fr/Res;
		Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
		// Comment in when you need information about how 
		// many iterations where done when solving (e.g. in
		// coarse grid solver for pressure poisson equation)
// 		protocol << "Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
		if (ITE == 0)
		    Cappa=0;
		else
		    Cappa=pow(Res,(1/(double)ITE));
		Prot<<"Rate of convergence "<<Cappa<<"\n";
		delete dr;delete dg;delete dd1;delete dd;
		return x;
	    }
	    if (Flag) {
		*dg=*dr;
		Sigma1=Fr*Fr;
	    } else {
		*dg=*dr;
		//(*this).PrecondSOR(*dg,Omega);
		(*this).PrecondILU(*dg);
		Sigma1=*dr*(*dg);
	    }
	    Gamma=Sigma1/Sigma0;
	    Sigma0=Sigma1;

	    *dd*=Gamma;*dd-=*dg;
	}
	Prot<<"CONVERGENCE FAILED !!\n";
	Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Fr/Res<<"\n";
	if (Res>=1e-70) {
	    Cappa=pow((Fr/Res),(1/(double)Nit));
	} else {
	    Cappa=0;
	}
	Prot<<"Rate of convergence "<<Cappa<<"\n";
	// Comment in when you need information about how 
	// many iterations where done when solving (e.g. in
	// coarse grid solver for pressure poisson equation)
//  	protocol << "Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Fr/Res<<"\n";
// 	protocol <<"Rate of convergence "<<Cappa<<"\n";
	delete dr;delete dg;delete dd1;delete dd;
	return x;
    }

//      if (Res>=1e-70)
//  	Res=Fr/Res;
//      Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
//      if (ITE == 0)
//  	Cappa=0;
//      else
//  	Cappa=pow(Res,(1/(double)ITE));
//      Prot<<"Rate of convergence "<<Cappa<<"\n";
//      delete dr;delete dg;delete dd1;delete dd;
//      return x;
}

unsigned int DoubleCompactMatrix::BiCGStab(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Eps,double Omega)
{
    int ITE,Flag;
    double Rho0,Rho1,Alpha,Beta,Omega0,Omega1,Omega2,Res,Fr,Cappa,MaxNorm;

    if (GetNumDiag() != x.GetLen() || x.GetLen() != b.GetLen()) {
	protocol << "Warning (process " << MyProcID << "): Matrix and vector dimensions are not apt in DoubleCompactMatrix::BiCGStab.\n";
	return FALSE;
    }

    DoubleVector dr=b;
    DoubleVector dr0(b.GetLen());
    DoubleVector dp(b.GetLen());
    DoubleVector dpa(b.GetLen());
    DoubleVector dsa(b.GetLen());

    Flag=Omega>0 && Omega<2;
    if (Flag) {
	ProtAdd<<"PrecondSOR !!\n";
	(*this).PrecondSOR(dr,Omega);
    }

    MaxNorm=dr.MaxNorm();
    // MaxNorm == 0
    if (fabs(MaxNorm - 0.0) < FLOAT_EPS) {
	x=0;
	Prot<<"Warning zero right hand side !!\n";
	return TRUE;
    }

    Rho0=1;
    Alpha=1;
    Omega0=1;

    dr=b;
    (*this).VectMult(x,dr,-1,1);
    if (Flag)
	(*this).PrecondSOR(dr,Omega);
    Res=dr.l2Norm();
    if (Res<=Eps) {
	ITE=0;
	Fr=Res;
	Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	return TRUE;
    } else {
	dr0=dr;
	for(ITE=1;ITE<=Nit;ITE++) {
	    Rho1=dr0*dr;
	    Beta=(Rho1*Alpha)/(Rho0*Omega0);
	    Rho0=Rho1;

	    dp*=Beta;
	    dp+=dr;
	    dp.AddMultConst(dpa,-Beta*Omega0);

	    (*this).VectMult(dp,dpa,1,0);
	    if (Flag)
		(*this).PrecondSOR(dpa,Omega);

	    Alpha=dr0*dpa;
	    Alpha=Rho1/Alpha;

	    dr.AddMultConst(dpa,-Alpha);

	    (*this).VectMult(dr,dsa,1,0);
	    if (Flag)
		(*this).PrecondSOR(dsa,Omega);

	    Omega1=dsa*dr;
	    Omega2=dsa*dsa;
	    Omega0=Omega1/Omega2;

	    x.AddMultConst(dp,Alpha);
	    x.AddMultConst(dr,Omega0);
	    dr.AddMultConst(dsa,-Omega0);

	    Fr=dr.l2Norm();
	    ProtAdd<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";

	    if (Fr<=Eps) {
		if (Res>=1e-70)
		    Res=Fr/Res;
		Prot<<"Iterations "<<ITE<<"  BiCG-Stab-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
// 		protocol<<"Iterations "<<ITE<<"  BiCG-Stab-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";

		if (ITE == 0)
		    Cappa=0;
		else
		    Cappa=pow(Res,(1/(double)ITE));
		Prot<<"Rate of convergence "<<Cappa<<"\n";
// 		protocol<<"Rate of convergence "<<Cappa<<"\n";
		return TRUE;
	    }
	}
	Prot<<"CONVERGENCE FAILED !!\n";
	Prot<<"Iterations "<<Nit<<"  BiCG-Stab-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
// 	protocol<<"CONVERGENCE FAILED !!\n";
// 	protocol<<"Iterations "<<Nit<<"  BiCG-Stab-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	if (Res>=1e-70) {
	    Cappa=pow((Fr/Res),(1/(double)Nit));
	} else {
	    Cappa=0;
	}
	Prot<<"Rate of convergence "<<Cappa<<"\n";
protocol<<"Rate of convergence "<<Cappa<<"\n";
	return FALSE;
    }

//      if (Res>=1e-70)
//  	Res=Fr/Res;
//      Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
//      if (ITE == 0)
//  	Cappa=0;
//      else
//  	Cappa=pow(Res,(1/(double)ITE));
//      Prot<<"Rate of convergence "<<Cappa<<"\n";
//      return TRUE;
}

void DoubleCompactMatrix::Filter(DoubleVector& x)
{
    DoubleVector mean=x;
    double rmean;

    mean=1;
    rmean=mean*x;
    rmean/=(double)mean.GetLen();

    if (fabs(rmean)>1e-16) {
	for(int IEQ=1;IEQ<=x.GetLen();IEQ++)
	    x(IEQ)-=rmean;
    }
}

DoubleVector& DoubleCompactMatrix::NeumannCG(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Eps,double Omega)
{
    int ITE,Flag;
    double Res,Fr,Sigma0,Alpha,Sigma1,Cappa,Gamma,MaxNorm;
//      double ResInt;

    if (GetNumDiag() != x.GetLen() || x.GetLen() != b.GetLen()) {
	protocol << "Warning (process " << MyProcID << "): Matrix and vector dimensions are not apt in DoubleCompactMatrix::NeumannCG.\n";
	return x;
    }

    Filter(x);
    Filter(b);

    DoubleVector dr=b,dd=b,dd1=b,dg=b;

    Flag=Omega<0;
    if (!Flag)
	ProtAdd<<"PrecondSOR !!\n";
    MaxNorm=b.MaxNorm();
    // MaxNorm == 0
    if (fabs(MaxNorm - 0.0) < FLOAT_EPS) {
	x=0;
	Prot<<"Warning zero right hand side !!\n";
	return x;
    }

    (*this).VectMult(x,dr);
    Filter(dr);

    dr-=b;
    Res=dr.l2Norm();
//      ResInt=Res;

    if (Res<=Eps) {
	ITE=0;
	Fr=Res;
    } else {
	if (Flag) {
	    Sigma0=Res*Res;
	    dg=dr;
	    Filter(dg);
	} else {
	    dg=dr;
	    (*this).PrecondSOR(dg,Omega);
	    Filter(dg);

	    Sigma0=dr*dg;
	}
	dd=dg;dd*=-1;
	for(ITE=1;ITE<=Nit;ITE++) {
	    (*this).VectMult(dd,dd1);
	    Filter(dd1);

	    Alpha=dd*dd1;
	    Alpha=Sigma0/Alpha;
	    x.AddMultConst(dd,Alpha);
	    dr.AddMultConst(dd1,Alpha);

	    Fr=dr.l2Norm();
	    ProtAdd<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";

	    if (Fr<=Eps) {
		if (Res>=1e-70)
		    Res=Fr/Res;
		Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
		if (ITE == 0)
		    Cappa=0;
		else
		    Cappa=pow(Res,(1/(double)ITE));
		Prot<<"Rate of convergence "<<Cappa<<"\n";
		return x;
	    }
	    if (Flag) {
		Sigma1=Fr*Fr;
		dg=dr;
		Filter(dg);
	    } else {
		dg=dr;
		(*this).PrecondSOR(dg,Omega);
		Filter(dg);

		Sigma1=dr*dg;
	    }
	    Gamma=Sigma1/Sigma0;
	    Sigma0=Sigma1;
	    dd*=Gamma;dd-=dg;
	}
	Prot<<"CONVERGENCE FAILED !!\n";
	Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	if (Res>=1e-70) {
	    Cappa=pow((Fr/Res),(1/(double)Nit));
	} else {
	    Cappa=0;
	}
	Prot<<"Rate of convergence "<<Cappa<<"\n";
	return x;
    }
    if (Res>=1e-70)
	Res=Fr/Res;
    Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
    if (ITE == 0)
	Cappa=0;
    else
	Cappa=pow(Res,(1/(double)ITE));
    Prot<<"Rate of convergence "<<Cappa<<"\n";
    return x;
}

DoubleVector& DoubleCompactMatrix::NeumannCGSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit)
{
    int ITE;
    double Res,Fr,Sigma0,Alpha,Sigma1,Gamma;
//      double MaxNorm;
//      double ResInt;

    Filter(x);
    Filter(b);

    DoubleVector dr=b,dd=b,dd1=b,dg=b;

    (*this).VectMult(x,dr);
    Filter(dr);

    dr  -= b;
    Res = dr.l2Norm();
//      ResInt=Res;

    Sigma0 = Res * Res;
    dd = dg; dd *= -1;
    for (ITE = 1; ITE <= Nit; ITE++) {
	(*this).VectMult(dd,dd1);
	Filter(dd1);

	Alpha = dd * dd1;
	Alpha = Sigma0 / Alpha;
	x.AddMultConst(dd,Alpha);
	dr.AddMultConst(dd1,Alpha);

	Fr=dr.l2Norm();

	Sigma1 = Fr * Fr;
	Gamma = Sigma1 / Sigma0;
	Sigma0 = Sigma1;
	dd *= Gamma; dd -= dg;
    }
    return x;
}

void DoubleCompactMatrix::CuthillMcKee()
{
    IntArray *KDEG=new IntArray(28);
    IntArray *KCON=new IntArray(*Column);
    int IEQ,ILD,ICOL,IDEG1,IDEG2,INDMIN,MINDEG,INDDEG,ICOUNT,INDNEQ;
//      int Pos;

    for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	*KDEG=0;

	for(ILD=Diag(IEQ)+1;ILD<=Diag(IEQ+1)-1;ILD++) {
	    (*KDEG)(ILD-Diag(IEQ))=Col(ILD);
	}

	for(IDEG1=1;IDEG1<=Diag(IEQ+1)-Diag(IEQ)-1;IDEG1++) {
	    INDMIN=1;

	    if ((*KDEG)(INDMIN) == 0)
		MINDEG=GetNumDiag();
	    else
		MINDEG=Diag((*KDEG)(INDMIN)+1)-Diag((*KDEG)(INDMIN))-1;

	    for(IDEG2=1;IDEG2<=Diag(IEQ+1)-Diag(IEQ)-1;IDEG2++) {
		if ((*KDEG)(IDEG2) == 0)
		    INDDEG=GetNumDiag();
		else
		    INDDEG=Diag((*KDEG)(IDEG2)+1)-Diag((*KDEG)(IDEG2))-1;

		if (INDDEG<MINDEG) {
		    INDMIN=IDEG2;
		    MINDEG=INDDEG;
		}
	    }

	    (*KCON)(Diag(IEQ)+IDEG1)=(*KDEG)(INDMIN);
	    (*KDEG)(INDMIN)        =0;
	}
    }

    Perm1=new IntArray(NumDiag-1);
    Perm2=new IntArray(NumDiag-1);
    *Perm1=0;
    *Perm2=0;

    ILUDiagonal=new IntArray(*Diagonal);
    ILUColumn=new IntArray(*Column);
    ILUDataArray=new DoubleArray(*this);

    ICOUNT=1;
    INDNEQ=1;
    (*Perm1)(1)=1;
    (*Perm2)(1)=1;


    do {
	for(ILD=Diag((*Perm1)(ICOUNT));ILD<=Diag((*Perm1)(ICOUNT)+1)-1;ILD++) {
	    ICOL=(*KCON)(ILD);
	    if ((*Perm2)(ICOL) == 0) {
		INDNEQ++;
		(*Perm2)(ICOL  )=INDNEQ;
		(*Perm1)(INDNEQ)=ICOL;
	    }
	}

	ICOUNT++;
    } while(ICOUNT != GetNumDiag());

    delete KDEG;
    delete KCON;

    //  for(ICOUNT=1;ICOUNT<=GetNumDiag();ICOUNT++)
    //  (*Perm1)(ICOUNT)=(*Perm2)(ICOUNT)=ICOUNT;
    //Prot<<"Perm1=\n"<<*Perm1<<"\n";
    //Prot<<"Perm2=\n"<<*Perm2<<"\n";
}

void DoubleCompactMatrix::Sort(IntArray& KH1,IntArray& KH2,int IDIM)
{
    int	BMORE,ICOMP,IAUX1,IAUX2;

    BMORE=TRUE;
    while(BMORE) {
	BMORE=FALSE;
	for(ICOMP=1;ICOMP<=IDIM-1;ICOMP++) {
	    if (KH1(ICOMP)>KH1(ICOMP+1)) {
		IAUX1=KH1(ICOMP);
		IAUX2=KH2(ICOMP);
		KH1(ICOMP)=KH1(ICOMP+1);
		KH2(ICOMP)=KH2(ICOMP+1);
		KH1(ICOMP+1)=IAUX1;
		KH2(ICOMP+1)=IAUX2;
		BMORE=TRUE;
	    }
	}
    }

}

void DoubleCompactMatrix::PermAll()
{
    int ILD,I,I1,JH,IH1,IH2,J,ID1,ICOL;
    IntArray *KH1=new IntArray(100);
    IntArray *KH2=new IntArray(100);
//      int row,end;
    double DH;

    ILD=1;

    for(I=1;I<=GetNumDiag();I++) {
	I1=(*Perm1)(I);
	ILUData(ILD)=Data(Diag(I1));
	ILUDiag(I)=ILD;
	ILUCol(ILD)=I;
	ILD=ILD+1;

	IH1=Diag(I1)+1;
	IH2=Diag(I1+1)-1;
	ID1=IH2-IH1+1;

	for(JH=IH1;JH<=IH2;JH++) {
	    (*KH1)(JH-IH1+1)=(*Perm2)(Col(JH));
	    (*KH2)(JH-IH1+1)=JH;
	}

	Sort(*KH1,*KH2,ID1);

	for(J=1;J<=ID1;J++) {
	    DH=Data((*KH2)(J));
	    ICOL=(*KH1)(J);
	    ILUData(ILD)=DH;
	    ILUCol(ILD)=ICOL;
	    ILD=ILD+1;
	}
    }

    ILUDiag(GetNumDiag()+1)=Diag(GetNumDiag()+1);

    delete KH1;delete KH2;

//        for(I=1;I<=NumDiag;I++)
//        ILUDiag(I)=Diag(I);
//        for(I=1;I<=NumData;I++) {
//        ILUData(I)=Data(I);
//        ILUCol(I)=Col(I);
//        }

//        *ILUDiagonal=*Diagonal;
//        *ILUColumn=*Column;
//        *ILUDataArray=(*(DoubleArray*)(this));


//        int IEQ,JCOL,num;
//        for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
//        for(JCOL=ILUDiag(IEQ)+1,num=0;JCOL<=ILUDiag(IEQ+1)-1;JCOL++,num++) {
//        ILUData(JCOL)=-1;
//        }
//        ILUData(ILUDiag(IEQ))=num;
//        }


//        Prot<<"After Perm !!\n";
//        for(row=1;row<=GetNumDiag();row++)
//        {
//        end=(*ILUDiagonal)(row+1)-1;
//        for(int col=(*ILUDiagonal)(row);col<=end;col++)
//        {
//        Prot<<"The value at row "<<row<<" ,column "<<(*ILUColumn)(col)<<" = ";
//        Prot<<ILUData(col)<<"\n";
//        }
//        }
}

void DoubleCompactMatrix::PermAll(DoubleVector *diag)
{
    int ILD,I,I1,JH,IH1,IH2,J,ID1,ICOL;
    IntArray *KH1=new IntArray(100);
    IntArray *KH2=new IntArray(100);
//      int row,end;
    double DH;

    ILD=1;

    for(I=1;I<=GetNumDiag();I++) {
	I1=(*Perm1)(I);
	ILUData(ILD)=(*diag)(I1);
	ILUDiag(I)=ILD;
	ILUCol(ILD)=I;
	ILD=ILD+1;

	IH1=Diag(I1)+1;
	IH2=Diag(I1+1)-1;
	ID1=IH2-IH1+1;

	for(JH=IH1;JH<=IH2;JH++) {
	    (*KH1)(JH-IH1+1)=(*Perm2)(Col(JH));
	    (*KH2)(JH-IH1+1)=JH;
	}

	Sort(*KH1,*KH2,ID1);

	for(J=1;J<=ID1;J++) {
	    DH=Data((*KH2)(J));
	    ICOL=(*KH1)(J);
	    ILUData(ILD)=DH;
	    ILUCol(ILD)=ICOL;
	    ILD=ILD+1;
	}
    }

    ILUDiag(GetNumDiag()+1)=Diag(GetNumDiag()+1);

    delete KH1;delete KH2;
}


void DoubleCompactMatrix::PermToNew(DoubleVector& oldvec,DoubleVector& newvec)
{
    for(int IEQ=1;IEQ<=oldvec.GetLen();IEQ++)
	newvec(IEQ)=oldvec((*Perm1)(IEQ));
}


void DoubleCompactMatrix::PermToNew(IntArray& oldvec,IntArray& newvec)
{
    for(int IEQ=1;IEQ<=oldvec.GetLen();IEQ++)
	newvec(IEQ)=oldvec((*Perm1)(IEQ));
}
void DoubleCompactMatrix::PermToOld(DoubleVector& newvec,DoubleVector& oldvec)
{
    for(int IEQ=1;IEQ<=oldvec.GetLen();IEQ++)
	oldvec(IEQ)=newvec((*Perm2)(IEQ));
}

double DoubleCompactMatrix::Sign(double a1,double a2)
{
    if (a2>=0)
	return fabs(a1);
    else
	return -fabs(a1);
}

void DoubleCompactMatrix::ILU(int ILU,double Alpha,double Tol,IntArray& Info)
{
    int BMILU,ICOL,ILD,IEQ,NEQ,JCOL,JLD,IP,JC,JCOLO;
    double A,AIJ;
    double	Alpha1;

    SetILUBound(Info);

    NEQ=GetNumDiag();
    if (ILU == 1) {
	// Constant shift for ILU
	Alpha1=1/(1+Alpha);
	for(IEQ=1;IEQ<=NEQ;IEQ++)
	    for(ICOL=ILUDiag(IEQ)+1;ICOL<=ILUDiag(IEQ+1)-1;ICOL++)
		ILUData(ICOL)*=Alpha1;
    } else {
	// Constant shift for MILU
	Alpha1=1+Alpha;
	for(IEQ=1;IEQ<=NEQ;IEQ++) {
	    ILD=ILUDiag(IEQ);
	    ILUData(ILD)*=Alpha1;
	}
    }
    BMILU=(ILU == 2);
    ILD=1;
    //Incomplete GAUSS elimination
    for(IEQ=2;IEQ<=NEQ;IEQ++) {
	//    if (Info(IEQ) == 0) {
	A=ILUData(ILD);
	if (fabs(A)<Tol) {
	    ILUData(ILD)=Sign(Tol,A);
	}
	ILD=ILUDiag(IEQ);
	if (ILUCol(ILD+1)<IEQ) {
	    for(JCOL=ILD+1;JCOL<=ILUDiag(IEQ+1)-1;JCOL++) {
		ICOL=ILUCol(JCOL);
		if (ICOL>=IEQ)
		    break;
		JLD=ILUDiag(ICOL);
		AIJ=ILUData(JCOL)/ILUData(JLD);
		// AIJ is the entry of the elimination matrix at (IEQ,ICOL)
		ILUData(JCOL)=AIJ;
		IP=ILUDiag(IEQ+1)-1;
		if (BMILU) {
		    // Modified incomplete LU decomposition
		    // Loop over subdiagonal entries in line ICOL
		    for(JC=ILUDiag(ICOL+1)-1;JC>=JLD;JC--) {
			JCOLO=ILUCol(JC);
			if (JCOLO<IEQ) {
			    if (JCOLO<=ICOL)
				break;
			    for(;;) {
				if (ILUCol(IP)<JCOLO) {
				    ILUData(ILD)-=AIJ*ILUData(JC);
				    break;
				} else if (ILUCol(IP) == JCOLO) {
				    ILUData(IP)-=AIJ*ILUData(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				    if (IP<=ILD) {
					ILUData(ILD)-=AIJ*ILUData(JC);
					break;
				    }
				}
			    }
			} else if (JCOLO == IEQ) {
			    ILUData(ILD)-=AIJ*ILUData(JC);
			} else {
			    for(;;) {
				if (ILUCol(IP)<JCOLO) {
				    ILUData(ILD)-=AIJ*ILUData(JC);
				    break;
				} else if (ILUCol(IP) == JCOLO) {
				    ILUData(IP)-=AIJ*ILUData(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				    if (IP<=ILD) {
					ILUData(ILD)-=AIJ*ILUData(JC);
					break;
				    }
				}
			    }
			}
		    }
		} else {
		    for(JC=ILUDiag(ICOL+1)-1;JC>=JLD;JC--) {
			JCOLO=ILUCol(JC);
			if (JCOLO<IEQ) {
			    if (JCOLO<=ICOL)
				break;
			    for(;;) {
				if (ILUCol(IP)<JCOLO) {
				    break;
				} else if (ILUCol(IP) == JCOLO) {
				    ILUData(IP)-=AIJ*ILUData(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				}
			    }
			} else if (JCOLO == IEQ) {
			    ILUData(ILD)-=AIJ*ILUData(JC);
			} else {
			    for(;;) {
				if (ILUCol(IP)<JCOLO) {
				    break;
				} else if (ILUCol(IP) == JCOLO) {
				    ILUData(IP)-=AIJ*ILUData(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				}
			    }
			}
		    }
		}
	    }
	}
	//}
    }


//      Prot<<"After ILU !!\n";
//      int end;
//      for(int row=1;row<=GetNumDiag();row++)
//      {
//  	end=(*ILUDiagonal)(row+1)-1;
//  	for(int col=(*ILUDiagonal)(row);col<=end;col++)
//  	{
//  	    Prot<<"The value at row "<<row<<" ,column "<<(*ILUColumn)(col)<<" = ";
//  	    Prot<<ILUData(col)<<"\n";
//  	}
//      }

}

void DoubleCompactMatrix::SetILUBound(IntArray& Info)
{
    int ICOL;
    IntArray temp(Info.GetLen());

    PermToNew(Info,temp);

    for(int i=1;i<=GetNumDiag();i++) {
	if (temp(i) != 0) {
	    ILUData(ILUDiag(i))=1;
	    for(ICOL=ILUDiag(i)+1;ICOL<=ILUDiag(i+1)-1;ICOL++)
		ILUData(ICOL)=0;
	}
    }
}

void DoubleCompactMatrix::ILU(int ILU,double Alpha,double Tol)
{
    int BMILU,ICOL,ILD,IEQ,NEQ,JCOL,JLD,IP,JC,JCOLO;
    double A,AIJ;
    double	Alpha1;

    NEQ=GetNumDiag();
    if (ILU == 1) {
	// Constant shift for ILU
	Alpha1=1/(1+Alpha);
	for(IEQ=1;IEQ<=NEQ;IEQ++)
	    for(ICOL=ILUDiag(IEQ)+1;ICOL<=ILUDiag(IEQ+1)-1;ICOL++)
		ILUData(ICOL)*=Alpha1;
    } else {
	// Constant shift for MILU
	Alpha1=1+Alpha;
	for(IEQ=1;IEQ<=NEQ;IEQ++) {
	    ILD=ILUDiag(IEQ);
	    ILUData(ILD)*=Alpha1;
	}
    }
    BMILU=(ILU == 2);
    ILD=1;
    //Incomplete GAUSS elimination
    for(IEQ=2;IEQ<=NEQ;IEQ++) {
	A=ILUData(ILD);
	if (fabs(A)<Tol) {
	    ILUData(ILD)=Sign(Tol,A);
	}
	ILD=ILUDiag(IEQ);
	if (ILUCol(ILD+1)<IEQ) {
	    for(JCOL=ILD+1;JCOL<=ILUDiag(IEQ+1)-1;JCOL++) {
		ICOL=ILUCol(JCOL);
		if (ICOL>=IEQ)
		    break;
		JLD=ILUDiag(ICOL);
		AIJ=ILUData(JCOL)/ILUData(JLD);
		// AIJ is the entry of the elimination matrix at (IEQ,ICOL)
		ILUData(JCOL)=AIJ;
		IP=ILUDiag(IEQ+1)-1;
		if (BMILU) {
		    // Modified incomplete LU decomposition
		    // Loop over subdiagonal entries in line ICOL
		    for(JC=ILUDiag(ICOL+1)-1;JC>=JLD;JC--) {
			JCOLO=ILUCol(JC);
			if (JCOLO<IEQ) {
			    if (JCOLO<=ICOL)
				break;
			    for(;;) {
				if (ILUCol(IP)<JCOLO) {
				    ILUData(ILD)-=AIJ*ILUData(JC);
				    break;
				} else if (ILUCol(IP) == JCOLO) {
				    ILUData(IP)-=AIJ*ILUData(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				    if (IP<=ILD) {
					ILUData(ILD)-=AIJ*ILUData(JC);
					break;
				    }
				}
			    }
			} else if (JCOLO == IEQ) {
			    ILUData(ILD)-=AIJ*ILUData(JC);
			} else {
			    for(;;) {
				if (ILUCol(IP)<JCOLO) {
				    ILUData(ILD)-=AIJ*ILUData(JC);
				    break;
				} else if (ILUCol(IP) == JCOLO) {
				    ILUData(IP)-=AIJ*ILUData(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				    if (IP<=ILD) {
					ILUData(ILD)-=AIJ*ILUData(JC);
					break;
				    }
				}
			    }
			}
		    }
		} else {
		    for(JC=ILUDiag(ICOL+1)-1;JC>=JLD;JC--) {
			JCOLO=ILUCol(JC);
			if (JCOLO<IEQ) {
			    if (JCOLO<=ICOL)
				break;
			    for(;;) {
				if (ILUCol(IP)<JCOLO) {
				    break;
				} else if (ILUCol(IP) == JCOLO) {
				    ILUData(IP)-=AIJ*ILUData(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				}
			    }
			} else if (JCOLO == IEQ) {
			    ILUData(ILD)-=AIJ*ILUData(JC);
			} else {
			    for(;;) {
				if (ILUCol(IP)<JCOLO) {
				    break;
				} else if (ILUCol(IP) == JCOLO) {
				    ILUData(IP)-=AIJ*ILUData(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				}
			    }
			}
		    }
		}
	    }
	}
    }


//      Prot<<"After ILU !!\n";
//      int end;
//      for(int row=1;row<=GetNumDiag();row++)
//      {
//  	end=(*ILUDiagonal)(row+1)-1;
//  	for(int col=(*ILUDiagonal)(row);col<=end;col++)
//  	{
//  	    Prot<<"The value at row "<<row<<" ,column "<<(*ILUColumn)(col)<<" = ";
//  	    Prot<<ILUData(col)<<"\n";
//  	}
//      }

}

void DoubleCompactMatrix::ILU(DoubleVector& x)
{
    int IEQ,JCOL,ICOL,NEQ,ILD;
    double Aux;

    NEQ = GetNumDiag();

    for(IEQ = 2;IEQ <= NEQ; IEQ++)
    {
	Aux = 0;
	for(JCOL = ILUDiag(IEQ) + 1; JCOL <= ILUDiag(IEQ+1) - 1; JCOL++) {
	    ICOL = ILUCol(JCOL);
	    if (ICOL >= IEQ)
		break;
	    Aux += ILUData(JCOL) * x(ICOL);
	}
	x(IEQ) -= Aux;
    }

    x(NEQ) /= ILUData(ILUDiag(NEQ));
    for (IEQ = NEQ-1; IEQ >= 1; IEQ--) {
	ILD = ILUDiag(IEQ);
	Aux = 0;
	for (JCOL = ILUDiag(IEQ+1) - 1; JCOL >= ILD+1; JCOL--) {
	    ICOL = ILUCol(JCOL);
	    if (ICOL <= IEQ)
		break;
	    Aux += ILUData(JCOL) * x(ICOL);
	}
	x(IEQ) = (x(IEQ) - Aux) / ILUData(ILD);
    }
}

DoubleVector& DoubleCompactMatrix::PrecondILU(DoubleVector& x)
{
    DoubleVector *CVector = new DoubleVector(x.GetLen());

    PermToNew(x,*CVector);
    ILU(*CVector);
    PermToOld(*CVector,x);

    delete CVector;

    return x;
}

DoubleVector& DoubleCompactMatrix::ILUSmooth(DoubleVector& x,DoubleVector& b,
					     unsigned int Nit,double Omega)
{
    int ITE,IEQ;
    DoubleVector	CVector(GetNumDiag());
    DoubleVector	CVector2(GetNumDiag());

    for(ITE=1;ITE<=Nit;ITE++)
    {
	CVector=0;
	VectMult(x,CVector);

	CVector-=b;

	PermToNew(CVector,CVector2);
	ILU(CVector2);
	PermToOld(CVector2,CVector);

	for(IEQ=1;IEQ<=x.GetLen();IEQ++)
	    x(IEQ)-=Omega*CVector(IEQ);
    }

    return x;
}

DoubleVector& DoubleCompactMatrix::ILU(DoubleVector& x,DoubleVector& b,
				       unsigned int Nit,double Res,double Omega)
{
    int ITE,IEQ;
    double Tol;
    DoubleVector	CVector(GetNumDiag());
    DoubleVector	CVector2(GetNumDiag());

    for(ITE=1;ITE<=Nit;ITE++)
    {
	CVector=0;
	VectMult(x,CVector);

	CVector-=b;

	Tol=CVector.l2Norm();
	if (Tol<Res)
	    return x;
	Prot<<"ILU ite="<<ITE<<" res="<<Res<<"\n";

	PermToNew(CVector,CVector2);
	ILU(CVector2);
	PermToOld(CVector2,CVector);

	for(IEQ=1;IEQ<=x.GetLen();IEQ++)
	    x(IEQ)-=Omega*CVector(IEQ);
    }

    return x;
}


void DoubleCompactMatrix::arraysizeViolation(const char *callingFunction, const char *Name, int a, int amax)
{
    message
	= progname + " (process " + int_to_string(MyProcID) + "):\n"
	+ "  Unrecoverable error discovered:\n"
	+ "    Wrong access to an object of type DoubleCompactMatrix with name" + Name + ":\n";

    if (a < 1) {
	message += "    Trying to access array with too small index: " + int_to_string(a) + ".\n";
    } else {
	message += "    Trying to access array with too large index: " + int_to_string(a)
	    + ". Maximum allowed: " + int_to_string(amax) + ".\n";
    }
    message += "  Program aborted in ";
    message += callingFunction;
    message += '\n';

    STD_CERR << message;
    protocol  << message;

    exit(ARRAY_LIMIT_ERROR);
}


void DoubleCompactMatrix::elementNotFound(const char *callingFunction, const char *Name)
{
    message
	= progname + " (process " + int_to_string(MyProcID) + "):\n"
	+ "  Unrecoverable error discovered:\n"
	+ "    Wrong access to an object of type DoubleCompactMatrix with name" + Name + ":\n"
	+ "  Program aborted in ";
    message += callingFunction;
    message += '\n';

    STD_CERR << message;
    protocol  << message;

    exit(ARRAY_LIMIT_ERROR);
}


void DoubleCompactMatrix::PrintRowSum(void)
{
    // check row sum
    double var_sb = 0.0;

    for(int IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	var_sb = 0;
	for(int ICOL=Diag(IEQ);ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    var_sb += Data(ICOL);
	}
	protocol << "row sum: " << var_sb << "\n";
    }

    return;
}


void DoubleCompactMatrix::PrintMaxRowSum(void)
{
    double var_sb = 0.0, max = -DBL_MAX;

    for(int IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	var_sb = 0;
	for(int ICOL=Diag(IEQ);ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    var_sb += Data(ICOL);
	}

	if (var_sb > max) 
	    max = var_sb;
    }
    protocol << "maximal row sum: " << max << "\n";

    return;
}


void DoubleCompactMatrix::ShowSparseMatrix(void)
{
    // show as in FeatFlow with MT > 9
    for(int IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	for(int ICOL=Diag(IEQ);ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    protocol << "   " << IEQ << "  " << ICOL << "  " << Col(ICOL) << "   " << Data(ICOL) << "\n";
	}
	protocol << " ***\n";
    }

    return;
}


void DoubleCompactMatrix::ShowFullMatrix()
{
    // build complete matrix
    DoubleArray2D* full_matrix;

    full_matrix = new DoubleArray2D(GetNumDiag(), GetNumDiag(), "Matrix A voll");
    for(int IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	(*full_matrix)(IEQ, IEQ) = Data(Diag(IEQ));	  // set diagonal element
	for (int ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    (*full_matrix)(IEQ, Col(ICOL)) = Data(ICOL);
	}
    }

    // show complete matrix
//     COutput matrix(ACTIVE);
//     std::string matrixfile("./matrix");
//     matrix.mSetFile(matrixfile.c_str());
//     matrix.mToggleScreenOutput(OFF);
	
    for (int i = 1;  i <= GetNumDiag(); i++) {
	for (int j = 1;  j <= GetNumDiag(); j++) {
// 	    matrix << i << "  " << j << "  " << double_to_string((*full_matrix)(i, j), "f", 16) << "\n";
	    protocol << i << "  " << j << "  " << double_to_string((*full_matrix)(i, j), "f", 16) << "\n";
	}
    }
//  matrix << '\n';
    protocol << '\n';
    delete full_matrix;

    return;
}
