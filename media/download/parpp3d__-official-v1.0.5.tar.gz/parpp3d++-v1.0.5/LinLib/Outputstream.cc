#include "Output.h"

Output::Output(BYTEPTR aName,unsigned int aFlag) 
{
  Type=FILE_FLAG;
  Flag=aFlag;
//  File=new ofstream(aName);
  File=fopen(aName,"w");
  if(!File) {
    printf("Couldnt open file %s\n",aName);
    exit(1);
  }
}

Output::~Output(void)
{
  if(Type==FILE_FLAG) {
    if(File)
//      delete File;
      fclose(File);
  }
}

FILE *Output::OpenFile(BYTEPTR Name)
{
//  ofstream *MyFile;
  FILE *MyFile;
  
//  MyFile=new ofstream(Name);
  MyFile=fopen(Name,"w");
  if(!MyFile) {
    printf("Couldnt open file %s\n",Name);
    exit(1);
  }
  return MyFile;
}

VOID Output::CloseFile(FILE *File)
{
//  delete File;
  fclose(File);
}

VOID Output::SetFile(BYTEPTR Name)
{
  if(Type==FILE_FLAG) {
    if(File)
//      delete File;
      fclose(File);
  }
  Type=FILE_FLAG;
  Flag=YES;
//  File=new ofstream(Name);
  File=fopen(Name,"w");
  if(!File) {
    printf("Couldnt open file %s\n",Name);
    exit(1);
  }
}

VOID Output::SetFile(FILE *MyFile)
{
  Type=FILE_FLAG;
  Flag=YES;
  File=MyFile;
}

VOID Output::SetScreen(VOID)
{
  Type=SCREEN_FLAG;
  Flag=YES;
}

Output& Output::operator<<(INTEGER aNumber)
{
  if(Flag==YES) {
    if(Type==SCREEN_FLAG) {
//      cout<<aNumber;
      printf("%d",aNumber);
    } else {
      if(File) {
//	(*File).width(8);
//	(*File)<<aNumber;
	fprintf(File,"%d",aNumber);
      }
    }
  }
  return *this;
}

Output& Output::operator<<(REAL aNumber)
{
  if(Flag==YES) {
    if(Type==SCREEN_FLAG) {
//      cout<<aNumber;
      printf("%e",aNumber);
    } else {
      if(File) {
//	(*File).setf(ios::scientific,ios::floatfield);
//	(*File).precision(5);
//	(*File).width(4);
//	(*File)<<aNumber;
	fprintf(File,"%e",aNumber);
      }
    }
  }
  return *this;
}

Output& Output::operator<<(DOUBLE aNumber)
{
  if(Flag==YES) {
    if(Type==SCREEN_FLAG) {
//      cout<<aNumber;
      printf("%le",aNumber);
    } else {
      if(File) {
//	(*File).setf(ios::scientific,ios::floatfield);
//	(*File).precision(5);
//	(*File).width(4);
//	(*File)<<aNumber;
	fprintf(File,"%le",aNumber);
      }
    }
  }
  return *this;
}

Output& Output::operator<<(unsigned int aNumber)
{
  if(Flag==YES) {
    if(Type==SCREEN_FLAG) {
//      cout<<aNumber;
      printf("%u",aNumber);
    } else {
      if(File) {
//	(*File).width(8);
//	(*File)<<aNumber;
	fprintf(File,"%u",aNumber);
      }
    }
  }
  return *this;
}

 
Output& Output::operator<<(LONG aNumber)
{
  if(Flag==YES) {
    if(Type==SCREEN_FLAG) {
//      cout<<aNumber;
      printf("%ld",aNumber);
    } else {
      if(File) {
//	(*File).width(8);
//	(*File)<<aNumber;
	fprintf(File,"%ld",aNumber);
      }
    }
  }
  return *this;
}

Output& Output::operator<<(BYTEPTR aString)
{
  if(Flag==YES) {
    if(Type==SCREEN_FLAG) {
//      cout<<aString;
      printf("%s",aString);
    } else {
      if(File) {
//	(*File)<<aString;
	fprintf(File,"%s",aString);
      }
    }
  }
  return *this;
}



