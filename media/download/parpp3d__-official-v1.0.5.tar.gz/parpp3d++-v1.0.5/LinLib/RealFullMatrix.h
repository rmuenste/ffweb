#ifndef REALFULLMATRIXH

#define REALFULLMATRIXH

#include "RealArray2D.h"
#include "RealVector.h"

class RealFullMatrix:public RealArray2D
{       
public:
    RealFullMatrix(unsigned int Rows,unsigned int Cols):RealArray2D(Rows,Cols) {}
    RealFullMatrix(unsigned int Rows,unsigned int Cols,BYTEPTR aName):RealArray2D(Rows,Cols,aName) {}
    ~RealFullMatrix(void) {}
        
// Methods for Full-Matrix              
    RealFullMatrix& operator=(RealFullMatrix& aRealFullMatrix);
    RealFullMatrix& operator=(REAL aNumber);
    RealVector& VectMult(RealVector& aSrcVect,RealVector& aDestVect); 
                
    friend Output& operator<<(Output& o,RealFullMatrix& aMatrix);
};

#endif
