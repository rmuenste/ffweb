#ifndef DOUBLEFULLMATRIXH

#define DOUBLEFULLMATRIXH

#include "DoubleArray2D.h"
#include "DoubleVector.h"

class DoubleFullMatrix:public DoubleArray2D
{	
public:
    DoubleFullMatrix(UNSIGNED Rows,UNSIGNED Cols):DoubleArray2D(Rows,Cols) {}
    DoubleFullMatrix(UNSIGNED Rows,UNSIGNED Cols,BYTEPTR aName):DoubleArray2D(Rows,Cols,aName) {}
    ~DoubleFullMatrix(VOID) {}
	
// Methods for Full-Matrix		
    DoubleFullMatrix& operator=(DoubleFullMatrix& aDoubleFullMatrix);
    DoubleFullMatrix& operator=(DOUBLE aNumber);
    DoubleVector& VectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect); 
    // a1*A*aSrcVect+a2*aDestVect=aDestVect
    DoubleVector& VectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect,DOUBLE a1,DOUBLE a2);
		
    VOID	LR_Zerlegung(DoubleVector *f,DoubleVector *sol);
    UNSIGNED	FindPivot(UNSIGNED i);
    VOID	ExchangeRow(UNSIGNED source,UNSIGNED dest,DoubleVector *f);
		
    friend Output& operator<<(Output& o,DoubleFullMatrix& aMatrix);
};

#endif
