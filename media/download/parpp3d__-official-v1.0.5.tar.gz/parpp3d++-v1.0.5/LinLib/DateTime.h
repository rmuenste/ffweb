#ifndef DATETIMEH

#define DATETIMEH

#include "Output.h"
#include "MyTypes.h"
//  #include <string>
#include <mpi.h>				  // for MPI_Wtime()

class DateTime
{
private:
  double SystemTime;
		
public:
  DateTime(void);
  
  void   SetTime(void);
//    string GetTime(void);
  double GetTimeDiff(void);
  friend Output& operator<<(Output& o,DateTime& aDateTime);
};

#endif
