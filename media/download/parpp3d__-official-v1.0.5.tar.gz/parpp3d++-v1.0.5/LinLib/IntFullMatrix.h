#ifndef INTFULLMATRIXH

#define INTFULLMATRIXH

#include "IntArray2D.h"
#include "IntVector.h"

class IntFullMatrix:public IntArray2D
{	
public:
    IntFullMatrix(unsigned int Rows,unsigned int Cols):IntArray2D(Rows,Cols) {}
    IntFullMatrix(unsigned int Rows,unsigned int Cols,BYTEPTR aName):IntArray2D(Rows,Cols,aName) {}
	
// Methods for Full-Matrix		
    IntFullMatrix& operator=(IntFullMatrix& anIntFullMatrix);
    IntFullMatrix& operator=(int aNumber);
    IntVector& VectMult(IntVector& aSrcVect,IntVector& aDestVect); 
		
    friend Output& operator<<(Output& o,IntFullMatrix& aMatrix);
};

#endif
