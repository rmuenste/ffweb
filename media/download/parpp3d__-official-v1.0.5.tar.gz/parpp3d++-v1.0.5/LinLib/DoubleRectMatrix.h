#ifndef DOUBLERECTMATRIXH

#define DOUBLERECTMATRIXH

#include "math.h"
#include "IntArray.h"
#include "DoubleArray.h"
#include "DoubleVector.h"

class DoubleRectMatrix:public DoubleArray
{
protected:
    UNSIGNED 	NumData;
    UNSIGNED	NumRow;
    IntArray*	Column;
    IntArray*	Row;
		
public:
    DoubleRectMatrix(UNSIGNED aNumData,UNSIGNED aNumRow)
	:DoubleArray(aNumData),NumData(aNumData),NumRow(aNumRow+1)
	{Column=new IntArray(aNumData);Row=new IntArray(aNumRow+1);
	(*Row)(aNumRow+1)=aNumData+1;}
				
    DoubleRectMatrix(UNSIGNED aNumData,UNSIGNED aNumRow,BYTEPTR aName)
	:DoubleArray(aNumData,aName),NumData(aNumData),NumRow(aNumRow+1) 
	{Column=new IntArray(aNumData);Row=new IntArray(aNumRow+1);
	(*Row)(aNumRow+1)=aNumData+1;}
  
    ~DoubleRectMatrix(VOID);
  
// Methods for Rect-Matrix
    VOID	Delete(DoubleRectMatrix *aMatrix);
    DoubleRectMatrix& operator=(DoubleRectMatrix& aDoubleCompMatrix);
    DoubleRectMatrix& operator=(DOUBLE aNumber);
    DOUBLE& operator()(UNSIGNED aRow,UNSIGNED aCol);
    DOUBLE&	SetElement(UNSIGNED DiagPos,UNSIGNED DiagVal,UNSIGNED ColPos,
			   UNSIGNED ColVal,UNSIGNED DataPos);
    UNSIGNED& Col(UNSIGNED aPos);
    UNSIGNED& Diag(UNSIGNED aPos);
    DOUBLE&   Data(UNSIGNED aPos);
    UNSIGNED GetNumRow();
    UNSIGNED GetNumData();
    DoubleVector& VectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect);
// a1*A*aSrcVect+a2*aDestVect=aDestVect
    DoubleVector& VectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect,
			   DOUBLE a1,DOUBLE a2);
// a1*A+a2*M=A
    DoubleRectMatrix& AddMultConst(DoubleRectMatrix& aMatrix,
				   DOUBLE a1,DOUBLE a2);
  
    friend Output& operator<<(Output& o,DoubleRectMatrix& aMatrix);
};	

inline UNSIGNED DoubleRectMatrix::GetNumRow()
{
    return NumRow-1;
}

inline UNSIGNED DoubleRectMatrix::GetNumData()
{
    return NumData-1;
}

inline UNSIGNED& DoubleRectMatrix::Col(UNSIGNED aPos)
{
#ifdef DEBUG
    if(aPos<1 || aPos>NumData) {
	Err<<"WRONG ACCESS TO DOUBLECOMPACTMATRIX !! Name:"<<GetName()<<"\n";
	exit(1);
    }
#endif
    return (UNSIGNED&)((*Column)(aPos));
}

inline UNSIGNED& DoubleRectMatrix::Diag(UNSIGNED aPos)
{
#ifdef DEBUG
    if(aPos<1 || aPos>NumRow) {
	Err<<"WRONG ACCESS TO DOUBLERECTMATRIX !! Name:"<<GetName()<<"\n";
	exit(1);
    }
#endif
    return (UNSIGNED&)((*Row)(aPos));
}

inline DOUBLE& DoubleRectMatrix::Data(UNSIGNED aPos)
{
#ifdef DEBUG
    if(aPos<1 || aPos>NumData) {
	Err<<"WRONG ACCESS TO DOUBLERECTMATRIX !! Name:"<<GetName()<<"\n";
	exit(1);
    }
#endif
    return ((DoubleArray&)(*this))(aPos);
}


#endif
