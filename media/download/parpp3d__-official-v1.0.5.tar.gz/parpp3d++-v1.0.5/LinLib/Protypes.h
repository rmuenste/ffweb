#ifndef PROTYPESH

#define PROTYPESH

#include "IntArray.h"
#include "RealArray.h"
#include "DoubleArray.h"
#include "IntVector.h"
#include "RealVector.h"
#include "DoubleVector.h"

// **********  IntVector-Protypes ************

extern VOID VecAdd(IntVector& ,IntVector& ,IntVector& );
extern VOID VecAdd(IntVector& ,RealVector& ,IntVector& );
extern VOID VecAdd(IntVector& ,IntVector& ,RealVector& );
extern VOID VecAdd(IntVector& ,DoubleVector& ,IntVector& );
extern VOID VecAdd(IntVector& ,IntVector& ,DoubleVector& );
extern VOID VecAdd(IntVector& ,RealVector& ,DoubleVector& );
extern VOID VecAdd(IntVector& ,DoubleVector& ,RealVector& );
extern VOID VecSub(IntVector& ,IntVector& ,IntVector& );
extern VOID VecSub(IntVector& ,RealVector& ,IntVector& );
extern VOID VecSub(IntVector& ,IntVector& ,RealVector& );
extern VOID VecSub(IntVector& ,DoubleVector& ,IntVector& );
extern VOID VecSub(IntVector& ,IntVector& ,DoubleVector& );
extern VOID VecSub(IntVector& ,RealVector& ,DoubleVector& );
extern VOID VecSub(IntVector& ,DoubleVector& ,RealVector& );

// ************* RealVector-Protypes **************

extern VOID VecAdd(RealVector& ,RealVector& ,RealVector& );
extern VOID VecAdd(RealVector& ,RealVector& ,IntVector& );
extern VOID VecAdd(RealVector& ,IntVector& ,RealVector& );
extern VOID VecAdd(RealVector& ,DoubleVector& ,RealVector& );
extern VOID VecAdd(RealVector& ,RealVector& ,DoubleVector& );
extern VOID VecAdd(RealVector& ,IntVector& ,DoubleVector& );
extern VOID VecAdd(RealVector& ,DoubleVector& ,IntVector& );
extern VOID VecSub(RealVector& ,RealVector& ,RealVector& );
extern VOID VecSub(RealVector& ,RealVector& ,IntVector& );
extern VOID VecSub(RealVector& ,IntVector& ,RealVector& );
extern VOID VecSub(RealVector& ,DoubleVector& ,RealVector& );
extern VOID VecSub(RealVector& ,RealVector& ,DoubleVector& );
extern VOID VecSub(RealVector& ,IntVector& ,DoubleVector& );
extern VOID VecSub(RealVector& ,DoubleVector& ,IntVector& );

// ************* DoubleVector-Protypes **************

extern VOID VecAdd(DoubleVector& ,DoubleVector& ,DoubleVector& );
extern VOID VecAdd(DoubleVector& ,DoubleVector& ,IntVector& );
extern VOID VecAdd(DoubleVector& ,IntVector& ,DoubleVector& );
extern VOID VecAdd(DoubleVector& ,DoubleVector& ,RealVector& );
extern VOID VecAdd(DoubleVector& ,RealVector& ,DoubleVector& );
extern VOID VecAdd(DoubleVector& ,IntVector& ,RealVector& );
extern VOID VecAdd(DoubleVector& ,RealVector& ,IntVector& );
extern VOID VecSub(DoubleVector& ,DoubleVector& ,DoubleVector& );
extern VOID VecSub(DoubleVector& ,DoubleVector& ,IntVector& );
extern VOID VecSub(DoubleVector& ,IntVector& ,DoubleVector& );
extern VOID VecSub(DoubleVector& ,DoubleVector& ,RealVector& );
extern VOID VecSub(DoubleVector& ,RealVector& ,DoubleVector& );
extern VOID VecSub(DoubleVector& ,IntVector& ,RealVector& );
extern VOID VecSub(DoubleVector& ,RealVector& ,IntVector& );

#endif
