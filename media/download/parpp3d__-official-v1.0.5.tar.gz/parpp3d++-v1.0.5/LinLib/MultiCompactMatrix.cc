#include "MultiCompactMatrix.h"

MultiCompactMatrix::MultiCompactMatrix(unsigned int aNum)
{
    MatrixPtr=new DoubleCompactMatrix*[aNum];
    Num=aNum;
    for(INTEGER i=0;i<Num;i++)
	MatrixPtr[i]=0;
}

MultiCompactMatrix::MultiCompactMatrix(MultiCompactMatrix& aMatrix)
{
    Num=aMatrix.Num;
    MatrixPtr=new DoubleCompactMatrix*[Num];
    for(INTEGER i=0;i<Num;i++)
	if(aMatrix.MatrixPtr[i])
	    MatrixPtr[i]=new DoubleCompactMatrix(*(aMatrix.MatrixPtr[i]));
}

MultiCompactMatrix::~MultiCompactMatrix(VOID)
{
    for(INTEGER i=0;i<Num;i++)
	if(MatrixPtr[i])
	    delete MatrixPtr[i];
}

MultiCompactMatrix& MultiCompactMatrix::operator=(MultiCompactMatrix& aMatrix)
{
    Num=aMatrix.Num;
    for(INTEGER i=0;i<Num;i++)
	if(aMatrix.MatrixPtr[i])
	    *(MatrixPtr[i])=*(aMatrix.MatrixPtr[i]);
}

DoubleCompactMatrix*& MultiCompactMatrix::operator[](unsigned int aNum)
{
#ifdef DEBUG
    if(aNum < 1  ||  aNum > Num) {
	Err<<"MultiCompactMatrix: wrong access !!\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type MultiCompactMatrix.\n"
		 << "  Cause of error: ";
	if (aNum <= 0) {
	    protocol << "Trying to access array with too small row index: " << aNum << ".\n";
	} else {
	    protocol << "Trying to access array with too large row index: " << aNum << ". Maximum allowed: " << Num << ".\n";
	}
	protocol << "  Program aborted in MultiCompactMatrix::operator[].\n";
	exit(1);
    }
#endif
    return MatrixPtr[aNum-1];
}

MultiCompactMatrix& MultiCompactMatrix::operator=(DOUBLE aNumber)
{
    for(INTEGER i=0;i<Num;i++)
	*(MatrixPtr[i])=aNumber;
		
    return *this;
}

MultiCompactMatrix& MultiCompactMatrix::operator*=(DOUBLE aNumber)
{
    for(INTEGER i=0;i<Num;i++)
	*(MatrixPtr[i])*=aNumber;
		
    return *this;
}

//  MultiCompactMatrix& MultiCompactMatrix::operator=(MultiCompactMatrix& aMultiCompMatrix)
//  {
//  	for(INTEGER i=0;i<Num;i++)
//  		MatrixPtr[i]=new DoubleCompactMatrix(*(aMultiCompMatrix.MatrixPtr[i]));
		
//  	return *this;
//  }

MultiCompactMatrix& MultiCompactMatrix::operator+=(MultiCompactMatrix& aMultiCompMatrix)
{
    for(INTEGER i=0;i<Num;i++)
	*(MatrixPtr[i])+=*(aMultiCompMatrix.MatrixPtr[i]);
	
    return *this;
}

MultiCompactMatrix& MultiCompactMatrix::AddMultConst(MultiCompactMatrix& aMatrix,
						     DOUBLE a1,DOUBLE a2)
{
    for(INTEGER i=0;i<Num;i++)
	MatrixPtr[i]->AddMultConst(*(aMatrix.MatrixPtr[i]),a1,a2);
		
    return *this;
}

MultiCompactMatrix& MultiCompactMatrix::AddMultiVector(MultiVector& aVect)
{
    DoubleCompactMatrix *mat;
    DoubleVector        *vect;
    int index;

    for(INTEGER i=0;i<Num;i++) {
	mat=MatrixPtr[i];
	vect=aVect[i+1];

	for(index=1;index<=mat->GetNumDiag();index++)
	    mat->Data(mat->Diag(index))+=(*vect)(index);
    }
    
    return *this;
}
