#include "DoubleVector.h"
#include "Protypes.h"
#include <math.h>

DoubleVector::DoubleVector(unsigned int mySize)
{
    Name    = "DoubleVector";
    Len     = mySize;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index = 0; index < Len; index++) {
	aHandle[index] = 0;
    }
}

DoubleVector::DoubleVector(unsigned int mySize, BYTEPTR aName)
{
    Name    = aName;
    Len     = mySize;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index = 0; index < Len; index++)
	aHandle[index] = 0;
}

DoubleVector::DoubleVector(DoubleVector& anDoubleVector)
{
    unsigned int size = anDoubleVector.GetLen();

    Name    = anDoubleVector.Name;
    Len     = size;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index = 0; index < Len; index++)
	aHandle[index] = anDoubleVector.aHandle[index];
}

DoubleVector& DoubleVector::operator=(DoubleVector& aDoubleVector)
{
    unsigned int size = aDoubleVector.GetLen();

    if (GetLen() >= size) {
	for (unsigned int index = 0; index < size; index++) {
	    aHandle[index] = aDoubleVector.aHandle[index];
	    // This statement (with array checking) gives run-time error
	    // when compiled with Intel C Compiler 8.1 and optimisation
//	    (*this)(index) = aDoubleVector(index);
	}
    }
    return *this;
}

DoubleVector& DoubleVector::operator=(double aNumber)
{
    for (unsigned int index = 1; index<=GetLen(); index++) {
	(*this)(index)=aNumber;
    }
    return *this;
}

DoubleVector& operator+=(DoubleVector& a1,DoubleVector& a2)
{
    if(a1.GetLen()==a2.GetLen()) {
	for (unsigned int index = 1; index<=a1.GetLen(); index++)
	    a1(index)=a1(index)+a2(index);
    }
    return a1;
}

DoubleVector& operator-=(DoubleVector& a1,DoubleVector& a2)
{
    if(a1.GetLen()==a2.GetLen()) {
	for (unsigned int index = 1; index<=a1.GetLen(); index++)
	    a1(index)=a1(index)-a2(index);
    }
    return a1;
}

DoubleVector& operator *= (DoubleVector& a1, double aNumber)
{
    for (unsigned int index = 1; index <= a1.GetLen(); index++)
	a1(index) = a1(index) * aNumber; 
    return a1; 
}

Output& operator << (Output& o, DoubleVector& anDoubleVector)
{
    for (unsigned int index = 1; index <= anDoubleVector.GetLen(); index++)
    {
	o << "The value at index position " << index << "="; 
	o << anDoubleVector(index) << "\n"; 
    }
    return o; 
}

DoubleVector& DoubleVector::AddMultConst(DoubleVector& aDoubleVector, double aNumber)
{
    if (GetLen() == aDoubleVector.GetLen()) {
	for (unsigned int index = 1; index <= GetLen(); index++)
	    (*this)(index) += (aNumber * aDoubleVector(index)); 
    }
    return *this; 
}

double operator * (DoubleVector& v1, DoubleVector& v2)
{
    double temp = 0; 

    if (v1.GetLen() != v2.GetLen()) {
// ********** Error : different vectors **********
	Err << "DoubleVector: different vectors !!  Name:" << v1.GetName() << "\n"; 
	exit(1); 
    }

    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	temp += v1(index) * v2(index); 

    return temp; 
}

double DoubleVector::l2Norm(void)
{
    double temp = 0; 

    for (unsigned int index = 1; index <= Len; index++)
	temp += (*this)(index) * (*this)(index); 
    if (temp > 0)
	return sqrt(temp); 

    return 0; 
}

double DoubleVector::MaxNorm(void)
{
    double MaxValue = ABS((*this)(1)); 

    for (unsigned int index = 2; index <= GetLen(); index++)
	if (ABS((*this)(index)) > MaxValue)
	    MaxValue = ABS((*this)(index)); 

    return MaxValue; 
}

double DoubleVector::MaxNorm(unsigned int& MaxIndex)
{
    double MaxValue = ABS((*this)(1)); 

    MaxIndex = 1; 
    for (unsigned int index =2; index <= GetLen(); index++) {
	if (ABS((*this)(index)) > MaxValue) {
	    MaxValue = ABS((*this)(index)); 
	    MaxIndex = index; 
	}
    }

    return MaxValue; 
}


// Vector addition  v1=v2+v3
void VecAdd(DoubleVector& v1,DoubleVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = v2(index) + v3(index);
}

void VecAdd(DoubleVector& v1,IntVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) + v3(index));
}

void VecAdd(DoubleVector& v1,DoubleVector& v2,IntVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) + v3(index));
}

void VecAdd(DoubleVector& v1,DoubleVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) + v3(index));
}

void VecAdd(DoubleVector& v1,RealVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) + v3(index));
}

void VecAdd(DoubleVector& v1,IntVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) + v3(index));
}

void VecAdd(DoubleVector& v1,RealVector& v2,IntVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) + v3(index));
}

// Vector substraction  v1=v2-v3
void VecSub(DoubleVector& v1,DoubleVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = v2(index) - v3(index);
}

void VecSub(DoubleVector& v1,DoubleVector& v2,IntVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) - v3(index));
}

void VecSub(DoubleVector& v1,IntVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) - v3(index));
}

void VecSub(DoubleVector& v1,DoubleVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) - v3(index));
}

void VecSub(DoubleVector& v1,RealVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) - v3(index));
}

void VecSub(DoubleVector& v1,IntVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) - v3(index));
}

void VecSub(DoubleVector& v1,RealVector& v2,IntVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index) = (double)(v2(index) - v3(index));
}

void DoubleVector::memtest(double *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for DoubleVector (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
