#ifndef REALARRAY2DH

#define REALARRAY2DH

#include <stdlib.h>
#include "MyTypes.h"
#include "Global.h"

class RealArray2D
{
private:
    REAL *aHandle;
    UNSIGNED Len;
    BYTEPTR Name;

    unsigned int Rows;
    unsigned int Cols;
    std::string  message;			  // Will act as "composer" for error messages
                                                  // This speeds up compilation with templates and
                                                  // reduces code. (No need to write code both for STD_CERR and protocol)

public:
    RealArray2D(UNSIGNED myRows,UNSIGNED myCols);
    RealArray2D(UNSIGNED myRows,UNSIGNED myCols,BYTEPTR aName);
    RealArray2D(RealArray2D& anRealArray2D);
    ~RealArray2D(VOID) {delete[] aHandle;}

    REAL& operator()(unsigned int row, unsigned int col) {
#ifdef DEBUG
        if (row < 1  ||  row > Rows  ||  col < 1  ||  col > Cols) {
            message
                = "pp3d++ (process " + int_to_string(MyProcID, 0) + "):\n"
                + "  Unrecoverable error discovered:\n"
                + "    Wrong access to an object of type RealArray2D with name" + GetName() + ":\n";

            if (row < 1) {
                message += "    Trying to access array with too small row index: " + int_to_string(row) + ".\n";
            } else if (row > Rows) {
                message += "    Trying to access array with too large row index: " + int_to_string(row)
                         + ". Maximum allowed: " + int_to_string(Rows) + ".\n";
            } else if (col < 1) {
                message += "    Trying to access array with too small col index: " + int_to_string(col) + ".\n";
            } else if (col > Cols) {
                message += "    Trying to access array with too large col index: " + int_to_string(col)
                         + ". Maximum allowed: " + int_to_string(Cols) + ".\n";
            }

            STD_CERR << message;
            protocol  << message;

            exit(ARRAY_LIMIT_ERROR);
        }
#endif
            return aHandle[(row-1)*Cols+col-1];
        }

    UNSIGNED    GetLen(VOID) {return Len;}
    BYTEPTR     GetName(VOID) {return Name;}
    UNSIGNED    GetRows(VOID) {return Rows;}
    UNSIGNED    GetCols(VOID) {return Cols;}

    void         memtest(float *aHandle, unsigned int bytesRequested);

    RealArray2D& operator=(RealArray2D& aRealArray2D);
    RealArray2D& operator=(REAL aNumber);
// Array addition  a1+=a2
    friend RealArray2D& operator+=(RealArray2D& a1,RealArray2D& a2);
// Array substraction a1-=a2
    friend RealArray2D& operator-=(RealArray2D& a1,RealArray2D& a2);
// Scales a Array by a constant  a1=aNumber*a1
    friend RealArray2D& operator*=(RealArray2D& v1,REAL aNumber);

    friend Output& operator<<(Output& o,RealArray2D& anRealArray2D);
};


#endif
