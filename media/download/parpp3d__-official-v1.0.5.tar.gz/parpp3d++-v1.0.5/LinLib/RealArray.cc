#include "RealArray.h"
#include "Protypes.h"
#include "Global.h"

RealArray::RealArray(unsigned int mySize)
{
    Name    = "RealArray";
    Len     = mySize;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index = 0; index < mySize; index++)
	aHandle[index]=0;
}

RealArray::RealArray(unsigned int mySize,BYTEPTR aName)
{
    Name    = aName;
    Len     = mySize;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index = 0; index < mySize; index++)
	aHandle[index]=0;
}

RealArray::RealArray(RealArray& anRealArray)
{
    unsigned int size=anRealArray.GetLen();

    Name    = anRealArray.Name;
    Len     = size;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index = 0; index < size; index++)
	aHandle[index] = anRealArray.aHandle[index];
}

RealArray& RealArray::operator=(RealArray& aRealArray)
{
    unsigned int size=aRealArray.GetLen();

    if(GetLen()>=size) {
	for (unsigned int index =1;index<=size;index++)
	    (*this)(index)=aRealArray(index);
    }
    return *this;
}

RealArray& RealArray::operator=(REAL aNumber)
{
    for (unsigned int index =1;index<=GetLen();index++) {
	(*this)(index)=aNumber;
    }
    return *this;
}

RealArray& operator+=(RealArray& a1,RealArray& a2)
{
    for (unsigned int index =1;index<=a1.GetLen();index++)
	a1(index)=a1(index)+a2(index);
    return a1;
}

RealArray& operator-=(RealArray& a1,RealArray& a2)
{
    for (unsigned int index =1;index<=a1.GetLen();index++)
	a1(index)=a1(index)-a2(index);
    return a1;
}

RealArray& operator*=(RealArray& a1,REAL aNumber)
{
    for (unsigned int index =1;index<=a1.GetLen();index++)
	a1(index)=a1(index)*aNumber;
    return a1;
}

Output& operator<<(Output& o,RealArray& aRealArray)
{
    for (unsigned int index =1;index<=aRealArray.GetLen();index++)
    {
	o<<"The value at index position "<<index<<"=";
	o<<aRealArray(index)<<"\n";
    }
    return o;
}

void RealArray::memtest(float *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for RealArray (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
