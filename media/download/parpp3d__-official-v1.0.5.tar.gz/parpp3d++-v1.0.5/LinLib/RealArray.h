#ifndef REALARRAYH

#define REALARRAYH

//#include <stdlib.h>
#include "MyTypes.h"
#include "Global.h"

class RealArray
{
private:
    REAL *aHandle;
    UNSIGNED Len;
    BYTEPTR     Name;
    std::string  message;			  // Will act as "composer" for error messages
                                                  // This speeds up compilation with templates and
                                                  // reduces code. (No need to write code both for STD_CERR and protocol)

public:
    RealArray(UNSIGNED mySize);
    RealArray(UNSIGNED mySize,BYTEPTR aName);
    RealArray(RealArray& anRealArray);
    ~RealArray(VOID) {delete[] aHandle;}

    REAL& operator()(UNSIGNED index) {
#ifdef DEBUG
        if (index < 1  ||  index > GetLen()) {
            message
                = "pp3d++ (process " + int_to_string(MyProcID, 0) + "):\n"
                + "  Unrecoverable error discovered:\n"
                + "    Wrong access to an object of type RealArray with name" + GetName() + ":\n";

            if (index < 1) {
                message += "    Trying to access array with too small row index: " + int_to_string(index) + ".\n";
            } else if (index > GetLen()) {
                message += "    Trying to access array with too large row index: " + int_to_string(index)
                         + ". Maximum allowed: " + int_to_string(GetLen()) + ".\n";
            }

            STD_CERR << message;
            protocol  << message;

            exit(ARRAY_LIMIT_ERROR);
        }
#endif
            return aHandle[index-1];
        }

    unsigned int GetLen(VOID)  { return Len;}
    BYTEPTR      GetName(VOID) {return Name;}

    void memtest(float *aHandle, unsigned int bytesRequested);

    RealArray& operator=(RealArray& aRealArray);
    RealArray& operator=(REAL aNumber);
// Array addition  a1+=a2
    friend RealArray& operator+=(RealArray& a1,RealArray& a2);
// Array substraction a1-=a2
    friend RealArray& operator-=(RealArray& a1,RealArray& a2);
// Scales an Array by a constant  a1=aNumber*a1
    friend RealArray& operator*=(RealArray& a1,REAL aNumber);

    friend Output& operator<<(Output& o,RealArray& anRealArray);
};


#endif
