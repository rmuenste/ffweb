#include "IntArray3D.h"

IntArray3D::IntArray3D(unsigned int myDimX,unsigned int myDimY,unsigned int myDimZ)
{
    Name    = "IntArray3D";
    Len     = myDimX * myDimY * myDimZ;
    DimX    = myDimX;
    DimY    = myDimY;
    DimZ    = myDimZ;
    aHandle = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for (unsigned int index =0;index<Len;index++)
	aHandle[index]=0;
}

IntArray3D::IntArray3D(unsigned int myDimX,unsigned int myDimY,unsigned int myDimZ,BYTEPTR aName)
{
    Name    = aName;
    Len     = myDimX * myDimY * myDimZ;
    DimX    = myDimX;
    DimY    = myDimY;
    DimZ    = myDimZ;
    aHandle = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for (unsigned int index =0;index<Len;index++)
	aHandle[index]=0;
}

IntArray3D::IntArray3D(IntArray3D& anIntArray3D)
{
    unsigned int size=anIntArray3D.GetLen();

    Name    = anIntArray3D.Name;
    Len     = size;
    DimX    = anIntArray3D.GetDimX();
    DimY    = anIntArray3D.GetDimY();
    DimZ    = anIntArray3D.GetDimZ();
    aHandle = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for (unsigned int x = 1;x<=DimX;x++)
	for (unsigned int y = 1;y<=DimY;y++)
	    for (unsigned int z = 1;z<=DimZ;z++)
		(*this)(x,y,z)=anIntArray3D(x,y,z);
}

IntArray3D& IntArray3D::operator=(IntArray3D& anIntArray3D)
{
    if(anIntArray3D.DimX<=DimX && anIntArray3D.DimY<=DimY && anIntArray3D.DimZ<=DimZ)
    {
	for (unsigned int x = 1;x<=anIntArray3D.DimX;x++)
	    for (unsigned int y = 1;y<=anIntArray3D.DimY;y++)
		for (unsigned int z = 1;z<=anIntArray3D.DimZ;z++)
		    (*this)(x,y,z)=anIntArray3D(x,y,z);
    }
    return *this;
}

IntArray3D& IntArray3D::operator=(INTEGER aNumber)
{
    for (unsigned int x = 1;x<=DimX;x++)
	for (unsigned int y = 1;y<=DimY;y++)
	    for (unsigned int z = 1;z<=DimZ;z++)
		(*this)(x,y,z)=aNumber;
    return *this;
}

IntArray3D& operator+=(IntArray3D& a1,IntArray3D& a2)
{
    if(a1.DimX==a2.DimX && a1.DimY==a2.DimY && a1.DimZ==a2.DimZ) {
	for (unsigned int x = 1;x<=a1.DimX;x++)
	    for (unsigned int y = 1;y<=a1.DimY;y++)
		for (unsigned int z = 1;z<=a1.DimZ;z++)
		    a1(x,y,z)=a1(x,y,z)+a2(x,y,z);
    }
    return a1;
}

IntArray3D& operator-=(IntArray3D& a1,IntArray3D& a2)
{
    if(a1.DimX==a2.DimX && a1.DimY==a2.DimY && a1.DimZ==a2.DimZ) {
	for (unsigned int x = 1;x<=a1.DimX;x++)
	    for (unsigned int y = 1;y<=a1.DimY;y++)
		for (unsigned int z = 1;z<=a1.DimZ;z++)
		    a1(x,y,z)=a1(x,y,z)-a2(x,y,z);
    }
    return a1;
}

IntArray3D& operator*=(IntArray3D& a1,INTEGER aNumber)
{
    for (unsigned int x = 1;x<=a1.DimX;x++)
	for (unsigned int y = 1;y<=a1.DimY;y++)
	    for (unsigned int z = 1;z<=a1.DimZ;z++)
		a1(x,y,z)=a1(x,y,z)*aNumber;
    return a1;
}

Output& operator<<(Output& o,IntArray3D& anIntArray3D)
{
    for (unsigned int x = 1;x<=anIntArray3D.DimX;x++)
    {
	for (unsigned int y = 1;y<=anIntArray3D.DimY;y++) {
	    for (unsigned int z = 1;z<=anIntArray3D.DimZ;z++) {
		o<<"The value in ( "<<x<<","<<y<<","<<z<<")  = ";
		o<<anIntArray3D(x,y,z)<<"\n";
	    }
	}
    }
    return o;
}

void IntArray3D::memtest(int *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for IntArray3D (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
