#ifndef MULTIVECTORH

#define MULTIVECTORH

#include "DoubleVector.h"

class MultiVector
{
private:
    DoubleVector **VectorPtr;
    UNSIGNED Num;
		
public:
    MultiVector(UNSIGNED aNum);
  
    ~MultiVector(VOID);
  
// Methods for MultiCompact-Matrix
    MultiVector& operator=(MultiVector& aMultiVector);
    MultiVector& operator+=(MultiVector& aMultiVector);
    MultiVector& operator=(DOUBLE aNumber);
    DoubleVector*& operator[](UNSIGNED aNum);
  
};	

#endif
