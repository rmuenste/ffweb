#include "IntArray2D.h"
#include "Protypes.h"
#include "Global.h"

IntArray2D::IntArray2D(unsigned int myRows,unsigned int myCols)
{
    Name    = "IntArray2D";
    Len     = myRows*myCols;
    Rows    = myRows;
    Cols    = myCols;
    aHandle = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for (unsigned int index =0; index < Len; index++)
	aHandle[index]=0;
}

IntArray2D::IntArray2D(unsigned int myRows,unsigned int myCols,BYTEPTR aName)
{
    Name    = aName;
    Len     = myRows * myCols;
    Rows    = myRows;
    Cols    = myCols;
    aHandle = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for (unsigned int index =0;index<Len;index++)
	aHandle[index]=0;
}

IntArray2D::IntArray2D(IntArray2D& anIntArray2D)
{
    unsigned int size=anIntArray2D.GetLen();

    Name    = anIntArray2D.Name;
    Len     = size;
    Rows    = anIntArray2D.GetRows();
    Cols    = anIntArray2D.GetCols();
    aHandle  =new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for (unsigned int row = 1; row <= Rows; row++)
	for (unsigned int col = 1; col <= Cols; col++)
	    (*this)(row,col) = anIntArray2D(row,col);
}

IntArray2D& IntArray2D::operator=(IntArray2D& anIntArray2D)
{
//  unsigned int size=anIntArray2D.GetLen();

    if (anIntArray2D.Rows <= Rows  &&  anIntArray2D.Cols <= Cols) {
	for (unsigned int row = 1; row <= anIntArray2D.Rows; row++)
	    for (unsigned int col = 1; col <= anIntArray2D.Cols; col++)
		(*this)(row,col)=anIntArray2D(row,col);
    }
    return *this;
}

IntArray2D& IntArray2D::operator=(INTEGER aNumber)
{
    for (unsigned int row = 1; row <= Rows; row++)
	for (unsigned int col = 1; col <= Cols; col++)
	    (*this)(row,col)=aNumber;
    return *this;
}

IntArray2D& operator+=(IntArray2D& a1,IntArray2D& a2)
{
    if(a1.Rows==a2.Rows && a1.Cols==a2.Cols) {
	for (unsigned int row = 1;row<=a1.Rows;row++)
	    for (unsigned int col = 1;col<=a1.Cols;col++)
		a1(row,col)=a1(row,col)+a2(row,col);
    }
    return a1;
}

IntArray2D& operator-=(IntArray2D& a1,IntArray2D& a2)
{
    if(a1.Rows==a2.Rows && a1.Cols==a2.Cols) {
	for (unsigned int row = 1;row<=a1.Rows;row++)
	    for (unsigned int col = 1;col<=a1.Cols;col++)
		a1(row,col)=a1(row,col)-a2(row,col);
    }
    return a1;
}

IntArray2D& operator*=(IntArray2D& a1,INTEGER aNumber)
{
    for (unsigned int row = 1;row<=a1.Rows;row++)
	for (unsigned int col = 1;col<=a1.Cols;col++)
	    a1(row,col)=a1(row,col)*aNumber;
    return a1;
}

Output& operator<<(Output& o,IntArray2D& anIntArray2D)
{
    for (unsigned int row = 1;row<=anIntArray2D.Rows;row++)
    {
	for (unsigned int col = 1;col<=anIntArray2D.Cols;col++) {
	    o<<"The value in row "<<row<<" col "<<col<<" = ";
	    o<<anIntArray2D(row,col)<<"\n";
	}
    }
    return o;
}

void IntArray2D::memtest(int *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for IntArray2D (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
