#include "RealCompactMatrix.h"

RealCompactMatrix::~RealCompactMatrix(VOID)
{
    if(Diagonal!=(IntArray*)0)
	delete Diagonal;
    if(Column!=(IntArray*)0)
	delete Column;
}

RealCompactMatrix& RealCompactMatrix::operator=(RealCompactMatrix& aRealCompMatrix)
{
    if(aRealCompMatrix.NumData==NumData && aRealCompMatrix.NumDiag==NumDiag)
    {
	unsigned int index;
	for(index=1;index<=NumData;index++)
	    (*this).Data(index)=aRealCompMatrix.Data(index);
	for(index=1;index<=NumDiag;index++)
	    (*Diagonal)(index)=(*aRealCompMatrix.Diagonal)(index);
	for(index=1;index<=NumData;index++)
	    (*Column)(index)=(*aRealCompMatrix.Column)(index);
    }
    return *this;
}

RealCompactMatrix& RealCompactMatrix::operator=(REAL aNumber)
{
    for (unsigned int index =1;index<=NumData;index++)
	(*this).Data(index)=aNumber;
		
    return *this;
}

REAL& RealCompactMatrix::operator()(unsigned int aRow,unsigned int aCol)
{
    unsigned int end;
	
    if(aRow > 0  &&  aRow <= GetNumDiag()) {
        end = (*Diagonal)(aRow+1) - 1;
        for (unsigned int index = (*Diagonal)(aRow); index <= end; index++) {
            if ((*Column)(index) == aCol)
		return (*this).Data(index);
        }

#ifdef DEBUG
	// If we did not find the requested column, we have an illegal access
        Err<<"RealCompactMatrix: wrong access !!   Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type RealCompactMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: "
		 << "  Trying to access array with pair (" << aRow << "," << aCol << ").\n"
		 << "  Program aborted in RealCompactMatrix::operator().\n";
#endif
        exit(1);
    } else {
	// Array access out of bound
#ifdef DEBUG
        Err<<"RealCompactMatrix: wrong access !!   Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type DoubleCompactMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: ";
	if (aRow <= 0) {
	    protocol << "Trying to access array with too small row index: " << aRow << ".\n";
	} else {
	    protocol << "Trying to access array with too large row index: " << aRow << ". Maximum allowed: " << GetNumDiag() << ".\n";
	}
	protocol << "  Program aborted in DoubleCompactMatrix::operator().\n";
#endif
        exit(1);
    }
}

REAL& RealCompactMatrix::SetElement(unsigned int DiagPos, unsigned int DiagVal,
				    unsigned int ColPos,  unsigned int ColVal, unsigned int DataPos)
{
    if (DiagPos >= 1  &&  DiagPos <= NumDiag) {
	(*Diagonal)(DiagPos) = DiagVal;
    } else {
#ifdef DEBUG
        Err<<"RealCompactMatrix: wrong access (SetElement)!!   Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type RealCompactMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: ";
	if (DiagPos < 1) {
	    protocol << "Trying to access array with too small diag index: " << DiagPos << ".\n";
	} else {
	    protocol << "Trying to access array with too large diag index: " << DiagPos << ". Maximum allowed: " << NumDiag << ".\n";
	}
	protocol << "  Program aborted in RealCompactMatrix::SetElement.\n";
#endif
        exit(1);
    }

    if (ColPos >= 1  &&  ColPos <= NumData) {
	(*Column)(ColPos) = ColVal;
    } else {
#ifdef DEBUG
        Err<<"RealCompactMatrix: wrong access (SetElement)!!   Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type RealCompactMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: ";
	if (ColPos < 1) {
	    protocol << "Trying to access array with too small col index: " << ColPos << ".\n";
	} else {
	    protocol << "Trying to access array with too large col index: " << ColPos << ". Maximum allowed: " << NumData << ".\n";
	}
	protocol << "  Program aborted in RealCompactMatrix::SetElement.\n";
#endif
        exit(1);
    }

    if (DataPos >= 1  &&  DataPos <= NumData)
	return (*this).Data(DataPos);
    else {
#ifdef DEBUG
        Err<<"RealCompactMatrix: wrong access (SetElement)!!   Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type RealCompactMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: ";
	if (DataPos < 1) {
	    protocol << "Trying to access array with too small diag index: " << DataPos << ".\n";
	} else {
	    protocol << "Trying to access array with too large diag index: " << DataPos << ". Maximum allowed: " << NumData << ".\n";
	}
	protocol << "  Program aborted in RealCompactMatrix::SetElement.\n";
#endif
        exit(1);
    }
}

RealVector& RealCompactMatrix::VectMult(RealVector& aSrcVect,RealVector& aDestVect)
// Compute aDestVect = thisMatrix * aSrcVect
{
    if(aSrcVect.GetLen()==GetNumDiag() && aDestVect.GetLen()==GetNumDiag()) {
	unsigned int index;
	for(index=1;index<=GetNumDiag();index++)
	    aDestVect(index)=aSrcVect(index)*(*this).Data((*Diagonal)(index));
	for(index=1;index<=GetNumDiag();index++) {
	    for(INTEGER index2=(*Diagonal)(index)+1;index2<=(*Diagonal)(index+1)-1;index2++) {
		aDestVect(index)+=((*this).Data(index2)*aSrcVect((*Column)(index2)));
	    }
	}
    }

    return aDestVect;
}

Output& operator<<(Output& o,RealCompactMatrix& aMatrix)
{
    unsigned int end;
	
    for (unsigned int row = 1;row<=aMatrix.GetNumDiag();row++)
    {
	end=(*aMatrix.Diagonal)(row+1)-1;
	for (unsigned int col = (*aMatrix.Diagonal)(row);col<=end;col++)
	{
	    o<<"The value at row "<<row<<" ,column "<<(*aMatrix.Column)(col)<<" = ";
	    o<<aMatrix.Data(col)<<"\n";
	}
    }
    return o;
}

RealVector& RealCompactMatrix::Jacobi(RealVector& x,RealVector& b,unsigned int Nit,DOUBLE Eps,DOUBLE Omega)
{	
    RealVector	CVector(b.GetLen());
    INTEGER ITE,IEQ,ICOL;
    REAL Dm1,Dm2,MaxNorm;
	
    CVector=b;
    Prot<<"Diag(1)="<<(*Diagonal)(1)<<"\n";
    if(GetNumDiag()!=x.GetLen() || x.GetLen()!=b.GetLen())
	return x;
		
    ProtAdd<<"Jacobi-Iteration\n";
    MaxNorm=b.MaxNorm();
    // MaxNorm==0
    if(fabs(MaxNorm - 0.0) < FLOAT_EPS) {
	b=0;
	Prot<<"Warning zero right hand side !!\n";
	return x;
    }
	
    for(ITE=1;ITE<=Nit;ITE++) {
	Dm1=Dm2=0;
	CVector=b;
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    Prot<<CVector;
	    Prot<<"Diag(2)="<<Diag(1)<<"\n";
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		CVector(IEQ)-=(Data(ICOL)*x(Col(ICOL)));
	    }
	}
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    CVector(IEQ)=(REAL)((1-Omega)*x(IEQ)+(Omega*CVector(IEQ)/Data(Diag(IEQ))));
	    Dm1=MAX(Dm1,fabs(CVector(IEQ)-x(IEQ)));
	    Dm2=MAX(Dm2,fabs(CVector(IEQ)));
	    x(IEQ)=CVector(IEQ);
	}
	if(Dm1<=Eps*Dm2) {
	    Prot<<"  Iteration "<<ITE<<" Jacobi    Maximum of Correction = "<<Dm1/Dm2<<"\n";
	    return x;
	}
	ProtAdd<<"  Iteration "<<ITE<<"  Jacobi    !! CORR!! = "<<Dm1/Dm2<<"\n";
    }
    Prot<<"Iteration "<<ITE<<"  Jacobi    !! CORR!! = "<<Dm1/Dm2<<"\n";
    return x;
}

RealVector& RealCompactMatrix::GaussSeidel(RealVector& x,RealVector& b,unsigned int Nit,DOUBLE Eps)
{
    INTEGER ITE,IEQ,ICOL;
    REAL Dm1,Dm2,Aux,MaxNorm;
	
    if(GetNumDiag()!=x.GetLen() || x.GetLen()!=b.GetLen())
	return x;
		
    ProtAdd<<"Gau�-Seidel-Iteration\n";	
    MaxNorm=b.MaxNorm();
    // MaxNorm==0
    if(fabs(MaxNorm - 0.0) < FLOAT_EPS) {
	b=0;
	Prot<<"Warning zero right hand side !!\n";
	return x;
    }
	
    for(ITE=1;ITE<=Nit;ITE++) {
	Dm1=Dm2=0;
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    Aux=b(IEQ);
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		Aux-=(Data(ICOL)*x(Col(ICOL)));
	    }
	    Aux/=Data(Diag(IEQ));
	    Dm1=MAX(Dm1,fabs(Aux-x(IEQ)));
	    Dm2=MAX(Dm2,fabs(Aux));
	    x(IEQ)=(REAL)Aux;
	}
	if(Dm1<=Eps*Dm2) {
	    Prot<<"  Iteration "<<ITE<<" Gau�-Seidel    Maximum of Correction = "<<Dm1/Dm2<<"\n";
	    return x;
	}
	ProtAdd<<"  Iteration "<<ITE<<"  Gau�-Seidel    !! CORR!! = "<<Dm1/Dm2<<"\n";
    }
    Prot<<"Iteration "<<ITE<<"  Gau�-Seidel    !! CORR!! = "<<Dm1/Dm2<<"\n";
    Prot<<"Iteration "<<ITE<<" Gau�-Seidel    Maximum of Correction = "<<Dm1/Dm2<<"\n";
    return x;
}

RealVector& RealCompactMatrix::SOR(RealVector& x,RealVector& b,unsigned int Nit,DOUBLE Eps,DOUBLE Omega)
{
    INTEGER ITE,IEQ,ICOL;
    REAL Dm1,Dm2,Aux,MaxNorm;
	
    if(GetNumDiag()!=x.GetLen() || x.GetLen()!=b.GetLen())
	return x;
		
    ProtAdd<<"SOR-Iteration\n";	
    MaxNorm=b.MaxNorm();
    // MaxNorm==0
    if(fabs(MaxNorm - 0.0) < FLOAT_EPS) {
	b=0;
	Prot<<"Warning zero right hand side !!\n";
	return x;
    }
	
    for(ITE=1;ITE<=Nit;ITE++) {
	Dm1=Dm2=0;
	for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	    Aux=b(IEQ);
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
		Aux-=(Data(ICOL)*x(Col(ICOL)));
	    }
	    Aux=Omega*(Aux/Data(Diag(IEQ))-x(IEQ))+x(IEQ);
	    Dm1=MAX(Dm1,fabs(Aux-x(IEQ)));
	    Dm2=MAX(Dm2,fabs(Aux));
	    x(IEQ)=(REAL)Aux;
	}
	if(Dm1<=Eps*Dm2) {
	    Prot<<"  Iteration "<<ITE<<" SOR    Maximum of Correction = "<<Dm1/Dm2<<"\n";
	    return x;
	}
	ProtAdd<<"  Iteration "<<ITE<<"  SOR    !! CORR!! = "<<Dm1/Dm2<<"\n";
    }
    Prot<<"Iteration "<<ITE<<"  SOR    !! CORR!! = "<<Dm1/Dm2<<"\n";
    Prot<<"Iteration "<<ITE<<"  SOR    Maximum of Correction = "<<Dm1/Dm2<<"\n";
    return x;
}

RealVector& RealCompactMatrix::PrecondSOR(RealVector& x,DOUBLE Omega)
{
    INTEGER IEQ,ICOL,ILD;
    REAL Aux;
	
    if(GetNumDiag()!=x.GetLen())
	return x;
			
    ProtAdd<<"PrecondSOR !!\n";
	
    for(IEQ=1;IEQ<=GetNumDiag();IEQ++) {
	Aux=0;
	ILD=Diag(IEQ);
	for(ICOL=ILD+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    if(Col(ICOL)>=IEQ)
		break;
	    else
		Aux+=(Data(ICOL)*x(Col(ICOL)));
	}
	x(IEQ)=(x(IEQ)-Aux*Omega)/Data(ILD);
    }
    for(IEQ=GetNumDiag()-1;IEQ>=1;IEQ--) {
	Aux=0;
	ILD=Diag(IEQ);
	for(ICOL=ILD+1;ICOL<=Diag(IEQ+1)-1;ICOL++) {
	    if(Col(ICOL)>IEQ)
		Aux+=(Data(ICOL)*x(Col(ICOL)));
	}
	x(IEQ)=(x(IEQ)-Aux*Omega)/Data(ILD);
    }
    return x;
}

VOID RealCompactMatrix::ILU(INTEGER ILU,DOUBLE Alpha,DOUBLE Tol)
{
    INTEGER BMILU,ICOL,ILD,IEQ,NEQ,JCOL,JLD,IP,JC,JCOLO;
    DOUBLE A,AIJ;
    DOUBLE	Alpha1;
	
    ProtAdd<<"ILU-Decomposition !!\n";
	
    NEQ=GetNumDiag();
    if(ILU==1) {
// Constant shift for ILU
	Alpha1=1/(1+Alpha);
	for(IEQ=1;IEQ<=NEQ;IEQ++) 
	    for(ICOL=Diag(IEQ)+1;ICOL<=Diag(IEQ+1)-1;ICOL++)
		Data(ICOL)*=Alpha1;
    } else {
// Constant shift for MILU
	Alpha1=1+Alpha;
	for(IEQ=1;IEQ<=NEQ;IEQ++) {
	    ILD=Diag(IEQ);
	    Data(ILD)*=Alpha1;
	}
    }
    BMILU=(ILU==2);
    ILD=1;
//Incomplete GAUSS elimination
    for(IEQ=2;IEQ<=NEQ;IEQ++) {
	A=Data(ILD);
	if(fabs(A)<Tol) 
	    Data(ILD)=SIGN(Tol,A);
	ILD=Diag(IEQ);
	if(Col(ILD+1)<IEQ) {
	    for(JCOL=ILD+1;JCOL<=Diag(IEQ+1)-1;JCOL++) {
		ICOL=Col(JCOL);
		if(ICOL>=IEQ)
		    break;
		JLD=Diag(ICOL);
		AIJ=Data(JCOL)/Data(JLD);
// AIJ is the entry of the elimination matrix at (IEQ,ICOL)
		Data(JCOL)=AIJ;
		IP=Diag(IEQ+1)-1;
		if(BMILU) {
// Modified incomplete LU decomposition
// Loop over subdiagonal entries in line ICOL
		    for(JC=Diag(ICOL+1)-1;JC>=JLD;JC--) {
			JCOLO=Col(JC);
			if((JCOLO-IEQ)<0) {
			    if(JCOLO<=ICOL)
				break;
			    for(;;) {
				if((Col(IP)-JCOLO)<0) {
				    Data(ILD)-=AIJ*Data(JC);
				    break;
				} else if((Col(IP)-JCOLO)==0) {
				    Data(IP)-=AIJ*Data(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				    if(IP<=ILD) {
					Data(ILD)-=AIJ*Data(JC);
					break;
				    }
				}
			    }
			} else if((JCOLO-IEQ)==0) {
			    Data(ILD)-=AIJ*Data(JC);
			} else {
			    for(;;) {
				if((Col(IP)-JCOLO)<0) {
				    Data(ILD)-=AIJ*Data(JC);
				    break;
				} else if((Col(IP)-JCOLO)==0) {
				    Data(IP)-=AIJ*Data(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				    if(IP<=ILD) {
					Data(ILD)-=AIJ*Data(JC);
					break;
				    }
				}
			    }
			}
		    }
		} else {
		    for(JC=Diag(ICOL+1)-1;JC>=JLD;JC--) {
			JCOLO=Col(JC);
			if((JCOLO-IEQ)<0) {
			    if(JCOLO<=ICOL)
				break;
			    for(;;) {
				if((Col(IP)-JCOLO)<0) {
				    Data(ILD)-=AIJ*Data(JC);
				    break;
				} else if((Col(IP)-JCOLO)==0) {
				    Data(IP)-=AIJ*Data(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				}
			    }
			} else if((JCOLO-IEQ)==0) {
			    Data(ILD)-=AIJ*Data(JC);
			} else {
			    for(;;) {
				if((Col(IP)-JCOLO)<0) {
				    Data(ILD)-=AIJ*Data(JC);
				    break;
				} else if((Col(IP)-JCOLO)==0) {
				    Data(IP)-=AIJ*Data(JC);
				    IP--;
				    break;
				} else {
				    IP--;
				}
			    }
			}
		    }
		}
	    }
	}
    }
}

RealVector& RealCompactMatrix::CG(RealVector& x,RealVector& b,unsigned int Nit,DOUBLE Eps,DOUBLE Omega)
{
    RealVector dr=b,dd=b,dd1=b,dg=b;
    INTEGER ITE,Flag;
    REAL Res,Fr,Sigma0,Alpha,Sigma1,Cappa,Gamma,MaxNorm;
	
    if(GetNumDiag()!=x.GetLen() || x.GetLen()!=b.GetLen())
	return x;
	
    Flag=Omega<0;	
    MaxNorm=b.MaxNorm();
    // MaxNorm==0
    if(fabs(MaxNorm - 0.0) < FLOAT_EPS) {
	b=0;
	Prot<<"Warning zero right hand side !!\n";
	return x;
    }
	
    (*this).VectMult(x,dr);
    dr-=b;
    Res=dr.l2Norm();
    if(Res<=Eps) {
	ITE=0;
	Fr=Res;
    } else {
	if(Flag) {
	    Sigma0=Res*Res;
	} else {
	    dg=dr;
	    (*this).PrecondSOR(dg,Omega);
	    Sigma0=dr*dg;
	}
	dd=dg;dd*=-1;
	for(ITE=1;ITE<=Nit;ITE++) {
	    (*this).VectMult(dd,dd1);
	    Alpha=dd*dd1;
	    Alpha=Sigma0/Alpha;
	    x.AddMultConst(dd,Alpha);
	    dr.AddMultConst(dd1,Alpha);
			
	    Fr=dr.l2Norm();
	    ProtAdd<<"  Iteration "<<ITE<<"  !!Res!! = "<<Fr<<"\n";
			
	    if(Fr<=Eps) {
		if(Res>=1e-70)
		    Res=Fr/Res;
		Prot<<"Iterations "<<ITE<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
		if(ITE==0)
		    Cappa=0;
		else
		    Cappa=pow((double)Res,(1/(DOUBLE)ITE));
		Prot<<"Rate of convergence "<<Cappa<<"\n";
		return x;	
	    }
	    if(Flag) {
		Sigma1=Fr*Fr;
	    } else {
		dg=dr;
		(*this).PrecondSOR(dg,Omega);
		Sigma1=dr*dg;
	    }
	    Gamma=Sigma1/Sigma0;
	    Sigma0=Sigma1;
	    dd*=Gamma;dd-=dg;
	}
	Prot<<"CONVERGENCE FAILED !!\n";
	Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
	if(Res>=1e-70) {
	    Cappa=pow((double)(Fr/Res),(1/(DOUBLE)Nit));
	} else {
	    Cappa=0;
	}
	Prot<<"Rate of convergence "<<Cappa<<"\n";
	return x;
    }
    if(Res>=1e-70)
	Res=Fr/Res;
    Prot<<"Iterations "<<Nit<<"  CG-Verfahren  Norm of residual "<<Fr<<" !!Res!!/!!Initial Res!! "<<Res<<"\n";
    if(ITE==0)
	Cappa=0;
    else
	Cappa=pow((double)Res,(1/(DOUBLE)ITE));
    Prot<<"Rate of convergence "<<Cappa<<"\n";
    return x;
}
