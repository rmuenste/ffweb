#ifndef REALVECTORH

#define REALVECTORH

#include "MyTypes.h"
#include "Global.h"

class RealVector
{
private:
    REAL *aHandle;
    UNSIGNED Len;
    BYTEPTR	Name;
    std::string message;			  // Will act as "composer" for error messages
						  // This speeds up compilation with templates and
						  // reduces code. (No need to write code both for STD_CERR and protocol)
		
public:
    RealVector(UNSIGNED mySize);
    RealVector(UNSIGNED mySize,BYTEPTR aName);
    RealVector(RealVector& aRealVector);
    ~RealVector(VOID) {delete[] aHandle;}
		
    REAL& operator()(UNSIGNED index) {
#ifdef DEBUG
	if (index < 1  ||  index > GetLen()) {
            message
                = "pp3d++ (process " + int_to_string(MyProcID, 0) + "):\n"
                + "  Unrecoverable error discovered:\n"
                + "    Wrong access to an object of type RealVector with name" + GetName() + ":\n";

	    if (index < 1) {
		message += "    Trying to access array with too small row index: " + int_to_string(index) + ".\n";
	    } else if (index > GetLen()) {
		message += "    Trying to access array with too large row index: " + int_to_string(index)
		         + ". Maximum allowed: " + int_to_string(GetLen()) + ".\n";
	    }

            STD_CERR << message;
            protocol  << message;

	    exit(ARRAY_LIMIT_ERROR);
	}
#endif
	    return aHandle[index-1];
	}
		
    UNSIGNED	GetLen(VOID) {return Len;}
    BYTEPTR	GetName(VOID) {return Name;}
		
    void        memtest(float *aHandle, unsigned int bytesRequested);

    RealVector& operator=(RealVector& aRealVector);
    RealVector& operator=(REAL aNumber);
		
// Vector addition  a1+=a2
    friend RealVector& operator+=(RealVector& a1,RealVector& a2);
// Vector substraction a1-=a2
    friend RealVector& operator-=(RealVector& a1,RealVector& a2);
// Scales a Vector by a constant  a1=aNumber*a1
    friend RealVector& operator*=(RealVector& v1,REAL aNumber);
//  VectorA+=Alpha*VectorB
    RealVector& AddMultConst(RealVector& aRealVector,REAL aNumber);
// Dot product of two vectors   (DOUBLE)aNumber=v1*v2
    friend DOUBLE	operator*(RealVector& v1,RealVector& v2);
// l2-Norm
    DOUBLE l2Norm(VOID);
// Max-Norm
    REAL MaxNorm(VOID);
    REAL MaxNorm(UNSIGNED& MaxIndex);
		
    friend Output& operator<<(Output& o,RealVector& anRealVector);
};

#endif
