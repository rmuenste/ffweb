#ifndef MULTICOMPACTMATRIXH

#define MULTICOMPACTMATRIXH

#include "DoubleCompactMatrix.h"
#include "MultiVector.h"

class MultiCompactMatrix
{
private:
    DoubleCompactMatrix **MatrixPtr;
    UNSIGNED Num;
  
public:
    MultiCompactMatrix(UNSIGNED aNum);
    MultiCompactMatrix(MultiCompactMatrix& aMatrix);
    ~MultiCompactMatrix(VOID);
  
    MultiCompactMatrix& operator=(MultiCompactMatrix& aMultiCompMatrix);
// Methods for MultiCompact-Matrix
    MultiCompactMatrix& AddMultiVector(MultiVector& aVect);
    // a1*A+a2*M=A
    MultiCompactMatrix& AddMultConst(MultiCompactMatrix& aMatrix,
				     DOUBLE a1,DOUBLE a2);
//  MultiCompactMatrix& operator=(MultiCompactMatrix& aMultiCompMatrix);
    MultiCompactMatrix& operator+=(MultiCompactMatrix& aMultiCompMatrix);
    MultiCompactMatrix& operator=(DOUBLE aNumber);
    MultiCompactMatrix& operator*=(DOUBLE aNumber);
    DoubleCompactMatrix*& operator[](UNSIGNED aNum);
  
};	

#endif
