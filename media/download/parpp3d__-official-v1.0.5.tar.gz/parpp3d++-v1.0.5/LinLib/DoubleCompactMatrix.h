
#ifndef DOUBLECOMPACTMATRIXH

#define DOUBLECOMPACTMATRIXH

#include "math.h"
#include "IntArray.h"
#include "DoubleArray.h"
#include "DoubleArray2D.h"
#include "DoubleVector.h"
#include "typecasts.h"

class DoubleCompactMatrix:public DoubleArray
{
protected:
    unsigned int NumData;
    unsigned int NumDiag;
    IntArray*	 Column;
    IntArray*	 Diagonal;

    // for ILU
    IntArray*	 ILUColumn;
    IntArray*	 ILUDiagonal;
    DoubleArray* ILUDataArray;

    IntArray*    Perm1;
    IntArray*    Perm2;

    std::string message;			  // Will act as "composer" for error messages
						  // This speeds up compilation with templates and
						  // reduces code. (No need to write code both for STD_CERR and protocol)
    void DoubleCompactMatrix::arraysizeViolation(const char *callingFunction, const char *Name, int a, int amax);
    void DoubleCompactMatrix::elementNotFound   (const char *callingFunction, const char *Name);
		
public:
    void DoubleCompactMatrix::ShowFullMatrix    (void);		  // build full matrix and print to file './matrix'
    void DoubleCompactMatrix::PrintRowSum       (void);
    void DoubleCompactMatrix::PrintMaxRowSum    (void);
    void DoubleCompactMatrix::ShowSparseMatrix  (void);

    DoubleCompactMatrix(unsigned int aNumData,unsigned int aNumDiag)
	:DoubleArray(aNumData), NumData(aNumData), NumDiag(aNumDiag+1) {
	Column   = new IntArray(aNumData);
	Diagonal = new IntArray(aNumDiag+1);
	(*Diagonal)(aNumDiag+1) = aNumData + 1;
	ILUDiagonal  = 0;
	ILUColumn    = 0;
	ILUDataArray = 0;
	Perm1 = 0;
	Perm2 = 0;
    }
				
    DoubleCompactMatrix(unsigned int aNumData, unsigned int aNumDiag, BYTEPTR aName)
	:DoubleArray(aNumData, aName), NumData(aNumData), NumDiag(aNumDiag+1) {
	Column   = new IntArray(aNumData);
	Diagonal = new IntArray(aNumDiag+1);
	(*Diagonal)(aNumDiag+1) = aNumData + 1;
	ILUDiagonal  = 0;
	ILUColumn    = 0;
	ILUDataArray = 0;
	Perm1 = 0;
	Perm2 = 0;
    }

    DoubleCompactMatrix(DoubleCompactMatrix& aMatrix);
  
    ~DoubleCompactMatrix(VOID);
  
// Methods for Compact-Matrix
    VOID	Delete(DoubleCompactMatrix *aMatrix);
    DoubleCompactMatrix& operator=(DoubleCompactMatrix& aDoubleCompMatrix);
    DoubleCompactMatrix& operator=(DOUBLE aNumber);
    DOUBLE& operator()(unsigned int aRow,unsigned int aCol);
    DOUBLE&	SetElement(unsigned int DiagPos,unsigned int DiagVal,unsigned int ColPos,
			   unsigned int ColVal,unsigned int DataPos);
    UNSIGNED& Col(unsigned int aPos);
    UNSIGNED& Diag(unsigned int aPos);
    double&   Data(unsigned int aPos);
    unsigned int GetNumDiag();
    unsigned int GetNumData();
    DoubleVector& VectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect);
    // a1*A*aSrcVect+a2*aDestVect=aDestVect
    DoubleVector& VectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect,
			   DOUBLE a1,DOUBLE a2);
    DoubleVector& TimeMult(DoubleVector& aLump,DoubleVector& aSrcVect,
			   DoubleVector& aDestVect,
			   DOUBLE a1,DOUBLE a2);

    // a1*A+a2*M=A
    DoubleCompactMatrix& AddMultConst(DoubleCompactMatrix& aMatrix,
				      DOUBLE a1,DOUBLE a2);
  
    DoubleVector& Jacobi(DoubleVector& x,DoubleVector& b,unsigned int Nit,
			 DOUBLE Eps,DOUBLE Omega);
    DoubleVector& JacobiSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit,
			       DOUBLE Omega);
    DoubleVector& GaussSeidel(DoubleVector& x,DoubleVector& b,unsigned int Nit,
			      DOUBLE Eps);
    DoubleVector& GaussSeidelSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit);
    DoubleVector& SOR(DoubleVector& x,DoubleVector& b,unsigned int Nit,DOUBLE Eps,
		      DOUBLE Omega);
    DoubleVector& SORSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit,
			    DOUBLE Omega);
    DoubleVector& NeumannSORSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit,
				   DOUBLE Omega);
    DoubleVector& SSORSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit,
			     DOUBLE Omega);
    DoubleVector& PrecondSOR(DoubleVector& x,DOUBLE Omega);
    DoubleVector& CG(DoubleVector& x,DoubleVector& b,unsigned int Nit,DOUBLE Eps,
		     DOUBLE Omega);
    unsigned int BiCGStab(DoubleVector& x,DoubleVector& b,unsigned int Nit,
		      DOUBLE Eps,DOUBLE Omega);
    VOID Filter(DoubleVector& x);
    DoubleVector& NeumannCG(DoubleVector& x,DoubleVector& b,unsigned int Nit,DOUBLE Eps,
			    DOUBLE Omega);
    DoubleVector& NeumannCGSmooth(DoubleVector& x,
				  DoubleVector& b,unsigned int Nit);

    // for ILU
    double    Sign(double a1,double a2);
    unsigned& ILUCol(unsigned int aPos);
    unsigned& ILUDiag(unsigned int aPos);
    double&   ILUData(unsigned int aPos);
    void      Sort(IntArray& KH1,IntArray& KH2,int ID1);
    void      CuthillMcKee();
    void      PermAll();                       // Data,Diag und Col umsortieren
    void      PermAll(DoubleVector *new_diag); // Data,Diag und Col umsortieren 
    // neue Diagonal
    void DoubleCompactMatrix::SetILUBound(IntArray& Info);
    // permutiere zu neuer Numerierung 
    void      PermToNew(DoubleVector& oldvec,DoubleVector& newvec); 
    void      PermToNew(IntArray& oldvec,IntArray& newvec); 
    // permutiere zu alter Numerierung
    void      PermToOld(DoubleVector& newvec,DoubleVector& oldvec); 
    DoubleVector& ILU(DoubleVector& x,DoubleVector& b,
		      unsigned int Nit,double Res,double Omega);
    void	    ILU(int ILU,double Alpha,double Tol,IntArray& Info);
    void	    ILU(int ILU,double Alpha,double Tol);
    void	    ILU(DoubleVector& x);
    DoubleVector& ILUSmooth(DoubleVector& x,DoubleVector& b,unsigned int Nit,double Omega);
    DoubleVector& PrecondILU(DoubleVector& x);

    friend Output& operator<<(Output& o,DoubleCompactMatrix& aMatrix);
};	

inline unsigned int DoubleCompactMatrix::GetNumDiag()
{
    return NumDiag-1;
}

inline unsigned int DoubleCompactMatrix::GetNumData()
{
    return NumData-1;
}

inline UNSIGNED& DoubleCompactMatrix::Col(unsigned int aPos)
{
#ifdef DEBUG
    if (aPos < 1  ||  aPos > NumData) {
	arraysizeViolation("DoubleCompactMatrix::Col", GetName(), aPos, NumData);
    }
#endif
    return (UNSIGNED&)((*Column)(aPos));
}

inline UNSIGNED& DoubleCompactMatrix::Diag(unsigned int aPos)
{
#ifdef DEBUG
    if (aPos < 1  ||  aPos > NumData) {
	arraysizeViolation("DoubleCompactMatrix::Diag", GetName(), aPos, NumData);
    }
#endif
    return (UNSIGNED&)((*Diagonal)(aPos));
}

inline DOUBLE& DoubleCompactMatrix::Data(unsigned int aPos)
{
#ifdef DEBUG
    if (aPos < 1  ||  aPos > NumData) {
	arraysizeViolation("DoubleCompactMatrix::Data", GetName(), aPos, NumData);
    }
#endif
    return ((DoubleArray&)(*this))(aPos);
}

inline unsigned& DoubleCompactMatrix::ILUCol(unsigned int aPos)
{
#ifdef DEBUG
    if (aPos < 1  ||  aPos > NumData) {
	arraysizeViolation("DoubleCompactMatrix::ILUCol", GetName(), aPos, NumData);
    }
#endif
    return (unsigned&)((*ILUColumn)(aPos));
}

inline unsigned& DoubleCompactMatrix::ILUDiag(unsigned int aPos)
{
#ifdef DEBUG
    if (aPos < 1  ||  aPos > NumData) {
	arraysizeViolation("DoubleCompactMatrix::ILUDiag", GetName(), aPos, NumData);
    }
#endif
    return (unsigned&)((*ILUDiagonal)(aPos));
}

inline DOUBLE& DoubleCompactMatrix::ILUData(unsigned int aPos)
{
#ifdef DEBUG
    if (aPos < 1  ||  aPos > NumData) {
	arraysizeViolation("DoubleCompactMatrix::ILUData", GetName(), aPos, NumData);
    }
#endif
    return (*ILUDataArray)(aPos);
}


#endif
