#include "DoubleRectMatrix.h"

DoubleRectMatrix::~DoubleRectMatrix(VOID)
{
    if(Row!=(IntArray*)0)
    	delete Row;
    if(Column!=(IntArray*)0)
    	delete Column;
}

VOID DoubleRectMatrix::Delete(DoubleRectMatrix  *aMatrix)
{
    if(Row!=(IntArray*)0)
    	delete Row;
    if(Column!=(IntArray*)0)
    	delete Column;
    Row=0;
    Column=0;
    aMatrix->Row=0;
    aMatrix->Column=0;
    delete this;
    delete aMatrix;
}

DoubleRectMatrix& DoubleRectMatrix::operator=(DoubleRectMatrix& aDoubleRectMatrix)
{
    if(aDoubleRectMatrix.NumData==NumData && aDoubleRectMatrix.NumRow==NumRow)
    {
	int index;
    	for(index=1;index<=NumData;index++)
	    (*this).Data(index)=aDoubleRectMatrix.Data(index);
    	for(index=1;index<=NumRow;index++)
	    (*Row)(index)=(*aDoubleRectMatrix.Row)(index);
    	for(index=1;index<=NumData;index++)
	    (*Column)(index)=(*aDoubleRectMatrix.Column)(index);
    }
    return *this;
}

DoubleRectMatrix& DoubleRectMatrix::operator=(DOUBLE aNumber)
{
    for (unsigned int index =1;index<=NumData;index++)
    	(*this).Data(index)=aNumber;
  
    return *this;
}

DOUBLE& DoubleRectMatrix::operator()(unsigned int aRow,unsigned int aCol)
{
    unsigned int end;
  
    if(aRow > 0  &&  aRow <= GetNumRow()) {
    	end = (*Row)(aRow+1) - 1;
    	for (int index = (*Row)(aRow); index <= end; index++) {
	    if ((*Column)(index) == aCol)
		return (*this).Data(index);
    	}

#ifdef DEBUG
	// If we did not find the requested column, we have an illegal access
    	Err<<"DoubleRectMatrix: wrong access !!  Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type DoubleRectMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: "
		 << "  Trying to access array with pair (" << aRow << "," << aCol << ").\n"
		 << "  Program aborted in DoubleRectMatrix::operator().\n";
#endif
    	exit(1);
    } else {
	// Array access out of bound
#ifdef DEBUG
    	Err<<"DoubleRectMatrix: wrong access !!  Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type DoubleRectMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: ";
	if (aRow <= 0) {
	    protocol << "Trying to access array with too small row index: " << aRow << ".\n";
	} else {
	    protocol << "Trying to access array with too large row index: " << aRow << ". Maximum allowed: " << GetNumRow() << ".\n";
	}
	protocol << "  Program aborted in DoubleRectMatrix::operator().\n";
#endif
    	exit(1);
    }
}

DOUBLE& DoubleRectMatrix::SetElement(unsigned int DiagPos, unsigned int DiagVal,
				     unsigned int ColPos,  unsigned int ColVal, unsigned int DataPos)
{
    if(DiagPos >= 1  &&  DiagPos <= NumRow) {
    	(*Row)(DiagPos) = DiagVal;
    } else {
#ifdef DEBUG
    	Err<<"DoubleRectMatrix: wrong access (SetElement)!!  Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type DoubleRectMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: ";
	if (DiagPos < 1) {
	    protocol << "Trying to access array with too small diag index: " << DiagPos << ".\n";
	} else {
	    protocol << "Trying to access array with too large diag index: " << DiagPos << ". Maximum allowed: " << NumRow << ".\n";
	}
	protocol << "  Program aborted in DoubleRectMatrix::SetElement.\n";
#endif
    	exit(1);
    }
    if (ColPos >= 1  &&  ColPos <= NumData) {
    	(*Column)(ColPos) = ColVal;
    } else {
#ifdef DEBUG
    	Err<<"DoubleRectMatrix: wrong access (SetElement)!!  Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type DoubleRectMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: ";
	if (ColPos < 1) {
	    protocol << "Trying to access array with too small col index: " << ColPos << ".\n";
	} else {
	    protocol << "Trying to access array with too large col index: " << ColPos << ". Maximum allowed: " << NumData << ".\n";
	}
	protocol << "  Program aborted in DoubleRectMatrix::SetElement.\n";
#endif
    	exit(1);
    }
    if (DataPos >= 1  &&  DataPos <= NumData) {
    	return (*this).Data(DataPos);
    } else {
#ifdef DEBUG
    	Err<<"DoubleRectMatrix: wrong access (SetElement)!!   Name:"<<GetName()<<"\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type DoubleRectMatrix with name <" << GetName() << ">.\n"
		 << "  Cause of error: ";
	if (DataPos < 1) {
	    protocol << "Trying to access array with too small diag index: " << DataPos << ".\n";
	} else {
	    protocol << "Trying to access array with too large diag index: " << DataPos << ". Maximum allowed: " << NumData << ".\n";
	}
	protocol << "  Program aborted in DoubleRectMatrix::SetElement.\n";
#endif
    	exit(1);
    }
}

DoubleVector& DoubleRectMatrix::VectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect)
// Compute aDestVect = thisMatrix * aSrcVect
{
    if (aDestVect.GetLen() == GetNumRow()) {
    	for (int index = 1, k = 1; index <= GetNumRow(); index++) {
	    for (int index2 = (*Row)(index); index2 <= (*Row)(index + 1) - 1; index2++) {
		aDestVect(index) += ((*this).Data(k++) * aSrcVect((*Column)(index2))); 
	    }
    	}
    }

    return aDestVect;
}

DoubleVector& DoubleRectMatrix::VectMult(DoubleVector& aSrcVect, DoubleVector& aDestVect, double a1, double a2)
// Compute aDestVect = a2 * aDestVect  +  a1 * thisMatrix * aSrcVect
{
    DOUBLE a;
    INTEGER index,k;
  
    if(aDestVect.GetLen()==GetNumRow()) {
	// a1 != 0
	if (fabs(a1 - 0.0) > FLOAT_EPS) {
	    // a2 == 0
	    if (fabs(a2 - 0.0) < FLOAT_EPS) {
		aDestVect=0;
		for(index=1,k=1;index<=GetNumRow();index++) {
		    for(int index2=(*Row)(index);index2<=(*Row)(index+1)-1;index2++) {
			aDestVect(index)+=((*this).Data(k++)*aSrcVect((*Column)(index2)));
		    }
		}
	    } else {
		a=a2/a1;
		// a != 1
		if (fabs(a - 1.0) > FLOAT_EPS)
		    aDestVect*=a;
		for(index=1,k=1;index<=GetNumRow();index++) {
		    for(int index2=(*Row)(index);index2<=(*Row)(index+1)-1;index2++) {
			aDestVect(index)+=((*this).Data(k++)*aSrcVect((*Column)(index2)));
		    }
		}
	    }
	    // a1 != 1
	    if (fabs(a1 - 1.0) > FLOAT_EPS)
		aDestVect*=a1;
	} else {
	    aDestVect*=a2;
    	}
    }

    return aDestVect;
}

DoubleRectMatrix& DoubleRectMatrix::AddMultConst(DoubleRectMatrix& aMatrix,DOUBLE a1,DOUBLE a2)
{
    if(NumData==aMatrix.NumData) {
	// a1 != 1
	if (fabs(a1 - 1.0) > FLOAT_EPS) {
	    for(INTEGER i=1;i<=NumData;i++)
		Data(i)=a1*Data(i)+a2*aMatrix.Data(i);
    	} else {
	    for(INTEGER i=1;i<=NumData;i++)
		Data(i)+=a2*aMatrix.Data(i);
    	}
    }
    return *this;
}


Output& operator<<(Output& o,DoubleRectMatrix& aMatrix)
{
    unsigned int end;
  
    for (unsigned int row = 1;row<=aMatrix.GetNumRow();row++)
    {
	end=(*aMatrix.Row)(row+1)-1;
	for (unsigned int col = (*aMatrix.Row)(row);col<=end;col++)
    	{
	    o<<"The value at row "<<row<<" ,column "<<(*aMatrix.Column)(col)<<" = ";
	    o<<aMatrix.Data(col)<<"\n";
    	}
    }
    return o;
}
