#ifndef INTARRAY2DH

#define INTARRAY2DH

#include <stdlib.h>
#include <stddef.h>
#include "MyTypes.h"
#include "Global.h"

extern int MyProcID;


class IntArray2D
{
private:
    INTEGER *aHandle;
    UNSIGNED Len;
    BYTEPTR Name;

    unsigned int Rows;
    unsigned int Cols;
    std::string  message;			  // Will act as "composer" for error messages
                                                  // This speeds up compilation with templates and
                                                  // reduces code. (No need to write code both for STD_CERR and protocol)

public:
    IntArray2D(UNSIGNED myRows,UNSIGNED myCols);
    IntArray2D(UNSIGNED myRows,UNSIGNED myCols,BYTEPTR aName);
    IntArray2D(IntArray2D& anIntArray2D);
    ~IntArray2D(VOID) {delete[] aHandle;}

    INTEGER& operator()(UNSIGNED row,UNSIGNED col) {
#ifdef DEBUG
	if (row < 1  ||  row > Rows  ||  col < 1  ||  col > Cols) {
            message
                = "pp3d++ (process " + int_to_string(MyProcID, 0) + "):\n"
                + "  Unrecoverable error discovered:\n"
                + "    Wrong access to an object of type IntArray2D with name" + GetName() + ":\n";

	    if (row < 1) {
		message += "    Trying to access array with too small row index: " + int_to_string(row) + ".\n";
	    } else if (row > Rows) {
		message += "    Trying to access array with too large row index: " + int_to_string(row)
		         + ". Maximum allowed: " + int_to_string(Rows) + ".\n";
	    } else if (col < 1) {
		message += "    Trying to access array with too small col index: " + int_to_string(col) + ".\n";
	    } else if (col > Cols) {
		message += "    Trying to access array with too large col index: " + int_to_string(col)
		         + ". Maximum allowed: " + int_to_string(Cols) + ".\n";
	    }

            STD_CERR << message;
            protocol  << message;

	    exit(ARRAY_LIMIT_ERROR);
	}
#endif
	    return aHandle[(row-1)*Cols+col-1];
	}

    UNSIGNED	GetLen(VOID) {return Len;}
    BYTEPTR	GetName(VOID) {return Name;}
    UNSIGNED	GetRows(VOID) {return Rows;}
    UNSIGNED	GetCols(VOID) {return Cols;}

    void        memtest(int *aHandle, unsigned int bytesRequested);

    IntArray2D& operator=(IntArray2D& anIntArray2D);
    IntArray2D& operator=(INTEGER aNumber);
    // Array addition  a1+=a2
    friend IntArray2D& operator+=(IntArray2D& a1,IntArray2D& a2);
    // Array substraction a1-=a2
    friend IntArray2D& operator-=(IntArray2D& a1,IntArray2D& a2);
    // Scales a Array by a constant  a1=aNumber*a1
    friend IntArray2D& operator*=(IntArray2D& v1,INTEGER aNumber);

    friend Output& operator<<(Output& o,IntArray2D& anIntArray2D);
};


#endif
