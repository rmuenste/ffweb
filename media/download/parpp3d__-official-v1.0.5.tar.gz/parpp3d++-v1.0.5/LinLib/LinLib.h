#ifndef LINLIBH

#define LINLIBH

#include "IntArray.h"
#include "RealArray.h"
#include "DoubleArray.h"
#include "IntArray2D.h"
#include "RealArray2D.h"
#include "DoubleArray2D.h"
#include "IntArray3D.h"
#include "RealArray3D.h"
#include "DoubleArray3D.h"
#include "IntVector.h"
#include "RealVector.h"
#include "DoubleVector.h"
#include "MultiVector.h"
#include "IntFullMatrix.h"
#include "RealFullMatrix.h"
#include "DoubleFullMatrix.h"
#include "RealCompactMatrix.h"
#include "DoubleCompactMatrix.h"
#include "DoubleRectMatrix.h"
#include "MultiCompactMatrix.h"
#include "MultiRectMatrix.h"
#include "DateTime.h"
#include "MemInfo.h"
#include "Output.h"
// #include "Input.h"
#include "Protypes.h"
#include "Global.h"
#include "MyTypes.h"
#include <math.h>

#endif
