#ifndef MULTIRECTMATRIXH

#define MULTIRECTMATRIXH

#include "DoubleRectMatrix.h"

class MultiRectMatrix
{
private:
    DoubleRectMatrix **MatrixPtr;
    UNSIGNED Num;
		
public:
    MultiRectMatrix(UNSIGNED aNum);
    ~MultiRectMatrix(VOID);
  
// Methods for MultiCompact-Matrix
    // a1*A+a2*M=A
    MultiRectMatrix& AddMultConst(MultiRectMatrix& aMatrix,
				  DOUBLE a1,DOUBLE a2);
    MultiRectMatrix& operator=(MultiRectMatrix& aMultiCompMatrix);
    MultiRectMatrix& operator+=(MultiRectMatrix& aMultiCompMatrix);
    MultiRectMatrix& operator=(DOUBLE aNumber);
    MultiRectMatrix& operator*=(DOUBLE aNumber);
    DoubleRectMatrix*& operator[](UNSIGNED aNum);
};	

#endif
