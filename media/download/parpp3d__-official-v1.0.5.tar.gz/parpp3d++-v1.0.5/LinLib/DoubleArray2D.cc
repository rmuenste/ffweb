#include "DoubleArray2D.h"
#include "Protypes.h"
#include "Global.h"

DoubleArray2D::DoubleArray2D(unsigned int myRows,unsigned int myCols)
{
    Name    = "DoubleArray2D";
    Len     = myRows * myCols;
    Rows    = myRows;
    Cols    = myCols;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index =0;index<Len;index++)
	aHandle[index]=0;
}

DoubleArray2D::DoubleArray2D(unsigned int myRows,unsigned int myCols,BYTEPTR aName)
{
    Name    = aName;
    Len     = myRows * myCols;
    Rows    = myRows;
    Cols    = myCols;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index =0;index<Len;index++)
	aHandle[index]=0;
}

DoubleArray2D::DoubleArray2D(DoubleArray2D& anDoubleArray2D)
{
    unsigned int size=anDoubleArray2D.GetLen();
	
    Name    = anDoubleArray2D.Name;
    Len     = size;
    Rows    = anDoubleArray2D.GetRows();
    Cols    = anDoubleArray2D.GetCols();
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int row = 1;row<=Rows;row++)
	for (unsigned int col = 1;col<=Cols;col++)
	    (*this)(row,col)=anDoubleArray2D(row,col);
}

DoubleArray2D& DoubleArray2D::operator=(DoubleArray2D& aDoubleArray2D)
{
//  unsigned int size=aDoubleArray2D.GetLen();
	
    if(aDoubleArray2D.Rows<=Rows && aDoubleArray2D.Cols<=Cols)
    {
	for (unsigned int row = 1;row<=aDoubleArray2D.Rows;row++)
	    for (unsigned int col = 1;col<=aDoubleArray2D.Cols;col++)
		(*this)(row,col)=aDoubleArray2D(row,col);
    }
    return *this;
}

DoubleArray2D& DoubleArray2D::operator=(DOUBLE aNumber)
{
    for (unsigned int row = 1;row<=Rows;row++)
	for (unsigned int col = 1;col<=Cols;col++)
	    (*this)(row,col)=aNumber;
    return *this;
}

DoubleArray2D& operator+=(DoubleArray2D& a1,DoubleArray2D& a2)
{
    if(a1.Rows==a2.Rows && a1.Cols==a2.Cols) {
	for (unsigned int row = 1;row<=a1.Rows;row++)
	    for (unsigned int col = 1;col<=a1.Cols;col++)
		a1(row,col)=a1(row,col)+a2(row,col);
    }
    return a1;
}

DoubleArray2D& operator-=(DoubleArray2D& a1,DoubleArray2D& a2)
{
    if(a1.Rows==a2.Rows && a1.Cols==a2.Cols) {
	for (unsigned int row = 1;row<=a1.Rows;row++)
	    for (unsigned int col = 1;col<=a1.Cols;col++)
		a1(row,col)=a1(row,col)-a2(row,col);
    }
    return a1;
}

DoubleArray2D& operator*=(DoubleArray2D& a1,DOUBLE aNumber)
{
    for (unsigned int row = 1;row<=a1.Rows;row++)
	for (unsigned int col = 1;col<=a1.Cols;col++)
	    a1(row,col)=a1(row,col)*aNumber;
    return a1;
}

Output& operator<<(Output& o,DoubleArray2D& anDoubleArray2D)
{
    for (unsigned int row = 1;row<=anDoubleArray2D.Rows;row++)
    {
	for (unsigned int col = 1;col<=anDoubleArray2D.Cols;col++) {
	    o<<"The value in row "<<row<<" col "<<col<<" = ";
	    o<<anDoubleArray2D(row,col)<<"\n";
	}
    }
    return o;
}

void DoubleArray2D::memtest(double *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for DoubleArray2D (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
