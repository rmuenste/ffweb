#include "RealVector.h"
#include "Protypes.h"
#include <math.h>

RealVector::RealVector(unsigned int mySize)
{
    Name    = "RealVector";
    Len     = mySize;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index = 0; index < Len; index++)
	aHandle[index] = 0;
}

RealVector::RealVector(unsigned int mySize,BYTEPTR aName)
{
    Name    = aName;
    Len     = mySize;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index = 0; index < Len; index++)
	aHandle[index] = 0;
}

RealVector::RealVector(RealVector& aRealVector)
{
    unsigned int size = aRealVector.GetLen();
	
    Name    = aRealVector.Name;
    Len     = size;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index = 0; index < Len; index++)
	aHandle[index] = aRealVector.aHandle[index];
}

RealVector& RealVector::operator=(RealVector& aRealVector)
{
    unsigned int size = aRealVector.GetLen();
	
    if (GetLen() >= size) {
	for (unsigned int index = 1;index<=size;index++)
	    (*this)(index)=aRealVector(index);
    }
    return *this;
}

RealVector& RealVector::operator=(REAL aNumber)
{
    for (unsigned int index = 1;index<=GetLen();index++) {
	(*this)(index)=aNumber;
    }
    return *this;
}

RealVector& RealVector::AddMultConst(RealVector& aRealVector,REAL aNumber)
{
    if(GetLen()==aRealVector.GetLen()) {
	for (unsigned int index = 1;index<=GetLen();index++)
	    (*this)(index)+=(aNumber*aRealVector(index));
    }
    return *this;
}

DOUBLE operator*(RealVector& v1,RealVector& v2)
{
    DOUBLE temp=0;
	
    if(v1.GetLen()!=v2.GetLen()) {
// ********** Error : different vectors **********
	Err<<"RealVector: different vectors !!   Name:"<<v1.GetName()<<"\n";
	exit(1);
    }

    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	temp+=v1(index)*v2(index);
	
    return temp;
}

DOUBLE RealVector::l2Norm(void)
{
    DOUBLE temp=*this* *this;
	
    if(temp!=0)
	return sqrt(temp);
		
    return 0;
}

REAL RealVector::MaxNorm(void)
{
    REAL MaxValue=ABS((*this)(1));
	
    for (unsigned int index = 2;index<=GetLen();index++) 
	if(ABS((*this)(index))>MaxValue)
	    MaxValue=ABS((*this)(index));
		
    return MaxValue;
}

REAL RealVector::MaxNorm(unsigned int& MaxIndex)
{
    REAL MaxValue=ABS((*this)(1));
	
    MaxIndex=1;
    for (unsigned int index = 2;index<=GetLen();index++) { 
	if(ABS((*this)(index))>MaxValue) {
	    MaxValue=ABS((*this)(index));
	    MaxIndex=index;
	}
    }
		
    return MaxValue;
}

RealVector& operator+=(RealVector& a1,RealVector& a2)
{
    if(a1.GetLen()==a2.GetLen()) {
	for (unsigned int index = 1;index<=a1.GetLen();index++)
	    a1(index)=a1(index)+a2(index);
    }
    return a1;
}

RealVector& operator-=(RealVector& a1,RealVector& a2)
{
    if(a1.GetLen()==a2.GetLen()) {
	for (unsigned int index = 1;index<=a1.GetLen();index++)
	    a1(index)=a1(index)-a2(index);
    }
    return a1;
}

RealVector& operator*=(RealVector& a1,REAL aNumber)
{
    for (unsigned int index = 1;index<=a1.GetLen();index++)
	a1(index)=a1(index)*aNumber;
    return a1;
}

Output& operator<<(Output& o,RealVector& anRealVector)
{
    for (unsigned int index = 1;index<=anRealVector.GetLen();index++)
    {
	o<<"The value at index position "<<index<<"=";
	o<<anRealVector(index)<<"\n";
    }
    return o;
}


// Vector addition  v1=v2+v3
void VecAdd(RealVector& v1,RealVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=v2(index)+v3(index);
}

void VecAdd(RealVector& v1,IntVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)+v3(index));
}

void VecAdd(RealVector& v1,RealVector& v2,IntVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)+v3(index));
}

void VecAdd(RealVector& v1,DoubleVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)+v3(index));
}

void VecAdd(RealVector& v1,RealVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)+v3(index));
}

void VecAdd(RealVector& v1,IntVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)+v3(index));
}

void VecAdd(RealVector& v1,DoubleVector& v2,IntVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)+v3(index));
}

// Vector substraction  v1=v2-v3
void VecSub(RealVector& v1,RealVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=v2(index)-v3(index);
}

void VecSub(RealVector& v1,RealVector& v2,IntVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)-v3(index));
}

void VecSub(RealVector& v1,IntVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)-v3(index));
}

void VecSub(RealVector& v1,DoubleVector& v2,RealVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)-v3(index));
}

void VecSub(RealVector& v1,RealVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)-v3(index));
}

void VecSub(RealVector& v1,IntVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)-v3(index));
}

void VecSub(RealVector& v1,DoubleVector& v2,IntVector& v3)
{
    for (unsigned int index = 1; index <= v1.GetLen(); index++)
	v1(index)=(REAL)(v2(index)-v3(index));
}

void RealVector::memtest(float *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for RealVector (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
