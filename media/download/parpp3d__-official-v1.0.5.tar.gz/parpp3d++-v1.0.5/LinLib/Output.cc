#include "Output.h"
#ifdef NO_NAMESPACE_STD_USAGE
# define STD_CIN   cin
# define STD_COUT  cout
# define STD_CERR  cerr
#else
# define STD_CIN   std::cin
# define STD_COUT  std::cout
# define STD_CERR  std::cerr
#endif

extern Output Err;

Output::Output(BYTEPTR aName, unsigned int aFlag) 
{
    Type = FILE_FLAG;
    Flag = aFlag;
    File = fopen(aName,"w");
    if (!File) {
        Err << progname.c_str() << ":\nCould not open file " << aName << "\n";
        STD_CERR << progname.c_str() << ":\nCould not open file " << aName << "\n";
        exit(1);
    }
}

Output::~Output(void)
{
    if(Type==FILE_FLAG) {
        if (File)
            fclose(File);
    }
}

FILE *Output::OpenFile(BYTEPTR Name)
{
    FILE *MyFile;
  
    MyFile = fopen(Name,"w");
    if (!MyFile) {
        Err << progname.c_str() << ":\nCould not open file " << Name << "\n";
        STD_CERR << progname.c_str() << ":\nCould not open file " << Name << "\n";
        exit(1);
    }
    return MyFile;
}

VOID Output::CloseFile(FILE *File)
{
    fclose(File);
}

VOID Output::CloseFile()
{
    if(File)
        fclose(File);
    File=NULL;
}

VOID Output::SetFile(BYTEPTR Name)
{
    if(Type==FILE_FLAG) {
        if(File)
            fclose(File);
    }
    Type = FILE_FLAG;
    Flag = YES;
    File = fopen(Name,"w");
    if (!File) {
        Err << progname.c_str() << ":\nCould not open file " << Name << "\n";
        STD_CERR << progname.c_str() << ":\nCould not open file " << Name << "\n";
        exit(1);
    }
}

VOID Output::SetFile(FILE *MyFile)
{
    Type=FILE_FLAG;
    Flag=YES;
    File=MyFile;
}

VOID Output::SetScreen(VOID)
{
    Type=SCREEN_FLAG;
    Flag=YES;
}

VOID Output::SetFlag(unsigned int mflag)
{
    Flag=mflag;
}


Output& Output::operator<<(INTEGER aNumber)
{
    if(Flag==YES) {
#ifdef MAC_CODE
        if(Type==DOC_FLAG) {
            sprintf(strbuf,"%ld",aNumber);
            if(mDoc)
                mDoc->PrintString(strbuf);
        } else 
#endif		
            if (Type==SCREEN_FLAG) {
//	            cout<<aNumber;
                printf("%d",aNumber);
            } else {
                if (File) {
                    fprintf(File,"%d",aNumber);
//	                fflush(File);
                }
            }
    }

    return *this;
}

Output& Output::operator<<(REAL aNumber)
{
    if(Flag==YES) {
#ifdef MAC_CODE
        if(Type==DOC_FLAG) {
            sprintf(strbuf,"%e",aNumber);
            if(mDoc)
                mDoc->PrintString(strbuf);
        } else 
#endif
            if(Type==SCREEN_FLAG) {
//	  cout<<aNumber;
                printf("%e",aNumber);
            } else {
                if(File) {
                    fprintf(File,"%e",aNumber);
//	    fflush(File);
                }
            }
    }
    return *this;
}

Output& Output::operator<<(DOUBLE aNumber)
{
    if(Flag==YES) {
#ifdef MAC_CODE
        if(Type==DOC_FLAG) {
            sprintf(strbuf,"%e",aNumber);
            if(mDoc)
                mDoc->PrintString(strbuf);
        } else 
#endif
            if(Type==SCREEN_FLAG) {
//	  cout<<aNumber;
                printf("%e",aNumber);
            } else {
                if(File) {
                    fprintf(File,"%e",aNumber);
//	    fflush(File);
                }
            }
    }
    return *this;
}

#ifdef MAC_CODE
Output& Output::operator<<(extended aNumber)
{
  	if(Flag==YES) {
        if(Type==DOC_FLAG) {
			sprintf(strbuf,"%ne",aNumber);
            if(mDoc)
				mDoc->PrintString(strbuf);
		} else if(Type==SCREEN_FLAG) {
			cout<<aNumber;
        } else {
      		if(File) {
				fprintf(File,"%ne",aNumber);
//				fflush(File);
      		}
        }
  	}
  	return *this;
}
#endif

Output& Output::operator<<(unsigned int aNumber)
{
    if(Flag==YES) {
#ifdef MAC_CODE
        if(Type==DOC_FLAG) {
            sprintf(strbuf,"%u",aNumber);
            if(mDoc)
                mDoc->PrintString(strbuf);
        } else 
#endif
            if(Type==SCREEN_FLAG) {
//	  cout<<aNumber;
                printf("%u",aNumber);
            } else {
                if(File) {
                    fprintf(File,"%u",aNumber);
//	    fflush(File);
                }
            }
    }
    return *this;
}
  
 
Output& Output::operator<<(LONG aNumber)
{
    if(Flag==YES) {
#ifdef MAC_CODE
        if(Type==DOC_FLAG) {
            sprintf(strbuf,"%ld",aNumber);
            if(mDoc)
                mDoc->PrintString(strbuf);
        } else 
#endif
            if(Type==SCREEN_FLAG) {
//	  cout<<aNumber;
                printf("%ld",aNumber);
            } else {
                if(File) {
                    fprintf(File,"%ld",aNumber);
//	    fflush(File);
                }
            }
    }
    return *this;
}


Output& Output::operator<<(BYTEPTR aString)
{
    if(Flag==YES) {
#ifdef MAC_CODE
        if(Type==DOC_FLAG) {
            if(mDoc)
                mDoc->PrintString(aString);
        } else 
#endif
            if(Type==SCREEN_FLAG) {
//	  cout<<aString;
                printf("%s",aString);
            } else {
                if(File) {
                    fprintf(File,"%s",aString);
//	    fflush(File);
                }
            }
    }
    return *this;
}

Output& Output::operator<<(std::string aString)
{
   if(Flag==YES) {
       if(Type==SCREEN_FLAG) {
//  	   STD_COUT << aString;
	   printf("%s",aString.c_str());
       } else {
	   if(File) {
	       fprintf(File,"%s",aString.c_str());
//	    fflush(File);
	   }
       }
   }
   return *this;
}


void Output::Flush()
{
    fflush(File);
}

