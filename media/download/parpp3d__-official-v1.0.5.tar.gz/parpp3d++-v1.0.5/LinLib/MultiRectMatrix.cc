#include "MultiRectMatrix.h"

MultiRectMatrix::MultiRectMatrix(unsigned int aNum)
{
    MatrixPtr=new DoubleRectMatrix*[aNum];
    Num=aNum;
    for(INTEGER i=0;i<Num;i++)
	MatrixPtr[i]=0;
}

MultiRectMatrix::~MultiRectMatrix(VOID)
{
    for(INTEGER i=0;i<Num;i++)
	if(MatrixPtr[i])
	    delete MatrixPtr[i];
}

DoubleRectMatrix*& MultiRectMatrix::operator[](unsigned int aNum)
{
#ifdef DEBUG
    if(aNum < 1  ||  aNum > Num) {
	Err<<"MultiRectMatrix: wrong access !!\n";

	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Illegal access to an object of type MultiRectMatrix.\n"
		 << "  Cause of error: ";
	if (aNum <= 0) {
	    protocol << "Trying to access array with too small row index: " << aNum << ".\n";
	} else {
	    protocol << "Trying to access array with too large row index: " << aNum << ". Maximum allowed: " << Num << ".\n";
	}
	protocol << "  Program aborted in MultiRectMatrix::operator[].\n";
	exit(1);
    }
#endif
    return MatrixPtr[aNum-1];
}

MultiRectMatrix& MultiRectMatrix::operator=(DOUBLE aNumber)
{
    for(INTEGER i=0;i<Num;i++)
	*(MatrixPtr[i])=aNumber;
		
    return *this;
}

MultiRectMatrix& MultiRectMatrix::operator*=(DOUBLE aNumber)
{
    for(INTEGER i=0;i<Num;i++)
	*(MatrixPtr[i])*=aNumber;
		
    return *this;
}

MultiRectMatrix& MultiRectMatrix::operator=(MultiRectMatrix& aMultiCompMatrix)
{
    for(INTEGER i=0;i<Num;i++)
	MatrixPtr[i]=new DoubleRectMatrix(*(aMultiCompMatrix.MatrixPtr[i]));
		
    return *this;
}

MultiRectMatrix& MultiRectMatrix::operator+=(MultiRectMatrix& aMultiCompMatrix)
{
    for(INTEGER i=0;i<Num;i++)
	*(MatrixPtr[i])+=*(aMultiCompMatrix.MatrixPtr[i]);
	
    return *this;
}

MultiRectMatrix& MultiRectMatrix::AddMultConst(MultiRectMatrix& aMatrix,
					       DOUBLE a1,DOUBLE a2)
{
    for(INTEGER i=0;i<Num;i++)
	MatrixPtr[i]->AddMultConst(*(aMatrix.MatrixPtr[i]),a1,a2);
		
    return *this;
}
