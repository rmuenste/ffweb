#include "DoubleFullMatrix.h"

DoubleFullMatrix& DoubleFullMatrix::operator=(DoubleFullMatrix& aDoubleFullMatrix)
{
    if(aDoubleFullMatrix.GetRows()==GetRows() && aDoubleFullMatrix.GetCols()==GetCols())
    {
	for (unsigned int row = 1;row<=GetRows();row++)
	    for (unsigned int col = 1;col<=GetRows();col++)
		(*this)(row,col)=aDoubleFullMatrix(row,col);
    }
    return *this;
}

DoubleFullMatrix& DoubleFullMatrix::operator=(DOUBLE aNumber)
{
    for (unsigned int row = 1;row<=GetRows();row++)
	for (unsigned int col = 1;col<=GetRows();col++)
	    (*this)(row,col)=aNumber;
    return *this;
}

DoubleVector& DoubleFullMatrix::VectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect)
// Compute aDestVect = thisMatrix * aSrcVect
{
    DOUBLE	sum=0;
    unsigned int cols=GetCols(),rows=GetRows();
	
    if(cols==aSrcVect.GetLen() && rows==aDestVect.GetLen()) {
	for(INTEGER index1=1;index1<=rows;index1++) {
	    for(INTEGER index2=1;index2<=cols;index2++) {
		sum+=((*this)(index1,index2)*aSrcVect(index2));
	    }
	    aDestVect(index1)=sum;
	    sum=0;
	}
    }

    return aDestVect;
}

DoubleVector& DoubleFullMatrix::VectMult(DoubleVector& aSrcVect,DoubleVector& aDestVect,DOUBLE a1,DOUBLE a2)
// Compute aDestVect = a2 * aDestVect  +  a1 * thisMatrix * aSrcVect
{
    DOUBLE a;
    INTEGER index,index2;
	
    if(aSrcVect.GetLen()==GetRows() && aDestVect.GetLen()==GetRows()) {
	if(a1!=0) {
	    if(a2==0) {
		for(index=1;index<=GetRows();index++)
		    aDestVect(index)=aSrcVect(index)*(*this)(index,index);
	    } else {
		a=a2/a1;
		if(a!=1)
		    aDestVect*=a;
		for(index=1;index<=GetRows();index++)
		    aDestVect(index)+=aSrcVect(index)*(*this)(index,index);
	    }
	    for(index=1;index<=GetRows();index++) {
		for(index2=1;index2<=GetCols();index2++) {
		    aDestVect(index)+=((*this)(index,index2)*aSrcVect(index2));
		}
	    } 
	    if(a1!=1)
		aDestVect*=a1;
	} else {
	    aDestVect*=a2;
	}
    }

    return aDestVect;
}

unsigned int DoubleFullMatrix::FindPivot(unsigned int i)
{
    unsigned int j,maxindex=i;
    DOUBLE	maxelem=ABS(((*this)(i,i)));
	
    for(j=i+1;j<=GetRows();j++) {
	if(ABS(((*this)(j,i)))>maxelem) {
	    maxelem=ABS(((*this)(j,i)));
	    maxindex=j;
	}
    }
    return maxindex;
}

VOID DoubleFullMatrix::ExchangeRow(unsigned int source,unsigned int dest,DoubleVector *f)
{
    DOUBLE buf;
    unsigned int i;
	
    for(i=1;i<=GetCols();i++) {
	buf=(*this)(source,i);
	(*this)(source,i)=(*this)(dest,i);
	(*this)(dest,i)=buf;
    }
    buf=(*f)(source);
    (*f)(source)=(*f)(dest);
    (*f)(dest)=buf;
}

VOID DoubleFullMatrix::LR_Zerlegung(DoubleVector *f,DoubleVector *sol)
{
    INTEGER i,m,n,j,pivot;
    DOUBLE sum;
	
    for(i=1;i<=GetRows();i++) {
	pivot=FindPivot(i);
	if(pivot!=i) {
//			Prot<<"Pivot exchange row "<<i<<" with row "<<pivot<<"\n";
//			ExchangeRow(i,pivot,f);
	}
	for(m=i+1;m<=GetRows();m++) {
	    (*this)(m,i)/=(*this)(i,i);
	    (*f)(m)-=((*f)(i)*(*this)(m,i));
	    for(n=i+1;n<=GetCols();n++) {
		if((*this)(i,n)!=0) {
		    sum=(*this)(i,n)*(*this)(m,i);
		    if(ABS(((*this)(m,n)-sum))<1.0e-20) {
			(*this)(m,n)=0;
		    } else {
			(*this)(m,n)-=sum;
		    }
		}
	    }
	}
//		Prot<<"Zeile="<<i<<"     A=\n"<<(*this);
    }
		
    for(i=1;i<=GetRows();i++) {
	for(m=1;m<=GetCols();m++) {
	    if(m<i)
		(*this)(i,m)=0;
	}
    }
    for(i=GetRows();i>=1;i--) {
	sum=0;
	for(j=i+1;j<=GetRows();j++) 
	    sum+=(*sol)(j)*(*this)(i,j);
	(*sol)(i)=((*f)(i)-sum)/(*this)(i,i);
	if(ABS(((*sol)(i)))<1.0e-14)
	    (*sol)(i)=0;
//		Prot<<"Sol("<<i<<")=("<<(*f)(i)<<" - "<<sum<<") / "<<(*this)(i,i)<<"\n";
    }
}

Output& operator<<(Output& o,DoubleFullMatrix& aMatrix)
{
    for (unsigned int row = 1;row<=aMatrix.GetRows();row++)
    {
	for (unsigned int col = 1;col<=aMatrix.GetCols();col++)
	{
	    o<<"The value at row "<<row<<" ,column "<<col<<" = ";
	    o<<aMatrix(row,col)<<"\n";
	}
    }
    return o;
}
