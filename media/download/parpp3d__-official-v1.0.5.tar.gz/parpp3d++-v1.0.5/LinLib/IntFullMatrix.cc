#include "IntFullMatrix.h"

IntFullMatrix& IntFullMatrix::operator=(IntFullMatrix& anIntFullMatrix)
{
    if(anIntFullMatrix.GetRows()==GetRows() && anIntFullMatrix.GetCols()==GetCols())
    {
	for (unsigned int row = 1;row<=GetRows();row++)
	    for (unsigned int col = 1;col<=GetRows();col++)
		(*this)(row,col)=anIntFullMatrix(row,col);
    }
    return *this;
}

IntFullMatrix& IntFullMatrix::operator=(INTEGER aNumber)
{
    for (unsigned int row = 1;row<=GetRows();row++)
	for (unsigned int col = 1;col<=GetRows();col++)
	    (*this)(row,col)=aNumber;
    return *this;
}

IntVector& IntFullMatrix::VectMult(IntVector& aSrcVect,IntVector& aDestVect)
{
    int	sum=0;
    unsigned int cols=GetCols(),rows=GetRows();
	
    if (cols == aSrcVect.GetLen() && rows == aDestVect.GetLen()) {
	for (unsigned int index1 = 1; index1 <= rows; index1++) {
	    for (unsigned int index2 = 1; index2 <= cols; index2++) {
		sum += ((*this)(index1, index2) * aSrcVect(index2)); 
	    }
	    aDestVect(index1) = sum; 
	    sum = 0; 
	}
    }

    return aDestVect;
}

Output& operator<<(Output& o,IntFullMatrix& aMatrix)
{
    for (unsigned int row = 1;row<=aMatrix.GetRows();row++)
    {
	for (unsigned int col = 1;col<=aMatrix.GetCols();col++)
	{
	    o<<"The value at row "<<row<<" ,column "<<col<<" = ";
	    o<<aMatrix(row,col)<<"\n";
	}
    }
    return o;
}
