#include "DateTime.h"

DateTime::DateTime(VOID)
{
  SystemTime=MPI_Wtime();
}

VOID DateTime::SetTime(VOID)
{
  SystemTime=MPI_Wtime();
}

//  string DateTime::GetTime(void)
//  {
//      return system("date");
//  }

double DateTime::GetTimeDiff(VOID)
{
    double diff,temp;

    temp = MPI_Wtime();
  
//  return (temp-SystemTime)/CLOCK_TICK;
    diff = temp - SystemTime;
    if (diff < -1e8) {
	printf("!!!! Time difference negative: %f - %f = %f!!!\n", temp, SystemTime, temp - SystemTime);
  	printf("!!!! Check time synchronity of the nodes !!!\n");
        return 0;
    } else
        return diff;
}

Output& operator<<(Output& o,DateTime& aDateTime)
{
  o<<"Time (seconds): "<<aDateTime.GetTimeDiff()<<"\n";
  return o;
}


