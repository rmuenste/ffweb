#include "MemInfo.h"

MemInfo::MemInfo(void)
{
}

int MemInfo::GetFreeSpace(void)
{
#ifdef HAVA_MALLINFO
    info = mallinfo();
#endif
    STD_COUT << "Use of GetFreeSpace:\n"
//  	      << info.ordblks  << "/* number of ordinary blocks */\n"
//  	      << info.smblks   << "/* number of small blocks */\n"
//  	      << info.hblks    << "/* number of holding blocks */\n"
//  	      << info.hblkhd   << "/* space in holding block headers */\n"
	      << info.usmblks  << "/* space in small blocks in use */\n"
//  	      << info.fsmblks  << "/* space in free small blocks */\n" 
	      << info.uordblks << "/* space in ordinary blocks in use */\n"
//  	      << info.fordblks << "/* space in free ordinary blocks */\n"
//  	      << info.keepcost << "/* cost of enabling keep option */\n\n"
	;

    return 0;
//      info = mallinfo(); 
//      return info.FreeBytes; 
    
//      return 0;
}

Output& operator << (Output& o, MemInfo& aInfo)
{
//      aInfo.info = mallinfo(); 
//      o << "arena :  " << (long)aInfo.info.Arena << " bytes\n"; 
//      o << "free bytes : " << (long)aInfo.info.FreeBytes << " bytes\n"; 
//      o << "used blocks : " << (long)aInfo.info.UsedBlocks << " blocks\n"; 
//      o << "free blocks : " << (long)aInfo.info.FreeBlocks << " blocks\n"; 

//      o << "MemInfo not implemented (problems with mallinfo on Sp2) !!\n"; 

    return o;
}
