#include "IntVector.h"
#include "Protypes.h"
#include <math.h>

IntVector::IntVector(unsigned int mySize)
{
    Name     = "IntVector";
    Len      = mySize;
    aHandle  = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for (unsigned int index = 0; index < Len; index++)
	aHandle[index] = 0;
}

IntVector::IntVector(unsigned int mySize, BYTEPTR aName)
{
    Name     = aName;
    Len      = mySize;
    aHandle  = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for (unsigned int index = 0; index < Len; index++)
	aHandle[index] = 0;
}

IntVector::IntVector(const IntVector& anIntVector)
{
    unsigned int size = anIntVector.Len;

    Name     = anIntVector.Name;
    Len      = size;
    aHandle  = new int[Len];

    memtest(aHandle, sizeof(int) * Len);

    for (unsigned int index = 0; index < Len; index++)
	aHandle[index] = anIntVector.aHandle[index];
}

IntVector& IntVector::operator=(IntVector& anIntVector)
{
    unsigned int size = anIntVector.Len;

    if (Len >= size) {
	for (unsigned int index = 0; index < size; index++)
	    aHandle[index]=anIntVector.aHandle[index];
    }
    return *this;
}

IntVector& IntVector::operator=(int aNumber)
{
    for (unsigned int index = 1;index<=GetLen();index++) {
	(*this)(index)=aNumber;
    }
    return *this;
}

IntVector& operator+=(IntVector& a1,IntVector& a2)
{
    if(a1.GetLen()==a2.GetLen()) {
	for (unsigned int index = 1;index<=a1.GetLen();index++)
	    a1(index)=a1(index)+a2(index);
    }
    return a1;
}

IntVector& operator-=(IntVector& a1,IntVector& a2)
{
    if(a1.GetLen()==a2.GetLen()) {
	for (unsigned int index = 1;index<=a1.GetLen();index++)
	    a1(index)=a1(index)-a2(index);
    }
    return a1;
}

IntVector& operator*=(IntVector& a1,int aNumber)
{
    for (unsigned int index = 1;index<=a1.GetLen();index++)
	a1(index)=a1(index)*aNumber;
    return a1;
}

Output& operator<<(Output& o,IntVector& anIntVector)
{
    for (unsigned int index = 1;index<=anIntVector.GetLen();index++)
    {
	o<<"The value at index position "<<index<<"=";
	o<<anIntVector(index)<<"\n";
    }
    return o;
}

DOUBLE operator*(IntVector& v1,IntVector& v2)
{
    DOUBLE temp=0;

    if(v1.GetLen()!=v2.GetLen()) {
// ********** Error : different vectors **********
	Err<<"IntVector: different vectors !!   Name:"<<v1.GetName()<<"\n";
	exit(1);
    }

    for (unsigned int index = 1;index<=v1.GetLen();index++)
	temp+=v1(index)*v2(index);

    return temp;
}

DOUBLE IntVector::l2Norm(void)
{
    DOUBLE temp=*this* *this;

    if(temp!=0)
	return sqrt(temp);

    return 0;
}

int IntVector::MaxNorm(void)
{
    int MaxValue=ABS((*this)(1));

    for (unsigned int index = 2;index<=GetLen();index++)
	if(ABS((*this)(index))>MaxValue)
	    MaxValue=ABS((*this)(index));

    return MaxValue;
}

int IntVector::MaxNorm(unsigned int& MaxIndex)
{
    int MaxValue=ABS((*this)(1));

    MaxIndex=1;
    for (unsigned int index = 2;index<=GetLen();index++) {
	if(ABS((*this)(index))>MaxValue) {
	    MaxValue=ABS((*this)(index));
	    MaxIndex=index;
	}
    }

    return MaxValue;
}

// Vector addition  v1=v2+v3
void VecAdd(IntVector& v1,IntVector& v2,IntVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index)=v2(index) + v3(index);
}

void VecAdd(IntVector& v1,RealVector& v2,IntVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) + v3(index));
}

void VecAdd(IntVector& v1,IntVector& v2,RealVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) + v3(index));
}

void VecAdd(IntVector& v1,DoubleVector& v2,IntVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) + v3(index));
}

void VecAdd(IntVector& v1,IntVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) + v3(index));
}

void VecAdd(IntVector& v1,RealVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) + v3(index));
}

void VecAdd(IntVector& v1,DoubleVector& v2,RealVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) + v3(index));
}

// Vector substraction  v1=v2 - v3
void VecSub(IntVector& v1,IntVector& v2,IntVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index)=v2(index) - v3(index);
}

void VecSub(IntVector& v1,RealVector& v2,IntVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) - v3(index));
}

void VecSub(IntVector& v1,IntVector& v2,RealVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) - v3(index));
}

void VecSub(IntVector& v1,DoubleVector& v2,IntVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) - v3(index));
}

void VecSub(IntVector& v1,IntVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) - v3(index));
}

void VecSub(IntVector& v1,RealVector& v2,DoubleVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) - v3(index));
}

void VecSub(IntVector& v1,DoubleVector& v2,RealVector& v3)
{
    for (unsigned int index = 1;index<=v1.GetLen();index++)
	v1(index) = (int)(v2(index) - v3(index));
}

void IntVector::memtest(int *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for IntVector (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
