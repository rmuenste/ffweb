#include "Input.h"


Input::Input(BYTEPTR aName) 
{
//  File=new ifstream(aName);
  File=fopen(aName,"r");
  if(!File) {
    Err<<"Couldnt open file "<<aName;
    exit(1);
  }
}

Input::~Input(VOID)
{
  //  delete File;
  fclose(File);
}

Input& Input::operator>>(DOUBLE& aNumber)
{	
  if(File) {
    //  (*File).precision(5);
    //  (*File)>>aNumber;
    fscanf(File,"%lf",&aNumber);
  }
  return *this;
}

Input& Input::operator>>(REAL& aNumber)
{
  if(File) {
    //  (*File).precision(5);
    //  (*File)>>aNumber;
    fscanf(File,"%f",&aNumber);
  }
  return *this;
}


Input& Input::operator>>(INTEGER& aNumber)
{
  if(File)
    //  (*File)>>aNumber;
    fscanf(File,"%d",&aNumber);
  return *this;
}

Input& Input::operator>>(unsigned int& aNumber)
{
  if(File)
    //  (*File)>>aNumber;
    fscanf(File,"%d",&aNumber);
  return *this;
}

VOID Input::ReadParam(INTEGER& NumElements,INTEGER& NumVertices,INTEGER& NumEdges,INTEGER& NumVertElem,INTEGER& NumVertBound)
{
  if(File) {
    GoToNextLine();
    GoToNextLine();
    (*this)>>NumElements;
    (*this)>>NumVertices;
    (*this)>>NumEdges;
    (*this)>>NumVertElem;
    (*this)>>NumVertBound;
  }
}

VOID Input::ReadCoord(DoubleArray2D* VertCoord,INTEGER NumVertices)
{
  if(File) {
    GoToNextLine();
    GoToNextLine();
    for(INTEGER i=1;i<=NumVertices;i++) {
      (*this)>>(*VertCoord)(1,i);
      (*this)>>(*VertCoord)(2,i);
    }
  }
}

VOID Input::ReadVertElem(IntArray2D* VertElem,INTEGER NumElements,INTEGER NumVertElem)
{
  if(File) {
    GoToNextLine();
    GoToNextLine();
    for(INTEGER i=1;i<=NumElements;i++) {
      for(INTEGER j=1;j<=NumVertElem;j++) {
	(*this)>>(*VertElem)(j,i);
      }
    }
  }
}

VOID Input::ReadInfoVertEdge(IntArray* InfoVertEdge,INTEGER NumVertices)
{
  if(File) {
    GoToNextLine();
    GoToNextLine();
    for(INTEGER i=1;i<=NumVertices;i++) {
      (*this)>>(*InfoVertEdge)(i);
    }
  }
}

VOID Input::ReadInfoVertBound(IntArray2D* InfoVertBound,INTEGER NumBound)
{
  if(File) {
    GoToNextLine();
    GoToNextLine();
    for(INTEGER i=1;i<=NumBound;i++) {
      (*this)>>(*InfoVertBound)(1,i);
      (*this)>>(*InfoVertBound)(2,i);
    }
  }
}

VOID Input::GoToNextLine(VOID)
{
  char c;
  
//  (*File).get(c);
  c=fgetc(File);
  while(c!='\n') {
//    (*File).get(c);
    c=fgetc(File);
  }
}


