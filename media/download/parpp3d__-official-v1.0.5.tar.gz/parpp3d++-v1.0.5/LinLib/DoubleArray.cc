#include "DoubleArray.h"
#include "Protypes.h"
#include "Global.h"

DoubleArray::DoubleArray(unsigned int mySize)
{
    Name    = "DoubleArray";
    Len     = mySize;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index =0;index<mySize;index++)
	aHandle[index]=0;
}

DoubleArray::DoubleArray(unsigned int mySize,BYTEPTR aName)
{
    Name    = aName;
    Len     = mySize;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index =0;index<mySize;index++)
	aHandle[index]=0;
}

DoubleArray::DoubleArray(DoubleArray& anDoubleArray)
{
    unsigned int size=anDoubleArray.GetLen();

    Name    = anDoubleArray.Name;
    Len     = size;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index =0;index<size;index++)
	aHandle[index]=anDoubleArray.aHandle[index];
}

DoubleArray& DoubleArray::operator=(DoubleArray& anDoubleArray)
{
    unsigned int size=anDoubleArray.GetLen();

    if(GetLen()>=size) {
	for (unsigned int index =1;index<=size;index++)
	    (*this)(index)=anDoubleArray(index);
    }
    return *this;
}

DoubleArray& DoubleArray::operator=(double aNumber)
{
    for (unsigned int index =1;index<=GetLen();index++) {
	(*this)(index)=aNumber;
    }
    return *this;
}

DoubleArray& operator+=(DoubleArray& a1,DoubleArray& a2)
{
    for (unsigned int index =1;index<=a1.GetLen();index++)
	a1(index)=a1(index)+a2(index);
    return a1;
}

DoubleArray& operator-=(DoubleArray& a1,DoubleArray& a2)
{
    for (unsigned int index =1;index<=a1.GetLen();index++)
	a1(index)=a1(index)-a2(index);
    return a1;
}

DoubleArray& operator*=(DoubleArray& a1,double aNumber)
{
    for (unsigned int index =1;index<=a1.GetLen();index++)
	a1(index)=a1(index)*aNumber;
    return a1;
}

Output& operator<<(Output& o,DoubleArray& anDoubleArray)
{
    for (unsigned int index =1;index<=anDoubleArray.GetLen();index++)
    {
	o<<"The value at index position "<<index<<"=";
	o<<anDoubleArray(index)<<"\n";
    }
    return o;
}

void DoubleArray::memtest(double *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for DoubleArray (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
