#ifndef REALCOMPACTMATRIXH

#define REALCOMPACTMATRIXH

#include "math.h"
#include "IntArray.h"
#include "RealArray.h"
#include "RealVector.h"

class RealCompactMatrix:public RealArray
{
private:
    UNSIGNED 		NumData;
    UNSIGNED		NumDiag;
    IntArray *Column;
    IntArray *Diagonal;

public:
    RealCompactMatrix(UNSIGNED aNumData,UNSIGNED aNumDiag)
	:RealArray(aNumData),NumData(aNumData),NumDiag(aNumDiag+1)
	{Column=new IntArray(aNumData);Diagonal=new IntArray(aNumDiag+1);
	(*Diagonal)(aNumDiag+1)=aNumData+1;}
				
    RealCompactMatrix(UNSIGNED aNumData,UNSIGNED aNumDiag,BYTEPTR aName)
	:RealArray(aNumData,aName),NumData(aNumData),NumDiag(aNumDiag+1) 
	{Column=new IntArray(aNumData);Diagonal=new IntArray(aNumDiag+1);
	(*Diagonal)(aNumDiag+1)=aNumData+1;}
				
    ~RealCompactMatrix(VOID);

// Methods for Compact-Matrix
    RealCompactMatrix& operator=(RealCompactMatrix& aRealCompMatrix);
    RealCompactMatrix& operator=(REAL aNumber);
    REAL& operator()(UNSIGNED aRow,UNSIGNED aCol);
    REAL&	SetElement(UNSIGNED DiagPos,UNSIGNED DiagVal,UNSIGNED ColPos,UNSIGNED ColVal,UNSIGNED DataPos);
		
    INTEGER& Col(UNSIGNED aPos) {
#ifdef DEBUG
	if(aPos<1 || aPos>NumData) {
	    Err<<"WRONG ACCESS TO REALCOMPACTMATRIX !! Name:"<<GetName()<<"\n";
	    exit(1);
	}
#endif
	return (*Column)(aPos);
    }
    INTEGER& Diag(UNSIGNED aPos) {
#ifdef DEBUG
	if(aPos<1 || aPos>NumDiag) {
	    Err<<"WRONG ACCESS TO REALCOMPACTMATRIX !! Name:"<<GetName()<<"\n";
	    exit(1);
	}
#endif
	return (*Diagonal)(aPos);
    }
    REAL& 	Data(UNSIGNED aPos) {
#ifdef DEBUG
	if(aPos<1 || aPos>NumData) {
	    Err<<"WRONG ACCESS TO REALCOMPACTMATRIX !! Name:"<<GetName()<<"\n";
	    exit(1);
	}
#endif
	return ((RealArray&)(*this))(aPos);
    }
    UNSIGNED GetNumDiag() {return NumDiag-1;}
		
    RealVector& VectMult(RealVector& aSrcVect,RealVector& aDestVect);
    RealVector& Jacobi(RealVector& x,RealVector& b,UNSIGNED Nit,DOUBLE Eps,DOUBLE Omega);
    RealVector& GaussSeidel(RealVector& x,RealVector& b,UNSIGNED Nit,DOUBLE Eps);
    RealVector& SOR(RealVector& x,RealVector& b,UNSIGNED Nit,DOUBLE Eps,DOUBLE Omega);
    RealVector& PrecondSOR(RealVector& x,DOUBLE Omega);
    VOID			   ILU(INTEGER ILU,DOUBLE Alpha,DOUBLE Tol);
    RealVector& CG(RealVector& x,RealVector& b,UNSIGNED Nit,DOUBLE Eps,DOUBLE Omega);
		
    friend Output& operator<<(Output& o,RealCompactMatrix& aMatrix);
};	


#endif
