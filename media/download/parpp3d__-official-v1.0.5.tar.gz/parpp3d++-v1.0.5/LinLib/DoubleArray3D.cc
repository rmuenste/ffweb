#include "DoubleArray3D.h"

DoubleArray3D::DoubleArray3D(unsigned int myDimX,unsigned int myDimY,unsigned int myDimZ)
{
    Name    = "DoubleArray3D";
    Len     = myDimX * myDimY * myDimZ;
    DimX    = myDimX;
    DimY    = myDimY;
    DimZ    = myDimZ;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index=0;index<Len;index++)
	aHandle[index]=0;
}

DoubleArray3D::DoubleArray3D(unsigned int myDimX,unsigned int myDimY,unsigned int myDimZ,BYTEPTR aName)
{
    Name    = aName;
    Len     = myDimX * myDimY * myDimZ;
    DimX    = myDimX;
    DimY    = myDimY;
    DimZ    = myDimZ;
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int index=0;index<Len;index++)
	aHandle[index]=0;
}

DoubleArray3D::DoubleArray3D(DoubleArray3D& anDoubleArray3D)
{
    unsigned int size=anDoubleArray3D.GetLen();

    Name    = anDoubleArray3D.Name;
    Len     = size;
    DimX    = anDoubleArray3D.GetDimX();
    DimY    = anDoubleArray3D.GetDimY();
    DimZ    = anDoubleArray3D.GetDimZ();
    aHandle = new double[Len];

    memtest(aHandle, sizeof(double) * Len);

    for (unsigned int x = 1; x <= DimX; x++)
	for (unsigned int y = 1;y <= DimY; y++)
	    for (unsigned int z = 1; z <= DimZ; z++)
		(*this)(x,y,z)=anDoubleArray3D(x,y,z);
}

DoubleArray3D& DoubleArray3D::operator=(DoubleArray3D& aDoubleArray3D)
{
//  unsigned int size=aDoubleArray3D.GetLen();

    if(aDoubleArray3D.DimX<=DimX && aDoubleArray3D.DimY<=DimY && aDoubleArray3D.DimZ<=DimZ)
    {
	for (unsigned int x = 1;x<=aDoubleArray3D.DimX;x++)
	    for (unsigned int y=1;y<=aDoubleArray3D.DimY;y++)
		for (unsigned int z = 1;z<=aDoubleArray3D.DimZ;z++)
		    (*this)(x,y,z)=aDoubleArray3D(x,y,z);
    }
    return *this;
}

DoubleArray3D& DoubleArray3D::operator=(DOUBLE aNumber)
{
    for (unsigned int x=1;x<=DimX;x++)
	for (unsigned int y = 1;y<=DimY;y++)
	    for (unsigned int z=1;z<=DimZ;z++)
		(*this)(x,y,z)=aNumber;
    return *this;
}

DoubleArray3D& operator+=(DoubleArray3D& a1,DoubleArray3D& a2)
{
    if(a1.DimX==a2.DimX && a1.DimY==a2.DimY && a1.DimZ==a2.DimZ) {
	for (unsigned int x = 1;x<=a1.DimX;x++)
	    for (unsigned int y=1;y<=a1.DimY;y++)
		for (unsigned int z = 1;z<=a1.DimZ;z++)
		    a1(x,y,z)=a1(x,y,z)+a2(x,y,z);
    }
    return a1;
}

DoubleArray3D& operator-=(DoubleArray3D& a1,DoubleArray3D& a2)
{
    if(a1.DimX==a2.DimX && a1.DimY==a2.DimY && a1.DimZ==a2.DimZ) {
	for (unsigned int x = 1; x <= a1.DimX; x++)
	    for (unsigned int y = 1; y <= a1.DimY; y++)
		for (unsigned int z = 1; z <= a1.DimZ; z++)
		    a1(x,y,z)=a1(x,y,z)-a2(x,y,z);
    }
    return a1;
}

DoubleArray3D& operator*=(DoubleArray3D& a1,DOUBLE aNumber)
{
    for (unsigned int x = 1; x <= a1.DimX; x++)
	for (unsigned int y = 1;y <= a1.DimY; y++)
	    for (unsigned int z = 1;z <= a1.DimZ; z++)
		a1(x,y,z)=a1(x,y,z)*aNumber;
    return a1;
}

Output& operator<<(Output& o,DoubleArray3D& aDoubleArray3D)
{
    for (unsigned int x = 1; x <= aDoubleArray3D.DimX; x++) {
	for(unsigned int y = 1; y <= aDoubleArray3D.DimY; y++) {
	    for (unsigned int z = 1; z <= aDoubleArray3D.DimZ; z++) {
		o<<"The value in ( "<<x<<","<<y<<","<<z<<")  = ";
		o<<aDoubleArray3D(x,y,z)<<"\n";
	    }
	}
    }
    return o;
}

void DoubleArray3D::memtest(double *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for DoubleArray3D (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
