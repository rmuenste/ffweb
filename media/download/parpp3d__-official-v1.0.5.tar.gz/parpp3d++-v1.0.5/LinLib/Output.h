#ifndef OUTPUTH

#define OUTPUTH
#include <string>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "MyTypes.h"

#ifdef MAC_CODE
#include <LWindow.h>
#include "CTextDoc.h"
#endif

#define SCREEN_FLAG     1
#define FILE_FLAG       2
#define DOC_FLAG        3

#define YES             0
#define NO              1

extern std::string progname;

class Output
{
private:
    FILE        *File;
    unsigned     Type;
    unsigned     Flag;
#ifdef MAC_CODE
    CTextDoc    *mDoc;
#endif

    char         strbuf[1024];

public:
    Output(UNSIGNED aFlag) : Type(SCREEN_FLAG),Flag(aFlag) {}

#ifdef MAC_CODE
    Output(UNSIGNED aFlag) : Type(SCREEN_FLAG),Flag(aFlag),mDoc(NULL) {}
#endif

    Output(BYTEPTR aName,UNSIGNED aFlag);

#ifdef MAC_CODE
    Output(UNSIGNED Type,UNSIGNED aFlag) : Type(DOC_FLAG),Flag(aFlag),mDoc(NULL) {}
#endif

    ~Output(void);

    FILE     *OpenFile(BYTEPTR Name);
    void      CloseFile(FILE *File);
    void      CloseFile();
    void      SetFile(BYTEPTR Name);
    void      SetFile(FILE *MyFile);
    void      SetScreen(VOID);
    void      SetFlag(UNSIGNED mflag);
    void      Flush();

#ifdef MAC_CODE
    VOID      SetDoc(CTextDoc *doc) {mDoc=doc;}
#endif
    
    Output& operator<<(INTEGER aNumber);
    Output& operator<<(REAL aNumber);
    Output& operator<<(DOUBLE aNumber);
#ifdef MAC_CODE
    Output& operator<<(extended aNumber);
#endif
    Output& operator<<(UNSIGNED aNumber);
    Output& operator<<(LONG aNumber);
    Output& operator<<(BYTEPTR aString);
    Output& operator<<(std::string aString);
};      

#endif
