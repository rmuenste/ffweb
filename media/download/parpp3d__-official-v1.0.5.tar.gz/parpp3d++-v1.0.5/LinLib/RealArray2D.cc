#include "RealArray2D.h"

RealArray2D::RealArray2D(unsigned int myRows,unsigned int myCols)
{
    Name    = "RealArray2D";
    Len     = myRows * myCols;
    Rows    = myRows;
    Cols    = myCols;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index =0;index<Len;index++)
	aHandle[index]=0;
}

RealArray2D::RealArray2D(unsigned int myRows,unsigned int myCols,BYTEPTR aName)
{
    Name    = aName;
    Len     = myRows * myCols;
    Rows    = myRows;
    Cols    = myCols;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index =0;index<Len;index++)
	aHandle[index]=0;
}

RealArray2D::RealArray2D(RealArray2D& anRealArray2D)
{
    unsigned int size=anRealArray2D.GetLen();
	
    Name    = anRealArray2D.Name;
    Len     = size;
    Rows    = anRealArray2D.GetRows();
    Cols    = anRealArray2D.GetCols();
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int row = 1;row<=Rows;row++)
	for (unsigned int col = 1;col<=Cols;col++)
	    (*this)(row,col)=anRealArray2D(row,col);
}

RealArray2D& RealArray2D::operator=(RealArray2D& aRealArray2D)
{
//  unsigned int size=aRealArray2D.GetLen();
	
    if(aRealArray2D.Rows<=Rows && aRealArray2D.Cols<=Cols)
    {
	for (unsigned int row = 1;row<=aRealArray2D.Rows;row++)
	    for (unsigned int col = 1;col<=aRealArray2D.Cols;col++)
		(*this)(row,col)=aRealArray2D(row,col);
    }
    return *this;
}

RealArray2D& RealArray2D::operator=(REAL aNumber)
{
    for (unsigned int row = 1;row<=Rows;row++)
	for (unsigned int col = 1;col<=Cols;col++)
	    (*this)(row,col)=aNumber;
    return *this;
}

RealArray2D& operator+=(RealArray2D& a1,RealArray2D& a2)
{
    if(a1.Rows==a2.Rows && a1.Cols==a2.Cols) {
	for (unsigned int row = 1;row<=a1.Rows;row++)
	    for (unsigned int col = 1;col<=a1.Cols;col++)
		a1(row,col)=a1(row,col)+a2(row,col);
    }
    return a1;
}

RealArray2D& operator-=(RealArray2D& a1,RealArray2D& a2)
{
    if(a1.Rows==a2.Rows && a1.Cols==a2.Cols) {
	for (unsigned int row = 1;row<=a1.Rows;row++)
	    for (unsigned int col = 1;col<=a1.Cols;col++)
		a1(row,col)=a1(row,col)-a2(row,col);
    }
    return a1;
}

RealArray2D& operator*=(RealArray2D& a1,REAL aNumber)
{
    for (unsigned int row = 1;row<=a1.Rows;row++)
	for (unsigned int col = 1;col<=a1.Cols;col++)
	    a1(row,col)=a1(row,col)*aNumber;
    return a1;
}

Output& operator<<(Output& o,RealArray2D& anRealArray2D)
{
    for (unsigned int row = 1;row<=anRealArray2D.Rows;row++)
    {
	for (unsigned int col = 1;col<=anRealArray2D.Cols;col++) {
	    o<<"The value in row "<<row<<" col "<<col<<" = ";
	    o<<anRealArray2D(row,col)<<"\n";
	}
    }
    return o;
}

void RealArray2D::memtest(float *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for RealArray2D (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
