#ifndef INTARRAYH

#define INTARRAYH

#include <stdlib.h>
#include "MyTypes.h"
#include "Global.h"

extern int MyProcID;

class IntArray
{
private:
    INTEGER *aHandle;
    UNSIGNED Len;
    BYTEPTR	Name;
    std::string  message;			  // Will act as "composer" for error messages
                                                  // This speeds up compilation with templates and
                                                  // reduces code. (No need to write code both for STD_CERR and protocol)
		
public:
    IntArray(UNSIGNED mySize);
    IntArray(UNSIGNED mySize,BYTEPTR aName);
    IntArray(IntArray& anIntArray);
    ~IntArray(VOID) {delete[] aHandle;}
		
    int& operator()(unsigned int index) {
#ifdef DEBUG
	if (index < 1  ||  index > GetLen()) {
            std::string message
                = "pp3d++ (process " + int_to_string(MyProcID, 0) + "):\n"
                + "  Unrecoverable error discovered:\n"
                + "    Wrong access to an object of type IntArray with name" + GetName() + ":\n";

	    if (index < 1) {
		message += "    Trying to access array with too small row index: " + int_to_string(index) + ".\n";
	    } else if (index > GetLen()) {
		message += "    Trying to access array with too large row index: " + int_to_string(index)
		         + ". Maximum allowed: " + int_to_string(GetLen()) + ".\n";
	    }

            STD_CERR << message;
            protocol  << message;

	    exit(ARRAY_LIMIT_ERROR);
	}
#endif
	return aHandle[index-1];
    }
		
    unsigned int  GetLen(VOID) {return Len;}
    BYTEPTR	  GetName(VOID) {return Name;}
    int          *GetDataPtr(VOID) {return aHandle;}

    void memtest(int *aHandle, unsigned int bytesRequested);
		
    IntArray& operator=(IntArray& anIntArray);
    IntArray& operator=(INTEGER aNumber);
// Array addition  a1+=a2
    friend IntArray& operator+=(IntArray& a1,IntArray& a2);
// Array substraction a1-=a2
    friend IntArray& operator-=(IntArray& a1,IntArray& a2);
// Scales a Array by a constant  a1=aNumber*a1
    friend IntArray& operator*=(IntArray& v1,INTEGER aNumber);
		
    friend Output& operator<<(Output& o,IntArray& anIntArray);
};

#endif
