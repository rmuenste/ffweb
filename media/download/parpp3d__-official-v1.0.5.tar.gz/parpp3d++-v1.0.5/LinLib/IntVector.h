#ifndef INTVECTORH

#define INTVECTORH

#include <stdlib.h>
#include "MyTypes.h"
#include "Global.h"

class IntVector
{
private:
    INTEGER *aHandle;
    UNSIGNED Len;
    BYTEPTR	Name;
    std::string message;			  // Will act as "composer" for error messages
						  // This speeds up compilation with templates and
						  // reduces code. (No need to write code both for STD_CERR and protocol)

public:
    IntVector(UNSIGNED mySize);
    IntVector(UNSIGNED mySize,BYTEPTR aName);
    IntVector(const IntVector& anIntVector);
    ~IntVector(VOID) {delete[] aHandle;}

    INTEGER& operator()(UNSIGNED index) {
#ifdef DEBUG
	if (index < 1  ||  index > GetLen()) {
            message
                = "pp3d++ (process " + int_to_string(MyProcID, 0) + "):\n"
                + "  Unrecoverable error discovered:\n"
                + "    Wrong access to an object of type IntVector with name" + GetName() + ":\n";

	    if (index < 1) {
		message += "    Trying to access array with too small row index: " + int_to_string(index) + ".\n";
	    } else if (index > GetLen()) {
		message += "    Trying to access array with too large row index: " + int_to_string(index)
		         + ". Maximum allowed: " + int_to_string(GetLen()) + ".\n";
	    }

            STD_CERR << message;
            protocol  << message;

	    exit(ARRAY_LIMIT_ERROR);
	}
#endif
	    return aHandle[index-1];
	}

    UNSIGNED	GetLen(VOID) {return Len;}
    BYTEPTR	GetName(VOID) {return Name;}

    void memtest(int *aHandle, unsigned int bytesRequested);

    IntVector& operator=(IntVector& anIntVector);
    IntVector& operator=(INTEGER aNumber);

// Vector addition  a1+=a2
    friend IntVector& operator+=(IntVector& a1,IntVector& a2);
// Vector substraction a1-=a2
    friend IntVector& operator-=(IntVector& a1,IntVector& a2);
// Scales a Vector by a constant  a1=aNumber*a1
    friend IntVector& operator*=(IntVector& v1,INTEGER aNumber);

// Dot product of two vectors   (DOUBLE)aNumber=v1*v2
    friend DOUBLE	operator*(IntVector& v1,IntVector& v2);
// l2-Norm
    DOUBLE l2Norm(VOID);
// Max-Norm
    INTEGER MaxNorm(VOID);
    INTEGER MaxNorm(UNSIGNED& MaxIndex);

    friend Output& operator<<(Output& o,IntVector& anIntVector);
};

#endif
