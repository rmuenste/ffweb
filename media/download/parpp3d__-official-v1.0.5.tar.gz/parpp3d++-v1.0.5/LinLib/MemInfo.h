#ifndef MEMINFOH

#define MEMINFOH

#ifdef NO_NAMESPACE_STD_USAGE
# define STD_CIN   cin
# define STD_COUT  cout
# define STD_CERR  cerr
#else
# define STD_CIN   std::cin
# define STD_COUT  std::cout
# define STD_CERR  std::cerr
#endif

extern "C" {
#include <sys/types.h>
}

extern "C" {
//      struct mallinfo_t {
//  	size_t	Arena;			/* arena size			*/
//  	size_t	FreeBytes;		/* free bytes in the arena	*/
//  	size_t	UsedBlocks;		/* total blocks used		*/
//  	size_t	FreeBlocks;		/* total blocks free		*/
//      };
    struct mallinfo_t {
        unsigned long arena;    /* total space in arena */
        unsigned long ordblks;  /* number of ordinary blocks */
        unsigned long smblks;   /* number of small blocks */
        unsigned long hblks;    /* number of holding blocks */
        unsigned long hblkhd;   /* space in holding block headers */
        unsigned long usmblks;  /* space in small blocks in use */
        unsigned long fsmblks;  /* space in free small blocks */
        unsigned long uordblks; /* space in ordinary blocks in use */
        unsigned long fordblks; /* space in free ordinary blocks */
        unsigned long keepcost; /* cost of enabling keep option */
    };

    struct mallinfo_t mallinfo(void);
}

#include "Output.h"
#include "MyTypes.h"

class MemInfo
{
private:
    struct mallinfo_t info;
  
public:
    MemInfo(VOID);
  
    int GetFreeSpace(VOID);
    friend Output& operator<<(Output& o,MemInfo& aInfo);
};

#endif
