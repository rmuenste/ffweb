#ifndef DOUBLEVECTORH

#define DOUBLEVECTORH

#include <stdlib.h>
#include "MyTypes.h"
#include "Global.h"

class DoubleVector
{
private:
    double *aHandle;
    unsigned int Len;
    BYTEPTR	Name;
    std::string message;			  // Will act as "composer" for error messages
						  // This speeds up compilation with templates and
						  // reduces code. (No need to write code both for STD_CERR and protocol)

public:
    DoubleVector(unsigned int mySize);
    DoubleVector(unsigned int mySize, BYTEPTR aName);
    DoubleVector(DoubleVector& aDoubleVector);
    ~DoubleVector(void) {delete[] aHandle;}

    double& operator()(unsigned int index) {
#ifdef DEBUG
	if (index < 1  ||  index > GetLen()) {
            message
                = "pp3d++ (process " + int_to_string(MyProcID, 0) + "):\n"
                + "  Unrecoverable error discovered:\n"
                + "    Wrong access to an object of type DoubleVector with name " + GetName() + ":\n";

	    if (index < 1) {
		message += "    Trying to access array with too small row index: " + int_to_string(index) + ".\n";
	    } else if (index > GetLen()) {
		message += "    Trying to access array with too large row index: " + int_to_string(index)
		         + ". Maximum allowed: " + int_to_string(GetLen()) + ".\n";
	    }

            STD_CERR << message;
            protocol  << message;

	    exit(ARRAY_LIMIT_ERROR);
	}
#endif
	    return aHandle[index-1];
	}

    unsigned int	GetLen (void) { return Len;     }
    BYTEPTR		GetName(void) { return Name;    }
    double          *GetDataPtr(void) { return aHandle; }

    void memtest(double *aHandle, unsigned int bytesRequested);

    DoubleVector& operator=(DoubleVector& aDoubleVector);
    DoubleVector& operator=(double aNumber);

    // Vector addition  a1+=a2
    friend DoubleVector& operator += (DoubleVector& a1, DoubleVector& a2); 
    // Vector substraction a1 -= a2
    friend DoubleVector& operator -= (DoubleVector& a1, DoubleVector& a2); 
    // Scales a Vector by a constant  a1 = aNumber * a1
    friend DoubleVector& operator *= (DoubleVector& v1, double aNumber); 

//  VectorA+=Alpha*VectorB
    DoubleVector& AddMultConst(DoubleVector& aDoubleVector,double aNumber);
    // Dot product of two vectors   (double)aNumber=v1*v2
    friend double	operator*(DoubleVector& v1,DoubleVector& v2);
    // l2-Norm
    double l2Norm(void);
    // Max-Norm
    double MaxNorm(void);
    double MaxNorm(unsigned int& MaxIndex);

    friend Output& operator<<(Output& o,DoubleVector& anDoubleVector);
};

#endif
