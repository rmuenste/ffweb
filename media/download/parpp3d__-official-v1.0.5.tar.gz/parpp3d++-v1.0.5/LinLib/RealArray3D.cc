#include "RealArray3D.h"

RealArray3D::RealArray3D(unsigned int myDimX,unsigned int myDimY,unsigned int myDimZ)
{
    Name    = "RealArray3D";
    Len     = myDimX * myDimY * myDimZ;
    DimX    = myDimX;
    DimY    = myDimY;
    DimZ    = myDimZ;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index =0;index<Len;index++)
	aHandle[index]=0;
}

RealArray3D::RealArray3D(unsigned int myDimX,unsigned int myDimY,unsigned int myDimZ,BYTEPTR aName)
{
    Name    = aName;
    Len     = myDimX * myDimY * myDimZ;
    DimX    = myDimX;
    DimY    = myDimY;
    DimZ    = myDimZ;
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int index =0;index<Len;index++)
	aHandle[index]=0;
}

RealArray3D::RealArray3D(RealArray3D& anRealArray3D)
{
    unsigned int size=anRealArray3D.GetLen();

    Name    = anRealArray3D.Name;
    Len     = size;
    DimX    = anRealArray3D.GetDimX();
    DimY    = anRealArray3D.GetDimY();
    DimZ    = anRealArray3D.GetDimZ();
    aHandle = new float[Len];

    memtest(aHandle, sizeof(float) * Len);

    for (unsigned int x = 1;x<=DimX;x++)
	for (unsigned int y = 1;y<=DimY;y++)
	    for (unsigned int z = 1;z<=DimZ;z++)
		(*this)(x,y,z)=anRealArray3D(x,y,z);
}

RealArray3D& RealArray3D::operator=(RealArray3D& aRealArray3D)
{
//  unsigned int size=aRealArray3D.GetLen();

    if(aRealArray3D.DimX<=DimX && aRealArray3D.DimY<=DimY && aRealArray3D.DimZ<=DimZ)
    {
	for (unsigned int x = 1;x<=aRealArray3D.DimX;x++)
	    for (unsigned int y = 1;y<=aRealArray3D.DimY;y++)
		for (unsigned int z = 1;z<=aRealArray3D.DimZ;z++)
		    (*this)(x,y,z)=aRealArray3D(x,y,z);
    }
    return *this;
}

RealArray3D& RealArray3D::operator=(REAL aNumber)
{
    for (unsigned int x = 1;x<=DimX;x++)
	for (unsigned int y = 1;y<=DimY;y++)
	    for (unsigned int z = 1;z<=DimZ;z++)
		(*this)(x,y,z)=aNumber;
    return *this;
}

RealArray3D& operator+=(RealArray3D& a1,RealArray3D& a2)
{
    if(a1.DimX==a2.DimX && a1.DimY==a2.DimY && a1.DimZ==a2.DimZ) {
	for (unsigned int x = 1;x<=a1.DimX;x++)
	    for (unsigned int y = 1;y<=a1.DimY;y++)
		for (unsigned int z = 1;z<=a1.DimZ;z++)
		    a1(x,y,z)=a1(x,y,z)+a2(x,y,z);
    }
    return a1;
}

RealArray3D& operator-=(RealArray3D& a1,RealArray3D& a2)
{
    if(a1.DimX==a2.DimX && a1.DimY==a2.DimY && a1.DimZ==a2.DimZ) {
	for (unsigned int x = 1;x<=a1.DimX;x++)
	    for (unsigned int y = 1;y<=a1.DimY;y++)
		for (unsigned int z = 1;z<=a1.DimZ;z++)
		    a1(x,y,z)=a1(x,y,z)-a2(x,y,z);
    }
    return a1;
}

RealArray3D& operator*=(RealArray3D& a1,REAL aNumber)
{
    for (unsigned int x = 1;x<=a1.DimX;x++)
	for (unsigned int y = 1;y<=a1.DimY;y++)
	    for (unsigned int z = 1;z<=a1.DimZ;z++)
		a1(x,y,z)=a1(x,y,z)*aNumber;
    return a1;
}

Output& operator<<(Output& o,RealArray3D& aRealArray3D)
{
    for (unsigned int x = 1;x<=aRealArray3D.DimX;x++)
    {
	for (unsigned int y = 1;y<=aRealArray3D.DimY;y++) {
	    for (unsigned int z = 1;z<=aRealArray3D.DimZ;z++) {
		o<<"The value in ( "<<x<<","<<y<<","<<z<<")  = ";
		o<<aRealArray3D(x,y,z)<<"\n";
	    }
	}
    }
    return o;
}

void RealArray3D::memtest(float *aHandle, unsigned int bytesRequested)
{
    if (aHandle == NULL) {
	message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Unrecoverable error discovered:\n"
	    + "    Run out of memory. Request for RealArray3D (" + int_to_string(bytesRequested) + " bytes) failed.\n";

	STD_CERR << message;
	protocol  << message;

	exit(VIRTUAL_MEMORY_EXHAUSTED_ERROR);
    }
    return;
}
