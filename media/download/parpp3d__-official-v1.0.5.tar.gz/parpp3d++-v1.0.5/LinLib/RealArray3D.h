#ifndef REALARRAY3DH

#define REALARRAY3DH

#include <stdlib.h>
#include "MyTypes.h"
#include "Global.h"

class RealArray3D
{
private:
    REAL *aHandle;
    UNSIGNED Len;
    BYTEPTR Name;

    unsigned int DimX;
    unsigned int DimY;
    unsigned int DimZ;
    std::string  message;			  // Will act as "composer" for error messages
                                                  // This speeds up compilation with templates and
                                                  // reduces code. (No need to write code both for STD_CERR and protocol)

public:
    RealArray3D(UNSIGNED myDimX,UNSIGNED myDimY,UNSIGNED myDimZ);
    RealArray3D(UNSIGNED myDimX,UNSIGNED myDimY,UNSIGNED myDimZ,BYTEPTR aName);
    RealArray3D(RealArray3D& aRealArray3D);
    ~RealArray3D(VOID) {delete[] aHandle;}

    REAL& operator()(unsigned int x, unsigned int y, unsigned int z) {
#ifdef DEBUG
        if (x < 1  ||  x > DimX  ||  y < 1  ||  y > DimY  ||  z < 1  ||  z > DimZ) {
            message
                = "pp3d++ (process " + int_to_string(MyProcID, 0) + "):\n"
                + "  Unrecoverable error discovered:\n"
                + "    Wrong access to an object of type RealArray3D with name" + GetName() + ":\n";

            if (x < 1) {
                message += "    Trying to access array with too small x index: " + int_to_string(x) + ".\n";
            } else if (x > DimX) {
                message += "    Trying to access array with too large x index: " + int_to_string(x)
                         + ". Maximum allowed: " + int_to_string(DimX) + ".\n";
            } else if (y < 1) {
                message += "    Trying to access array with too small y index: " + int_to_string(y) + ".\n";
            } else if (y > DimY) {
                message += "    Trying to access array with too large y index: " + int_to_string(y)
                         + ". Maximum allowed: " + int_to_string(DimY) + ".\n";
            } else if (z < 1) {
                message += "    Trying to access array with too small z index: " + int_to_string(z) + ".\n";
            } else if (z > DimZ) {
                message += "    Trying to access array with too large z index: " + int_to_string(z)
                         + ". Maximum allowed: " + int_to_string(DimZ) + ".\n";
            }

            STD_CERR << message;
            protocol  << message;

            exit(ARRAY_LIMIT_ERROR);
        }
#endif
            return aHandle[(x-1)*DimY*DimZ+(y-1)*DimZ+z-1];
        }

    UNSIGNED GetLen(VOID) {return Len;}
    BYTEPTR  GetName(VOID) {return Name;}
    UNSIGNED GetDimX(VOID) {return DimX;}
    UNSIGNED GetDimY(VOID) {return DimY;}
    UNSIGNED GetDimZ(VOID) {return DimZ;}

    void         memtest(float *aHandle, unsigned int bytesRequested);

    RealArray3D& operator=(RealArray3D& aRealArray3D);
    RealArray3D& operator=(REAL aNumber);
// Array addition  a1+=a2
    friend RealArray3D& operator+=(RealArray3D& a1,RealArray3D& a2);
// Array substraction a1-=a2
    friend RealArray3D& operator-=(RealArray3D& a1,RealArray3D& a2);
// Scales a Array by a constant  a1=aNumber*a1
    friend RealArray3D& operator*=(RealArray3D& v1,REAL aNumber);

    friend Output& operator<<(Output& o,RealArray3D& aRealArray3D);
};

#endif
