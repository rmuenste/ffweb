#ifndef TYPESH

#define TYPESH

#include <float.h>

#define INTEGER			int
#define UNSIGNED		unsigned
#define FLOAT				float
#define REAL				float
#define DOUBLE			double
#define EXTENDED       double
#define LONG				long
#define ULONG			unsigned long
#define BYTE				char
#define VOID				void

#define INTPTR			int*
#define FLOATPTR		float*
#define REALPTR			float*
#define DOUBLEPTR		double*
#define BYTEPTR			char*
#define VOIDPTR			void*
#define INTREF			int&
#define FLOATREF		float&
#define REALREF			float&
#define DOUBLEREF		double&
#define UNSIGNEDPTR	unsigned*

#ifndef MAC_CODE
#define FALSE		0
#define TRUE		1
#endif

#define TINT				1
#define TREAL				2
#define TDOUBLE			3

#ifndef _DBL_MIN
#ifndef DBL_MIN
#define DBL_MIN   1e-30
#endif
#endif

#ifndef _DBL_MAX
#ifndef DBL_MAX
#define DBL_MAX   1e+30
#endif
#endif


#define ABS(aNumber)  (((aNumber)>=0)?(aNumber):(-aNumber))
#define MAX(a1,a2)	   (((a1)>(a2))?(a1):(a2))
#define MAX3(a1,a2,a3)	   MAX(MAX(a1, a2), a3)
#define MIN(a1,a2)	   (((a1)<(a2))?(a1):(a2))
#define MIN3(a1,a2,a3)	   MIN(MIN(a1, a2), a3)
#define SIGN(a1,a2)	   (((a1)>=0)?ABS(a1):-ABS(a1))

#endif
