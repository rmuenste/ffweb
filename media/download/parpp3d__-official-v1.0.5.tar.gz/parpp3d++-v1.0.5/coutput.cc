#include "coutput.h"

// #define VERBOSE_DEBUG 1

COutput::COutput(const char *aName, bool aFlag) 
{
    mediatype  = FILE_FLAG;
    active     = aFlag;
    filename   = aName;
    outfile    = new std::ofstream(aName, std::ios::out);

#ifdef VERBOSE_DEBUG
    STD_COUT << "Opening file " << filename << "\n";
#endif
    if (! *outfile ) {
        COutput::mAbortProgram("Could not open file '" + filename + "'", FILE_OPEN_ERROR);
    }

    return;
}

COutput::~COutput()
{
#ifdef VERBOSE_DEBUG
    STD_COUT << "Closing file " << filename << "\n";
#endif

    // Output was send to screen?
    if (mediatype & SCREEN_FLAG)
        mediatype ^= SCREEN_FLAG;

    // Output was send to a file?
    if (mediatype & FILE_FLAG) {
        mediatype ^= FILE_FLAG;
//      outfile->mFlush();
        outfile->close();
    }

    active = NONACTIVE;

    return;
}

void COutput::mCloseFile()
{
    // Screen output stream should not be closed, because
    // std::cout cannot be closed
    if (mediatype & SCREEN_FLAG) {
        mediatype ^= SCREEN_FLAG;
    }

    // Output stream can be closed.
    if (mediatype & FILE_FLAG) {
        mediatype ^= FILE_FLAG;
        outfile->close();
    }

    active = NONACTIVE;

    return;
}

// Sets the file name to use, tests whether this file is readable and
// activates this output stream.
void COutput::mSetFile(const char *aName)
{
    if (mediatype & FILE_FLAG) {
        mediatype ^= FILE_FLAG;
    }

    mediatype |= FILE_FLAG;
    active     = ACTIVE;
    filename   = aName;
    outfile    = new std::ofstream(aName);
    if (! *outfile ) {
//        throw file_open_error;
        COutput::mAbortProgram("Could not open file " + filename, FILE_OPEN_ERROR);
    }

    return;
}

// Output will be send to file (too) if ON.
// Otherwise nothing will be sent to file.
void COutput::mToggleFileOutput(bool aSwitch)
{
    if (aSwitch == ON) {
        // Turn on screen output.
        if (!(mediatype & FILE_FLAG)) {
            mediatype |= FILE_FLAG;
        }

        active = ACTIVE;
    } else {
        // Turn off screen output.
        if (mediatype & FILE_FLAG) {
            mediatype ^= FILE_FLAG;
        }
    }

    return;
}

// Output will be send to screen (too) if ON.
// Otherwise nothing will be sent to screen.
void COutput::mToggleScreenOutput(bool aSwitch)
{
    if (aSwitch == ON) {
        // Turn on screen output.
        if (!(mediatype & SCREEN_FLAG)) {
            mediatype |= SCREEN_FLAG;
        }

        active = ACTIVE;
    } else {
        // Turn off screen output.
        if (mediatype & SCREEN_FLAG) {
            mediatype ^= SCREEN_FLAG;
        }
    }

    return;
}

void COutput::mActivate()
{
    active = ACTIVE;
    return;
}

void COutput::mDeactivate()
{
    active = NONACTIVE;
    return;
}


void COutput::mFlush()
{
    // Flush screen output
    if (mediatype & SCREEN_FLAG) {
        STD_COUT.flush();
    }

    // Flush file output
    if (mediatype & FILE_FLAG) {
        outfile->flush();
    }

    return;
}

void COutput::mStatus()
{
    if (mediatype & SCREEN_FLAG) {
        STD_COUT << "Sending output to screen.\n";
    }
    if (mediatype & FILE_FLAG) {
        STD_COUT << "Sending output to file <" << filename << ">.\n";
    }

    return;
}

void COutput::mAbortProgram(const std::string errorMessage, const int errorNumber)
{
    std::string message = progname + " (process " + int_to_string(MyProcID) + "):\n"
                        + "  " + errorMessage + "\n" 
                        + "  Program aborted.\n";

    // Send error message to every output medium that has been bind
    // but at least to stderr
    STD_CERR << message;

    // Flush file output
    if (mediatype & FILE_FLAG) {
        *outfile << message;
    }

    // Clean up MPI environment and exit program.
    MPI_Abort(MPI_COMM_WORLD, errorNumber);
}
