#ifndef MULTIGRID3DH

#define MULTIGRID3DH

#include "SquareGrid_3D.h"
#include "FiniteElement_3D.h"

#define MAXMULTI	10
#define MAXARRAY	11

#define F_CYCLE  0
#define V_CYCLE  1
#define W_CYCLE  2

class MultiGrid_3D: public SquareGrid_3D
{
  friend class FiniteElement_3D;
  friend class BilinearElement_3D;

 protected:
  INTEGER	MNumElements[MAXARRAY];		// NEL
  INTEGER	MNumVertices[MAXARRAY];		// NVT
  INTEGER	MNumEdges[MAXARRAY];		// NMT
  INTEGER	MNumVertElem[MAXARRAY];		// NVE
  INTEGER	MNumElemVert[MAXARRAY];		// NVEL
  INTEGER	MNumBound[MAXARRAY];		// NBCT
  INTEGER	MNumVertBound[MAXARRAY];	// NVBD
  
// 3-D
  int MTotNumEdges[MAXARRAY];	// NET
  int MTotNumFaces[MAXARRAY];	// NAT
  int MNumEdgeElem[MAXARRAY];	// NEE
  int MNumFaceElem[MAXARRAY];	// NAE
  int MNumElemEdge[MAXARRAY];	// NEEL
  int MNumEdgeVert[MAXARRAY];	// NVED
  int MNumFaceVert[MAXARRAY];	// NVAR
  int MNumFaceEdge[MAXARRAY];	// NEAR
  int MNumEdgesBound[MAXARRAY];	// NEBD
  int MNumFacesBound[MAXARRAY];	// NABD  
		
  DoubleArray2D	*MVertCoord[MAXARRAY];		// LCORVG
  DoubleArray2D	*MMidCoord[MAXARRAY];		// LCORMG
  IntArray2D	*MVertElem[MAXARRAY];			// LVERT
  IntArray2D	*MNeighElem[MAXARRAY];		// LADJ
  IntArray2D	*MElemVert[MAXARRAY];			// LVEL
  IntArray2D	*MElemEdge[MAXARRAY];		// LMEL
  IntArray		*MInfoVertEdge[MAXARRAY];	// LNPR
  IntArray2D	*MInfoVertBound[MAXARRAY];	// LMM
  IntArray		*MVertBound[MAXARRAY];		// LVBD
  IntArray		*MElemBound[MAXARRAY];		// LEBD
  IntArray		*MPosBoundEntry[MAXARRAY];  // LBCT
  DoubleArray	*MVertParamBound[MAXARRAY];// LVBDP
  DoubleArray	*MMidParamBound[MAXARRAY];	// LMBDP
// 3-D
  DoubleArray2D	*MMidFaceCoord[MAXARRAY];		// LCORAG
  IntArray2D	*MMidEdges[MAXARRAY];			// LEDGE
  IntArray2D	*MMidFaces[MAXARRAY];			// LAREA
  IntArray2D	*MElemMeetEdge[MAXARRAY];		// LEEL
  IntArray2D	*MElemMeetFace[MAXARRAY];		// LAEL
  IntArray2D	*MVertMeetEdge[MAXARRAY];		// LVED
  IntArray2D	*MFaceMeetEdge[MAXARRAY];		// LAED
  IntArray2D	*MVertMeetFace[MAXARRAY];		// LVAR
  IntArray2D	*MEdgeMeetFace[MAXARRAY];		// LEAR
  IntArray2D	*MElemMeetVert[MAXARRAY];		// LEVE
  IntArray2D	*MFaceMeetVert[MAXARRAY];		// LAVE
  IntArray		*MMidFacesBound[MAXARRAY];		// LABD
  
  UNSIGNED   MNumEquations[MAXARRAY];
  
  UNSIGNED   ActiveLevel;          //ILEV
  UNSIGNED   TotalLevel;            //NLEV
  UNSIGNED   MinLevel;              //NLMIN
  UNSIGNED   MaxLevel;             //NLMAX
  UNSIGNED   Cycle;                    //ICYCLE
  UNSIGNED   PreSmSteps;          //KPRSM
  UNSIGNED   PostSmSteps;        //KPOSM
  
//  DoubleCompactMatrix *A[MAXARRAY];
 // DoubleVector *f[MAXARRAY];
  
 public:
  MultiGrid_3D(UNSIGNED P_TotalLevel);
  virtual ~MultiGrid_3D(VOID);
  
//    VOID   SetPreSteps(UNSIGNED steps) {PreSmSteps=steps;}
//    VOID   SetPostSteps(UNSIGNED steps) {PostSmSteps=steps;}
//    VOID   SetCycle(UNSIGNED num) {Cycle=num;}
  
    void   ConToRot(DoubleVector *vect1,DoubleVector *vect2,UNSIGNED level);
    void   RotToCon(DoubleVector *vect1,DoubleVector *vect2,UNSIGNED level);
  
//    VOID   SetLevel(UNSIGNED ILEV);
    VOID	MultiRefine(UNSIGNED ISCAD,UNSIGNED ISE,UNSIGNED ISA,
                            UNSIGNED ISEEL,UNSIGNED ISAEL,UNSIGNED ISVEL,UNSIGNED IDISP);
		 
//    DoubleVector* GetRightSideVector(FiniteElement_3D& Elem);

//    double StepControl(DoubleCompactMatrix *A,DoubleVector& x,
//  		     DoubleVector& d,DoubleVector& f);
//    void InitILU(MultiCompactMatrix* A);		 
//    void ILU(MultiCompactMatrix* A,double alpha);		 
//    VOID AssembleMatrices(FiniteElement_3D& 	Elem,
//    			 MultiCompactMatrix*       A,
//  		       UNSIGNED					BCON,
//  		       IntArray2D&				KAB,
//  		       UNSIGNED					KABN,
//  		       UNSIGNED					ICUB,
//  		       UNSIGNED					ISYMM,
//  		       UNSIGNED					ICLEAR,
//  		       UNSIGNED					ILINT);
		       
//    VOID AssembleTopMatrix(FiniteElement_3D& Elem,DoubleCompactMatrix*& A,
//  				UNSIGNED BCON,IntArray2D& KAB,
//                  		UNSIGNED KABN,UNSIGNED ICUB,
//                  		UNSIGNED ISYMM,UNSIGNED ICLEAR,UNSIGNED ILINT);
                		
//    VOID AssembleRightHandSide(FiniteElement_3D& 	Elem,
//    			 MultiVector                      f,
//  		       UNSIGNED					BCON,
//  		       IntArray&				      KB,
//  		       UNSIGNED					KBN,
//  		       UNSIGNED					ICUB,
//  		       UNSIGNED					ICLEAR,
//  		       UNSIGNED					ILINT);
			 
//     VOID CalcRightSide(FiniteElement_3D& 	Elem,
//     			 DoubleVector*&               LB,
//  		       UNSIGNED					BCON,
//  		       IntArray&				      KB,
//  		       UNSIGNED					KBN,
//  		       UNSIGNED					ICUB,
//  		       UNSIGNED					ICLEAR,
//  		       UNSIGNED					ILINT);
			 
//     UNSIGNED MultiDriver(FiniteElement_3D& Elem,MultiCompactMatrix* A,
//  			DoubleVector *LX,DoubleVector *LB,
//  			UNSIGNED NIT,DOUBLE EPS);
//     UNSIGNED NeumannMultiDriver(FiniteElement_3D& Elem,MultiCompactMatrix* A,
//  			       DoubleVector  *LX1,DoubleVector *LB1,
//  			       UNSIGNED NIT,DOUBLE EPS);
//     UNSIGNED ProjMultiDriver(FiniteElement_3D& Elem,
//  			    FiniteElement_3D& ConElem,
//  			    MultiCompactMatrix* A,
//  			    DoubleVector *LX,DoubleVector *LB,
//  			    UNSIGNED NIT,DOUBLE EPS);
//     UNSIGNED ProjNeumannMultiDriver(FiniteElement_3D& Elem,MultiCompactMatrix* A,
//  			       DoubleVector  *LX1,DoubleVector *LB1,
//  			       UNSIGNED NIT,DOUBLE EPS);
						   
   virtual VOID ExactSol(MultiCompactMatrix* A,DoubleVector *LX,DoubleVector *LB,DoubleVector *LD)=0;
   virtual VOID PreSmooth(MultiCompactMatrix* A,DoubleVector *LX,DoubleVector *LB,DoubleVector *LD,
                               UNSIGNED Steps)=0;
   virtual VOID PostSmooth(MultiCompactMatrix* A,DoubleVector *LX,DoubleVector *LB,DoubleVector *LD,
                               UNSIGNED Steps)=0;
   virtual VOID CopyBoundaryData(DoubleVector *LB)=0;
   
};

#endif
