#ifndef ROTATEDELEMENT3DH

#define ROTATEDELEMENT3DH

#include "FiniteElement_3D.h"

class RotatedElement_3D:public FiniteElement_3D
{
public:
  RotatedElement_3D(SquareGrid_3D *NGrid):FiniteElement_3D(NGrid) 
  {IDFL=NumFaceElem;NDIM=1;}
  ~RotatedElement_3D(void) {}
		
  void GetValue(double X1,double X2,double X3);
  unsigned int GetDOF(void);
  unsigned int GetTotalDOF(void);
  unsigned int GetIEROW(void);
  int      GetElemType(void);
  void SetGlobalDOF(unsigned int IEL,unsigned int IPAR);
  void Restrict(DoubleVector *LD,DoubleVector *LB,
		IntArray2D *VertElem2,IntArray2D *VertElem1,
		IntArray2D *MidFaces2,IntArray2D *MidFaces1,
		IntArray2D *NeighElem2,IntArray2D *NeighElem1,
		unsigned int NumVertices2,unsigned int NumVertices1,
		unsigned int NumElements2,unsigned int NumElements1);
  void Prol(DoubleVector *LD,DoubleVector *LB,
	    IntArray2D *VertElem2,IntArray2D *VertElem1,
	    IntArray2D *MidFaces2,IntArray2D *MidFaces1,
	    IntArray2D *NeighElem2,IntArray2D *NeighElem1,
	    unsigned int NumVertices2,unsigned int NumVertices1,
	    unsigned int NumElements2,unsigned int NumElements1);
};

inline unsigned int RotatedElement_3D::GetDOF(void)
{
  return IDFL;
}

inline unsigned int RotatedElement_3D::GetTotalDOF(void)
{
  return Grid->TotNumFaces;
}

inline unsigned int RotatedElement_3D::GetIEROW(void)
{
  return 12;
}

inline int RotatedElement_3D::GetElemType(void)
{
  return PARAM;
}


#endif
