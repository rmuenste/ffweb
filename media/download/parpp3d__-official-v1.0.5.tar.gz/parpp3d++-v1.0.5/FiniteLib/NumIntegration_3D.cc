#include "NumIntegration_3D.h"

//  INPUT    TYPE                                                        
//  -----    ----                                                        
//  ICUB     I*4    Number of cubature formula                           
//                 ICUB    NCUB    DEGREE                               
//                   1       1        1      1x1x1 Gaussian formula     
//                   2       6        1      Midpoints of areas         
//                   3       8        1      Product trapezoidal rule   
//                   4      12        1      Midpoints of edges (nyi)   
//                   5       4        2      Stroud                     
//                   6       6        3      Stroud                     
//                   7       8        3      2x2x2 Gaussian formula     
//                   8      14        5      Hammer and Stroud          
//                   9      27        5      3x3x3 Gaussian formula     
//                  10      34        7      Sarma and Stroud           
//                                 

NumIntegration_3D::NumIntegration_3D(UNSIGNED ICUB)
{
	INTEGER i,j;
	
	VCubPoint=new DoubleArray2D(NNCUBP,3);
	(*VCubPoint)=0;
	VOmega=new DoubleArray(NNCUBP);
	(*VOmega)=0;
	
	switch(ICUB) {
		case GAUSS1:
			(*VCubPoint)(1,1)=0;
			(*VCubPoint)(1,2)=0;
			(*VCubPoint)(1,3)=0;
			(*VOmega)(1)=8;
			VNumCubPoints=1;
			break;
		case MIDAREA:
			for(i=1;i<=6;i++)
				for(j=1;j<=3;j++)
					(*VCubPoint)(i,j)=0;
			(*VCubPoint)(1,2)=0;
			(*VCubPoint)(1,3)=-1;
			(*VCubPoint)(2,1)=-1;
			(*VCubPoint)(3,2)=-1;
			(*VCubPoint)(4,1)=1;
			(*VCubPoint)(5,2)=1;
			(*VCubPoint)(6,3)=1;
			for(i=1;i<=6;i++)
				(*VOmega)(i)=1.33333333333333333;
			VNumCubPoints=6;
			break;
		case TRAPEZ:
			for(i=1;i<=5;i+=4)
			{
				(*VCubPoint)(i,1)=-1;
				(*VCubPoint)(i,2)=-1;
				(*VCubPoint)(i+1,1)=1;
				(*VCubPoint)(i+1,2)=-1;
				(*VCubPoint)(i+2,1)=1;
				(*VCubPoint)(i+2,2)=1;
				(*VCubPoint)(i+3,1)=-1;
				(*VCubPoint)(i+3,2)=1;
			}
			for(i=1;i<=4;i++)
				(*VCubPoint)(i,3)=-1;
			for(i=5;i<=8;i++)
				(*VCubPoint)(i,3)=1;
			for(i=1;i<=8;i++)
				(*VOmega)(i)=1;
			VNumCubPoints=8;
		case MIDEDGE:
			Err<<"cubature formula MIDEDGE not yet implemented !!\n";
			exit(0);
			break;
		case STROUD1:
			(*VCubPoint)(1,1)=0.816496580927726;
			(*VCubPoint)(1,2)=0;
			(*VCubPoint)(1,3)=0.577350269189626;
			(*VCubPoint)(2,1)=0;
			(*VCubPoint)(2,2)=0.816496580927726;
			(*VCubPoint)(2,3)=-0.577350269189626;
			(*VCubPoint)(3,1)=-0.816496580927726;
			(*VCubPoint)(3,2)=0;
			(*VCubPoint)(3,3)=0.577350269189626;
			(*VCubPoint)(4,1)=0;
			(*VCubPoint)(4,2)=-0.816496580927726;
			(*VCubPoint)(4,3)=-0.577350269189626;
			for(i=1;i<=4;i++)
				(*VOmega)(i)=2;
			VNumCubPoints=4;
			break;
		case STROUD2:
			(*VCubPoint)(1,1)=0.408248290463863;
			(*VCubPoint)(1,2)=0.707106781186547;
			(*VCubPoint)(1,3)=-0.577350269189626;
			(*VCubPoint)(2,1)=-0.408248290463863;
			(*VCubPoint)(2,2)=0.707106781186547;
			(*VCubPoint)(2,3)=0.577350269189626;
			(*VCubPoint)(3,1)=-0.816496580927726;
			(*VCubPoint)(3,2)=0;
			(*VCubPoint)(3,3)=-0.577350269189626;
			(*VCubPoint)(4,1)=-0.408248290463863;
			(*VCubPoint)(4,2)=-0.707106781186547;
			(*VCubPoint)(4,3)=0.577350269189626;
			(*VCubPoint)(5,1)=0.408248290463863;
			(*VCubPoint)(5,2)=-0.707106781186547;
			(*VCubPoint)(5,3)=-0.577350269189626;
			(*VCubPoint)(6,1)=0.816496580927726;
			(*VCubPoint)(6,2)=0;
			(*VCubPoint)(6,3)=0.577350269189626;
			
			for(i=1;i<=6;i++)
				(*VOmega)(i)=1.33333333333333333;
			VNumCubPoints=6;
			break;
		case GAUSS2:
			for(i=1;i<=5;i+=4)
			{
				(*VCubPoint)(i,1)=0.577350269189626;
				(*VCubPoint)(i,2)=0.577350269189626;
				(*VCubPoint)(i+1,1)=-0.577350269189626;
				(*VCubPoint)(i+1,2)=0.577350269189626;
				(*VCubPoint)(i+2,1)=-0.577350269189626;
				(*VCubPoint)(i+2,2)=-0.577350269189626;
				(*VCubPoint)(i+3,1)=0.577350269189626;
				(*VCubPoint)(i+3,2)=-0.577350269189626;
			}
			for(i=1;i<=4;i++)
				(*VCubPoint)(i,3)=-0.577350269189626;
			for(i=5;i<=8;i++)
				(*VCubPoint)(i,3)=0.577350269189626;
			
			for(i=1;i<=8;i++) 
				(*VOmega)(i)=1;
			VNumCubPoints=8;
			break;
		case HAMMER:
			for(i=1;i<=6;i++)
				for(j=1;j<=3;j++)
					(*VCubPoint)(i,j)=0;
			(*VCubPoint)(1,1)=0.795822425754221;
			(*VCubPoint)(2,2)=0.795822425754221;
			(*VCubPoint)(3,3)=0.795822425754221;
			(*VCubPoint)(4,1)=-0.795822425754221;
			(*VCubPoint)(5,2)=-0.795822425754221;
			(*VCubPoint)(6,3)=-0.795822425754221;
			for(i=7;i<=11;i+=4)
			{
				(*VCubPoint)(i,1)=0.758786910639328;
				(*VCubPoint)(i,2)=0.758786910639328;
				(*VCubPoint)(i+1,1)=-0.758786910639328;
				(*VCubPoint)(i+1,2)=0.758786910639328;
				(*VCubPoint)(i+2,1)=-0.758786910639328;
				(*VCubPoint)(i+2,2)=-0.758786910639328;
				(*VCubPoint)(i+3,1)=0.758786910639328;
				(*VCubPoint)(i+3,2)=-0.758786910639328;
			}
			for(i=7;i<=10;i++)
				(*VCubPoint)(i,3)=-0.758786910639328;
			for(i=11;i<=14;i++)
				(*VCubPoint)(i,3)=0.758786910639328;
			for(i=1;i<=6;i++) 
				(*VOmega)(i)=0.886426592797784;
			for(i=7;i<=14;i++) 
				(*VOmega)(i)=0.335180055401662;
			VNumCubPoints=14;
			break;
		case GAUSS3:
			for(i=1;i<=19;i+=9)
			{
				(*VCubPoint)(i,1)=0.774596669241483;
				(*VCubPoint)(i,2)=0.774596669241483;
				(*VCubPoint)(i+1,1)=0.774596669241483;
				(*VCubPoint)(i+1,2)=0.774596669241483;
				(*VCubPoint)(i+2,1)=0.774596669241483;
				(*VCubPoint)(i+2,2)=0.774596669241483;
				(*VCubPoint)(i+3,1)=0.774596669241483;
				(*VCubPoint)(i+3,2)=0.774596669241483;
				(*VCubPoint)(i+4,1)=0.774596669241483;
				(*VCubPoint)(i+4,2)=0;
				(*VCubPoint)(i+5,1)=0.774596669241483;
				(*VCubPoint)(i+5,2)=0;
				(*VCubPoint)(i+6,1)=0;
				(*VCubPoint)(i+6,2)=0.774596669241483;
				(*VCubPoint)(i+7,1)=0;
				(*VCubPoint)(i+7,2)=0.774596669241483;
				(*VCubPoint)(i+8,1)=0;
				(*VCubPoint)(i+8,2)=0;
			}
			for(i=1;i<=9;i++)
				(*VCubPoint)(i,3)=-0.774596669241483;
			for(i=10;i<=18;i++)
				(*VCubPoint)(i,3)=0;
			for(i=19;i<=27;i++) 
				(*VCubPoint)(i,3)=0.774596669241483;
			for(i=1;i<=4;i++) 
				(*VOmega)(i)=0.17146776406036;
			for(i=5;i<=8;i++) 
				(*VOmega)(i)=0.27434842249657;
			(*VOmega)(9)=0.43895747599451;
			for(i=10;i<=13;i++) 
				(*VOmega)(i)=0.27434842249657;
			for(i=14;i<=17;i++) 
				(*VOmega)(i)=0.43895747599451;
			(*VOmega)(18)=0.70233196159122;
			for(i=19;i<=22;i++) 
				(*VOmega)(i)=0.17146776406036;
			for(i=23;i<=26;i++) 
				(*VOmega)(i)=0.27434842249657;
			(*VOmega)(27)=0.43895747599451;
			VNumCubPoints=27;
			break;
		case SARMA:
			break;
	}
}

NumIntegration_3D::~NumIntegration_3D(VOID)
{
	if(VCubPoint)
		delete VCubPoint;
	if(VOmega)
		delete VOmega;
}
