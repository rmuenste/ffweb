#include "MultiGrid_3D.h"

//#define CONTROL_MSG

MultiGrid_3D::MultiGrid_3D(UNSIGNED P_TotalLevel)
{
    INTEGER i;

    for(i=1;i<=MAXMULTI;i++) {
        MVertCoord[i]=0;
        MMidCoord[i]=0;
        MVertElem[i]=0;
        MMidEdges[i]=0;
        MNeighElem[i]=0;
        MElemVert[i]=0;
        MElemEdge[i]=0;
        MInfoVertEdge[i]=0;
        MInfoVertBound[i]=0;
        MVertBound[i]=0;
        MElemBound[i]=0;
        MPosBoundEntry[i]=0;
        MVertParamBound[i]=0;
        MMidParamBound[i]=0;

        MMidFaceCoord[i]=0;
        MMidEdges[i]=0;
        MMidFaces[i]=0;
        MElemMeetEdge[i]=0;
        MElemMeetFace[i]=0;
        MVertMeetEdge[i]=0;
        MFaceMeetEdge[i]=0;
        MVertMeetFace[i]=0;
        MEdgeMeetFace[i]=0;
        MElemMeetVert[i]=0;
        MFaceMeetVert[i]=0;
        MMidFacesBound[i]=0;

    }

    if(P_TotalLevel<1)
        TotalLevel=1;
    else if(P_TotalLevel>MAXMULTI)
        TotalLevel=MAXMULTI;
    else
        TotalLevel=P_TotalLevel;

    MinLevel=1;
    MaxLevel=TotalLevel;
}

MultiGrid_3D::~MultiGrid_3D(VOID)
{
    INTEGER i;

    for(i=1;i<=TotalLevel-1;i++) {
        if(MVertCoord[i])
            delete MVertCoord[i];
        if(MMidCoord[i])
            delete MMidCoord[i];
        if(MVertElem[i])
            delete MVertElem[i];
        if(MMidEdges[i])
            delete MMidEdges[i];
        if(MNeighElem[i])
            delete MNeighElem[i];
        if(MElemVert[i])
            delete MElemVert[i];
        if(MElemEdge[i])
            delete MElemEdge[i];
        if(MInfoVertEdge[i])
            delete MInfoVertEdge[i];
        if(MInfoVertBound[i])
            delete MInfoVertBound[i];
        if(MVertBound[i])
            delete MVertBound[i];
        if(MElemBound[i])
            delete MElemBound[i];
        if(MPosBoundEntry[i])
            delete MPosBoundEntry[i];
        if(MVertParamBound[i])
            delete MVertParamBound[i];
        if(MMidParamBound[i])
            delete MMidParamBound[i];

        if(MMidFaceCoord[i])
            delete MMidFaceCoord[i];
        if(MMidEdges[i])
            delete MMidEdges[i];
        if(MMidFaces[i])
            delete MMidFaces[i];
        if(MElemMeetEdge[i])
            delete MElemMeetEdge[i];
        if(MElemMeetFace[i])
            delete MElemMeetFace[i];
        if(MVertMeetEdge[i])
            delete MVertMeetEdge[i];
        if(MFaceMeetEdge[i])
            delete MFaceMeetEdge[i];
        if(MVertMeetFace[i])
            delete MVertMeetFace[i];
        if(MEdgeMeetFace[i])
            delete MEdgeMeetFace[i];
        if(MElemMeetVert[i])
            delete MElemMeetVert[i];
        if(MFaceMeetVert[i])
            delete MFaceMeetVert[i];
        if(MMidFacesBound[i])
            delete MMidFacesBound[i];
    }
}

//  double MultiGrid_3D::StepControl(DoubleCompactMatrix *A,DoubleVector& x,
//                                   DoubleVector& d,DoubleVector& f)
//  {
//      int index,JCOL;
//      DoubleVector aux(x.GetLen());
//      double aux1,aux2,alpha;

//      A->VectMult(x,aux);
//      aux1=aux*d;
//      A->VectMult(d,aux);
//      aux2=aux*d;

//      alpha=f*d;

//      return (alpha-aux1)/aux2;
//  }

void MultiGrid_3D::MultiRefine(unsigned int ISCAD, unsigned int ISE,   unsigned int ISA,
                               unsigned int ISEEL, unsigned int ISAEL, unsigned int ISVEL, unsigned int IDISP)
{
    unsigned int P_ISE;

    if(ISE<1)
        P_ISE=1;
    else
        P_ISE=ISE;

    for(INTEGER ILEV=1;ILEV<=TotalLevel;ILEV++) {
        if(ILEV==1)
            Refine(0,0,P_ISE,ISA,ISEEL,ISAEL,ISVEL,IDISP);
        else
            Refine(1,0,P_ISE,ISA,ISEEL,ISAEL,ISVEL,IDISP);

        BoundaryProjection();

        MNumElements[ILEV]=NumElements;
        MNumVertices[ILEV]=NumVertices;
        MNumEdges[ILEV]=NumEdges;
        MNumVertElem[ILEV]=NumVertElem;
        MNumElemVert[ILEV]=NumElemVert;
        MNumElemVert[ILEV]=NumElemVert;
        MNumVertBound[ILEV]=NumVertBound;

        MTotNumEdges[ILEV]=TotNumEdges;
        MTotNumFaces[ILEV]=TotNumFaces;
        MNumEdgeElem[ILEV]=NumEdgeElem;
        MNumFaceElem[ILEV]=NumFaceElem;
        MNumElemEdge[ILEV]=NumElemEdge;
        MNumEdgeVert[ILEV]=NumEdgeVert;
        MNumFaceVert[ILEV]=NumFaceVert;
        MNumFaceEdge[ILEV]=NumFaceEdge;
        MNumEdgesBound[ILEV]=NumEdgesBound;
        MNumFacesBound[ILEV]=NumFacesBound;

        if(ILEV<TotalLevel) {
            if(VertCoord) {
                MVertCoord[ILEV]=new DoubleArray2D(*VertCoord);
            }
            if(MidCoord) {
                MMidCoord[ILEV]=new DoubleArray2D(*MidCoord);
            }
            if(VertElem) {
                MVertElem[ILEV]=new IntArray2D(*VertElem);
            }
            if(MidEdges) {
                MMidEdges[ILEV]=new IntArray2D(*MidEdges);
            }
            if(NeighElem) {
                MNeighElem[ILEV]=new IntArray2D(*NeighElem);
            }
            if(ElemVert) {
                MElemVert[ILEV]=new IntArray2D(*ElemVert);
            }
            if(ElemEdge) {
                MElemEdge[ILEV]=new IntArray2D(*ElemEdge);
            }
            if(InfoVertEdge) {
                MInfoVertEdge[ILEV]=new IntArray(*InfoVertEdge);
            }
            if(InfoVertBound) {
                MInfoVertBound[ILEV]=new IntArray2D(*InfoVertBound);
            }
            if(VertBound) {
                MVertBound[ILEV]=new IntArray(*VertBound);
            }
            if(ElemBound) {
                MElemBound[ILEV]=new IntArray(*ElemBound);
            }
            if(PosBoundEntry) {
                MPosBoundEntry[ILEV]=new IntArray(*PosBoundEntry);
            }

            if(MidFaceCoord)
                MMidFaceCoord[ILEV]=new DoubleArray2D(*MidFaceCoord);
            if(MidEdges)
                MMidEdges[ILEV]=new IntArray2D(*MidEdges);
            if(MidFaces)
                MMidFaces[ILEV]=new IntArray2D(*MidFaces);
            if(ElemMeetEdge)
                MElemMeetEdge[ILEV]=new IntArray2D(*ElemMeetEdge);
            if(ElemMeetFace)
                MElemMeetFace[ILEV]=new IntArray2D(*ElemMeetFace);
            if(VertMeetEdge)
                MVertMeetEdge[ILEV]=new IntArray2D(*VertMeetEdge);
            if(FaceMeetEdge)
                MFaceMeetEdge[ILEV]=new IntArray2D(*FaceMeetEdge);
            if(VertMeetFace)
                MVertMeetFace[ILEV]=new IntArray2D(*VertMeetFace);
            if(EdgeMeetFace)
                MEdgeMeetFace[ILEV]=new IntArray2D(*EdgeMeetFace);
            if(ElemMeetVert)
                MElemMeetVert[ILEV]=new IntArray2D(*ElemMeetVert);
            if(FaceMeetVert)
                MFaceMeetVert[ILEV]=new IntArray2D(*FaceMeetVert);
            if(MidFacesBound)
                MMidFacesBound[ILEV]=new IntArray(*MidFacesBound);
        } else {
            MVertCoord[ILEV]=VertCoord;
            MMidCoord[ILEV]=MidCoord;
            MVertElem[ILEV]=VertElem;
            MMidEdges[ILEV]=MidEdges;
            MNeighElem[ILEV]=NeighElem;
            MElemVert[ILEV]=ElemVert;
            MElemEdge[ILEV]=ElemEdge;
            MInfoVertEdge[ILEV]=InfoVertEdge;
            MInfoVertBound[ILEV]=InfoVertBound;
            MVertBound[ILEV]=VertBound;
            MElemBound[ILEV]=ElemBound;
            MPosBoundEntry[ILEV]=PosBoundEntry;

            MMidFaceCoord[ILEV]=MidFaceCoord;
            MMidEdges[ILEV]=MidEdges;
            MMidFaces[ILEV]=MidFaces;
            MElemMeetEdge[ILEV]=ElemMeetEdge;
            MElemMeetFace[ILEV]=ElemMeetFace;
            MVertMeetEdge[ILEV]=VertMeetEdge;
            MFaceMeetEdge[ILEV]=FaceMeetEdge;
            MVertMeetFace[ILEV]=VertMeetFace;
            MEdgeMeetFace[ILEV]=EdgeMeetFace;
            MElemMeetVert[ILEV]=ElemMeetVert;
            MFaceMeetVert[ILEV]=FaceMeetVert;
            MMidFacesBound[ILEV]=MidFacesBound;
        }
    }

    return;
}

//  VOID MultiGrid_3D::SetLevel(UNSIGNED ILEV)
//  {
//      NumElements=MNumElements[ILEV];
//      NumVertices=MNumVertices[ILEV];
//      NumEdges=MNumEdges[ILEV];
//      NumVertElem=MNumVertElem[ILEV];
//      NumElemVert=MNumElemVert[ILEV];
//      NumVertBound=MNumVertBound[ILEV];

//      TotNumEdges=MTotNumEdges[ILEV];
//      TotNumFaces=MTotNumFaces[ILEV];
//      NumEdgeElem=MNumEdgeElem[ILEV];
//      NumFaceElem=MNumFaceElem[ILEV];
//      NumElemEdge=MNumElemEdge[ILEV];
//      NumEdgeVert=MNumEdgeVert[ILEV];
//      NumFaceVert=MNumFaceVert[ILEV];
//      NumFaceEdge=MNumFaceEdge[ILEV];
//      NumEdgesBound=MNumEdgesBound[ILEV];
//      NumFacesBound=MNumFacesBound[ILEV];

//      VertCoord=MVertCoord[ILEV];
//      MidCoord=MMidCoord[ILEV];
//      VertElem=MVertElem[ILEV];
//      MidEdges=MMidEdges[ILEV];
//      NeighElem=MNeighElem[ILEV];
//      ElemVert=MElemVert[ILEV];
//      ElemEdge=MElemEdge[ILEV];
//      InfoVertEdge=MInfoVertEdge[ILEV];
//      InfoVertBound=MInfoVertBound[ILEV];
//      VertBound=MVertBound[ILEV];
//      ElemBound=MElemBound[ILEV];
//      PosBoundEntry=MPosBoundEntry[ILEV];

//      MidFaceCoord=MMidFaceCoord[ILEV];
//      MidEdges=MMidEdges[ILEV];
//      MidFaces=MMidFaces[ILEV];
//      ElemMeetEdge=MElemMeetEdge[ILEV];
//      ElemMeetFace=MElemMeetFace[ILEV];
//      VertMeetEdge=MVertMeetEdge[ILEV];
//      FaceMeetEdge=MFaceMeetEdge[ILEV];
//      VertMeetFace=MVertMeetFace[ILEV];
//      EdgeMeetFace=MEdgeMeetFace[ILEV];
//      ElemMeetVert=MElemMeetVert[ILEV];
//      FaceMeetVert=MFaceMeetVert[ILEV];
//      MidFacesBound=MMidFacesBound[ILEV];

//      ActiveLevel=ILEV;
//  }


//  VOID MultiGrid_3D::AssembleMatrices(FiniteElement_3D& Elem,MultiCompactMatrix* A,
//                                      UNSIGNED BCON,IntArray2D& KAB,
//                                      UNSIGNED KABN,UNSIGNED ICUB,UNSIGNED ISYMM,UNSIGNED ICLEAR,
//                                      UNSIGNED ILINT)
//  {
//      for(INTEGER ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
//          NumElements=MNumElements[ILEV];
//          NumVertices=MNumVertices[ILEV];
//          NumEdges=MNumEdges[ILEV];
//          NumVertElem=MNumVertElem[ILEV];
//          NumElemVert=MNumElemVert[ILEV];
//          NumVertBound=MNumVertBound[ILEV];

//          TotNumEdges=MTotNumEdges[ILEV];
//          TotNumFaces=MTotNumFaces[ILEV];
//          NumEdgeElem=MNumEdgeElem[ILEV];
//          NumFaceElem=MNumFaceElem[ILEV];
//          NumElemEdge=MNumElemEdge[ILEV];
//          NumEdgeVert=MNumEdgeVert[ILEV];
//          NumFaceVert=MNumFaceVert[ILEV];
//          NumFaceEdge=MNumFaceEdge[ILEV];
//          NumEdgesBound=MNumEdgesBound[ILEV];
//          NumFacesBound=MNumFacesBound[ILEV];

//          VertCoord=MVertCoord[ILEV];
//          MidCoord=MMidCoord[ILEV];
//          VertElem=MVertElem[ILEV];
//          MidEdges=MMidEdges[ILEV];
//          NeighElem=MNeighElem[ILEV];
//          ElemVert=MElemVert[ILEV];
//          ElemEdge=MElemEdge[ILEV];
//          InfoVertEdge=MInfoVertEdge[ILEV];
//          InfoVertBound=MInfoVertBound[ILEV];
//          VertBound=MVertBound[ILEV];
//          ElemBound=MElemBound[ILEV];
//          PosBoundEntry=MPosBoundEntry[ILEV];

//          MidFaceCoord=MMidFaceCoord[ILEV];
//          MidEdges=MMidEdges[ILEV];
//          MidFaces=MMidFaces[ILEV];
//          ElemMeetEdge=MElemMeetEdge[ILEV];
//          ElemMeetFace=MElemMeetFace[ILEV];
//          VertMeetEdge=MVertMeetEdge[ILEV];
//          FaceMeetEdge=MFaceMeetEdge[ILEV];
//          VertMeetFace=MVertMeetFace[ILEV];
//          EdgeMeetFace=MEdgeMeetFace[ILEV];
//          ElemMeetVert=MElemMeetVert[ILEV];
//          FaceMeetVert=MFaceMeetVert[ILEV];
//          MidFacesBound=MMidFacesBound[ILEV];

//          Elem.CalcStiffMatrix((*A)[ILEV],BCON,KAB,KABN,ICUB,ISYMM,ICLEAR,ILINT);

//          if(ICLEAR==TRUE)
//              MNumEquations[ILEV]=Elem.GetNumEquations();
//      }
//  }

//  void MultiGrid_3D::InitILU(MultiCompactMatrix* A)
//  {
//      DoubleCompactMatrix* C;
//      for(int ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
//          C=(*A)[ILEV];
//          C->CuthillMcKee();
//          //C->PermAll();
//          //C->ILU(1,alpha,1e-12);
//      }
//  }

//  void MultiGrid_3D::ILU(MultiCompactMatrix* A,double alpha)
//  {
//      DoubleCompactMatrix* C;
//      for(int ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
//          C=(*A)[ILEV];
//          //C->CuthillMcKee();
//          C->PermAll();
//          C->ILU(1,alpha,1e-12);
//      }
//  }


//  VOID MultiGrid_3D::AssembleTopMatrix(FiniteElement_3D& Elem,DoubleCompactMatrix*& A,
//                                       UNSIGNED BCON,IntArray2D& KAB,
//                                       UNSIGNED KABN,UNSIGNED ICUB,UNSIGNED ISYMM,UNSIGNED ICLEAR,
//                                       UNSIGNED ILINT)
//  {
//      NumElements=MNumElements[MaxLevel];
//      NumVertices=MNumVertices[MaxLevel];
//      NumEdges=MNumEdges[MaxLevel];
//      NumVertElem=MNumVertElem[MaxLevel];
//      NumElemVert=MNumElemVert[MaxLevel];
//      NumVertBound=MNumVertBound[MaxLevel];

//      TotNumEdges=MTotNumEdges[MaxLevel];
//      TotNumFaces=MTotNumFaces[MaxLevel];
//      NumEdgeElem=MNumEdgeElem[MaxLevel];
//      NumFaceElem=MNumFaceElem[MaxLevel];
//      NumElemEdge=MNumElemEdge[MaxLevel];
//      NumEdgeVert=MNumEdgeVert[MaxLevel];
//      NumFaceVert=MNumFaceVert[MaxLevel];
//      NumFaceEdge=MNumFaceEdge[MaxLevel];
//      NumEdgesBound=MNumEdgesBound[MaxLevel];
//      NumFacesBound=MNumFacesBound[MaxLevel];

//      VertCoord=MVertCoord[MaxLevel];
//      MidCoord=MMidCoord[MaxLevel];
//      VertElem=MVertElem[MaxLevel];
//      MidEdges=MMidEdges[MaxLevel];
//      NeighElem=MNeighElem[MaxLevel];
//      ElemVert=MElemVert[MaxLevel];
//      ElemEdge=MElemEdge[MaxLevel];
//      InfoVertEdge=MInfoVertEdge[MaxLevel];
//      InfoVertBound=MInfoVertBound[MaxLevel];
//      VertBound=MVertBound[MaxLevel];
//      ElemBound=MElemBound[MaxLevel];
//      PosBoundEntry=MPosBoundEntry[MaxLevel];

//      MidFaceCoord=MMidFaceCoord[MaxLevel];
//      MidEdges=MMidEdges[MaxLevel];
//      MidFaces=MMidFaces[MaxLevel];
//      ElemMeetEdge=MElemMeetEdge[MaxLevel];
//      ElemMeetFace=MElemMeetFace[MaxLevel];
//      VertMeetEdge=MVertMeetEdge[MaxLevel];
//      FaceMeetEdge=MFaceMeetEdge[MaxLevel];
//      VertMeetFace=MVertMeetFace[MaxLevel];
//      EdgeMeetFace=MEdgeMeetFace[MaxLevel];
//      ElemMeetVert=MElemMeetVert[MaxLevel];
//      FaceMeetVert=MFaceMeetVert[MaxLevel];
//      MidFacesBound=MMidFacesBound[MaxLevel];

//      Elem.CalcStiffMatrix(A,BCON,KAB,KABN,ICUB,ISYMM,ICLEAR,ILINT);

//      if(ICLEAR==TRUE)
//          MNumEquations[MaxLevel]=Elem.GetNumEquations();
//  }


//  VOID MultiGrid_3D::AssembleRightHandSide(FiniteElement_3D& Elem,
//                                           MultiVector f,UNSIGNED BCON,IntArray& KB,
//                                           UNSIGNED KBN,UNSIGNED ICUB,UNSIGNED ICLEAR,UNSIGNED ILINT)
//  {
//      for(INTEGER ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
//          NumElements=MNumElements[ILEV];
//          NumVertices=MNumVertices[ILEV];
//          NumEdges=MNumEdges[ILEV];
//          NumVertElem=MNumVertElem[ILEV];
//          NumElemVert=MNumElemVert[ILEV];
//          NumVertBound=MNumVertBound[ILEV];

//          TotNumEdges=MTotNumEdges[ILEV];
//          TotNumFaces=MTotNumFaces[ILEV];
//          NumEdgeElem=MNumEdgeElem[ILEV];
//          NumFaceElem=MNumFaceElem[ILEV];
//          NumElemEdge=MNumElemEdge[ILEV];
//          NumEdgeVert=MNumEdgeVert[ILEV];
//          NumFaceVert=MNumFaceVert[ILEV];
//          NumFaceEdge=MNumFaceEdge[ILEV];
//          NumEdgesBound=MNumEdgesBound[ILEV];
//          NumFacesBound=MNumFacesBound[ILEV];

//          VertCoord=MVertCoord[ILEV];
//          MidCoord=MMidCoord[ILEV];
//          VertElem=MVertElem[ILEV];
//          MidEdges=MMidEdges[ILEV];
//          NeighElem=MNeighElem[ILEV];
//          ElemVert=MElemVert[ILEV];
//          ElemEdge=MElemEdge[ILEV];
//          InfoVertEdge=MInfoVertEdge[ILEV];
//          InfoVertBound=MInfoVertBound[ILEV];
//          VertBound=MVertBound[ILEV];
//          ElemBound=MElemBound[ILEV];
//          PosBoundEntry=MPosBoundEntry[ILEV];

//          MidFaceCoord=MMidFaceCoord[ILEV];
//          MidEdges=MMidEdges[ILEV];
//          MidFaces=MMidFaces[ILEV];
//          ElemMeetEdge=MElemMeetEdge[ILEV];
//          ElemMeetFace=MElemMeetFace[ILEV];
//          VertMeetEdge=MVertMeetEdge[ILEV];
//          FaceMeetEdge=MFaceMeetEdge[ILEV];
//          VertMeetFace=MVertMeetFace[ILEV];
//          EdgeMeetFace=MEdgeMeetFace[ILEV];
//          ElemMeetVert=MElemMeetVert[ILEV];
//          FaceMeetVert=MFaceMeetVert[ILEV];
//          MidFacesBound=MMidFacesBound[ILEV];

//          Elem.CalcRightSide(f[ILEV],BCON,KB,KBN,ICUB,ICLEAR,ILINT);
//      }
//  }

//  VOID MultiGrid_3D::CalcRightSide(FiniteElement_3D& Elem,DoubleVector*& LB,
//                                   UNSIGNED BCON,IntArray& KB,
//                                   UNSIGNED KBN,UNSIGNED ICUB,UNSIGNED ICLEAR,UNSIGNED ILINT)
//  {
//      NumElements=MNumElements[MaxLevel];
//      NumVertices=MNumVertices[MaxLevel];
//      NumEdges=MNumEdges[MaxLevel];
//      NumVertElem=MNumVertElem[MaxLevel];
//      NumElemVert=MNumElemVert[MaxLevel];
//      NumVertBound=MNumVertBound[MaxLevel];

//      TotNumEdges=MTotNumEdges[MaxLevel];
//      TotNumFaces=MTotNumFaces[MaxLevel];
//      NumEdgeElem=MNumEdgeElem[MaxLevel];
//      NumFaceElem=MNumFaceElem[MaxLevel];
//      NumElemEdge=MNumElemEdge[MaxLevel];
//      NumEdgeVert=MNumEdgeVert[MaxLevel];
//      NumFaceVert=MNumFaceVert[MaxLevel];
//      NumFaceEdge=MNumFaceEdge[MaxLevel];
//      NumEdgesBound=MNumEdgesBound[MaxLevel];
//      NumFacesBound=MNumFacesBound[MaxLevel];

//      VertCoord=MVertCoord[MaxLevel];
//      MidCoord=MMidCoord[MaxLevel];
//      VertElem=MVertElem[MaxLevel];
//      MidEdges=MMidEdges[MaxLevel];
//      NeighElem=MNeighElem[MaxLevel];
//      ElemVert=MElemVert[MaxLevel];
//      ElemEdge=MElemEdge[MaxLevel];
//      InfoVertEdge=MInfoVertEdge[MaxLevel];
//      InfoVertBound=MInfoVertBound[MaxLevel];
//      VertBound=MVertBound[MaxLevel];
//      ElemBound=MElemBound[MaxLevel];
//      PosBoundEntry=MPosBoundEntry[MaxLevel];

//      MidFaceCoord=MMidFaceCoord[MaxLevel];
//      MidEdges=MMidEdges[MaxLevel];
//      MidFaces=MMidFaces[MaxLevel];
//      ElemMeetEdge=MElemMeetEdge[MaxLevel];
//      ElemMeetFace=MElemMeetFace[MaxLevel];
//      VertMeetEdge=MVertMeetEdge[MaxLevel];
//      FaceMeetEdge=MFaceMeetEdge[MaxLevel];
//      VertMeetFace=MVertMeetFace[MaxLevel];
//      EdgeMeetFace=MEdgeMeetFace[MaxLevel];
//      ElemMeetVert=MElemMeetVert[MaxLevel];
//      FaceMeetVert=MFaceMeetVert[MaxLevel];
//      MidFacesBound=MMidFacesBound[MaxLevel];

//      Elem.CalcRightSide(LB,BCON,KB,KBN,ICUB,ICLEAR,ILINT);
//  }


//  DoubleVector* MultiGrid_3D::GetRightSideVector(FiniteElement_3D& Elem)
//  {
//      NumElements=MNumElements[MaxLevel];
//      NumVertices=MNumVertices[MaxLevel];
//      NumEdges=MNumEdges[MaxLevel];
//      NumVertElem=MNumVertElem[MaxLevel];
//      NumElemVert=MNumElemVert[MaxLevel];
//      NumVertBound=MNumVertBound[MaxLevel];

//      VertCoord=MVertCoord[MaxLevel];
//      MidCoord=MMidCoord[MaxLevel];
//      VertElem=MVertElem[MaxLevel];
//      MidEdges=MMidEdges[MaxLevel];
//      NeighElem=MNeighElem[MaxLevel];
//      ElemVert=MElemVert[MaxLevel];
//      ElemEdge=MElemEdge[MaxLevel];
//      InfoVertEdge=MInfoVertEdge[MaxLevel];
//      InfoVertBound=MInfoVertBound[MaxLevel];
//      VertBound=MVertBound[MaxLevel];
//      ElemBound=MElemBound[MaxLevel];
//      PosBoundEntry=MPosBoundEntry[MaxLevel];

//      return Elem.GetRightSideVector();
//  }

//  UNSIGNED MultiGrid_3D::MultiDriver(FiniteElement_3D& Elem,MultiCompactMatrix* A,DoubleVector  *LX1,
//                                     DoubleVector *LB1,UNSIGNED NIT,DOUBLE EPS)
//  {
//      double alpha;

//      if(Cycle<0) {
//          Err<<"Wrong Cycle Number !!\n";
//          return FALSE;
//      }
//      if(MaxLevel<MinLevel || MinLevel<=0 || MaxLevel>MAXMULTI) {
//          Err<<"Wrong Parameter MaxLevel or MinLevel !!\n";
//          return FALSE;
//      }
//      if(LX1==0)
//          LX1=new DoubleVector(MNumEquations[MaxLevel]);
//      if(LB1==0)
//          LB1=new DoubleVector(MNumEquations[MaxLevel]);
//      if(LX1->GetLen()<MNumEquations[MaxLevel] || LB1->GetLen()<MNumEquations[MaxLevel]) {
//          delete LX1;delete LB1;
//          LX1=new DoubleVector(MNumEquations[MaxLevel]);
//          LB1=new DoubleVector(MNumEquations[MaxLevel]);
//      }

//      DoubleVector *LX[MAXARRAY];
//      DoubleVector *LB[MAXARRAY];
//      DoubleVector *LD[MAXARRAY];

//      for(ActiveLevel=MinLevel;ActiveLevel<MaxLevel;ActiveLevel++) {
//          LX[ActiveLevel]=new DoubleVector(MNumEquations[ActiveLevel]);
//          LB[ActiveLevel]=new DoubleVector(MNumEquations[ActiveLevel]);
//          LD[ActiveLevel]=new DoubleVector(MNumEquations[ActiveLevel]);
//      }
//      LX[MaxLevel]=LX1;
//      LB[MaxLevel]=LB1;
//      LD[MaxLevel]=new DoubleVector(MNumEquations[MaxLevel]);

//      DateTime Clock;
//      DateTime Clock2;
//      DOUBLE TMultiGrid=0,TSmooth=0,TEvalue=0,TDefect=0,TProl=0,TRestrict=0,TAll=0;
//      DOUBLE Def,DefOld,FD;
//      UNSIGNED ITE=1;

//  // only one level
//  //
//      if(MinLevel==MaxLevel) {
//          (*LX[MaxLevel])=(*LB[MaxLevel]);
//          Clock.SetTime();
//          ExactSol(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel]);
//          TEvalue+=Clock.GetTimeDiff();
//      } else {
//          UNSIGNED KITO[MAXMULTI],KIT[MAXMULTI];
//          UNSIGNED PFlag=TRUE,TFlag=TRUE;

//          KITO[MaxLevel]=1;
//          for(ActiveLevel=MinLevel+1;ActiveLevel<MaxLevel;ActiveLevel++) {
//              if(Cycle==0)
//                  KITO[ActiveLevel]=2;
//              else
//                  KITO[ActiveLevel]=Cycle;
//          }
//          ActiveLevel=MaxLevel;

//  //    Prot<<"before presmooth x=\n"<<*LX[MaxLevel]<<"\n";

//          Clock.SetTime();
//          if(PreSmSteps>0)
//              PreSmooth(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel],PreSmSteps);
//          TSmooth+=Clock.GetTimeDiff();

//  //    Prot<<"after presmooth x=\n"<<*LX[MaxLevel]<<"\n";


//          (*LD[MaxLevel])=(*LB[MaxLevel]);
//          Clock.SetTime();
//          (*A)[MaxLevel]->VectMult(*LX[MaxLevel],*LD[MaxLevel],-1,1);
//          TDefect+=Clock.GetTimeDiff();

//  //    Prot<<"defect d=\n"<<*LD[MaxLevel]<<"\n";
//  //		Prot<<"x=\n"<<*LX[MaxLevel]<<"\n";
//  //		Prot<<"b=\n"<<*LB[MaxLevel]<<"\n";

//          ActiveLevel--;

//          Def=LD[MaxLevel]->l2Norm();
//          DefOld=FD=Def;

//          if(FD>EPS) {
//              for(ITE=1;ITE<=NIT;ITE++) {
//                  for(ActiveLevel=MinLevel;ActiveLevel<=MaxLevel;ActiveLevel++)
//                      KIT[ActiveLevel]=KITO[ActiveLevel];

//                  ActiveLevel=MaxLevel;

//                  do {
//                      while(ActiveLevel!=MinLevel) {
//  // Pre-Smoothing
//                          Clock.SetTime();

//                          Prot<<"before presmooth x=\n"<<*LX[ActiveLevel]<<"\n";

//                          if(PreSmSteps>0)
//                              PreSmooth(A,LX[ActiveLevel],LB[ActiveLevel],LD[ActiveLevel],PreSmSteps);
//                          TSmooth+=Clock.GetTimeDiff();

//                          Prot<<"after presmooth x=\n"<<*LX[ActiveLevel]<<"\n";

//                          (*LD[ActiveLevel])=(*LB[ActiveLevel]);
//                          Clock.SetTime();
//                          (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel],*LD[ActiveLevel],-1,1);
//                          TDefect+=Clock.GetTimeDiff();

//                          Prot<<"defect x=\n"<<*LD[ActiveLevel]<<"\n";

//                          ActiveLevel--;

//  // Restriction of defect
//                          Clock.SetTime();

//                          Prot<<"Before restrict d=\n"<<*LD[ActiveLevel+1]<<"\n";

//                          Elem.Restrict(LD[ActiveLevel+1],LB[ActiveLevel],
//                                        MVertElem[ActiveLevel+1],MVertElem[ActiveLevel],
//                                        MMidFaces[ActiveLevel+1],MMidFaces[ActiveLevel],
//                                        MNeighElem[ActiveLevel+1],MNeighElem[ActiveLevel],
//                                        MNumVertices[ActiveLevel+1],MNumVertices[ActiveLevel],
//                                        MNumElements[ActiveLevel+1],MNumElements[ActiveLevel]);

//                          Prot<<"After restrict b=\n"<<*LB[ActiveLevel]<<"\n";

//                          TRestrict+=Clock.GetTimeDiff();

//  // Choose zero as initial vector on lower level
//                          (*LX[ActiveLevel])=0;
//                          CopyBoundaryData(LB[ActiveLevel]);

//  //	    Prot<<"After copy boundary b=\n"<<*LB[ActiveLevel]<<"\n";
//                      }

//  // Exact solution on lowest level
//                      (*LX[MinLevel])=(*LB[MinLevel]);
//                      Clock.SetTime();
//                      ExactSol(A,LX[MinLevel],LB[MinLevel],LD[MinLevel]);

//  //	  Prot<<"exact sol x=\n"<<*LX[MinLevel]<<"\n";

//                      TEvalue+=Clock.GetTimeDiff();

//                      while(ActiveLevel!=MaxLevel) {
//                          ActiveLevel++;
//                          Clock.SetTime();

//                          Prot<<"Before prol d=\n"<<*LX[ActiveLevel-1]<<"\n";

//                          Elem.Prol(LX[ActiveLevel-1],LD[ActiveLevel],
//                                    MVertElem[ActiveLevel],MVertElem[ActiveLevel-1],
//                                    MMidFaces[ActiveLevel],MMidFaces[ActiveLevel-1],
//                                    MNeighElem[ActiveLevel],MNeighElem[ActiveLevel-1],
//                                    MNumVertices[ActiveLevel],MNumVertices[ActiveLevel-1],
//                                    MNumElements[ActiveLevel],MNumElements[ActiveLevel-1]);

//                          Prot<<"After prol d=\n"<<*LD[ActiveLevel]<<"\n";

//                          TProl+=Clock.GetTimeDiff();

//                          alpha=StepControl((*A)[ActiveLevel],*LX[ActiveLevel],
//                                            *LD[ActiveLevel],*LB[ActiveLevel]);
//                          if(alpha!=1)
//                              (*LD[ActiveLevel])*=alpha;

//                          CopyBoundaryData(LD[ActiveLevel]);
//                          (*LX[ActiveLevel])+=(*LD[ActiveLevel]);

//                          if(PostSmSteps>0)
//                              PostSmooth(A,LX[ActiveLevel],LB[ActiveLevel],LD[ActiveLevel],PostSmSteps);


//                          KIT[ActiveLevel]=KIT[ActiveLevel]-1;
//                          if(KIT[ActiveLevel]==0) {
//                              if(Cycle==0)
//                                  KIT[ActiveLevel]=1;
//                              else
//                                  KIT[ActiveLevel]=KITO[ActiveLevel];
//                          } else {
//                              break;
//                          }
//                      }
//                  } while(ActiveLevel!=MaxLevel);

//                  Clock.SetTime();
//                  if(PreSmSteps>0)
//                      PreSmooth(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel],PreSmSteps);
//                  TSmooth+=Clock.GetTimeDiff();

//                  (*LD[MaxLevel])=(*LB[MaxLevel]);
//                  Clock.SetTime();
//                  (*A)[MaxLevel]->VectMult(*LX[MaxLevel],*LD[MaxLevel],-1,1);
//                  TDefect+=Clock.GetTimeDiff();

//                  Prot<<"defect d=\n"<<*LD[MaxLevel]<<"\n";

//                  Def=LD[MaxLevel]->l2Norm();
//                  ProtAdd<<"MultiGrid ITERATION "<<ITE<<"   !!RES!! = "<<Def<<"\n";
//                  DefOld=Def;

//                  if(Def<EPS)
//                      break;
//              }
//          }
//      }

//      TAll+=Clock2.GetTimeDiff();

//      if(FD>=1e-70)
//          FD=Def/FD;
//      if(ITE>NIT)
//          ITE--;
//      protocol << "22";
//      Prot<<" ("<<ITE<<",";
//      //Prot<<"MultiGrid ITERATIONS "<<ITE<<"  NORM OF RESIDUAL "<<Def<<"\n                !!RES!!/!!INITIAL RES!!"<<FD<<"\n";
//      if(ITE==1)
//          Prot<<"0.0) ";
//      else
//          Prot<<pow(FD,1.0/(DOUBLE)(ITE))<<") ";

//      ProtAdd<<"Time for MultiGrid:        "<<TAll<<" seconds\n";
//      ProtAdd<<"Time for calc. defect:     "<<TDefect<<" seconds\n";
//      ProtAdd<<"Time for smoothing:        "<<TSmooth<<" seconds\n";
//      ProtAdd<<"Time for restriction:      "<<TRestrict<<" seconds\n";
//      ProtAdd<<"Time for prolongation:     "<<TProl<<" seconds\n";
//      ProtAdd<<"Time fo solve coarse grid: "<<TEvalue<<" seconds\n";

//      for(ActiveLevel=MinLevel;ActiveLevel<MaxLevel;ActiveLevel++) {
//          delete LX[ActiveLevel];
//          delete LB[ActiveLevel];
//          delete LD[ActiveLevel];
//      }
//      delete LD[MaxLevel];
//  }

//  UNSIGNED MultiGrid_3D::NeumannMultiDriver(FiniteElement_3D& Elem,MultiCompactMatrix* A,DoubleVector  *LX1,
//                                            DoubleVector *LB1,UNSIGNED NIT,DOUBLE EPS)
//  {
//      if(Cycle<0) {
//          Err<<"Wrong Cycle Number !!\n";
//          return FALSE;
//      }
//      if(MaxLevel<MinLevel || MinLevel<=0 || MaxLevel>MAXMULTI) {
//          Err<<"Wrong Parameter MaxLevel or MinLevel !!\n";
//          return FALSE;
//      }
//      if(LX1==0)
//          LX1=new DoubleVector(MNumEquations[MaxLevel]);
//      if(LB1==0)
//          LB1=new DoubleVector(MNumEquations[MaxLevel]);
//      if(LX1->GetLen()<MNumEquations[MaxLevel] || LB1->GetLen()<MNumEquations[MaxLevel]) {
//          delete LX1;delete LB1;
//          LX1=new DoubleVector(MNumEquations[MaxLevel]);
//          LB1=new DoubleVector(MNumEquations[MaxLevel]);
//      }

//      DoubleVector *LX[MAXARRAY];
//      DoubleVector *LB[MAXARRAY];
//      DoubleVector *LD[MAXARRAY];

//      for(ActiveLevel=MinLevel;ActiveLevel<MaxLevel;ActiveLevel++) {
//          LX[ActiveLevel]=new DoubleVector(MNumEquations[ActiveLevel]);
//          LB[ActiveLevel]=new DoubleVector(MNumEquations[ActiveLevel]);
//          LD[ActiveLevel]=new DoubleVector(MNumEquations[ActiveLevel]);
//      }
//      LX[MaxLevel]=LX1;
//      LB[MaxLevel]=LB1;
//      LD[MaxLevel]=new DoubleVector(MNumEquations[MaxLevel]);

//  #ifdef CONTROL_MSG
//      Prot<<"before filter LB[MaxLevel]=\n"<<*LB[MaxLevel]<<"\n";
//  #endif

//      (*A)[MaxLevel]->Filter(*LB[MaxLevel]);

//  #ifdef CONTROL_MSG
//      Prot<<"LB[MaxLevel]=\n"<<*LB[MaxLevel]<<"\n";
//  #endif

//      DateTime Clock;
//      DOUBLE TMultiGrid=0,TSmooth=0,TEvalue=0,TDefect=0,TProl=0,TRestrict=0;
//      DOUBLE Def,DefOld,FD;
//      UNSIGNED ITE=1;

//  // only one level
//  //
//      if(MinLevel==MaxLevel) {
//          (*LX[MaxLevel])=(*LB[MaxLevel]);
//          Clock.SetTime();
//          ExactSol(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel]);
//          TEvalue+=Clock.GetTimeDiff();
//      } else {
//          UNSIGNED KITO[MAXMULTI],KIT[MAXMULTI];
//          UNSIGNED PFlag=TRUE,TFlag=TRUE;

//          KITO[MaxLevel]=1;
//          for(ActiveLevel=MinLevel+1;ActiveLevel<MaxLevel;ActiveLevel++) {
//              if(Cycle==0)
//                  KITO[ActiveLevel]=2;
//              else
//                  KITO[ActiveLevel]=Cycle;
//          }
//          ActiveLevel=MaxLevel;

//          Clock.SetTime();
//          if(PreSmSteps>0)
//              PreSmooth(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel],PreSmSteps);
//          TSmooth+=Clock.GetTimeDiff();

//  #ifdef CONTROL_MSG
//          Prot<<"After Presmooth LX[MaxLevel]=\n"<<*LX[MaxLevel]<<"\n";
//  #endif


//          (*LD[MaxLevel])=(*LB[MaxLevel]);
//          Clock.SetTime();
//          (*A)[MaxLevel]->VectMult(*LX[MaxLevel],*LD[MaxLevel],-1,1);
//  //		(*A)[MaxLevel]->Filter(*LD[MaxLevel]);
//          TDefect+=Clock.GetTimeDiff();

//  #ifdef CONTROL_MSG
//          Prot<<"Defect LD[MaxLevel]=\n"<<*LD[MaxLevel]<<"\n";
//  #endif


//          ActiveLevel--;

//          Def=LD[MaxLevel]->l2Norm();
//          DefOld=FD=Def;

//          if(FD>EPS) {
//              for(ITE=1;ITE<=NIT;ITE++) {
//                  for(ActiveLevel=MinLevel;ActiveLevel<=MaxLevel;ActiveLevel++)
//                      KIT[ActiveLevel]=KITO[ActiveLevel];

//                  ActiveLevel=MaxLevel;

//                  do {
//                      while(ActiveLevel!=MinLevel) {
//  // Pre-Smoothing
//                          Clock.SetTime();
//                          if(PreSmSteps>0)
//                              PreSmooth(A,LX[ActiveLevel],LB[ActiveLevel],LD[ActiveLevel],PreSmSteps);
//                          TSmooth+=Clock.GetTimeDiff();

//  #ifdef CONTROL_MSG
//                          Prot<<"After Presmooth LX["<<ActiveLevel<<"]=\n"<<*LX[ActiveLevel]<<"\n";
//  #endif

//                          (*LD[ActiveLevel])=(*LB[ActiveLevel]);
//                          Clock.SetTime();
//                          (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel],*LD[ActiveLevel],-1,1);
//  //	    (*A)[ActiveLevel]->Filter(*LD[ActiveLevel]);
//                          TDefect+=Clock.GetTimeDiff();

//  #ifdef CONTROL_MSG
//                          Prot<<"Defect LD["<<ActiveLevel<<"]=\n"<<*LD[ActiveLevel]<<"\n";
//  #endif

//                          ActiveLevel--;

//  // Restriction of defect
//                          Clock.SetTime();

//  //	    *LD[ActiveLevel+1]=1.;

//                          Elem.Restrict(LD[ActiveLevel+1],LB[ActiveLevel],
//                                        MVertElem[ActiveLevel+1],MVertElem[ActiveLevel],
//                                        MMidFaces[ActiveLevel+1],MMidFaces[ActiveLevel],
//                                        MNeighElem[ActiveLevel+1],MNeighElem[ActiveLevel],
//                                        MNumVertices[ActiveLevel+1],MNumVertices[ActiveLevel],
//                                        MNumElements[ActiveLevel+1],MNumElements[ActiveLevel]);
//  //						(*A)[ActiveLevel]->Filter(*LB[ActiveLevel]);
//                          TRestrict+=Clock.GetTimeDiff();

//  #ifdef CONTROL_MSG
//                          Prot<<"After Restrict LB["<<ActiveLevel<<"]=\n"<<*LB[ActiveLevel]<<"\n";
//  #endif


//  // Choose zero as initial vector on lower level
//                          (*LX[ActiveLevel])=0;
//                      }

//  // Exact solution on lowest level
//                      (*LX[MinLevel])=(*LB[MinLevel]);
//                      Clock.SetTime();
//                      ExactSol(A,LX[MinLevel],LB[MinLevel],LD[MinLevel]);
//                      TEvalue+=Clock.GetTimeDiff();

//  #ifdef CONTROL_MSG
//                      Prot<<"After CommunicateExact LX["<<MinLevel<<"]=\n"<<*LX[MinLevel]<<"\n";
//  #endif


//                      while(ActiveLevel!=MaxLevel) {
//                          ActiveLevel++;
//                          Clock.SetTime();

//                          Elem.Prol(LX[ActiveLevel-1],LD[ActiveLevel],
//                                    MVertElem[ActiveLevel],MVertElem[ActiveLevel-1],
//                                    MMidFaces[ActiveLevel],MMidFaces[ActiveLevel-1],
//                                    MNeighElem[ActiveLevel],MNeighElem[ActiveLevel-1],
//                                    MNumVertices[ActiveLevel],MNumVertices[ActiveLevel-1],
//                                    MNumElements[ActiveLevel],MNumElements[ActiveLevel-1]);
//  //						(*A)[ActiveLevel]->Filter(*LD[ActiveLevel]);
//                          TProl+=Clock.GetTimeDiff();

//  #ifdef CONTROL_MSG
//                          Prot<<"After Prol LD["<<ActiveLevel<<"]=\n"<<*LD[ActiveLevel]<<"\n";
//  #endif

//                          (*LX[ActiveLevel])+=(*LD[ActiveLevel]);

//                          if(PostSmSteps>0)
//                              PostSmooth(A,LX[ActiveLevel],LB[ActiveLevel],LD[ActiveLevel],PostSmSteps);

//  #ifdef CONTROL_MSG
//                          Prot<<"After PostSmooth LX["<<ActiveLevel<<"]=\n"<<*LX[ActiveLevel]<<"\n";
//  #endif


//                          KIT[ActiveLevel]=KIT[ActiveLevel]-1;
//                          if(KIT[ActiveLevel]==0) {
//                              if(Cycle==0)
//                                  KIT[ActiveLevel]=1;
//                              else
//                                  KIT[ActiveLevel]=KITO[ActiveLevel];
//                          } else {
//                              break;
//                          }
//                      }
//                  } while(ActiveLevel!=MaxLevel);

//                  Clock.SetTime();
//                  if(PreSmSteps>0)
//                      PreSmooth(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel],PreSmSteps);
//                  TSmooth+=Clock.GetTimeDiff();

//                  (*LD[MaxLevel])=(*LB[MaxLevel]);
//                  Clock.SetTime();
//                  (*A)[MaxLevel]->VectMult(*LX[MaxLevel],*LD[MaxLevel],-1,1);
//  //				(*A)[MaxLevel]->Filter(*LD[MaxLevel]);
//                  TDefect+=Clock.GetTimeDiff();

//  //	Prot<<"Before l2-norm LD["<<MaxLevel<<"]=\n"<<*LD[MaxLevel]<<"\n";

//                  Def=LD[MaxLevel]->l2Norm();
//                  Prot<<"MultiGrid ITERATION "<<ITE<<"   !!RES!! = "<<Def<<"\n";
//                  DefOld=Def;

//                  if(Def<EPS)
//                      break;
//              }
//          }
//      }

//      Prot<<"FD="<<FD<<"\n";
//  //  Prot<<"Def="<<Def<<"\n";
//  //  Prot<<"Def/FD="<<Def/FD<<"\n";
//      if(FD>=1e-15)
//          FD=Def/FD;
//      Prot<<"MultiGrid ITERATIONS "<<ITE<<"  NORM OF RESIDUAL "<<Def<<"\n         !!RES!!/!!INITIAL RES!!"<<FD<<"\n";
//      Prot<<"RATE OF CONVERGENCE "<<pow(FD,1.0/(DOUBLE)(ITE))<<"\n";

//      for(ActiveLevel=MinLevel;ActiveLevel<MaxLevel;ActiveLevel++) {
//          delete LX[ActiveLevel];
//          delete LB[ActiveLevel];
//          delete LD[ActiveLevel];
//      }
//      delete LD[MaxLevel];
//  }

//  UNSIGNED MultiGrid_3D::ProjMultiDriver(FiniteElement_3D& Elem,
//                                         FiniteElement_3D& ConElem,
//                                         MultiCompactMatrix* A,DoubleVector  *LX1,
//                                         DoubleVector *LB1,UNSIGNED NIT,DOUBLE EPS)
//  {
//      double alpha;

//      if(Cycle<0) {
//          Err<<"Wrong Cycle Number !!\n";
//          return FALSE;
//      }
//      if(MaxLevel<MinLevel || MinLevel<=0 || MaxLevel>MAXMULTI) {
//          Err<<"Wrong Parameter MaxLevel or MinLevel !!\n";
//          return FALSE;
//      }
//      if(LX1==0)
//          LX1=new DoubleVector(MNumElements[MaxLevel]);
//      if(LB1==0)
//          LB1=new DoubleVector(MNumElements[MaxLevel]);
//      if(LX1->GetLen()<MNumElements[MaxLevel] || LB1->GetLen()<MNumElements[MaxLevel]) {
//          delete LX1;delete LB1;
//          LX1=new DoubleVector(MNumElements[MaxLevel]);
//          LB1=new DoubleVector(MNumElements[MaxLevel]);
//      }

//      DoubleVector *LX[MAXARRAY];
//      DoubleVector *LB[MAXARRAY];
//      DoubleVector *LD[MAXARRAY];
//      DoubleVector *LT[MAXARRAY];
//      DoubleVector *LT2[MAXARRAY];

//      for(ActiveLevel=MinLevel;ActiveLevel<MaxLevel;ActiveLevel++) {
//          LX[ActiveLevel]=new DoubleVector(MNumElements[ActiveLevel]);
//          LB[ActiveLevel]=new DoubleVector(MNumElements[ActiveLevel]);
//          LD[ActiveLevel]=new DoubleVector(MNumElements[ActiveLevel]);
//          LT[ActiveLevel]=new DoubleVector(MTotNumFaces[ActiveLevel]);
//          LT2[ActiveLevel]=new DoubleVector(MTotNumFaces[ActiveLevel]);
//      }
//      LX[MaxLevel]=LX1;
//      LB[MaxLevel]=LB1;
//      LD[MaxLevel]=new DoubleVector(MNumElements[MaxLevel]);
//      LT[MaxLevel]=new DoubleVector(MTotNumFaces[MaxLevel]);
//      LT2[MaxLevel]=new DoubleVector(MTotNumFaces[MaxLevel]);

//      DateTime Clock;
//      DOUBLE TMultiGrid=0,TSmooth=0,TEvalue=0,TDefect=0,TProl=0,TRestrict=0;
//      DOUBLE Def,DefOld,FD;
//      UNSIGNED ITE;

//  // only one level
//  //
//      if(MinLevel==MaxLevel) {
//          (*LX[MaxLevel])=(*LB[MaxLevel]);
//          Clock.SetTime();
//          ExactSol(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel]);
//          TEvalue+=Clock.GetTimeDiff();
//      } else {
//          UNSIGNED KITO[MAXMULTI],KIT[MAXMULTI];
//          UNSIGNED PFlag=TRUE,TFlag=TRUE;

//          KITO[MaxLevel]=1;
//          for(ActiveLevel=MinLevel+1;ActiveLevel<MaxLevel;ActiveLevel++) {
//              if(Cycle==0)
//                  KITO[ActiveLevel]=2;
//              else
//                  KITO[ActiveLevel]=Cycle;
//          }
//          ActiveLevel=MaxLevel;

//  //		Prot<<"before presmooth x=\n"<<*LX[MaxLevel]<<"\n";

//          Clock.SetTime();
//          if(PreSmSteps>0)
//              PreSmooth(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel],PreSmSteps);
//          TSmooth+=Clock.GetTimeDiff();


//          (*LD[MaxLevel])=(*LB[MaxLevel]);
//          Clock.SetTime();
//          (*A)[MaxLevel]->VectMult(*LX[MaxLevel],*LD[MaxLevel],-1,1);
//          TDefect+=Clock.GetTimeDiff();

//  //		Prot<<"defect d=\n"<<*LD[MaxLevel]<<"\n";
//  //		Prot<<"x=\n"<<*LX[MaxLevel]<<"\n";
//  //		Prot<<"b=\n"<<*LB[MaxLevel]<<"\n";

//          ActiveLevel--;

//          Def=LD[MaxLevel]->l2Norm();
//          DefOld=FD=Def;

//          if(FD>EPS) {
//              for(ITE=1;ITE<=NIT;ITE++) {
//                  for(ActiveLevel=MinLevel;ActiveLevel<=MaxLevel;ActiveLevel++)
//                      KIT[ActiveLevel]=KITO[ActiveLevel];

//                  ActiveLevel=MaxLevel;

//                  do {
//                      while(ActiveLevel!=MinLevel) {
//  // Pre-Smoothing
//                          Clock.SetTime();
//  //						Prot<<"before presmooth x=\n"<<*LB[ActiveLevel]<<"\n";
//                          if(PreSmSteps>0)
//                              PreSmooth(A,LX[ActiveLevel],LB[ActiveLevel],LD[ActiveLevel],PreSmSteps);
//                          TSmooth+=Clock.GetTimeDiff();

//  //						Prot<<"after presmooth x=\n"<<*LX[ActiveLevel]<<"\n";

//                          (*LD[ActiveLevel])=(*LB[ActiveLevel]);
//                          Clock.SetTime();
//                          (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel],*LD[ActiveLevel],-1,1);
//                          TDefect+=Clock.GetTimeDiff();

//  //						Prot<<"defect x=\n"<<*LD[ActiveLevel]<<"\n";

//                          ActiveLevel--;

//  // Restriction of defect
//                          Clock.SetTime();

//  //						Prot<<"Before restrict d=\n"<<*LD[ActiveLevel+1]<<"\n";

//                       
//                       //   ConToRot(LD[ActiveLevel+1],LT[ActiveLevel+1],ActiveLevel+1);
//                       //   Elem.Restrict(LT[ActiveLevel+1],LT2[ActiveLevel],
//                       //   MVertElem[ActiveLevel+1],MVertElem[ActiveLevel],
//                       //   MMidFaces[ActiveLevel+1],MMidFaces[ActiveLevel],
//                       //   MNeighElem[ActiveLevel+1],MNeighElem[ActiveLevel],
//                       //   MNumVertices[ActiveLevel+1],MNumVertices[ActiveLevel],
//                       //   MNumElements[ActiveLevel+1],MNumElements[ActiveLevel]);
//  //			//			Prot<<"after restrict b=\n"<<*LB[ActiveLevel]<<"\n";
//  // RotToCon(LT2[ActiveLevel],LB[ActiveLevel],ActiveLevel);
//                         


//                          ConElem.Restrict(LD[ActiveLevel+1],LB[ActiveLevel],
//                                           MVertElem[ActiveLevel+1],MVertElem[ActiveLevel],
//                                           MMidFaces[ActiveLevel+1],MMidFaces[ActiveLevel],
//                                           MNeighElem[ActiveLevel+1],MNeighElem[ActiveLevel],
//                                           MNumVertices[ActiveLevel+1],MNumVertices[ActiveLevel],
//                                           MNumElements[ActiveLevel+1],MNumElements[ActiveLevel]);

//                          TRestrict+=Clock.GetTimeDiff();

//  // Choose zero as initial vector on lower level
//                          (*LX[ActiveLevel])=0;
//                          //	    CopyBoundaryData(LB[ActiveLevel]);
//                      }

//  // Exact solution on lowest level
//                      (*LX[MinLevel])=(*LB[MinLevel]);
//                      Clock.SetTime();

//                      ExactSol(A,LX[MinLevel],LB[MinLevel],LD[MinLevel]);
//  //					Prot<<"exact sol x=\n"<<*LX[MinLevel]<<"\n";

//                      TEvalue+=Clock.GetTimeDiff();

//                      while(ActiveLevel!=MaxLevel) {
//                          ActiveLevel++;
//                          Clock.SetTime();


//                          //Prot<<"Before prol d=\n"<<*LX[ActiveLevel-1]<<"\n";+

                        
//  //                            ConToRot(LX[ActiveLevel-1],LT2[ActiveLevel-1],ActiveLevel-1);
//  //                            Elem.Prol(LT2[ActiveLevel-1],LT[ActiveLevel],
//  //                            MVertElem[ActiveLevel],MVertElem[ActiveLevel-1],
//  //                            MMidFaces[ActiveLevel],MMidFaces[ActiveLevel-1],
//  //                            MNeighElem[ActiveLevel],MNeighElem[ActiveLevel-1],
//  //                            MNumVertices[ActiveLevel],MNumVertices[ActiveLevel-1],
//  //                            MNumElements[ActiveLevel],MNumElements[ActiveLevel-1]);
//  //                            //Prot<<"After prol d=\n"<<*LD[ActiveLevel]<<"\n";
//  //                            RotToCon(LT[ActiveLevel],LD[ActiveLevel],ActiveLevel);
                        

//                          ConElem.Prol(LX[ActiveLevel-1],LD[ActiveLevel],
//                                       MVertElem[ActiveLevel],MVertElem[ActiveLevel-1],
//                                       MMidFaces[ActiveLevel],MMidFaces[ActiveLevel-1],
//                                       MNeighElem[ActiveLevel],MNeighElem[ActiveLevel-1],
//                                       MNumVertices[ActiveLevel],MNumVertices[ActiveLevel-1],
//                                       MNumElements[ActiveLevel],MNumElements[ActiveLevel-1]);

//                          TProl+=Clock.GetTimeDiff();

//                          //alpha=StepControl((*A)[ActiveLevel],*LX[ActiveLevel],
//                          //		      *LD[ActiveLevel],*LB[ActiveLevel]);
//                          //Prot<<"alpha="<<alpha<<"\n";
//                          //if(alpha<-9)
//                          //  alpha=-9;
//                          //else if(alpha>9)
//                          //  alpha=9;
//                          //(*LD[ActiveLevel])*=alpha;

//                          //	    CopyBoundaryData(LD[ActiveLevel]);
//                          (*LX[ActiveLevel])+=(*LD[ActiveLevel]);

//                          if(PostSmSteps>0)
//                              PostSmooth(A,LX[ActiveLevel],LB[ActiveLevel],LD[ActiveLevel],PostSmSteps);

//                          KIT[ActiveLevel]=KIT[ActiveLevel]-1;
//                          if(KIT[ActiveLevel]==0) {
//                              if(Cycle==0)
//                                  KIT[ActiveLevel]=1;
//                              else
//                                  KIT[ActiveLevel]=KITO[ActiveLevel];
//                          } else {
//                              break;
//                          }
//                      }
//                  } while(ActiveLevel!=MaxLevel);

//                  Clock.SetTime();
//                  if(PreSmSteps>0)
//                      PreSmooth(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel],PreSmSteps);
//                  TSmooth+=Clock.GetTimeDiff();

//                  (*LD[MaxLevel])=(*LB[MaxLevel]);
//                  Clock.SetTime();
//                  (*A)[MaxLevel]->VectMult(*LX[MaxLevel],*LD[MaxLevel],-1,1);
//                  TDefect+=Clock.GetTimeDiff();

//  //				Prot<<"defect d=\n"<<*LD[MaxLevel]<<"\n";

//                  Def=LD[MaxLevel]->l2Norm();
//                  ProtAdd<<"MultiGrid ITERATION "<<ITE<<"   !!RES!! = "<<Def<<"\n";
//                  DefOld=Def;

//                  if(Def<EPS)
//                      break;
//              }
//          }
//      }

//      if(FD>=1e-70)
//          FD=Def/FD;
//      if(ITE>NIT)
//          ITE--;

//      Prot<<" ("<<ITE<<",";
//      //  Prot<<"multigrid ite. "<<ITE<<"  NORM OF RESIDUAL "<<Def<<"  !!RES!!/!!INITIAL RES!!"<<FD<<"\n";
//      Prot<<pow(FD,1.0/(DOUBLE)(ITE))<<") ";

//      for(ActiveLevel=MinLevel;ActiveLevel<MaxLevel;ActiveLevel++) {
//          delete LX[ActiveLevel];
//          delete LB[ActiveLevel];
//          delete LD[ActiveLevel];
//          delete LT[ActiveLevel];
//          delete LT2[ActiveLevel];
//      }
//      delete LD[MaxLevel];
//      delete LT[MaxLevel];
//      delete LT2[MaxLevel];
//  }

//  UNSIGNED MultiGrid_3D::ProjNeumannMultiDriver(FiniteElement_3D& Elem,
//                                                MultiCompactMatrix* A,
//                                                DoubleVector  *LX1,
//                                                DoubleVector *LB1,UNSIGNED NIT,
//                                                DOUBLE EPS)
//  {

//      if(Cycle<0) {
//          Err<<"Wrong Cycle Number !!\n";
//          return FALSE;
//      }
//      if(MaxLevel<MinLevel || MinLevel<=0 || MaxLevel>MAXMULTI) {
//          Err<<"Wrong Parameter MaxLevel or MinLevel !!\n";
//          return FALSE;
//      }
//      if(LX1==0)
//          LX1=new DoubleVector(MNumElements[MaxLevel]);
//      if(LB1==0)
//          LB1=new DoubleVector(MNumElements[MaxLevel]);
//      if(LX1->GetLen()<MNumElements[MaxLevel] || LB1->GetLen()<MNumElements[MaxLevel]) {
//          delete LX1;delete LB1;
//          LX1=new DoubleVector(MNumElements[MaxLevel]);
//          LB1=new DoubleVector(MNumElements[MaxLevel]);
//      }

//      DoubleVector *LX[MAXARRAY];
//      DoubleVector *LB[MAXARRAY];
//      DoubleVector *LD[MAXARRAY];
//      DoubleVector *LT[MAXARRAY];
//      DoubleVector *LT2[MAXARRAY];

//      for(ActiveLevel=MinLevel;ActiveLevel<MaxLevel;ActiveLevel++) {
//          LX[ActiveLevel]=new DoubleVector(MNumElements[ActiveLevel]);
//          LB[ActiveLevel]=new DoubleVector(MNumElements[ActiveLevel]);
//          LD[ActiveLevel]=new DoubleVector(MNumElements[ActiveLevel]);
//          LT[ActiveLevel]=new DoubleVector(MTotNumFaces[ActiveLevel]);
//          LT2[ActiveLevel]=new DoubleVector(MTotNumFaces[ActiveLevel]);
//      }
//      LX[MaxLevel]=LX1;
//      LB[MaxLevel]=LB1;
//      LD[MaxLevel]=new DoubleVector(MNumElements[MaxLevel]);
//      LT[MaxLevel]=new DoubleVector(MTotNumFaces[MaxLevel]);
//      LT2[MaxLevel]=new DoubleVector(MTotNumFaces[MaxLevel]);
//      (*A)[MaxLevel]->Filter(*LB[MaxLevel]);

//      DateTime Clock;
//      DOUBLE TMultiGrid=0,TSmooth=0,TEvalue=0,TDefect=0,TProl=0,TRestrict=0;
//      DOUBLE Def,DefOld,FD;
//      UNSIGNED ITE;

//  // only one level
//  //
//      if(MinLevel==MaxLevel) {
//          (*LX[MaxLevel])=(*LB[MaxLevel]);
//          Clock.SetTime();
//          ExactSol(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel]);
//  //    (*A)[MaxLevel]->Filter(*LX[MaxLevel]);
//          TEvalue+=Clock.GetTimeDiff();
//      } else {
//          UNSIGNED KITO[MAXMULTI],KIT[MAXMULTI];
//          UNSIGNED PFlag=TRUE,TFlag=TRUE;

//          KITO[MaxLevel]=1;
//          for(ActiveLevel=MinLevel+1;ActiveLevel<MaxLevel;ActiveLevel++) {
//              if(Cycle==0)
//                  KITO[ActiveLevel]=2;
//              else
//                  KITO[ActiveLevel]=Cycle;
//          }
//          ActiveLevel=MaxLevel;

//          Clock.SetTime();
//          if(PreSmSteps>0)
//              PreSmooth(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel],PreSmSteps);
//  //    (*A)[MaxLevel]->Filter(*LX[MaxLevel]);
//          TSmooth+=Clock.GetTimeDiff();

//  //    Prot<<"After presmooth: LX=\n"<<*LX[MaxLevel]<<"\n";

//          (*LD[MaxLevel])=(*LB[MaxLevel]);
//          Clock.SetTime();
//          (*A)[MaxLevel]->VectMult(*LX[MaxLevel],*LD[MaxLevel],-1,1);
//  //    (*A)[MaxLevel]->Filter(*LD[MaxLevel]);
//          TDefect+=Clock.GetTimeDiff();

//  //    Prot<<"After calc defect: LD=\n"<<*LD[MaxLevel]<<"\n";

//          ActiveLevel--;

//          Def=LD[MaxLevel]->l2Norm();
//          DefOld=FD=Def;

//          if(FD>EPS) {
//              for(ITE=1;ITE<=NIT;ITE++) {
//                  for(ActiveLevel=MinLevel;ActiveLevel<=MaxLevel;ActiveLevel++)
//                      KIT[ActiveLevel]=KITO[ActiveLevel];

//                  ActiveLevel=MaxLevel;

//                  do {
//                      while(ActiveLevel!=MinLevel) {
//  // Pre-Smoothing
//                          Clock.SetTime();
//                          if(PreSmSteps>0)
//                              PreSmooth(A,LX[ActiveLevel],LB[ActiveLevel],LD[ActiveLevel],PreSmSteps);
//  //	    (*A)[MaxLevel]->Filter(*LX[ActiveLevel]);
//                          TSmooth+=Clock.GetTimeDiff();

//  //	    Prot<<"After calc presmooth: LD=\n"<<*LX[ActiveLevel]<<"\n";

//                          (*LD[ActiveLevel])=(*LB[ActiveLevel]);
//                          Clock.SetTime();
//                          (*A)[ActiveLevel]->VectMult(*LX[ActiveLevel],*LD[ActiveLevel],-1,1);
//  //	    (*A)[ActiveLevel]->Filter(*LD[ActiveLevel]);
//                          TDefect+=Clock.GetTimeDiff();

//                          ActiveLevel--;

//  // Restriction of defect
//                          Clock.SetTime();
//                          ConToRot(LD[ActiveLevel+1],LT[ActiveLevel+1],ActiveLevel+1);
//                          Elem.Restrict(LT[ActiveLevel+1],LT2[ActiveLevel],
//                                        MVertElem[ActiveLevel+1],MVertElem[ActiveLevel],
//                                        MMidFaces[ActiveLevel+1],MMidFaces[ActiveLevel],
//                                        MNeighElem[ActiveLevel+1],MNeighElem[ActiveLevel],
//                                        MNumVertices[ActiveLevel+1],MNumVertices[ActiveLevel],
//                                        MNumElements[ActiveLevel+1],MNumElements[ActiveLevel]);
//  //	    (*A)[ActiveLevel]->Filter(*LB[ActiveLevel]);
//                          RotToCon(LT2[ActiveLevel],LB[ActiveLevel],ActiveLevel);
//                          TRestrict+=Clock.GetTimeDiff();

//  //	    Prot<<"Level:"<<ActiveLevel<<"  LD=\n"<<*LD[ActiveLevel]<<"\n";
//  //	    Prot<<"Level:"<<ActiveLevel<<"  LB=\n"<<*LB[ActiveLevel]<<"\n";

//  // Choose zero as initial vector on lower level
//                          (*LX[ActiveLevel])=0;
//                      }

//  // Exact solution on lowest level
//                      (*LX[MinLevel])=(*LB[MinLevel]);
//                      Clock.SetTime();
//                      ExactSol(A,LX[MinLevel],LB[MinLevel],LD[MinLevel]);
//  //	  (*A)[MaxLevel]->Filter(*LX[MinLevel]);
//                      TEvalue+=Clock.GetTimeDiff();

//                      while(ActiveLevel!=MaxLevel) {
//                          ActiveLevel++;
//                          Clock.SetTime();
//                          ConToRot(LX[ActiveLevel-1],LT2[ActiveLevel-1],ActiveLevel-1);
//                          Elem.Prol(LT2[ActiveLevel-1],LT[ActiveLevel],
//                                    MVertElem[ActiveLevel],MVertElem[ActiveLevel-1],
//                                    MMidFaces[ActiveLevel],MMidFaces[ActiveLevel-1],
//                                    MNeighElem[ActiveLevel],MNeighElem[ActiveLevel-1],
//                                    MNumVertices[ActiveLevel],MNumVertices[ActiveLevel-1],
//                                    MNumElements[ActiveLevel],MNumElements[ActiveLevel-1]);
//  //	    (*A)[ActiveLevel]->Filter(*LD[ActiveLevel]);
//                          RotToCon(LT[ActiveLevel],LD[ActiveLevel],ActiveLevel);
//                          TProl+=Clock.GetTimeDiff();

//                          (*LX[ActiveLevel])+=(*LD[ActiveLevel]);

//                          if(PostSmSteps>0)
//                              PostSmooth(A,LX[ActiveLevel],LB[ActiveLevel],LD[ActiveLevel],PostSmSteps);
//  //	    (*A)[MaxLevel]->Filter(*LX[ActiveLevel]);

//                          KIT[ActiveLevel]=KIT[ActiveLevel]-1;
//                          if(KIT[ActiveLevel]==0) {
//                              if(Cycle==0)
//                                  KIT[ActiveLevel]=1;
//                              else
//                                  KIT[ActiveLevel]=KITO[ActiveLevel];
//                          } else {
//                              break;
//                          }
//                      }
//                  } while(ActiveLevel!=MaxLevel);

//                  Clock.SetTime();
//                  if(PreSmSteps>0)
//                      PreSmooth(A,LX[MaxLevel],LB[MaxLevel],LD[MaxLevel],PreSmSteps);
//  //	(*A)[MaxLevel]->Filter(*LX[MaxLevel]);
//                  TSmooth+=Clock.GetTimeDiff();

//                  (*LD[MaxLevel])=(*LB[MaxLevel]);
//                  Clock.SetTime();
//                  (*A)[MaxLevel]->VectMult(*LX[MaxLevel],*LD[MaxLevel],-1,1);
//  //	(*A)[MaxLevel]->Filter(*LD[MaxLevel]);
//                  TDefect+=Clock.GetTimeDiff();

//                  Def=LD[MaxLevel]->l2Norm();
//                  Prot<<"MultiGrid ITERATION "<<ITE<<"   !!RES!! = "<<Def<<"\n";
//                  DefOld=Def;

//                  if(Def<EPS)
//                      break;
//              }
//          }
//      }

//      if(FD>=1e-70)
//          FD=Def/FD;
//      Prot<<"MultiGrid ITERATIONS "<<ITE<<"  NORM OF RESIDUAL "<<Def<<"  !!RES!!/!!INITIAL RES!!"<<FD<<"\n";
//      Prot<<"RATE OF CONVERGENCE "<<pow(FD,1.0/(DOUBLE)(ITE))<<"\n";

//      for(ActiveLevel=MinLevel;ActiveLevel<MaxLevel;ActiveLevel++) {
//          delete LX[ActiveLevel];
//          delete LB[ActiveLevel];
//          delete LD[ActiveLevel];
//      }
//      delete LD[MaxLevel];
//  }


