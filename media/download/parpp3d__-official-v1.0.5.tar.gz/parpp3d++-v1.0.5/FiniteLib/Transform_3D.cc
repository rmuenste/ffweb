#include "MultiGrid_3D.h"

VOID MultiGrid_3D::ConToRot(DoubleVector *vect1,DoubleVector *vect2,UNSIGNED level)
{
  int IEL,IADJ,IMID,IVE;
  double DPH;
  
  NeighElem=MNeighElem[level];
  MidFaces=MMidFaces[level];
  NumVertices=MNumVertices[level];
  NumElements=MNumElements[level];
  
  for(IEL=1;IEL<=NumElements;IEL++)
    {
      DPH=(*vect1)(IEL);
      for(IVE=1;IVE<=6;IVE++)
	{
	  IADJ=(*NeighElem)(IVE,IEL);
	  IMID=(*MidFaces)(IVE,IEL);
	  
	  if(IADJ==0)
	    (*vect2)(IMID)=DPH;
	  if(IADJ>IEL)
	    (*vect2)(IMID)=0.5*(DPH+(*vect1)(IADJ));
	}
    }
  //	Prot<<"ConToRot: vect2=\n"<<*vect2<<"\n";
}

VOID MultiGrid_3D::RotToCon(DoubleVector *vect1,DoubleVector *vect2,UNSIGNED level)
{
  int IEL;
  MidFaces=MMidFaces[level];
  NumVertices=MNumVertices[level];
  NumElements=MNumElements[level];
  
  for(IEL=1;IEL<=NumElements;IEL++)
    {
      (*vect2)(IEL)=0.166666666666*((*vect1)((*MidFaces)(1,IEL))
				    +(*vect1)((*MidFaces)(2,IEL))
				    +(*vect1)((*MidFaces)(3,IEL))
				    +(*vect1)((*MidFaces)(4,IEL))
				    +(*vect1)((*MidFaces)(5,IEL))
				    +(*vect1)((*MidFaces)(6,IEL)));
    }
  //	Prot<<"RotToCon: vect2=\n"<<*vect2<<"\n";
}


