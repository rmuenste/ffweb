#include "SquareGrid_3D.h"

int SquareGrid_3D::KGVVEL(IntArray2D *KVEL1,int s1,IntArray2D *KVEL2,int s2,int NVEL,int IEL)
{
    int IGVEL,I,IVL1,J,IVL2;
	
    IGVEL=IEL;
    for(I=1;I<=NVEL;I++)
    {
	IVL1=(*KVEL1)(I,s1);
	if(IVL1==0)
	    return IGVEL;
	for(J=1;J<=NVEL;J++)
	{
	    IVL2=(*KVEL2)(J,s2);
	    if(IVL2==0)
		break;
	    if(IVL1==IVL2 && IVL1<IGVEL)
	    {
		IGVEL=IVL1;
		break;
	    }
	}
    }
    return IGVEL;
}

VOID SquareGrid_3D::CreateEdgeInfo_3D(UNSIGNED ISE)
{
    int IEL,IED,IV1,IV2,IVT1,IVT2,INPR,INPR1,INPR2,IVH1,IVH2,IGVEL,IEDH,IVTH1,IVTH2;
    double PX1,PX2; //,PX3;
    double PY1,PY2; //,PY3;
    double PZ1,PZ2; //,PZ3;
    double PAR1,PAR2,PAR3;
	
    IntArray2D KIV(2,12);
    KIV(1,1)=1;
    KIV(2,1)=2;
    KIV(1,2)=2;
    KIV(2,2)=3;
    KIV(1,3)=3;
    KIV(2,3)=4;
    KIV(1,4)=4;
    KIV(2,4)=1;
    KIV(1,5)=1;
    KIV(2,5)=5;
    KIV(1,6)=2;
    KIV(2,6)=6;
    KIV(1,7)=3;
    KIV(2,7)=7;
    KIV(1,8)=4;
    KIV(2,8)=8;
    KIV(1,9)=5;
    KIV(2,9)=6;
    KIV(1,10)=6;
    KIV(2,10)=7;
    KIV(1,11)=7;
    KIV(2,11)=8;
    KIV(1,12)=8;
    KIV(2,12)=5;
	
    TotNumEdges=0;
    for(IEL=1;IEL<=NumElements;IEL++)
    {
	for(IED=1;IED<=NumEdgeElem;IED++)
	{
	    IV1=KIV(1,IED);
	    IV2=KIV(2,IED);
	    IVT1=(*VertElem)(IV1,IEL);
	    IVT2=(*VertElem)(IV2,IEL);
			
	    IGVEL=KGVVEL(ElemVert,IVT1,ElemVert,IVT2,NumElemVert,IEL);
	    if(IGVEL>=IEL)
	    {
		TotNumEdges++;
		(*MidEdges)(IED,IEL)=TotNumEdges;
				
		if(ISE>=2)
		{
		    INPR1=(*InfoVertEdge)(IVT1);
		    INPR2=(*InfoVertEdge)(IVT2);
		    if(INPR1==INPR2)
		    {
			INPR=INPR1;
			(*InfoVertEdge)(NumVertices+TotNumEdges)=INPR;
		    } else {
			INPR=0;
			(*InfoVertEdge)(NumVertices+TotNumEdges)=INPR;
		    }
		}
		if(ISE>=3)
		{
		    if(INPR1==0)
		    {
			PX1=(*VertCoord)(1,IVT1);
			PY1=(*VertCoord)(2,IVT1);
			PZ1=(*VertCoord)(3,IVT1);
		    } else {
			PX1=ParX((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),INPR1);
			PY1=ParY((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),INPR1);
			PZ1=ParZ((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),INPR1);
		    }
		    if(INPR2==0)
		    {
			PX2=(*VertCoord)(1,IVT2);
			PY2=(*VertCoord)(2,IVT2);
			PZ2=(*VertCoord)(3,IVT2);
		    } else {
			PX2=ParX((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),INPR1);
			PY2=ParY((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),INPR1);
			PZ2=ParZ((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),INPR1);
		    }
				
		    if(INPR==0)
		    {
			(*MidCoord)(1,TotNumEdges)=0.5*(PX1+PX2);
			(*MidCoord)(2,TotNumEdges)=0.5*(PY1+PY2);
			(*MidCoord)(3,TotNumEdges)=0.5*(PZ1+PZ2);
		    } else {
			CalcEdgeParam((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),
				      (*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),
				      PAR1,PAR2,PAR3,INPR);
			(*MidFaceCoord)(1,TotNumEdges)=ParX(PAR1,PAR2,PAR3,INPR);
			(*MidFaceCoord)(2,TotNumEdges)=ParY(PAR1,PAR2,PAR3,INPR);
			(*MidFaceCoord)(3,TotNumEdges)=ParZ(PAR1,PAR2,PAR3,INPR);
		    }
		}
	    } else {
		for(IEDH=1;IEDH<=NumEdgeElem;IEDH++)
		{
		    IVH1=KIV(1,IEDH);
		    IVH2=KIV(2,IEDH);
		    IVTH1=(*VertElem)(IVH1,IGVEL);
		    IVTH2=(*VertElem)(IVH2,IGVEL);
		    if((IVTH1==IVT1 && IVTH2==IVT2) || (IVTH1==IVT2 && IVTH2==IVT1))
		    {
			(*MidEdges)(IED,IEL)=(*MidEdges)(IEDH,IGVEL);
			break;
		    }
		}
	    }
	}
    }
}
