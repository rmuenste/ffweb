#include "FiniteElement_3D.h"

FiniteElement_3D::FiniteElement_3D(SquareGrid_3D* NGrid)
{
    DX    = new DoubleArray(NNVE);
    DY    = new DoubleArray(NNVE);
    DZ    = new DoubleArray(NNVE);
    DJAC  = new DoubleArray2D(3,3);
    DBAS  = new DoubleArray3D(NNDIM,NNBAS,NNDER);
    DBAS1 = new DoubleArray3D(NNDIM,NNBAS,NNDER);
    BDER  = new IntArray(NNDER);
    BDER1 = new IntArray2D(NNDER,2);
    KVE   = new IntArray(NNVE);
    KDFG  = new IntArray(NNBAS);
    KDFL  = new IntArray(NNBAS);
    DETJ  = 0;
    IDFL  = 0;
    NumElemMatrix = 0;
    NumEquations  = 0;
    Grid          = NGrid;
    VertElem=Grid->VertElem;
    MidEdges=Grid->MidEdges;
    MidFaces=Grid->MidFaces;
    NumVertElem=Grid->NumVertElem;
    NumFaceElem=Grid->NumFaceElem;
    NumEdgeElem=Grid->NumEdgeElem;
    NumVertices=Grid->NumVertices;
    TotNumEdges=Grid->TotNumEdges;
    TotNumFaces=Grid->TotNumFaces;
}

FiniteElement_3D::~FiniteElement_3D(void)
{
    if(DX)
        delete DX;
    if(DY)
        delete DY;
    if(DJAC)
        delete DJAC;
    if(DBAS)
        delete DBAS;
    if(BDER)
        delete BDER;
    if(KVE)
        delete KVE;
    if(KDFG)
        delete KDFG;
    if(KDFL)
        delete KDFL;
}


void FiniteElement_3D::BubbleSort(IntArray& KV1,IntArray& KV2,unsigned IDIM)
{
    int	J,I,IV1,IV2;
    // BubbleSort doesn't count 'cos it concerns only very few elements
    DateTime SortTime;
    SortTime.SetTime();

    if (IDIM > 14) {
	if (Debug) protocol << "DEBUG(" << MyProcID << "): Entering FiniteElement_3D::BubbleSort.\n";
    }

    for(J=2;J<=IDIM;J++)
    {
        IV1=KV1(J);
        IV2=KV2(J);
        for(I=J-1;I>=1;I--)
        {
            if(KV1(I)<=IV1)
                break;
            KV1(I+1)=KV1(I);
            KV2(I+1)=KV2(I);
        }
        if(I<1)
            I=0;
        KV1(I+1)=IV1;
        KV2(I+1)=IV2;
    }

    if (IDIM > 14) {
	if (Debug) protocol << "DEBUG(" << MyProcID << "):  Leaving FiniteElement_3D::BubbleSort.\n";
    }

    return;
}


DoubleVector* FiniteElement_3D::GetRightSideVector(void)
{
    VertElem    = Grid->VertElem;
    MidEdges    = Grid->MidEdges;
    NumVertElem = Grid->NumVertElem;
    TotNumEdges = Grid->TotNumEdges;

    return new DoubleVector(GetTotalDOF());
}

DoubleCompactMatrix* FiniteElement_3D::GetStiffMatrix(unsigned int ISYMM)
{
    IntArray	*KLD, *KCOL; 
    DoubleCompactMatrix	*LA; 
    int	         IFree, IEQ, BSYMM, IEL, IROW, JDOFE, JCOL, IPOS2; 
    int          IEROW, NA1, IA1, JP, MM, JDOFE1, JPOSP, JINSP, JDOFP, flag, JCOL0, IPOS1, i, I2; 

    if (Debug) protocol << "DEBUG(" << MyProcID << "): Entering FiniteElement_3D::GetStiffMatrix.\n"; 

    VertElem=Grid->VertElem;
    MidEdges=Grid->MidEdges;
    MidFaces=Grid->MidFaces;
    NumVertElem=Grid->NumVertElem;
    TotNumEdges=Grid->TotNumEdges;
    TotNumFaces=Grid->TotNumFaces;

    NumEquations=GetTotalDOF();
    KLD   = new IntArray(NumEquations+1,"KLD");
    IEROW = GetIEROW();
    NumElemMatrix=NumEquations*IEROW;
    KCOL = new IntArray(NumEquations*IEROW,"KCOL");
    if(KCOL==NULL) {
        Prot<<"Not enough memory for KCOL !!\n";
        exit(0);
    }

    BSYMM = (ISYMM == 1);

    NA1=IEROW*NumEquations;
    IFree=(IEROW-1)*NumEquations;

    for(IA1=1;IA1<=NA1;IA1++)
        (*KCOL)(IA1)=0;
    for(IEQ=1;IEQ<=NumEquations;IEQ++)
    {
        (*KLD)(IEQ)=(IEQ-1)*IEROW+1;
        (*KCOL)((IEQ-1)*IEROW+1)=IEQ;
    }
    (*KLD)(NumEquations+1)=NA1+1;

    JDOFE1=1;

    // Loop over elements
    for(IEL=1;IEL<=Grid->NumElements;IEL++) {
        SetGlobalDOF(IEL,0);
        for(JDOFE=1;JDOFE<=GetDOF();JDOFE++) {
            IROW=(*KDFG)(JDOFE);
            if(!BSYMM || IROW!=NumEquations) {
                if(BSYMM)
                    JDOFE1=JDOFE;
                IPOS2=(*KLD)(IROW+1)-1;
                JPOSP=(*KLD)(IROW)+1;

                for(JDOFP=JDOFE1;JDOFP<=GetDOF();JDOFP++) {
                    flag=true;
                    if(JDOFE!=JDOFP) {
                        JCOL=(*KDFG)(JDOFP);
                        if(JPOSP>IPOS2) {
                            JINSP=JPOSP;
                        } else {
                            for(JINSP=JPOSP;JINSP<=IPOS2;JINSP++) {
                                JCOL0=(*KCOL)(JINSP);
                                if(JCOL0==0)
                                {
                                    JPOSP=JINSP+1;
                                    (*KCOL)(JINSP)=JCOL;
                                    flag=false;
                                    break;
                                }
                                if((JCOL-JCOL0)<0)
                                    break;
                                if((JCOL-JCOL0)==0)
                                {
                                    flag=false;
                                    break;
                                }
                            }
                            if(flag==true) {
                                if((*KCOL)(IPOS2)==0) {
                                    JPOSP=JINSP+1;
                                    for(JP=JPOSP;JP<=IPOS2;JP++)
                                        if((*KCOL)(JP)==0)
                                            break;
                                    for(MM=JP;MM>=JPOSP;MM--)
                                        (*KCOL)(MM)=(*KCOL)(MM-1);
                                    (*KCOL)(JINSP)=JCOL;
                                    flag=false;
                                }
                            }
                        }

                        if(flag==true) {
                            if(IFree==0) {
                                Err<<"GetStiffMatrix: Not enough space for Stiff-Matrix !!!\n";
                                exit(1);
                            }
                            if(IROW!=NumEquations || (*KCOL)(NA1)==0)
                            {
                                flag=true;
                                for(JP=IROW;JP<=NumEquations;JP++)
                                {
                                    I2=(*KLD)(JP+1)-1;
                                    if((*KCOL)(I2)==0)
                                        break;
                                }
                                if(JP<=NumEquations)
                                {
                                    for(MM=IROW+1;MM<=JP;MM++)
                                        (*KLD)(MM)=(*KLD)(MM)+1;
                                    IPOS2++;
                                    for(JP=I2-1;JP>=JINSP;JP--)
                                        (*KCOL)(JP+1)=(*KCOL)(JP);
                                    (*KCOL)(JINSP)=JCOL;
                                    JPOSP=JINSP+1;
                                } else
                                    flag=false;
                            } else
                                flag=false;
                            if(flag==false)
                            {
                                for(JP=IROW;JP>=2;JP--) {
                                    I2=(*KLD)(JP)-1;
                                    if((*KCOL)(I2)<=0)
                                        break;
                                }
                                for(MM=JP;MM<=IROW;MM++)
                                    (*KLD)(MM)--;
                                for(JP=I2;JP<=JINSP-2;JP++)
                                    (*KCOL)(JP)=(*KCOL)(JP+1);
                                (*KCOL)(JINSP-1)=JCOL;
                                JPOSP=JINSP;
                            }
                        }
                        IFree--;
                    }
                }
            }
        }
    }

    // Compress KCOL
    NumElemMatrix=0;
    for(IEQ=1;IEQ<=NumEquations;IEQ++) {
        IPOS1=(*KLD)(IEQ);
        for(IPOS2=(*KLD)(IEQ+1)-1;IPOS2>=IPOS1;IPOS2--)
            if((*KCOL)(IPOS2)!=0)
                break;
        if(IEQ!=1) {
            for(JP=IPOS1;JP<=IPOS2;JP++)
                (*KCOL)(JP-IPOS1+NumElemMatrix+1)=(*KCOL)(JP);
        }
        (*KLD)(IEQ)=NumElemMatrix+1;
        NumElemMatrix+=IPOS2-IPOS1+1;
    }
    (*KLD)(NumEquations+1)=NumElemMatrix+1;

    LA=new DoubleCompactMatrix(NumElemMatrix,NumEquations);
    for(i=1;i<=NumEquations+1;i++)
        (*LA).Diag(i)=(*KLD)(i);
    for(i=1;i<=NumElemMatrix;i++)
        (*LA).Col(i)=(*KCOL)(i);

    delete KLD;
    delete KCOL;

    if (Debug) protocol << "DEBUG(" << MyProcID << "):  Leaving FiniteElement_3D::GetStiffMatrix.\n";

    return LA;
} // end GetStiffMatrix

//  DoubleRectMatrix* FiniteElement::GetStiffMatrix(FiniteElement* elem2)
//  {
//    IntArray	*KLD,*KCOL,*KCOL1,*KIND;
//    DoubleCompactMatrix	*LA;
//    int	IFree,IEQ,BSYMM,IDOFE1,IEL,JDOFE,IROW,JDOFP,JCOL,IPOS;
//    int	BSORT,ICOL,IHELP,i;

//    VertElem=Grid->VertElem;
//    MidEdges=Grid->MidEdges;
//    NumVertElem=Grid->NumVertElem;
//    NumEdges=Grid->NumEdges;

//    NumEquations=GetTotalDOF();
//    KLD=new IntArray(NumEquations+1,"KLD");
//    IFree=MAXMEMORY;
//    IFree-=50;
//    NumElemMatrix=IFree/3-3;
//    KCOL=new IntArray(NumElemMatrix,"KCOL");
//    KCOL1=new IntArray(NumElemMatrix,"KCOL1");
//    KIND=new IntArray(NumElemMatrix,"KIND");

//    if(NumElemMatrix<NumEquations) {
//      Err<<"GetStiffMatrix: Not enough space for Stiff-Matrix !!!\n";
//      exit(1);
//    }
//    IFree=NumElemMatrix-NumEquations;
//    NumElemMatrix=NumEquations;
//    for(IEQ=1;IEQ<=NumEquations;IEQ++) {
//      (*KIND)(IEQ)=0;
//      (*KCOL1)(IEQ)=IEQ;
//    }
//    int IDFL1[2];
//    IDFL1[0]=GetDOF();
//    IDFL1[1]=elem2->GetDOF();

//    // Loop over elements
//    for(IEL=1;IEL<=Grid->NumElements;IEL++) {
//      SetGlobalDOF(IEL,0);
//      elem2->SetGlobalDOF(IEL,0);
//      for(JDOFE=1;JDOFE<=IDFL1[0];JDOFE++) {
//        IROW=(*KDFG)(JDOFE);

//  	for(JDOFP=1;JDOFP<=IDFL1[1];JDOFP++) {
//  	    JCOL=(*elem2->KDFG)(JDOFP);
//  	    if((*KCOL1)(IROW)==0)
//  	    	(*KCOL1)(IROW)=JCOL;
//  	    else
//  	    	IPOS=IROW;
//  	    do {
//  	      if((*KIND)(IPOS)==0) {
//  			if(IFree<=0) {
//  		  		Err<<"GetStiffMatrix: Not enough space for Stiff-Matrix !!!\n";
//  		  		exit(1);
//  			}
//  			NumElemMatrix++;
//  			IFree--;
//  			(*KCOL1)(NumElemMatrix)=JCOL;
//  			(*KIND)(IPOS)=NumElemMatrix;
//  			(*KIND)(NumElemMatrix)=0;
//  			break;
//  	      }
//  	      IPOS=(*KIND)(IPOS);
//  	    } while((*KCOL1)(IPOS)!=JCOL);
//  	  }
//  	}
//    }

//    // Collect entries on KCOL1 separately for each row
//    NumElemMatrix=0;
//    for(IEQ=1;IEQ<=NumEquations;IEQ++) {
//      NumElemMatrix++;
//      (*KLD)(IEQ)=NumElemMatrix;
//      (*KCOL)(NumElemMatrix)=(*KCOL1)(IEQ);
//      IPOS=IEQ;
//      while((*KIND)(IPOS)!=0) {
//        NumElemMatrix++;
//        IPOS=(*KIND)(IPOS);
//        (*KCOL)(NumElemMatrix)=(*KCOL1)(IPOS);
//      }
//    }
//    (*KLD)(NumEquations+1)=NumElemMatrix+1;

//    // Sort off-diagonal entries on KCOL separately for each row
//    for(IEQ=1;IEQ<=NumEquations;IEQ++) {
//      do {
//        BSORT=TRUE;
//        for(ICOL=(*KLD)(IEQ)+1;ICOL<=(*KLD)(IEQ+1)-2;ICOL++) {
//  		if((*KCOL)(ICOL)>(*KCOL)(ICOL+1)) {
//  	  		IHELP=(*KCOL)(ICOL);
//  	  		(*KCOL)(ICOL)=(*KCOL)(ICOL+1);
//  	  		(*KCOL)(ICOL+1)=IHELP;
//  	  		BSORT=FALSE;
//  		}
//        }
//      } while(BSORT==FALSE);
//    }

//    delete KCOL1;
//    delete KIND;
//    LR=new DoubleRectMatrix(NumElemMatrix,NumEquations);
//    for(i=1;i<=NumEquations+1;i++)
//      (*LR).Diag(i)=(*KLD)(i);
//    for(i=1;i<=NumElemMatrix;i++)
//      (*LR).Col(i)=(*KCOL)(i);

//    delete KLD;
//    delete KCOL;

//    return LR;
//  }

void FiniteElement_3D::CalcStiffMatrix(DoubleCompactMatrix*& NLA,
				       unsigned int BCON,
                                       IntArray2D&  KAB,
				       unsigned int KABN,  unsigned int ICUB,
                                       unsigned int ISYMM, unsigned int ICLEAR, unsigned int ILINT)
{
    DoubleArray2D	Coecon(NNDER,NNDER);
    NumIntegration_3D	MyCub(ICUB);
    IntArray2D		Kentry(NNBAS,NNBAS);
    int      BSYMM, i, j, i1, BFIRST, BCONO, IA, IB, ICUBP, IROW, ICOL, ICOL1, J1;
    int      JDOFE1, IEL, JDOFE, ILD, JCOLO, IDFG, JCOL, JP, IALBET, JCOLB, IVE, IDOFE;
//      int      IDIM;
    double  DB;
    double       XI1, XI2, XI3, OM, XX, YY, ZZ, AUX;
    double   	 DJ11, DJ12, DJ13, DJ21, DJ22, DJ23, DJ31, DJ32, DJ33, DJ41, DJ42, DJ43;
    double   	 DJ51, DJ52, DJ53, DJ61, DJ62, DJ63, DJ71, DJ72, DJ73, DJ81, DJ82, DJ83;

    if (Debug) protocol << "DEBUG(" << MyProcID << "): Entering FiniteElement_3D::CalcStiffMatrix.\n";

    VertElem    = Grid->VertElem;
    MidEdges    = Grid->MidEdges;
    MidFaces    = Grid->MidFaces;
    NumVertElem = Grid->NumVertElem;
    TotNumEdges = Grid->TotNumEdges;
    TotNumFaces = Grid->TotNumFaces;

    LA=NLA;

    if (NLA == 0) {
        LA  = GetStiffMatrix(ISYMM);
        NLA = LA;
    } else {
        NumElemMatrix = NLA->GetLen();
        NumEquations  = GetTotalDOF();
    }
    if(ICLEAR == TRUE)
        (*LA)=0;

    BSYMM=(ISYMM>=1);
    for(i=1;i<=NNDER;i++)
        (*BDER)(i)=FALSE;

    for(i=1;i<=KABN;i++) {
        for(j=1;j<=2;j++) {
            i1=KAB(j,i);
            if(i1<=0 || i1>NNDER) {
                Err<<"CalcStiffMatrix: Wrong value in array KAB specified !!\n";
                exit(1);
            }
            (*BDER)(i1)=TRUE;
        }
    }

    BFIRST=TRUE;
    AUX=Grid->StiffCoeff(0,0,0,-1,-1,BFIRST);
    BCONO=TRUE;

    if(BCON) {
        for(i=1;i<=KABN;i++) {
            IA=KAB(1,i);
            IB=KAB(2,i);
            Coecon(IA,IB)=Grid->StiffCoeff(0,0,0,IA,IB,BFIRST);
        }
    } else {
        BCONO=FALSE;
    }

    // Set zero elements of Jacobian for axiparallel grid
    ICUBP=ICUB;
    if(ILINT==2)
    {
        (*DJAC)(1,3)=0;
        (*DJAC)(2,3)=0;
        (*DJAC)(3,1)=0;
        (*DJAC)(3,2)=0;
    }

    // Loop over all elements
    if(GetElemType()==NON_PARAM) {
        JDOFE1=1;
        for(IEL=1;IEL<=Grid->NumElements;IEL++) {
            SetGlobalDOF(IEL,1);
            // Determine entry positions in matrix
            for(JDOFE=1;JDOFE<=GetDOF();JDOFE++) {
                ILD=(*LA).Diag((*KDFG)(JDOFE));
                Kentry(JDOFE,JDOFE)=ILD;
                if(BSYMM)
                    JDOFE1=JDOFE;
                JCOLO=ILD;
                for(IDOFE=JDOFE1;IDOFE<=GetDOF();IDOFE++) {
                    if(IDOFE!=JDOFE) {
                        IDFG=(*KDFG)(IDOFE);
                        for(JCOL=JCOLO;JCOL<=NumElemMatrix;JCOL++) {
                            if((*LA).Col(JCOL)==IDFG) {
                                JCOLO=JCOL+1;
                                Kentry(JDOFE,IDOFE)=JCOL;
                                break;
                            }
                        }
                    }
                }
            }

            // Evaluation of coordinates of the vertices
            for(IVE=1;IVE<=Grid->NumVertElem;IVE++) {
                JP=(*Grid->VertElem)(IVE,IEL);
                (*KVE)(IVE)=JP;
                (*DX)(IVE)=(*Grid->VertCoord)(1,JP);
                (*DY)(IVE)=(*Grid->VertCoord)(2,JP);
                (*DZ)(IVE)=(*Grid->VertCoord)(3,JP);
            }

            if(ILINT==2) {
                DJ11=((*DX)(2)+(*DX)(4))*Q2;
                DJ12=((*DY)(2)+(*DY)(4))*Q2;
                DJ13=((*DZ)(1)+(*DZ)(5))*Q2;
                (*DJAC)(1,1)=(-(*DX)(1)+(*DX)(2))*Q2;
                (*DJAC)(2,1)=(-(*DY)(1)+(*DY)(2))*Q2;
                (*DJAC)(1,2)=(-(*DX)(1)+(*DX)(4))*Q2;
                (*DJAC)(2,2)=(-(*DY)(1)+(*DY)(4))*Q2;
                (*DJAC)(3,3)=(-(*DZ)(1)+(*DZ)(5))*Q2;
                DETJ=(*DJAC)(3,3)*((*DJAC)(1,1)*(*DJAC)(2,2)-(*DJAC)(2,1)*(*DJAC)(1,2));
            } else if(ILINT==1) {
                DJ11=((*DX)(1)+(*DX)(2)+(*DX)(3)+(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ12=((*DY)(1)+(*DY)(2)+(*DY)(3)+(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ13=((*DZ)(1)+(*DZ)(2)+(*DZ)(3)+(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                (*DJAC)(1,1)=(-(*DX)(1)+(*DX)(2)+(*DX)(3)-(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                (*DJAC)(2,1)=(-(*DY)(1)+(*DY)(2)+(*DY)(3)-(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                (*DJAC)(3,1)=(-(*DZ)(1)+(*DZ)(2)+(*DZ)(3)-(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
                (*DJAC)(1,2)=(-(*DX)(1)-(*DX)(2)+(*DX)(3)+(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                (*DJAC)(2,2)=(-(*DY)(1)-(*DY)(2)+(*DY)(3)+(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                (*DJAC)(3,2)=(-(*DZ)(1)-(*DZ)(2)+(*DZ)(3)+(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                (*DJAC)(1,3)=(-(*DX)(1)-(*DX)(2)-(*DX)(3)-(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                (*DJAC)(2,3)=(-(*DY)(1)-(*DY)(2)-(*DY)(3)-(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                (*DJAC)(3,3)=(-(*DZ)(1)-(*DZ)(2)-(*DZ)(3)-(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DETJ= (*DJAC)(1,1)*((*DJAC)(2,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(2,3))
                    -(*DJAC)(2,1)*((*DJAC)(1,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(1,3))
                    +(*DJAC)(3,1)*((*DJAC)(1,2)*(*DJAC)(2,3)-(*DJAC)(2,2)*(*DJAC)(1,3));
            } else {
                DJ11=( (*DX)(1)+(*DX)(2)+(*DX)(3)+(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ12=( (*DY)(1)+(*DY)(2)+(*DY)(3)+(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ13=( (*DZ)(1)+(*DZ)(2)+(*DZ)(3)+(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DJ21=(-(*DX)(1)+(*DX)(2)+(*DX)(3)-(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                DJ22=(-(*DY)(1)+(*DY)(2)+(*DY)(3)-(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                DJ23=(-(*DZ)(1)+(*DZ)(2)+(*DZ)(3)-(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
                DJ31=(-(*DX)(1)-(*DX)(2)+(*DX)(3)+(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ32=(-(*DY)(1)-(*DY)(2)+(*DY)(3)+(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ33=(-(*DZ)(1)-(*DZ)(2)+(*DZ)(3)+(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DJ41=(-(*DX)(1)-(*DX)(2)-(*DX)(3)-(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ42=(-(*DY)(1)-(*DY)(2)-(*DY)(3)-(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ43=(-(*DZ)(1)-(*DZ)(2)-(*DZ)(3)-(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DJ51=( (*DX)(1)-(*DX)(2)+(*DX)(3)-(*DX)(4)+(*DX)(5)-(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                DJ52=( (*DY)(1)-(*DY)(2)+(*DY)(3)-(*DY)(4)+(*DY)(5)-(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                DJ53=( (*DZ)(1)-(*DZ)(2)+(*DZ)(3)-(*DZ)(4)+(*DZ)(5)-(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
                DJ61=( (*DX)(1)-(*DX)(2)-(*DX)(3)+(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                DJ62=( (*DY)(1)-(*DY)(2)-(*DY)(3)+(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                DJ63=( (*DZ)(1)-(*DZ)(2)-(*DZ)(3)+(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
                DJ71=( (*DX)(1)+(*DX)(2)-(*DX)(3)-(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ72=( (*DY)(1)+(*DY)(2)-(*DY)(3)-(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ73=( (*DZ)(1)+(*DZ)(2)-(*DZ)(3)-(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DJ81=(-(*DX)(1)+(*DX)(2)-(*DX)(3)+(*DX)(4)+(*DX)(5)-(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                DJ82=(-(*DY)(1)+(*DY)(2)-(*DY)(3)+(*DY)(4)+(*DY)(5)-(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                DJ83=(-(*DZ)(1)+(*DZ)(2)-(*DZ)(3)+(*DZ)(4)+(*DZ)(5)-(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
            }

            PreCalc(0.0,0.0,0.0);

            for(ICUBP=1;ICUBP<=MyCub.NumCubPoints();ICUBP++) {
                XI1=MyCub.CubPoint(ICUBP,1);
                XI2=MyCub.CubPoint(ICUBP,2);
                XI3=MyCub.CubPoint(ICUBP,3);
                // Jacobian of the trilinear mapping onto the reference element
                if(ILINT==0) {
                    (*DJAC)(1,1)=DJ21+DJ51*XI2+DJ61*XI3+DJ81*XI2*XI3;
                    (*DJAC)(1,2)=DJ31+DJ51*XI1+DJ71*XI3+DJ81*XI1*XI3;
                    (*DJAC)(1,3)=DJ41+DJ61*XI1+DJ71*XI2+DJ81*XI1*XI2;
                    (*DJAC)(2,1)=DJ22+DJ52*XI2+DJ62*XI3+DJ82*XI2*XI3;
                    (*DJAC)(2,2)=DJ32+DJ52*XI1+DJ72*XI3+DJ82*XI1*XI3;
                    (*DJAC)(2,3)=DJ42+DJ62*XI1+DJ72*XI2+DJ82*XI1*XI2;
                    (*DJAC)(3,1)=DJ23+DJ53*XI2+DJ63*XI3+DJ83*XI2*XI3;
                    (*DJAC)(3,2)=DJ33+DJ53*XI1+DJ73*XI3+DJ83*XI1*XI3;
                    (*DJAC)(3,3)=DJ43+DJ63*XI1+DJ73*XI2+DJ83*XI1*XI2;
                    DETJ= (*DJAC)(1,1)*((*DJAC)(2,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(2,3))
                        -(*DJAC)(2,1)*((*DJAC)(1,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(1,3))
                        +(*DJAC)(3,1)*((*DJAC)(1,2)*(*DJAC)(2,3)-(*DJAC)(2,2)*(*DJAC)(1,3));
                }
                // *** Cubature points on the actual element + weights
                if(ILINT==2) {
                    XX=DJ11+(*DJAC)(1,1)*XI1+(*DJAC)(1,2)*XI2;
                    YY=DJ12+(*DJAC)(2,1)*XI1+(*DJAC)(2,2)*XI2;
                    ZZ=DJ13+(*DJAC)(3,3)*XI3;
                } else if(ILINT==1) {
                    XX=DJ11+(*DJAC)(1,1)*XI1+(*DJAC)(1,2)*XI2+(*DJAC)(1,3)*XI3;
                    YY=DJ12+(*DJAC)(2,1)*XI1+(*DJAC)(2,2)*XI2+(*DJAC)(2,3)*XI3;
                    ZZ=DJ13+(*DJAC)(3,1)*XI1+(*DJAC)(3,2)*XI2+(*DJAC)(3,3)*XI3;
                } else {
                    XX=DJ11+(*DJAC)(1,1)*XI1+DJ31*XI2+DJ41*XI3+DJ71*XI2*XI3;
                    YY=DJ12+DJ22*XI1+(*DJAC)(2,2)*XI2+DJ42*XI3+DJ62*XI1*XI3;
                    ZZ=DJ13+DJ23*XI1+DJ33*XI2+(*DJAC)(3,3)*XI3+DJ53*XI1*XI2;
                }

                OM=MyCub.Omega(ICUBP)*fabs(DETJ);

                GetValue(XX,YY,ZZ);

                // Summing up over all pairs of multiindices
                BFIRST=TRUE;
                for(IALBET=1;IALBET<=KABN;IALBET++) {
                    IA=KAB(1,IALBET);
                    IB=KAB(2,IALBET);
                    if(BCON==FALSE)
                        AUX=Grid->StiffCoeff(XX,YY,ZZ,IA,IB,BFIRST)*OM;
                    else
                        AUX=Coecon(IA,IB)*OM;
                    for(JDOFE=1;JDOFE<=GetDOF();JDOFE++) {
                        DB=(*DBAS)(1,(*KDFL)(JDOFE),IA);
                        if(BSYMM)
                            JDOFE1=JDOFE;
                        for(IDOFE=JDOFE1;IDOFE<=GetDOF();IDOFE++) {
                            JCOLB=Kentry(JDOFE,IDOFE);
                            if (JCOLB > LA->GetLen())
                            {
                                Prot<<"IEL="<<IEL<<" NumData="<<LA->GetNumData()<<" JCOLB="<<JCOLB<<" too high !!!\n";
                                for(i=1;i<=GetDOF();i++)
                                    for(j=1;j<=GetDOF();j++)
                                        Prot<<"Kentry("<<i<<","<<j<<")="<<Kentry(i,j)<<"\n";

				protocol << progname << " (process " << MyProcID << "):\n"
					 << "  Program aborted in FiniteElement_3D::CalcStiffMatrix. Region 1.\n";
                                exit(0);
                            }
                            (*LA).Data(JCOLB)+=DB*(*DBAS)(1,(*KDFL)(IDOFE),IB)*AUX;
                        }
                    }
                }
            }
        }

    } else {
        JDOFE1=1;
        for(IEL=1;IEL<=Grid->NumElements;IEL++) {
            SetGlobalDOF(IEL,1);
            // Determine entry positions in matrix
            for(JDOFE=1;JDOFE<=GetDOF();JDOFE++) {
                ILD=(*LA).Diag((*KDFG)(JDOFE));
                Kentry(JDOFE,JDOFE)=ILD;
                if(BSYMM)
                    JDOFE1=JDOFE;
                JCOLO=ILD;
                for(IDOFE=JDOFE1;IDOFE<=GetDOF();IDOFE++) {
                    if(IDOFE!=JDOFE) {
                        IDFG=(*KDFG)(IDOFE);
                        for(JCOL=JCOLO;JCOL<=NumElemMatrix;JCOL++) {
                            if((*LA).Col(JCOL)==IDFG) {
                                JCOLO=JCOL+1;
                                Kentry(JDOFE,IDOFE)=JCOL;
                                break;
                            }
                        }
                    }
                }
            }

            // Evaluation of coordinates of the vertices
            for(IVE=1;IVE<=Grid->NumVertElem;IVE++) {
                JP=(*Grid->VertElem)(IVE,IEL);
                (*KVE)(IVE)=JP;
                (*DX)(IVE)=(*Grid->VertCoord)(1,JP);
                (*DY)(IVE)=(*Grid->VertCoord)(2,JP);
                (*DZ)(IVE)=(*Grid->VertCoord)(3,JP);
            }

            if(ILINT==2) {
                DJ11=((*DX)(2)+(*DX)(4))*Q2;
                DJ12=((*DY)(2)+(*DY)(4))*Q2;
                DJ13=((*DZ)(1)+(*DZ)(5))*Q2;
                (*DJAC)(1,1)=(-(*DX)(1)+(*DX)(2))*Q2;
                (*DJAC)(2,1)=(-(*DY)(1)+(*DY)(2))*Q2;
                (*DJAC)(1,2)=(-(*DX)(1)+(*DX)(4))*Q2;
                (*DJAC)(2,2)=(-(*DY)(1)+(*DY)(4))*Q2;
                (*DJAC)(3,3)=(-(*DZ)(1)+(*DZ)(5))*Q2;
                DETJ=(*DJAC)(3,3)*((*DJAC)(1,1)*(*DJAC)(2,2)-(*DJAC)(2,1)*(*DJAC)(1,2));
            } else if(ILINT==1) {
                DJ11=((*DX)(1)+(*DX)(2)+(*DX)(3)+(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ12=((*DY)(1)+(*DY)(2)+(*DY)(3)+(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ13=((*DZ)(1)+(*DZ)(2)+(*DZ)(3)+(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                (*DJAC)(1,1)=(-(*DX)(1)+(*DX)(2)+(*DX)(3)-(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                (*DJAC)(2,1)=(-(*DY)(1)+(*DY)(2)+(*DY)(3)-(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                (*DJAC)(3,1)=(-(*DZ)(1)+(*DZ)(2)+(*DZ)(3)-(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
                (*DJAC)(1,2)=(-(*DX)(1)-(*DX)(2)+(*DX)(3)+(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                (*DJAC)(2,2)=(-(*DY)(1)-(*DY)(2)+(*DY)(3)+(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                (*DJAC)(3,2)=(-(*DZ)(1)-(*DZ)(2)+(*DZ)(3)+(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                (*DJAC)(1,3)=(-(*DX)(1)-(*DX)(2)-(*DX)(3)-(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                (*DJAC)(2,3)=(-(*DY)(1)-(*DY)(2)-(*DY)(3)-(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                (*DJAC)(3,3)=(-(*DZ)(1)-(*DZ)(2)-(*DZ)(3)-(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DETJ= (*DJAC)(1,1)*((*DJAC)(2,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(2,3))
                    -(*DJAC)(2,1)*((*DJAC)(1,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(1,3))
                    +(*DJAC)(3,1)*((*DJAC)(1,2)*(*DJAC)(2,3)-(*DJAC)(2,2)*(*DJAC)(1,3));
            } else {
                DJ11=( (*DX)(1)+(*DX)(2)+(*DX)(3)+(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ12=( (*DY)(1)+(*DY)(2)+(*DY)(3)+(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ13=( (*DZ)(1)+(*DZ)(2)+(*DZ)(3)+(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DJ21=(-(*DX)(1)+(*DX)(2)+(*DX)(3)-(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                DJ22=(-(*DY)(1)+(*DY)(2)+(*DY)(3)-(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                DJ23=(-(*DZ)(1)+(*DZ)(2)+(*DZ)(3)-(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
                DJ31=(-(*DX)(1)-(*DX)(2)+(*DX)(3)+(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ32=(-(*DY)(1)-(*DY)(2)+(*DY)(3)+(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ33=(-(*DZ)(1)-(*DZ)(2)+(*DZ)(3)+(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DJ41=(-(*DX)(1)-(*DX)(2)-(*DX)(3)-(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ42=(-(*DY)(1)-(*DY)(2)-(*DY)(3)-(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ43=(-(*DZ)(1)-(*DZ)(2)-(*DZ)(3)-(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DJ51=( (*DX)(1)-(*DX)(2)+(*DX)(3)-(*DX)(4)+(*DX)(5)-(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                DJ52=( (*DY)(1)-(*DY)(2)+(*DY)(3)-(*DY)(4)+(*DY)(5)-(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                DJ53=( (*DZ)(1)-(*DZ)(2)+(*DZ)(3)-(*DZ)(4)+(*DZ)(5)-(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
                DJ61=( (*DX)(1)-(*DX)(2)-(*DX)(3)+(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                DJ62=( (*DY)(1)-(*DY)(2)-(*DY)(3)+(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                DJ63=( (*DZ)(1)-(*DZ)(2)-(*DZ)(3)+(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
                DJ71=( (*DX)(1)+(*DX)(2)-(*DX)(3)-(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
                DJ72=( (*DY)(1)+(*DY)(2)-(*DY)(3)-(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
                DJ73=( (*DZ)(1)+(*DZ)(2)-(*DZ)(3)-(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
                DJ81=(-(*DX)(1)+(*DX)(2)-(*DX)(3)+(*DX)(4)+(*DX)(5)-(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
                DJ82=(-(*DY)(1)+(*DY)(2)-(*DY)(3)+(*DY)(4)+(*DY)(5)-(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
                DJ83=(-(*DZ)(1)+(*DZ)(2)-(*DZ)(3)+(*DZ)(4)+(*DZ)(5)-(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
            }


            // Loop over all cubature points
            for(ICUBP=1;ICUBP<=MyCub.NumCubPoints();ICUBP++) {
                XI1=MyCub.CubPoint(ICUBP,1);
                XI2=MyCub.CubPoint(ICUBP,2);
                XI3=MyCub.CubPoint(ICUBP,3);
                // Jacobian of the trilinear mapping onto the reference element
                if(ILINT==0) {
                    (*DJAC)(1,1)=DJ21+DJ51*XI2+DJ61*XI3+DJ81*XI2*XI3;
                    (*DJAC)(1,2)=DJ31+DJ51*XI1+DJ71*XI3+DJ81*XI1*XI3;
                    (*DJAC)(1,3)=DJ41+DJ61*XI1+DJ71*XI2+DJ81*XI1*XI2;
                    (*DJAC)(2,1)=DJ22+DJ52*XI2+DJ62*XI3+DJ82*XI2*XI3;
                    (*DJAC)(2,2)=DJ32+DJ52*XI1+DJ72*XI3+DJ82*XI1*XI3;
                    (*DJAC)(2,3)=DJ42+DJ62*XI1+DJ72*XI2+DJ82*XI1*XI2;
                    (*DJAC)(3,1)=DJ23+DJ53*XI2+DJ63*XI3+DJ83*XI2*XI3;
                    (*DJAC)(3,2)=DJ33+DJ53*XI1+DJ73*XI3+DJ83*XI1*XI3;
                    (*DJAC)(3,3)=DJ43+DJ63*XI1+DJ73*XI2+DJ83*XI1*XI2;
                    DETJ= (*DJAC)(1,1)*((*DJAC)(2,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(2,3))
                        -(*DJAC)(2,1)*((*DJAC)(1,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(1,3))
                        +(*DJAC)(3,1)*((*DJAC)(1,2)*(*DJAC)(2,3)-(*DJAC)(2,2)*(*DJAC)(1,3));
                }

                OM=MyCub.Omega(ICUBP)*fabs(DETJ);

                GetValue(XI1,XI2,XI3);
                if(BCONO==FALSE) {
                    if(ILINT==2) {
                        XX=DJ11+(*DJAC)(1,1)*XI1+(*DJAC)(1,2)*XI2;
                        YY=DJ12+(*DJAC)(2,1)*XI1+(*DJAC)(2,2)*XI2;
                        ZZ=DJ13+(*DJAC)(3,3)*XI3;
                    } else if(ILINT==1) {
                        XX=DJ11+(*DJAC)(1,1)*XI1+(*DJAC)(1,2)*XI2+(*DJAC)(1,3)*XI3;
                        YY=DJ12+(*DJAC)(2,1)*XI1+(*DJAC)(2,2)*XI2+(*DJAC)(2,3)*XI3;
                        ZZ=DJ13+(*DJAC)(3,1)*XI1+(*DJAC)(3,2)*XI2+(*DJAC)(3,3)*XI3;
                    } else {
                        XX=DJ11+(*DJAC)(1,1)*XI1+DJ31*XI2+DJ41*XI3+DJ71*XI2*XI3;
                        YY=DJ12+DJ22*XI1+(*DJAC)(2,2)*XI2+DJ42*XI3+DJ62*XI1*XI3;
                        ZZ=DJ13+DJ23*XI1+DJ33*XI2+(*DJAC)(3,3)*XI3+DJ53*XI1*XI2;
                    }
                }
                // Summing up over all pairs of multiindices
                BFIRST=TRUE;
                for(IALBET=1;IALBET<=KABN;IALBET++) {
                    IA=KAB(1,IALBET);
                    IB=KAB(2,IALBET);
                    if(BCON==FALSE)
                        AUX=Grid->StiffCoeff(XX,YY,ZZ,IA,IB,BFIRST)*OM;
                    else
                        AUX=Coecon(IA,IB)*OM;
                    for(JDOFE=1;JDOFE<=GetDOF();JDOFE++) {
                        DB=(*DBAS)(1,(*KDFL)(JDOFE),IA);
                        if(BSYMM)
                            JDOFE1=JDOFE;
                        for(IDOFE=JDOFE1;IDOFE<=GetDOF();IDOFE++) {
                            JCOLB=Kentry(JDOFE,IDOFE);
                            if(JCOLB>LA->GetLen())
                            {
                                Prot<<"IEL="<<IEL<<" NumData="<<LA->GetNumData()<<" JCOLB="<<JCOLB<<" too high !!!\n";
                                for(i=1;i<=GetDOF();i++)
                                    for(j=1;j<=GetDOF();j++)
                                        Prot<<"Kentry("<<i<<","<<j<<")="<<Kentry(i,j)<<"\n";

				protocol << progname << " (process " << MyProcID << "):\n"
					 << "  Program aborted in FiniteElement_3D::CalcStiffMatrix. Region 2.\n";
                                exit(0);
                            }
                            (*LA).Data(JCOLB)+=DB*(*DBAS)(1,(*KDFL)(IDOFE),IB)*AUX;
                        }
                    }
                }
            }
        }
    }

    if(ISYMM>1) {
        for(IROW=1;IROW<=NumEquations;IROW++) {
            for(ICOL=(*LA).Diag(IROW)+1;ICOL<=(*LA).Diag(IROW+1)-1;ICOL++) {
                J1=(*LA).Col(ICOL);
                if(J1>=IROW)
                    break;
                for(ICOL1=(*LA).Diag(J1+1)-1;ICOL1>=(*LA).Diag(J1);ICOL1--) {
                    if((*LA).Col(ICOL1)==IROW) {
                        (*LA).Data(ICOL)=(*LA).Data(ICOL1);
                        break;
                    }
                }
            }
        }
    }

    if (Debug) protocol << "DEBUG(" << MyProcID << "):  Leaving FiniteElement_3D::CalcStiffMatrix.\n";

    return;
}

void FiniteElement_3D::CalcRightSide(DoubleVector*& LB,unsigned int BCON,IntArray& KB,unsigned int KBN,
                                     unsigned int ICUB,unsigned int ICLEAR,unsigned int ILINT)
{
    DoubleArray	Coecon(NNDER);
    NumIntegration_3D	MyCub(ICUB);
    int      i,i1,IGLOB,IBN,BFIRST,BCONO,IB,ICUBP;
//      int      JDOFE1;
    int      IEL,JDOFE,JP,IVE;
    double       XI1,XI2,XI3,OM,XX,YY,ZZ,AUX;
    double   	 DJ11,DJ12,DJ13,DJ21,DJ22,DJ23,DJ31,DJ32,DJ33,DJ41,DJ42,DJ43;
    double   	 DJ51,DJ52,DJ53,DJ61,DJ62,DJ63,DJ71,DJ72,DJ73,DJ81,DJ82,DJ83;

    if (Debug) protocol << "DEBUG(" << MyProcID << "): Entering FiniteElement_3D::CalcRightSide.\n";

    VertElem     = Grid->VertElem;
    MidEdges     = Grid->MidEdges;
    MidFaces     = Grid->MidFaces;
    NumVertElem  = Grid->NumVertElem;
    TotNumEdges  = Grid->TotNumEdges;
    TotNumFaces  = Grid->TotNumFaces;

    NumEquations = GetTotalDOF();

    if(NumEquations==0 || LB==0) {
        if(LB)
            delete LB;
        LB=GetRightSideVector();
    } else {
        if((*LB).GetLen()<NumEquations) {
            delete LB;
            LB=GetRightSideVector();
        }
    }
    if(ICLEAR==TRUE)
        (*LB)=0;

    for(i=1;i<=NNDER;i++)
        (*BDER)(i)=FALSE;
    for(i=1;i<=KBN;i++) {
        i1=KB(i);
        if(i1<=0 || i1>NNDER) {
            Err<<"CalcRightSide: Wrong value in array KAB specified !!\n";
            exit(1);
        }
        (*BDER)(i1)=TRUE;
    }
    BFIRST=TRUE;
    AUX=Grid->RightSideCoeff(0,0,0,-1,BFIRST);
    BCONO=TRUE;
    if(BCON) {
        for(i=1;i<=KBN;i++) {
            IB=KB(i);
            Coecon(IB)=Grid->RightSideCoeff(0,0,0,IB,BFIRST);
        }
    } else {
        BCONO=FALSE;
    }

// Set zero elements of Jacobian for axiparallel grid
    ICUBP=ICUB;
    if(ILINT==2)
    {
        (*DJAC)(1,3)=0;
        (*DJAC)(2,3)=0;
        (*DJAC)(3,1)=0;
        (*DJAC)(3,2)=0;
    }

    // Loop over all elements
    for(IEL=1;IEL<=Grid->NumElements;IEL++) {
        SetGlobalDOF(IEL,1);
//          JDOFE1=1;

        // Evaluation of coordinates of the vertices
        for(IVE=1;IVE<=Grid->NumVertElem;IVE++) {
            JP=(*Grid->VertElem)(IVE,IEL);
            (*KVE)(IVE)=JP;
            (*DX)(IVE)=(*Grid->VertCoord)(1,JP);
            (*DY)(IVE)=(*Grid->VertCoord)(2,JP);
            (*DZ)(IVE)=(*Grid->VertCoord)(3,JP);
        }

        if(ILINT==2) {
            DJ11=((*DX)(2)+(*DX)(4))*Q2;
            DJ12=((*DY)(2)+(*DY)(4))*Q2;
            DJ13=((*DZ)(1)+(*DZ)(5))*Q2;
            (*DJAC)(1,1)=(-(*DX)(1)+(*DX)(2))*Q2;
            (*DJAC)(2,1)=(-(*DY)(1)+(*DY)(2))*Q2;
            (*DJAC)(1,2)=(-(*DX)(1)+(*DX)(4))*Q2;
            (*DJAC)(2,2)=(-(*DY)(1)+(*DY)(4))*Q2;
            (*DJAC)(3,3)=(-(*DZ)(1)+(*DZ)(5))*Q2;
            DETJ=(*DJAC)(3,3)*((*DJAC)(1,1)*(*DJAC)(2,2)-(*DJAC)(2,1)*(*DJAC)(1,2));
        } else if(ILINT==1) {
            DJ11=((*DX)(1)+(*DX)(2)+(*DX)(3)+(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
            DJ12=((*DY)(1)+(*DY)(2)+(*DY)(3)+(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
            DJ13=((*DZ)(1)+(*DZ)(2)+(*DZ)(3)+(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
            (*DJAC)(1,1)=(-(*DX)(1)+(*DX)(2)+(*DX)(3)-(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
            (*DJAC)(2,1)=(-(*DY)(1)+(*DY)(2)+(*DY)(3)-(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
            (*DJAC)(3,1)=(-(*DZ)(1)+(*DZ)(2)+(*DZ)(3)-(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
            (*DJAC)(1,2)=(-(*DX)(1)-(*DX)(2)+(*DX)(3)+(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
            (*DJAC)(2,2)=(-(*DY)(1)-(*DY)(2)+(*DY)(3)+(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
            (*DJAC)(3,2)=(-(*DZ)(1)-(*DZ)(2)+(*DZ)(3)+(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
            (*DJAC)(1,3)=(-(*DX)(1)-(*DX)(2)-(*DX)(3)-(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
            (*DJAC)(2,3)=(-(*DY)(1)-(*DY)(2)-(*DY)(3)-(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
            (*DJAC)(3,3)=(-(*DZ)(1)-(*DZ)(2)-(*DZ)(3)-(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
            DETJ= (*DJAC)(1,1)*((*DJAC)(2,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(2,3))
                -(*DJAC)(2,1)*((*DJAC)(1,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(1,3))
                +(*DJAC)(3,1)*((*DJAC)(1,2)*(*DJAC)(2,3)-(*DJAC)(2,2)*(*DJAC)(1,3));
        } else {
            DJ11=( (*DX)(1)+(*DX)(2)+(*DX)(3)+(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
            DJ12=( (*DY)(1)+(*DY)(2)+(*DY)(3)+(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
            DJ13=( (*DZ)(1)+(*DZ)(2)+(*DZ)(3)+(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
            DJ21=(-(*DX)(1)+(*DX)(2)+(*DX)(3)-(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
            DJ22=(-(*DY)(1)+(*DY)(2)+(*DY)(3)-(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
            DJ23=(-(*DZ)(1)+(*DZ)(2)+(*DZ)(3)-(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
            DJ31=(-(*DX)(1)-(*DX)(2)+(*DX)(3)+(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
            DJ32=(-(*DY)(1)-(*DY)(2)+(*DY)(3)+(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
            DJ33=(-(*DZ)(1)-(*DZ)(2)+(*DZ)(3)+(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
            DJ41=(-(*DX)(1)-(*DX)(2)-(*DX)(3)-(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
            DJ42=(-(*DY)(1)-(*DY)(2)-(*DY)(3)-(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
            DJ43=(-(*DZ)(1)-(*DZ)(2)-(*DZ)(3)-(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
            DJ51=( (*DX)(1)-(*DX)(2)+(*DX)(3)-(*DX)(4)+(*DX)(5)-(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
            DJ52=( (*DY)(1)-(*DY)(2)+(*DY)(3)-(*DY)(4)+(*DY)(5)-(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
            DJ53=( (*DZ)(1)-(*DZ)(2)+(*DZ)(3)-(*DZ)(4)+(*DZ)(5)-(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
            DJ61=( (*DX)(1)-(*DX)(2)-(*DX)(3)+(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
            DJ62=( (*DY)(1)-(*DY)(2)-(*DY)(3)+(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
            DJ63=( (*DZ)(1)-(*DZ)(2)-(*DZ)(3)+(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
            DJ71=( (*DX)(1)+(*DX)(2)-(*DX)(3)-(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
            DJ72=( (*DY)(1)+(*DY)(2)-(*DY)(3)-(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
            DJ73=( (*DZ)(1)+(*DZ)(2)-(*DZ)(3)-(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
            DJ81=(-(*DX)(1)+(*DX)(2)-(*DX)(3)+(*DX)(4)+(*DX)(5)-(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
            DJ82=(-(*DY)(1)+(*DY)(2)-(*DY)(3)+(*DY)(4)+(*DY)(5)-(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
            DJ83=(-(*DZ)(1)+(*DZ)(2)-(*DZ)(3)+(*DZ)(4)+(*DZ)(5)-(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
        }

        // Loop over all cubature points
        for(ICUBP=1;ICUBP<=MyCub.NumCubPoints();ICUBP++) {
            XI1=MyCub.CubPoint(ICUBP,1);
            XI2=MyCub.CubPoint(ICUBP,2);
            XI3=MyCub.CubPoint(ICUBP,3);
            // Jacobian of the trilinear mapping onto the reference element
            if(ILINT==0) {
                (*DJAC)(1,1)=DJ21+DJ51*XI2+DJ61*XI3+DJ81*XI2*XI3;
                (*DJAC)(1,2)=DJ31+DJ51*XI1+DJ71*XI3+DJ81*XI1*XI3;
                (*DJAC)(1,3)=DJ41+DJ61*XI1+DJ71*XI2+DJ81*XI1*XI2;
                (*DJAC)(2,1)=DJ22+DJ52*XI2+DJ62*XI3+DJ82*XI2*XI3;
                (*DJAC)(2,2)=DJ32+DJ52*XI1+DJ72*XI3+DJ82*XI1*XI3;
                (*DJAC)(2,3)=DJ42+DJ62*XI1+DJ72*XI2+DJ82*XI1*XI2;
                (*DJAC)(3,1)=DJ23+DJ53*XI2+DJ63*XI3+DJ83*XI2*XI3;
                (*DJAC)(3,2)=DJ33+DJ53*XI1+DJ73*XI3+DJ83*XI1*XI3;
                (*DJAC)(3,3)=DJ43+DJ63*XI1+DJ73*XI2+DJ83*XI1*XI2;
                DETJ= (*DJAC)(1,1)*((*DJAC)(2,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(2,3))
                    -(*DJAC)(2,1)*((*DJAC)(1,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(1,3))
                    +(*DJAC)(3,1)*((*DJAC)(1,2)*(*DJAC)(2,3)-(*DJAC)(2,2)*(*DJAC)(1,3));
            }

            OM=MyCub.Omega(ICUBP)*fabs(DETJ);

            GetValue(XI1,XI2,XI3);
            if(BCONO==FALSE) {
                if(ILINT==2) {
                    XX=DJ11+(*DJAC)(1,1)*XI1+(*DJAC)(1,2)*XI2;
                    YY=DJ12+(*DJAC)(2,1)*XI1+(*DJAC)(2,2)*XI2;
                    ZZ=DJ13+(*DJAC)(3,3)*XI3;
                } else if(ILINT==1) {
                    XX=DJ11+(*DJAC)(1,1)*XI1+(*DJAC)(1,2)*XI2+(*DJAC)(1,3)*XI3;
                    YY=DJ12+(*DJAC)(2,1)*XI1+(*DJAC)(2,2)*XI2+(*DJAC)(2,3)*XI3;
                    ZZ=DJ13+(*DJAC)(3,1)*XI1+(*DJAC)(3,2)*XI2+(*DJAC)(3,3)*XI3;
                } else {
                    XX=DJ11+(*DJAC)(1,1)*XI1+DJ31*XI2+DJ41*XI3+DJ71*XI2*XI3;
                    YY=DJ12+DJ22*XI1+(*DJAC)(2,2)*XI2+DJ42*XI3+DJ62*XI1*XI3;
                    ZZ=DJ13+DJ23*XI1+DJ33*XI2+(*DJAC)(3,3)*XI3+DJ53*XI1*XI2;
                }
            }
            // Summing up over all pairs of multiindices
            BFIRST=TRUE;
            for(IBN=1;IBN<=KBN;IBN++) {
                IB=KB(IBN);
                if(BCON==FALSE)
                    AUX=Grid->RightSideCoeff(XX,YY,ZZ,IB,BFIRST)*OM;
                else
                    AUX=Coecon(IB)*OM;
                for(JDOFE=1;JDOFE<=GetDOF();JDOFE++) {
                    IGLOB=(*KDFG)(JDOFE);
                    (*LB)(IGLOB)+=(*DBAS)(1,(*KDFL)(JDOFE),IB)*AUX;
                }
            }
        }
    }

    if (Debug) protocol << "DEBUG(" << MyProcID << "):  Leaving FiniteElement_3D::CalcRightSide.\n";

    return;
}

void FiniteElement_3D::CalcValueCoeff(double xx,double yy,double zz,double dtx,double dty,
                                      double dnx,double dny,
                                      DoubleVector *sol1,DoubleVector *sol2,int iel,double& dut)
{
//  double     DJ11,DJ12,DJ13;
    double     DJ21,DJ22,DJ23,DJ31,DJ32,DJ33,DJ41,DJ42,DJ43;
    double     DJ51,DJ52,DJ53,DJ61,DJ62,DJ63,DJ71,DJ72,DJ73,DJ81,DJ82,DJ83;
    int        IVE,jdfl,JP;

    if (Debug) protocol << "DEBUG(" << MyProcID << "): Entering FiniteElement_3D::CalcValueCoeff.\n";

    (*BDER)(1)=TRUE;
    (*BDER)(2)=TRUE;
    (*BDER)(3)=TRUE;
    (*BDER)(4)=TRUE;
    *DBAS=0.;

    SetGlobalDOF(iel,1);

    // Evaluation of coordinates of the vertices
    for(IVE=1;IVE<=Grid->NumVertElem;IVE++) {
        JP=(*Grid->VertElem)(IVE,iel);
        (*KVE)(IVE)=JP;
        (*DX)(IVE)=(*Grid->VertCoord)(1,JP);
        (*DY)(IVE)=(*Grid->VertCoord)(2,JP);
        (*DZ)(IVE)=(*Grid->VertCoord)(3,JP);
    }

    if(GetElemType()==NON_PARAM) {
        PreCalc(0.0,0.0,0.0);
        GetValue(xx,yy,zz);

        dut=0.;

        for(jdfl=1;jdfl<=GetDOF();jdfl++) {
            dut+=(*sol1)((*KDFG)(jdfl))*(*DBAS)(1,(*KDFL)(jdfl),2)*dtx*dnx
                +(*sol2)((*KDFG)(jdfl))*(*DBAS)(1,(*KDFL)(jdfl),2)*dty*dnx
                +(*sol1)((*KDFG)(jdfl))*(*DBAS)(1,(*KDFL)(jdfl),3)*dtx*dny
                +(*sol2)((*KDFG)(jdfl))*(*DBAS)(1,(*KDFL)(jdfl),3)*dty*dny;
        }

    } else {
// SB: unused.
//          DJ11=( (*DX)(1)+(*DX)(2)+(*DX)(3)+(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
//          DJ12=( (*DY)(1)+(*DY)(2)+(*DY)(3)+(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
//          DJ13=( (*DZ)(1)+(*DZ)(2)+(*DZ)(3)+(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
        DJ21=(-(*DX)(1)+(*DX)(2)+(*DX)(3)-(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
        DJ22=(-(*DY)(1)+(*DY)(2)+(*DY)(3)-(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
        DJ23=(-(*DZ)(1)+(*DZ)(2)+(*DZ)(3)-(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
        DJ31=(-(*DX)(1)-(*DX)(2)+(*DX)(3)+(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
        DJ32=(-(*DY)(1)-(*DY)(2)+(*DY)(3)+(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
        DJ33=(-(*DZ)(1)-(*DZ)(2)+(*DZ)(3)+(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
        DJ41=(-(*DX)(1)-(*DX)(2)-(*DX)(3)-(*DX)(4)+(*DX)(5)+(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
        DJ42=(-(*DY)(1)-(*DY)(2)-(*DY)(3)-(*DY)(4)+(*DY)(5)+(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
        DJ43=(-(*DZ)(1)-(*DZ)(2)-(*DZ)(3)-(*DZ)(4)+(*DZ)(5)+(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
        DJ51=( (*DX)(1)-(*DX)(2)+(*DX)(3)-(*DX)(4)+(*DX)(5)-(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
        DJ52=( (*DY)(1)-(*DY)(2)+(*DY)(3)-(*DY)(4)+(*DY)(5)-(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
        DJ53=( (*DZ)(1)-(*DZ)(2)+(*DZ)(3)-(*DZ)(4)+(*DZ)(5)-(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
        DJ61=( (*DX)(1)-(*DX)(2)-(*DX)(3)+(*DX)(4)-(*DX)(5)+(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
        DJ62=( (*DY)(1)-(*DY)(2)-(*DY)(3)+(*DY)(4)-(*DY)(5)+(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
        DJ63=( (*DZ)(1)-(*DZ)(2)-(*DZ)(3)+(*DZ)(4)-(*DZ)(5)+(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;
        DJ71=( (*DX)(1)+(*DX)(2)-(*DX)(3)-(*DX)(4)-(*DX)(5)-(*DX)(6)+(*DX)(7)+(*DX)(8))*Q8;
        DJ72=( (*DY)(1)+(*DY)(2)-(*DY)(3)-(*DY)(4)-(*DY)(5)-(*DY)(6)+(*DY)(7)+(*DY)(8))*Q8;
        DJ73=( (*DZ)(1)+(*DZ)(2)-(*DZ)(3)-(*DZ)(4)-(*DZ)(5)-(*DZ)(6)+(*DZ)(7)+(*DZ)(8))*Q8;
        DJ81=(-(*DX)(1)+(*DX)(2)-(*DX)(3)+(*DX)(4)+(*DX)(5)-(*DX)(6)+(*DX)(7)-(*DX)(8))*Q8;
        DJ82=(-(*DY)(1)+(*DY)(2)-(*DY)(3)+(*DY)(4)+(*DY)(5)-(*DY)(6)+(*DY)(7)-(*DY)(8))*Q8;
        DJ83=(-(*DZ)(1)+(*DZ)(2)-(*DZ)(3)+(*DZ)(4)+(*DZ)(5)-(*DZ)(6)+(*DZ)(7)-(*DZ)(8))*Q8;


        // Jacobian of the trilinear mapping onto the reference element
        (*DJAC)(1,1)=DJ21+DJ51*yy+DJ61*zz+DJ81*yy*zz;
        (*DJAC)(1,2)=DJ31+DJ51*xx+DJ71*zz+DJ81*xx*zz;
        (*DJAC)(1,3)=DJ41+DJ61*xx+DJ71*yy+DJ81*xx*yy;
        (*DJAC)(2,1)=DJ22+DJ52*yy+DJ62*zz+DJ82*yy*zz;
        (*DJAC)(2,2)=DJ32+DJ52*xx+DJ72*zz+DJ82*xx*zz;
        (*DJAC)(2,3)=DJ42+DJ62*xx+DJ72*yy+DJ82*xx*yy;
        (*DJAC)(3,1)=DJ23+DJ53*yy+DJ63*zz+DJ83*yy*zz;
        (*DJAC)(3,2)=DJ33+DJ53*xx+DJ73*zz+DJ83*xx*zz;
        (*DJAC)(3,3)=DJ43+DJ63*xx+DJ73*yy+DJ83*xx*yy;
        DETJ= (*DJAC)(1,1)*((*DJAC)(2,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(2,3))
            -(*DJAC)(2,1)*((*DJAC)(1,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(1,3))
            +(*DJAC)(3,1)*((*DJAC)(1,2)*(*DJAC)(2,3)-(*DJAC)(2,2)*(*DJAC)(1,3));

        PreCalc(0.0,0.0,0.0);
        GetValue(xx,yy,zz);

        dut=0.;

        for(jdfl=1;jdfl<=GetDOF();jdfl++) {
            dut+=(*sol1)((*KDFG)(jdfl))*(*DBAS)(1,(*KDFL)(jdfl),2)*dtx*dnx
                +(*sol2)((*KDFG)(jdfl))*(*DBAS)(1,(*KDFL)(jdfl),2)*dty*dnx
                +(*sol1)((*KDFG)(jdfl))*(*DBAS)(1,(*KDFL)(jdfl),3)*dtx*dny
                +(*sol2)((*KDFG)(jdfl))*(*DBAS)(1,(*KDFL)(jdfl),3)*dty*dny;
        }
    }

    if (Debug) protocol << "DEBUG(" << MyProcID << "):  Leaving FiniteElement_3D::CalcValueCoeff.\n";

    return;
}


