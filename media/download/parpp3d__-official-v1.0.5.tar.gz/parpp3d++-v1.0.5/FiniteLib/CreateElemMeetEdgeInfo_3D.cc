#include "SquareGrid_3D.h"

VOID SquareGrid_3D::CreateElemMeetEdgeInfo_3D(IntArray2D* KEDGE,IntArray2D* KEEL,UNSIGNED flag)
{
    IntArray *arr;
    int IET,MIN;

    if (Debug) protocol << "DEBUG(" << MyProcID << "): Entering SquareGrid_3D::CreateElemMeetEdgeInfo_3D.\n";

    if (flag == 0) {
         arr = new IntArray(KEDGE->GetLen()); 
        *arr = 0; 

        NumElemEdge=0;
        for(int IEL=1;IEL<=NumElements;IEL++) {
            for (int IEE = 1; IEE <= NumEdgeElem; IEE++) {
                IET=(*KEDGE)(IEE,IEL);
                (*arr)(IET)++;
                if(NumElemEdge<(*arr)(IET)) {
                    NumElemEdge=(*arr)(IET);
		}
            }
        }
        delete arr;

	if (Debug) protocol << "DEBUG(" << MyProcID << "):  Leaving SquareGrid_3D::CreateElemMeetEdgeInfo_3D.\n";

        return;
    }

    if (flag == 1) {
        *KEEL = 0; 
        for(int IEL=1;IEL<=NumElements;IEL++)
        {
            for(int IEE=1;IEE<=NumEdgeElem;IEE++)
            {
                IET=(*KEDGE)(IEE,IEL);
                for(int IEEL=1;IEEL<=NumElemEdge;IEEL++)
                    if((*KEEL)(IET,IEEL)==0)
                        (*KEEL)(IET,IEEL)=IEL;
            }
        }


	// BubbleSort doesn't count 'cos it concerns only very few elements
        for(int IET=1;IET<=TotNumEdges;IET++) {
            for(int IEEL=1;IEEL<=NumElemEdge;IEEL++) {
                MIN=(*KEEL)(IET,IEEL);
                if(MIN)
                {
                    for(int JEEL=IEEL+1;JEEL<=NumElemEdge;JEEL++)
                    {
                        if((*KEEL)(IET,JEEL))
                        {
                            if((*KEEL)(IET,JEEL)<MIN)
                            {
                                (*KEEL)(IET,IEEL)=(*KEEL)(IET,JEEL);
                                (*KEEL)(IET,JEEL)=MIN;
                                MIN=(*KEEL)(IET,IEEL);
                            }
                        }
                    }
                }
            }
        }
    }

    if (Debug) protocol << "DEBUG(" << MyProcID << "):  Leaving SquareGrid_3D::CreateElemMeetEdgeInfo_3D.\n";

    return;
}
