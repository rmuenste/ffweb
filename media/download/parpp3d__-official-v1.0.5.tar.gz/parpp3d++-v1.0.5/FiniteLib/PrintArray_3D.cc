#include "SquareGrid_3D.h"

VOID SquareGrid_3D::PrintInfoVertEdge(VOID)
{
	Prot<<"InfoVertEdge:\n";
	Prot<<(*InfoVertEdge);
}

VOID SquareGrid_3D::PrintVertElem(VOID)
{
	Prot<<"VertElem:\n";
	Prot<<(*VertElem);
}

VOID SquareGrid_3D::PrintNeighElem(VOID)
{
	Prot<<"NeighElem:\n";
	Prot<<(*NeighElem);
}

VOID SquareGrid_3D::PrintVertCoord(VOID)
{
	Prot<<"VertCoord:\n";
	Prot<<(*VertCoord);
}

VOID SquareGrid_3D::PrintMidFaces(VOID)
{
	Prot<<"MidFaces:\n";
	Prot<<(*MidFaces);
}

VOID SquareGrid_3D::PrintInfo()
{
  Prot<<"Number of vertices: "<<NumVertices<<" Number of elements: "<<NumElements<<"\n";
  Prot<<"Number of edges: "<<TotNumEdges<<" Number of faces: "<<TotNumFaces<<"\n";
}

//  VOID SquareGrid_3D::WriteGrid(char* name)
//  {
//  	Output Daten(name,YES);
	
//  	Daten<<"Grobgitter\nEinheitskubus\n";
//  	Daten<<NumElements<<" "<<NumVertices<<" "<<NumBound<<" "<<NumVertElem<<" "<<NumEdgeElem<<" "<<NumFaceElem<<"  NEL NVT NBCT NVE NEE NAE\n";
//  	Daten<<"DCORVG\n";
//  	for(int i=1;i<=NumVertices;i++)
//  		Daten<<(*VertCoord)(1,i)<<" "<<(*VertCoord)(2,i)<<" "<<(*VertCoord)(3,i)<<"\n";
	
//  	Daten<<"KVERT\n";
//  	for(int j=1;j<=NumElements;j++)
//  	{
//  		for(int k=1;k<=NumVertElem;k++)
//  			Daten<<(*VertElem)(k,j)<<" ";
//  		Daten<<"\n";
//  	}
	
//  	Daten<<"KNPR\n";
//  	for(int n=1;n<=NumVertices;n++)
//  		Daten<<(*InfoVertEdge)(n)<<" ";
//  	Daten<<"\n";
	
//  }








