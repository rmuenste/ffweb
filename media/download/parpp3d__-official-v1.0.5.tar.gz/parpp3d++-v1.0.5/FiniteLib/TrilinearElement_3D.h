#ifndef TRILINEARELEMENT3DH

#define TRILINEARELEMENT3DH

#include "FiniteElement_3D.h"

class TrilinearElement_3D:public FiniteElement_3D
{
  public:
  TrilinearElement_3D(SquareGrid_3D *NGrid):FiniteElement_3D(NGrid) 
  {IDFL=NumVertElem;NDIM=1;}
  ~TrilinearElement_3D(VOID) {}
  
  VOID GetValue(DOUBLE X1,DOUBLE X2,DOUBLE X3);
  UNSIGNED GetDOF(VOID);
  UNSIGNED GetTotalDOF(VOID);
  UNSIGNED GetIEROW(VOID);
  int      GetElemType(void);
  VOID SetGlobalDOF(UNSIGNED IEL,UNSIGNED IPAR);
  VOID Restrict(DoubleVector *LD,DoubleVector *LB,
		IntArray2D *VertElem2,IntArray2D *VertElem1,
		IntArray2D *MidFaces2,IntArray2D *MidFaces1,
		IntArray2D *NeighElem2,IntArray2D *NeighElem1,
		UNSIGNED NumVertices2,UNSIGNED NumVertices1,
		UNSIGNED NumElements2,UNSIGNED NumElements1);
  VOID Prol(DoubleVector *LD,DoubleVector *LB,
	    IntArray2D *VertElem2,IntArray2D *VertElem1,
	    IntArray2D *MidFaces2,IntArray2D *MidFaces1,
	    IntArray2D *NeighElem2,IntArray2D *NeighElem1,
	    UNSIGNED NumVertices2,UNSIGNED NumVertices1,
	    UNSIGNED NumElements2,UNSIGNED NumElements1);
};

inline UNSIGNED TrilinearElement_3D::GetDOF(VOID)
{
  return IDFL;
}

inline UNSIGNED TrilinearElement_3D::GetTotalDOF(VOID)
{
  return Grid->NumVertices;
}

inline UNSIGNED TrilinearElement_3D::GetIEROW(VOID)
{
  return 27;
}

inline int TrilinearElement_3D::GetElemType(VOID)
{
  return PARAM;
}

#endif
