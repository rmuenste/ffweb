#include "SquareGrid_3D.h"

VOID SquareGrid_3D::AdjustGridInfo_3D()
{
  IntArray   KEL(8);
  IntArray   KIEL(4);
  IntArray   KIELH(4);
	
  IntArray2D KIV(2,12);
  KIV(1,1)=1;
  KIV(2,1)=2;
  KIV(1,2)=2;
  KIV(2,2)=3;
  KIV(1,3)=3;
  KIV(2,3)=4;
  KIV(1,4)=4;
  KIV(2,4)=1;
  KIV(1,5)=1;
  KIV(2,5)=5;
  KIV(1,6)=2;
  KIV(2,6)=6;
  KIV(1,7)=3;
  KIV(2,7)=7;
  KIV(1,8)=4;
  KIV(2,8)=8;
  KIV(1,9)=5;
  KIV(2,9)=6;
  KIV(1,10)=6;
  KIV(2,10)=7;
  KIV(1,11)=7;
  KIV(2,11)=8;
  KIV(1,12)=8;
  KIV(2,12)=5;

  IntArray2D KIAD(4,6);
  KIAD(1,1)=1;
  KIAD(2,1)=2;
  KIAD(3,1)=3;
  KIAD(4,1)=4;
  KIAD(1,2)=1;
  KIAD(2,2)=2;
  KIAD(3,2)=6;
  KIAD(4,2)=5;
  KIAD(1,3)=2;
  KIAD(2,3)=3;
  KIAD(3,3)=7;
  KIAD(4,3)=6;
  KIAD(1,4)=3;
  KIAD(2,4)=4;
  KIAD(3,4)=8;
  KIAD(4,4)=7;
  KIAD(1,5)=4;
  KIAD(2,5)=1;
  KIAD(3,5)=5;
  KIAD(4,5)=8;
  KIAD(1,6)=5;
  KIAD(2,6)=6;
  KIAD(3,6)=7;
  KIAD(4,6)=8;
	
	
  int NELOLD,NVTOLD,NETOLD,ICEDGE,IEL,IED,IEDGE,IVE1,IVE2,IVT1,IBCT1;
//    int NATOLD;
  int IVT2,IBCT2,I,I1,I2,IVT3,IVT4,IBCT3,IBCT4,INEIGH,J;
  int IV1,IV2,IV3,IV4,IV5,IV6,IV7,IV8,INEI1,INEI2,IVER1,IVER2,IVT5,IVT6,IVT7,IVT8;
  int IBCT5,IBCT6,IBCT7,IBCT8,IAR,IELH,IARH;
  double X1,X2,X3,X4,Y1,Y2,Y3,Y4,Z1,Z2,Z3,Z4,PAR1,PAR2,PAR3;
  double X5,X6,X7,X8,Y5,Y6,Y7,Y8,Z5,Z6,Z7,Z8;
	
  NELOLD=NumElements;
  NVTOLD=NumVertices;
  NETOLD=TotNumEdges;
//    NATOLD=TotNumFaces;
	
  NumVertices=NVTOLD+NETOLD;
  TotNumFaces=0;
  ICEDGE=0;
	
  for(IEL=1;IEL<=NELOLD;IEL++)
  {
    for(IED=1;IED<=NumEdgeElem;IED++)
    {
      IEDGE=(*MidEdges)(IED,IEL);
      if(IEDGE>ICEDGE)
      {
	ICEDGE++;
	IVE1=KIV(1,IED);
	IVE2=KIV(2,IED);
				
	IVT1=(*VertElem)(IVE1,IEL);
	IBCT1=(*InfoVertEdge)(IVT1);
	IVT2=(*VertElem)(IVE2,IEL);
	IBCT2=(*InfoVertEdge)(IVT2);
				
	if(IBCT1==0)
	{
	  X1=(*VertCoord)(1,IVT1);
	  Y1=(*VertCoord)(2,IVT1);
	  Z1=(*VertCoord)(3,IVT1);
	} else {
	  X1=ParX((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),IBCT1);
	  Y1=ParY((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),IBCT1);
	  Z1=ParZ((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),IBCT1);
	}
	if(IBCT2==0)
	{
	  X2=(*VertCoord)(1,IVT2);
	  Y2=(*VertCoord)(2,IVT2);
	  Z2=(*VertCoord)(3,IVT2);
	} else {
	  X2=ParX((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),IBCT2);
	  Y2=ParY((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),IBCT2);
	  Z2=ParZ((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),IBCT2);
	}

					
	if(IBCT1==0 || IBCT2==0 || IBCT1!=IBCT2)
	{
	  (*InfoVertEdge)(NVTOLD+IEDGE)=0;
	  (*VertCoord)(1,NVTOLD+IEDGE)=0.5*(X1+X2);
	  (*VertCoord)(2,NVTOLD+IEDGE)=0.5*(Y1+Y2);
	  (*VertCoord)(3,NVTOLD+IEDGE)=0.5*(Z1+Z2);
// for parallel computing
	  AppendBoundNode(IVT1,IVT2,IEDGE+NVTOLD,0);
	} else {
	  (*InfoVertEdge)(NVTOLD+IEDGE)=IBCT1;
	  CalcEdgeParam((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),
			(*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),
			PAR1,PAR2,PAR3,IBCT1);
	  (*VertCoord)(1,NVTOLD+IEDGE)=PAR1;
	  (*VertCoord)(2,NVTOLD+IEDGE)=PAR2;
	  (*VertCoord)(3,NVTOLD+IEDGE)=PAR3;
// for parallel computing
	  AppendBoundNode(IVT1,IVT2,IEDGE+NVTOLD,IBCT1);
	}
      }
    }
// Actualization of KVERT on old edges
    KEL(1)=IEL;
    for(I=1;I<=7;I++)
	KEL(I+1)=NumElements+I;
    for(I=1;I<=8;I++)
	(*VertElem)(1,KEL(I))=(*VertElem)(I,IEL);
			
    for(I1=1;I1<=4;I1++)
    {
      I2=(I1%4)+1;
      IEDGE=(*MidEdges)(I1,IEL);
      (*VertElem)(2,KEL(I1))=IEDGE+NVTOLD;
      (*VertElem)(4,KEL(I2))=IEDGE+NVTOLD;
    }
    for(I1=1;I1<=4;I1++)
    {
      I2=I1+4;
      IEDGE=(*MidEdges)(I1+4,IEL);
      (*VertElem)(5,KEL(I1))=IEDGE+NVTOLD;
      (*VertElem)(5,KEL(I2))=IEDGE+NVTOLD;
    }	
    for(I1=1;I1<=4;I1++)
    {
      I2=(I1%4)+1;
      IEDGE=(*MidEdges)(I1+8,IEL);
      (*VertElem)(2,KEL(I1+4))=IEDGE+NVTOLD;
      (*VertElem)(4,KEL(I2+4))=IEDGE+NVTOLD;
    }
// Calculation of coordinates and numbers of midpoints of areas and of neighbours
    for(IAR=1;IAR<=NumFaceElem;IAR++)
    {
      INEIGH=(*NeighElem)(IAR,IEL);
      if(INEIGH==0 || INEIGH>=IEL)
      {
	NumVertices++;
	TotNumFaces+=4;
				
	IVT1=(*VertElem)(1,KEL(KIAD(1,IAR)));
	IVT2=(*VertElem)(1,KEL(KIAD(2,IAR)));
	IVT3=(*VertElem)(1,KEL(KIAD(3,IAR)));
	IVT4=(*VertElem)(1,KEL(KIAD(4,IAR)));
	IBCT1=(*InfoVertEdge)(IVT1);
	IBCT2=(*InfoVertEdge)(IVT2);
	IBCT3=(*InfoVertEdge)(IVT3);
	IBCT4=(*InfoVertEdge)(IVT4);
				
	if(IBCT1==0)
	{
	  X1=(*VertCoord)(1,IVT1);
	  Y1=(*VertCoord)(2,IVT1);
	  Z1=(*VertCoord)(3,IVT1);
	} else {
	  X1=ParX((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),IBCT1);
	  Y1=ParY((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),IBCT1);
	  Z1=ParZ((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),IBCT1);
	}
	if(IBCT2==0)
	{
	  X2=(*VertCoord)(1,IVT2);
	  Y2=(*VertCoord)(2,IVT2);
	  Z2=(*VertCoord)(3,IVT2);
	} else {
	  X2=ParX((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),IBCT2);
	  Y2=ParY((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),IBCT2);
	  Z2=ParZ((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),IBCT2);
	}
	if(IBCT3==0)
	{
	  X3=(*VertCoord)(1,IVT3);
	  Y3=(*VertCoord)(2,IVT3);
	  Z3=(*VertCoord)(3,IVT3);
	} else {
	  X3=ParX((*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),IBCT3);
	  Y3=ParY((*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),IBCT3);
	  Z3=ParZ((*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),IBCT3);
	}
	if(IBCT4==0)
	{
	  X4=(*VertCoord)(1,IVT4);
	  Y4=(*VertCoord)(2,IVT4);
	  Z4=(*VertCoord)(3,IVT4);
	} else {
	  X4=ParX((*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),IBCT4);
	  Y4=ParY((*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),IBCT4);
	  Z4=ParZ((*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),IBCT4);
	}
	if(IAR==1 || IAR==6)
	{
	  (*VertElem)(3,KEL(KIAD(1,IAR)))=NumVertices;
	  (*VertElem)(3,KEL(KIAD(2,IAR)))=NumVertices;
	  (*VertElem)(3,KEL(KIAD(3,IAR)))=NumVertices;
	  (*VertElem)(3,KEL(KIAD(4,IAR)))=NumVertices;
	} else {
	  (*VertElem)(6,KEL(KIAD(1,IAR)))=NumVertices;
	  (*VertElem)(8,KEL(KIAD(2,IAR)))=NumVertices;
	  (*VertElem)(8,KEL(KIAD(3,IAR)))=NumVertices;
	  (*VertElem)(6,KEL(KIAD(4,IAR)))=NumVertices;
	}
	(*VertCoord)(1,NumVertices)=0.25*(X1+X2+X3+X4);
	(*VertCoord)(2,NumVertices)=0.25*(Y1+Y2+Y3+Y4);
	(*VertCoord)(3,NumVertices)=0.25*(Z1+Z2+Z3+Z4);
				
	if((IBCT1*IBCT2*IBCT3*IBCT4)==0)
	{
	  (*InfoVertEdge)(NumVertices)=0;
	  (*VertCoord)(1,NumVertices)=0.25*(X1+X2+X3+X4);
	  (*VertCoord)(2,NumVertices)=0.25*(Y1+Y2+Y3+Y4);
	  (*VertCoord)(3,NumVertices)=0.25*(Z1+Z2+Z3+Z4);
// for parallel computing
	  AppendBoundNode(IVT1,IVT2,IVT3,IVT4,NumVertices,0);
	} else {
	  if(IBCT1==IBCT2 && IBCT3==IBCT4 && IBCT1==IBCT4 && INEIGH==0)
	  {
	    (*InfoVertEdge)(NumVertices)=IBCT1;
	    CalcMidParam((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),
			 (*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),
			 (*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),
			 (*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),
			 PAR1,PAR2,PAR3,IBCT1);
	    (*VertCoord)(1,NumVertices)=PAR1;
	    (*VertCoord)(2,NumVertices)=PAR2;
	    (*VertCoord)(3,NumVertices)=PAR3;
// for parallel computing
	    AppendBoundNode(IVT1,IVT2,IVT3,IVT4,NumVertices,IBCT1);
	  } else {
	    (*InfoVertEdge)(NumVertices)=0;
	    (*VertCoord)(1,NumVertices)=0.25*(X1+X2+X3+X4);
	    (*VertCoord)(2,NumVertices)=0.25*(Y1+Y2+Y3+Y4);
	    (*VertCoord)(3,NumVertices)=0.25*(Z1+Z2+Z3+Z4);
// for parallel computing
	    AppendBoundNode(IVT1,IVT2,IVT3,IVT4,NumVertices,0);
	  }
	}
				
	if(IAR==1 || IAR==6)
	{
	  (*NeighElem)(1,KEL(KIAD(1,IAR)))=INEIGH;
	  (*NeighElem)(1,KEL(KIAD(2,IAR)))=INEIGH;
	  (*NeighElem)(1,KEL(KIAD(3,IAR)))=INEIGH;
	  (*NeighElem)(1,KEL(KIAD(4,IAR)))=INEIGH;
	} else {
	  (*NeighElem)(2,KEL(KIAD(1,IAR)))=INEIGH;
	  (*NeighElem)(5,KEL(KIAD(2,IAR)))=INEIGH;
	  (*NeighElem)(5,KEL(KIAD(3,IAR)))=INEIGH;
	  (*NeighElem)(2,KEL(KIAD(4,IAR)))=INEIGH;
	}
      } else {
	if(IEL==(*NeighElem)(1,INEIGH))
	{
	  KIELH(1)=INEIGH;
	  KIELH(2)=(*NeighElem)(3,KIELH(1));
	  KIELH(3)=(*NeighElem)(3,KIELH(2));
	  KIELH(4)=(*NeighElem)(3,KIELH(3));
	  IARH=1;
	} else if(IEL==(*NeighElem)(1,(*NeighElem)(6,INEIGH))) {
	  KIELH(1)=(*NeighElem)(6,INEIGH);
	  KIELH(2)=(*NeighElem)(3,KIELH(1));
	  KIELH(3)=(*NeighElem)(3,KIELH(2));
	  KIELH(4)=(*NeighElem)(3,KIELH(3));
	  IARH=6;
	} else {
	  IELH=INEIGH;
	  for(I=1;I<=4;I++)
	  {
	    if(IEL==(*NeighElem)(2,IELH))
	    {
	      KIELH(1)=IELH;
	      KIELH(2)=(*NeighElem)(3,KIELH(1));
	      KIELH(3)=(*NeighElem)(6,KIELH(2));
	      KIELH(4)=(*NeighElem)(4,KIELH(3));
	      IARH=I+1;
	      break;
	    }
	    IELH=(*NeighElem)(3,IELH);
	  }
	}
	KIEL(1)=KEL(KIAD(1,IAR));
	KIEL(2)=KEL(KIAD(2,IAR));
	KIEL(3)=KEL(KIAD(3,IAR));
	KIEL(4)=KEL(KIAD(4,IAR));
	for(I=1;I<=4;I++)
	{
	  if(IAR==1 || IAR==6)
	  {
	    IVT1=(*VertElem)(1,KIEL(I));
	    IVT2=(*VertElem)(2,KIEL(I));
	  } else {
	    IVT1=(*VertElem)(1,KIEL(I));
	    IVT2=(*VertElem)(5,KIEL(I));
	  }
	  for(J=1;J<=4;J++)
	  {
	    IV1=(*VertElem)(1,KIELH(J));
	    IV2=(*VertElem)(2,KIELH(J));
	    IV3=(*VertElem)(3,KIELH(J));
	    IV4=(*VertElem)(4,KIELH(J));
	    IV5=(*VertElem)(5,KIELH(J));
	    IV6=(*VertElem)(6,KIELH(J));
	    IV7=(*VertElem)(7,KIELH(J));
	    IV8=(*VertElem)(8,KIELH(J));
	    if((IV1==IVT1 || IV2==IVT1 ||
		IV3==IVT1 || IV4==IVT1 ||
		IV5==IVT1 || IV6==IVT1 ||
		IV7==IVT1 || IV8==IVT1) &&
	       (IV1==IVT2 || IV2==IVT2 ||
		IV3==IVT2 || IV4==IVT2 ||
		IV5==IVT2 || IV6==IVT2 ||
		IV7==IVT2 || IV8==IVT2))
		break;
					 
	  }
				
	  if(IAR==1 || IAR==6)
	  {
	    INEI1=1;
	    IVER1=3;
	  } else {
	    if(I==1 || I==4)
	    {
	      INEI1=2;
	      IVER1=6;
	    } else {
	      INEI1=5;
	      IVER1=8;
	    }
	  }
				
	  if(IARH==1 || IARH==6)
	  {
	    INEI2=1;
	    IVER2=3;
	  } else {
	    if(J==1 || J==4)
	    {
	      INEI2=2;
	      IVER2=6;
	    } else {
	      INEI2=5;
	      IVER2=8;
	    }
	  }
				
	  (*NeighElem)(INEI1,KIEL(I))=KIELH(J);
	  (*NeighElem)(INEI2,KIELH(J))=KIEL(I);
				
	  (*VertElem)(IVER1,KIEL(I))=(*VertElem)(IVER2,KIELH(J));
	}
      }
    }
		
    for(I1=1;I1<=4;I1++)
    {
      I2=(I1%4)+1;
      TotNumFaces++;
      (*NeighElem)(3,KEL(I1))=KEL(I2);
      (*NeighElem)(4,KEL(I2))=KEL(I1);
    }
    for(I1=1;I1<=4;I1++)
    {
      I2=I1+4;
      TotNumFaces++;
      (*NeighElem)(6,KEL(I1))=KEL(I2);
      (*NeighElem)(6,KEL(I2))=KEL(I1);
    }
    for(I1=1;I1<=4;I1++)
    {
      I2=(I1%4)+1;
      TotNumFaces++;
      (*NeighElem)(3,KEL(I1+4))=KEL(I2+4);
      (*NeighElem)(4,KEL(I2+4))=KEL(I1+4);
    }
    NumElements+=7;
  }
	
// calculation of coordinates and numbers of centers
	
  for(IEL=1;IEL<=NELOLD;IEL++)
  {
    KEL(1)=IEL;
    for(I=1;I<=3;I++)
	KEL(I+1)=(*NeighElem)(3,KEL(I));
			
    KEL(5)=(*NeighElem)(6,KEL(I));
		
    for(I=5;I<=7;I++)
	KEL(I+1)=(*NeighElem)(3,KEL(I));
			
    NumVertices++;
		
    for(IELH=1;IELH<=8;IELH++)
	(*VertElem)(7,KEL(IELH))=NumVertices;
			
    IVT1=(*VertElem)(1,KEL(1));
    IVT2=(*VertElem)(1,KEL(2));
    IVT3=(*VertElem)(1,KEL(3));
    IVT4=(*VertElem)(1,KEL(4));
    IVT5=(*VertElem)(1,KEL(5));
    IVT6=(*VertElem)(1,KEL(6));
    IVT7=(*VertElem)(1,KEL(7));
    IVT8=(*VertElem)(1,KEL(8));
    IBCT1=(*InfoVertEdge)(IVT1);
    IBCT2=(*InfoVertEdge)(IVT2);
    IBCT3=(*InfoVertEdge)(IVT3);
    IBCT4=(*InfoVertEdge)(IVT4);
    IBCT5=(*InfoVertEdge)(IVT5);
    IBCT6=(*InfoVertEdge)(IVT6);
    IBCT7=(*InfoVertEdge)(IVT7);
    IBCT8=(*InfoVertEdge)(IVT8);
		
    if(IBCT1==0)
    {
      X1=(*VertCoord)(1,IVT1);
      Y1=(*VertCoord)(2,IVT1);
      Z1=(*VertCoord)(3,IVT1);
    } else {
      X1=ParX((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),IBCT1);
      Y1=ParY((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),IBCT1);
      Z1=ParZ((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),IBCT1);
    }
    if(IBCT2==0)
    {
      X2=(*VertCoord)(1,IVT2);
      Y2=(*VertCoord)(2,IVT2);
      Z2=(*VertCoord)(3,IVT2);
    } else {
      X2=ParX((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),IBCT2);
      Y2=ParY((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),IBCT2);
      Z2=ParZ((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),IBCT2);
    }
    if(IBCT3==0)
    {
      X3=(*VertCoord)(1,IVT3);
      Y3=(*VertCoord)(2,IVT3);
      Z3=(*VertCoord)(3,IVT3);
    } else {
      X3=ParX((*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),IBCT3);
      Y3=ParY((*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),IBCT3);
      Z3=ParZ((*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),IBCT3);
    }
    if(IBCT4==0)
    {
      X4=(*VertCoord)(1,IVT4);
      Y4=(*VertCoord)(2,IVT4);
      Z4=(*VertCoord)(3,IVT4);
    } else {
      X4=ParX((*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),IBCT4);
      Y4=ParY((*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),IBCT4);
      Z4=ParZ((*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),IBCT4);
    }
    if(IBCT5==0)
    {
      X5=(*VertCoord)(1,IVT5);
      Y5=(*VertCoord)(2,IVT5);
      Z5=(*VertCoord)(3,IVT5);
    } else {
      X5=ParX((*VertCoord)(1,IVT5),(*VertCoord)(2,IVT5),(*VertCoord)(3,IVT5),IBCT5);
      Y5=ParY((*VertCoord)(1,IVT5),(*VertCoord)(2,IVT5),(*VertCoord)(3,IVT5),IBCT5);
      Z5=ParZ((*VertCoord)(1,IVT5),(*VertCoord)(2,IVT5),(*VertCoord)(3,IVT5),IBCT5);
    }
    if(IBCT6==0)
    {
      X6=(*VertCoord)(1,IVT6);
      Y6=(*VertCoord)(2,IVT6);
      Z6=(*VertCoord)(3,IVT6);
    } else {
      X6=ParX((*VertCoord)(1,IVT6),(*VertCoord)(2,IVT6),(*VertCoord)(3,IVT6),IBCT6);
      Y6=ParY((*VertCoord)(1,IVT6),(*VertCoord)(2,IVT6),(*VertCoord)(3,IVT6),IBCT6);
      Z6=ParZ((*VertCoord)(1,IVT6),(*VertCoord)(2,IVT6),(*VertCoord)(3,IVT6),IBCT6);
    }
    if(IBCT7==0)
    {
      X7=(*VertCoord)(1,IVT7);
      Y7=(*VertCoord)(2,IVT7);
      Z7=(*VertCoord)(3,IVT7);
    } else {
      X7=ParX((*VertCoord)(1,IVT7),(*VertCoord)(2,IVT7),(*VertCoord)(3,IVT7),IBCT7);
      Y7=ParY((*VertCoord)(1,IVT7),(*VertCoord)(2,IVT7),(*VertCoord)(3,IVT7),IBCT7);
      Z7=ParZ((*VertCoord)(1,IVT7),(*VertCoord)(2,IVT7),(*VertCoord)(3,IVT7),IBCT7);
    }
    if(IBCT8==0)
    {
      X8=(*VertCoord)(1,IVT8);
      Y8=(*VertCoord)(2,IVT8);
      Z8=(*VertCoord)(3,IVT8);
    } else {
      X8=ParX((*VertCoord)(1,IVT8),(*VertCoord)(2,IVT8),(*VertCoord)(3,IVT8),IBCT8);
      Y8=ParY((*VertCoord)(1,IVT8),(*VertCoord)(2,IVT8),(*VertCoord)(3,IVT8),IBCT8);
      Z8=ParZ((*VertCoord)(1,IVT8),(*VertCoord)(2,IVT8),(*VertCoord)(3,IVT8),IBCT8);
    }
    (*InfoVertEdge)(NumVertices)=0;
    (*VertCoord)(1,NumVertices)=0.125*(X1+X2+X3+X4+X5+X6+X7+X8);
    (*VertCoord)(2,NumVertices)=0.125*(Y1+Y2+Y3+Y4+Y5+Y6+Y7+Y8);
    (*VertCoord)(3,NumVertices)=0.125*(Z1+Z2+Z3+Z4+Z5+Z6+Z7+Z8);
  }
}
