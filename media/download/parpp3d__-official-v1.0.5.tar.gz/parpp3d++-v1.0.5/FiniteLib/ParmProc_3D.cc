#include "SquareGrid_3D.h"

DOUBLE SquareGrid_3D::ParX(DOUBLE T1,DOUBLE T2,DOUBLE T3,UNSIGNED IBCT)
{
    return T1;
}

DOUBLE SquareGrid_3D::ParY(DOUBLE T1,DOUBLE T2,DOUBLE T3,UNSIGNED IBCT)
{
    return T2;
}

DOUBLE SquareGrid_3D::ParZ(DOUBLE T1,DOUBLE T2,DOUBLE T3,UNSIGNED IBCT)
{
    return T3;
}

void SquareGrid_3D::BoundaryProjection()
{
    return;

//    int IVT,IEL,INPR;
//    double PXM,PYM,RAD,RADH,DL,PX,PY,PZ;

//    for(IVT=1;IVT<=NumVertices;IVT++) {
//      INPR=(*InfoVertEdge)(IVT);
//      if(INPR!=0) {
//        IEL=(*ElemVert)(4,IVT);
//        PX=(*VertCoord)(1,IVT);
//        PY=(*VertCoord)(2,IVT);
//        PZ=(*VertCoord)(3,IVT);

//        if((fabs(PZ-0.)>1e-8) && (fabs(PZ-0.41)>1e-8)&&
//           (fabs(PX-0.)>1e-8)&&(fabs(PX-2.50)>1e-8)&&
//           (fabs(PY-0.)>1e-8)&&(fabs(PY-0.41)>1e-8)) {
//  	PXM=0.50;
//  	PYM=0.20;
//  	RAD=0.05;
//  	DL=sqrt(pow(PX-PXM,2)+pow(PY-PYM,2));
//  	(*VertCoord)(1,IVT)=PXM+RAD/DL*(PX-PXM);
//  	(*VertCoord)(2,IVT)=PYM+RAD/DL*(PY-PYM);
//        } else if((fabs(PZ-0.0)<=1e-8)||(fabs(PZ-0.41)<=1e-8)) {
//  	PXM=0.50;
//  	PYM=0.20;
//  	RAD=0.05;
//  	RADH=0.05+1e-8;
//  	if((fabs(PX-PXM)<=RADH)&&(fabs(PY-PYM)<=RADH)&&IEL==0) {
//  	  DL=sqrt(pow(PX-PXM,2)+pow(PY-PYM,2));
//  	  (*VertCoord)(1,IVT)=PXM+RAD/DL*(PX-PXM);
//  	  (*VertCoord)(2,IVT)=PYM+RAD/DL*(PY-PYM);
//  	}
//        }
//      }
//    }
}
