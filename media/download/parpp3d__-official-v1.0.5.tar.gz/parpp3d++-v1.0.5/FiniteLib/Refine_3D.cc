#include "SquareGrid_3D.h"

void SquareGrid_3D::Refine(unsigned int NFINE,unsigned int ISCAD,unsigned int ISE,unsigned int ISA,
			   unsigned int ISEEL,unsigned int ISAEL,unsigned int ISVEL,unsigned int IDISP)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering SquareGrid_3D::Refine.\n";
        protocol.mFlush();
    }

    if(ISCAD>0)
        CreateNeighInfo_3D(IDISP);
    RefineMesh(NFINE,ISCAD,ISE,ISA,ISEEL,ISAEL,ISVEL,IDISP);

    if ((ISE == 0) && MidEdges) {
        delete MidEdges;
        MidEdges=0;
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving SquareGrid_3D::Refine.\n";
        protocol.mFlush();
    }

    return;
}

void SquareGrid_3D::RefineMesh(unsigned int NFINE, unsigned int ISCAD, unsigned int ISE, unsigned int ISA, 
			       unsigned int ISEEL, unsigned int ISAEL, unsigned int ISVEL, unsigned int IDISP)
{
    unsigned int NNEL,NNEL1,NNEL2,NNVT,NNVT1,INDA;
    IntArray2D	*ArrPtr2D;
    DoubleArray2D	*DoubleArrPtr2D;
    IntArray		*ArrPtr;
    int IER,i;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering SquareGrid_3D::RefineMesh.\n";
        protocol.mFlush();
    }

    if (VertElem)
        NNEL = VertElem->GetLen() / NUMOFVERT; 
    if (NeighElem)
        NNEL1 = NeighElem->GetLen() / NUMOFFACE; 
    if (MidEdges)
        NNEL2 = MidEdges->GetLen() / NUMOFEDGE; 
    if (NNEL > NNEL1  &&  NNEL1 != 0)
        NNEL = NNEL1; 
    if (NNEL > NNEL2  &&  NNEL2 != 0)
        NNEL = NNEL2; 
    if (VertCoord)
        NNVT = VertCoord->GetLen() / 3; 
    NNEL1 = NNEL; 
    NNVT1 = NNVT; 

    if (CopyVertCoord && VertCoord) {
        if (VertCoord->GetLen() != CopyVertCoord->GetLen())
            return;
        delete VertCoord;
        VertCoord = CopyVertCoord; 
        CopyVertCoord = 0; 
    }

    NumElemVert = 0; 
    if (ElemVert)
        delete ElemVert;
    ElemVert = new IntArray2D(NUMOFFACE, MAXINDEX, "ElemVert"); 
//  *ElemVert=0;

    IER = RefineMeshProc(NFINE, NNEL, NNVT); 

    if (IER == 0) {
        if(ISVEL>0 || ISE>0)
        {
            CreateVertexInfo_3D(VertElem,ElemVert,0);
            delete ElemVert;
            ElemVert=new IntArray2D(NumElemVert,NumVertices);
            CreateVertexInfo_3D(VertElem,ElemVert,1);
        } else {
            if(ElemVert)
            {
                delete ElemVert;
                ElemVert=0;
            }
        }

        CopyVertCoord=new DoubleArray2D(*VertCoord);
        CreateBoundCoord_3D();
        if(MidEdges) {
            ArrPtr2D=new IntArray2D(NUMOFEDGE,NNEL,"MidEdges");
            (*ArrPtr2D)=(*MidEdges);
            delete MidEdges;
            MidEdges=ArrPtr2D;
        } else
            MidEdges=new IntArray2D(NUMOFEDGE,NNEL,"MidEdges");

        // end if (IER == 0)
    } else if (IER == 1) {
        if (ElemVert)
            delete ElemVert;
        ElemVert = 0; 

        if(NNEL>NNEL1) {
            if(VertElem) {
                ArrPtr2D=new IntArray2D(NUMOFVERT,NNEL,"VertElem");
                (*ArrPtr2D)=(*VertElem);
                delete VertElem;
                VertElem=ArrPtr2D;
            } else
                VertElem=new IntArray2D(NUMOFVERT,NNEL,"VertElem");

            if(NeighElem) {
                ArrPtr2D=new IntArray2D(NUMOFFACE,NNEL,"NeighElem");
                (*ArrPtr2D)=(*NeighElem);
                delete NeighElem;
                NeighElem=ArrPtr2D;
            } else
                NeighElem=new IntArray2D(NUMOFFACE,NNEL,"NeighElem");

            if(MidEdges) {
                ArrPtr2D=new IntArray2D(NUMOFEDGE,NNEL,"MidEdges");
                (*ArrPtr2D)=(*MidEdges);
                delete MidEdges;
                MidEdges=ArrPtr2D;
            } else
                MidEdges=new IntArray2D(NUMOFEDGE,NNEL,"MidEdges");
        }
        if(NNVT>NNVT1) {
            if(VertCoord) {
                DoubleArrPtr2D=new DoubleArray2D(3,NNVT,"VertCoord");
                (*DoubleArrPtr2D)=0;
                (*DoubleArrPtr2D)=(*VertCoord);
                delete VertCoord;
                VertCoord=DoubleArrPtr2D;
            } else
                VertCoord=new DoubleArray2D(3,NNVT,"VertCoord");

            if(InfoVertEdge) {
                ArrPtr=new IntArray(NNVT,"InfoVertEdge");
                (*ArrPtr)=(*InfoVertEdge);
                delete InfoVertEdge;
                InfoVertEdge=ArrPtr;
            } else
                InfoVertEdge=new IntArray(NNVT,"InfoVertEdge");
        }
        NumElemVert=0;
        if(ElemVert)
            delete ElemVert;
        ElemVert=new IntArray2D(NUMOFFACE,MAXINDEX,"ElemVert");

        RefineMeshProc(NFINE,NNEL,NNVT);
//    CreateNeighInfo_3D(0);

        if(ISVEL>0 || ISE>0) {
            CreateVertexInfo_3D(VertElem,ElemVert,0);
            delete ElemVert;
            ElemVert=new IntArray2D(NumElemVert,NumVertices);
            CreateVertexInfo_3D(VertElem,ElemVert,1);
        } else {
            if(ElemVert)
                delete ElemVert;
            ElemVert=0;
        }

        CopyVertCoord=new DoubleArray2D(*VertCoord);
        CreateBoundCoord_3D();
    }

    if (ISE > 0) {
        if (ISE >= 2) {
            if(InfoVertEdge) {
                ArrPtr=new IntArray(NumVertices+8*TotNumEdges,"InfoVertEdge");
                (*ArrPtr)=(*InfoVertEdge);
                delete InfoVertEdge;
                InfoVertEdge=ArrPtr;
            }
        }
        if (ISE >= 3) {
            if (MidCoord)
                delete MidCoord;
            MidCoord=new DoubleArray2D(3,8*TotNumEdges,"MidCoord");
        }
        CreateEdgeInfo_3D(ISE);
        if (ISE >= 3)
        {
            if (MidCoord)
                delete MidCoord;
            MidCoord=0;
        }
        if (ISE >= 2) {
            if (InfoVertEdge)
                delete InfoVertEdge;
            InfoVertEdge=0;
        }
        if ((ISVEL>0) && (ISE>0)) {
            if (ElemVert)
                delete ElemVert;
            ElemVert=0;
        }
        if ((ISEEL > 0) && (ISE > 0)) {
            NumElemEdge = 0; 
            if (ElemMeetEdge)
                delete ElemMeetEdge; 
            ElemMeetEdge = new IntArray2D(NUMOFFACE, MAXINDEX, "ElemVert"); 
            CreateElemMeetEdgeInfo_3D(MidEdges, ElemMeetEdge, 0); 
            delete ElemMeetEdge; 
            ElemMeetEdge = new IntArray2D(NumElemEdge, TotNumEdges, "ElemVert"); 
            CreateElemMeetEdgeInfo_3D(MidEdges, ElemMeetEdge, 1); 
        }
        if (ISA>0) {
            if (MidFaces)
                delete MidFaces;
            MidFaces = new IntArray2D(NUMOFFACE, NumElements); 

            if (ISA >= 2) {
                if (ISE >= 2)
                    INDA=NumVertices+TotNumEdges;
                else
                    INDA=NumVertices;
                ArrPtr=new IntArray(INDA+8*TotNumFaces,"InfoVertEdge");
                *ArrPtr=*InfoVertEdge;
                delete InfoVertEdge;
                InfoVertEdge=ArrPtr;
            }
            if (ISA >= 3)
            {
                if (MidFaceCoord)
                    delete MidFaceCoord;
                MidFaceCoord=new DoubleArray2D(3,8*TotNumFaces,"MidFaceCoord");
            }

            CreateFaceInfo_3D(ISA,INDA);

            if (ISA >= 3)
            {
                DoubleArrPtr2D=new DoubleArray2D(3,TotNumFaces,"MidFaceCoord");
                for(i=1;i<=TotNumFaces;i++)
                {
                    (*DoubleArrPtr2D)(1,i)=(*MidFaceCoord)(1,i);
                    (*DoubleArrPtr2D)(2,i)=(*MidFaceCoord)(2,i);
                    (*DoubleArrPtr2D)(3,i)=(*MidFaceCoord)(3,i);
                }
                delete MidFaceCoord;
                MidFaceCoord=DoubleArrPtr2D;
            }
            if (ISA >= 2)
            {
                ArrPtr=new IntArray(INDA+TotNumFaces,"InfoVertEdge");
                for(i=1;i<=INDA+TotNumFaces;i++)
                    (*ArrPtr)(i)=(*InfoVertEdge)(i);
                delete InfoVertEdge;
                InfoVertEdge=ArrPtr;
            }
        }

        if ((ISAEL > 0) && (ISA > 0)) {
            if (ElemMeetFace)
                delete ElemMeetFace;
            ElemMeetFace = new IntArray2D(2, TotNumFaces); 
            CreateElemMeetFaceInfo_3D();
        }
        if (CopyVertCoord) {
            delete CopyVertCoord;
            CopyVertCoord=0;
        }
    } // end if (ISE > 0)


    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving SquareGrid_3D::RefineMesh.\n";
        protocol.mFlush();
    }

    return; 
}

int SquareGrid_3D::RefineMeshProc(unsigned int NFINE,unsigned int& NNEL,unsigned int& NNVT)
{
    unsigned int	NNEL1,NNVT1,NNET,NNAT,IFINE;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering SquareGrid_3D::RefineMeshProc.\n";
        protocol.mFlush();
    }

    NNEL1 = NNEL;
    NNVT1 = NNVT;
    NNEL  = NumElements;
    NNVT  = NumVertices;
    NNET  = TotNumEdges;
    NNAT  = TotNumFaces;

    if (NFINE>0) {
        for (IFINE=1;IFINE<=NFINE;IFINE++) {
            NNVT=NNVT+NNET+NNAT+NNEL;
            NNET=2*NNET+6*NNEL+4*NNAT;
            NNAT=4*NNAT+12*NNEL;
            NNEL*=8;
        }
    }

    if (NNEL > NNEL1 || NNVT > NNVT1) {
	if (Debug) {
	    protocol << "DEBUG(" << MyProcID << "):  Leaving SquareGrid_3D::RefineMeshProc\n";
	}

        return 1;
    }

    if (NFINE>0)
    {
        for(IFINE=1;IFINE<NFINE;IFINE++) {
//          AdjustGridInfo_3D();
            CreateVertexInfo_3D(VertElem,ElemVert,0);
            delete ElemVert;
            ElemVert=new IntArray2D(NumElemVert,NumVertices);
            CreateVertexInfo_3D(VertElem,ElemVert,1);
//          CreateEdgeInfo_3D(1);
        }
        AdjustGridInfo_3D();
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving SquareGrid_3D::RefineMeshProc.\n";
        protocol.mFlush();
    }

    return 0;
}
