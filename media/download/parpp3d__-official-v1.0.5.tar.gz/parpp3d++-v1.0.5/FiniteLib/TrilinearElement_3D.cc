#include "TrilinearElement_3D.h"

#define Q8	0.125
#define NNVME	8

VOID TrilinearElement_3D::SetGlobalDOF(UNSIGNED IEL,UNSIGNED IPAR)
{
  INTEGER IVE,NKE,IKE;
  IntArray	JVG(NNVEA),JVL(NNVEA);
  
  for(IVE=1;IVE<=NumVertElem;IVE++) {
    JVG(IVE)=(*VertElem)(IVE,IEL);
    JVL(IVE)=IVE;
  }
  NKE=NumVertElem;
 
  if(IPAR>=0)
      BubbleSort(JVG,JVL,NKE);
  
  for(IKE=1;IKE<=NKE;IKE++) {
    (*KDFG)(IKE)=JVG(IKE);
  }
  if(IPAR==1) {
    for(IKE=1;IKE<=NKE;IKE++) {
      (*KDFL)(IKE)=JVL(IKE);
    }
  }
}

VOID TrilinearElement_3D::GetValue(DOUBLE X1,DOUBLE X2,DOUBLE X3)
{
  DOUBLE XJ1;
  DoubleArray2D	DHELP(NNVE,4);
  int IDFL1;
  
  if(DETJ>0 && DETJ<1e-70) {
    Err<<"TrilinearElement_3D: Element has vanishing area !!!\n";
    exit(1);
  }
  if((*BDER)(5) || (*BDER)(6) || (*BDER)(7) || (*BDER)(8)) {
    Err<<"TrilinearElement_3D: Desired derivates not available !!!\n";
    exit(1);
  }
  
  if((*BDER)(1)) {
    DHELP(1,1)=Q8*(1.0-X1)*(1.0-X2)*(1.0-X3);
    DHELP(2,1)=Q8*(1.0+X1)*(1.0-X2)*(1.0-X3);
    DHELP(3,1)=Q8*(1.0+X1)*(1.0+X2)*(1.0-X3);
    DHELP(4,1)=Q8*(1.0-X1)*(1.0+X2)*(1.0-X3);
    DHELP(5,1)=Q8*(1.0-X1)*(1.0-X2)*(1.0+X3);
    DHELP(6,1)=Q8*(1.0+X1)*(1.0-X2)*(1.0+X3);
    DHELP(7,1)=Q8*(1.0+X1)*(1.0+X2)*(1.0+X3);
    DHELP(8,1)=Q8*(1.0-X1)*(1.0+X2)*(1.0+X3);
  }

  if((*BDER)(2) || !(*BDER)(3) || !(*BDER)(4)) {
    DHELP(1,2)=-Q8*(1.0-X2)*(1.0-X3);
    DHELP(2,2)= Q8*(1.0-X2)*(1.0-X3);
    DHELP(3,2)= Q8*(1.0+X2)*(1.0-X3);
    DHELP(4,2)=-Q8*(1.0+X2)*(1.0-X3);
    DHELP(5,2)=-Q8*(1.0-X2)*(1.0+X3);
    DHELP(6,2)= Q8*(1.0-X2)*(1.0+X3);
    DHELP(7,2)= Q8*(1.0+X2)*(1.0+X3);
    DHELP(8,2)=-Q8*(1.0+X2)*(1.0+X3);
      
    DHELP(1,3)=-Q8*(1.0-X1)*(1.0-X3);
    DHELP(2,3)=-Q8*(1.0+X1)*(1.0-X3);
    DHELP(3,3)= Q8*(1.0+X1)*(1.0-X3);
    DHELP(4,3)= Q8*(1.0-X1)*(1.0-X3);
    DHELP(5,3)=-Q8*(1.0-X1)*(1.0+X3);
    DHELP(6,3)=-Q8*(1.0+X1)*(1.0+X3);
    DHELP(7,3)= Q8*(1.0+X1)*(1.0+X3);
    DHELP(8,3)= Q8*(1.0-X1)*(1.0+X3);

    DHELP(1,4)=-Q8*(1.0-X1)*(1.0-X2);
    DHELP(2,4)=-Q8*(1.0+X1)*(1.0-X2);
    DHELP(3,4)=-Q8*(1.0+X1)*(1.0+X2);
    DHELP(4,4)=-Q8*(1.0-X1)*(1.0+X2);
    DHELP(5,4)= Q8*(1.0-X1)*(1.0-X2);
    DHELP(6,4)= Q8*(1.0+X1)*(1.0-X2);
    DHELP(7,4)= Q8*(1.0+X1)*(1.0+X2);
    DHELP(8,4)= Q8*(1.0-X1)*(1.0+X2);
  }
  
  if((*BDER)(1)) {
    for(IDFL1=1;IDFL1<=NNVE;IDFL1++)
	(*DBAS)(1,IDFL1,1)=DHELP(IDFL1,1);
  }
  XJ1=1.0/DETJ;
  if((*BDER)(2)) {
    for(IDFL1=1;IDFL1<=NNVE;IDFL1++)
	(*DBAS)(1,IDFL1,2)=XJ1*(
	  DHELP(IDFL1,2)*((*DJAC)(2,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(2,3))
	  -DHELP(IDFL1,3)*((*DJAC)(2,1)*(*DJAC)(3,3)-(*DJAC)(3,1)*(*DJAC)(2,3))
	  +DHELP(IDFL1,4)*((*DJAC)(2,1)*(*DJAC)(3,2)-(*DJAC)(3,1)*(*DJAC)(2,2)));
  }
  if((*BDER)(3)) {
    for(IDFL1=1;IDFL1<=NNVE;IDFL1++)
	(*DBAS)(1,IDFL1,3)=XJ1*(
	  -DHELP(IDFL1,2)*((*DJAC)(1,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(1,3))
	  +DHELP(IDFL1,3)*((*DJAC)(1,1)*(*DJAC)(3,3)-(*DJAC)(3,1)*(*DJAC)(1,3))
	  -DHELP(IDFL1,4)*((*DJAC)(1,1)*(*DJAC)(3,2)-(*DJAC)(3,1)*(*DJAC)(1,2)));
  }
  if((*BDER)(4)) {
    for(IDFL1=1;IDFL1<=NNVE;IDFL1++)
	(*DBAS)(1,IDFL1,4)=XJ1*(
	  DHELP(IDFL1,2)*((*DJAC)(1,2)*(*DJAC)(2,3)-(*DJAC)(2,2)*(*DJAC)(1,3))
	  -DHELP(IDFL1,3)*((*DJAC)(1,1)*(*DJAC)(2,3)-(*DJAC)(2,1)*(*DJAC)(1,3))
	  +DHELP(IDFL1,4)*((*DJAC)(1,1)*(*DJAC)(2,2)-(*DJAC)(2,1)*(*DJAC)(1,2)));
  }
}

VOID TrilinearElement_3D::Restrict(DoubleVector *LD,DoubleVector *LB,
				   IntArray2D *VertElem2,IntArray2D *VertElem1,
				   IntArray2D *MidFaces2,IntArray2D *MidFaces1,
				   IntArray2D *NeighElem2,IntArray2D *NeighElem1,
				   UNSIGNED NumVertices2,UNSIGNED NumVertices1,
				   UNSIGNED NumElements2,UNSIGNED NumElements1)
{
//  VertElem2,NeighElem2 and NumElements2:  fine grid information
//  NumVertices1: coarse grid information

  int IVT,IELH1,IELH2,IELH3,IELH4,IELH5,IELH6,IELH7,IELH8,IEL2,IEL1;
  int J1,J2,J3,J4,J5,J6,J7,J8,I1,I2,I3,I4,I5,I6,I7,I8,I9,I10,I11,I12;
  double A3,A6,A8;

  for(INTEGER i=1;i<=LB->GetLen();i++)
      (*LB)(i)=(*LD)(i);
	
  for(IEL2=1;IEL2<=NumElements2;IEL2++)
  {
    I1=(*VertElem2)(1,IEL2);
    I3=(*VertElem2)(3,IEL2);
    I6=(*VertElem2)(6,IEL2);
    I7=(*VertElem2)(7,IEL2);
    I8=(*VertElem2)(8,IEL2);

    if((*NeighElem2)(1,IEL2)==0)
	A3=0.25;
    else
	A3=0.125;

    if((*NeighElem2)(2,IEL2)==0)
	A6=0.25;
    else
	A6=0.125;

    if((*NeighElem2)(5,IEL2)==0)
	A8=0.25;
    else
	A8=0.125;

    (*LB)(I1)+=A3*(*LD)(I3)+A6*(*LD)(I6)+0.125*(*LD)(I7)+A8*(*LD)(I8);
  }
      
  IVT=NumVertices1;

  for(IEL1=1;IEL1<=NumElements1;IEL1++)
  {
    IELH1=IEL1;
    IELH2=(*NeighElem2)(3,IELH1);
    IELH3=(*NeighElem2)(3,IELH2);
    IELH4=(*NeighElem2)(3,IELH3);
    IELH5=(*NeighElem2)(6,IELH1);
    IELH6=(*NeighElem2)(3,IELH5);
    IELH7=(*NeighElem2)(3,IELH6);
    IELH8=(*NeighElem2)(3,IELH7);

    I1 =(*VertElem2)(2,IELH1);
    I2 =(*VertElem2)(2,IELH2);
    I3 =(*VertElem2)(2,IELH3);
    I4 =(*VertElem2)(2,IELH4);
    I5 =(*VertElem2)(5,IELH1);
    I6 =(*VertElem2)(5,IELH2);
    I7 =(*VertElem2)(5,IELH3);
    I8 =(*VertElem2)(5,IELH4);
    I9 =(*VertElem2)(2,IELH5);
    I10=(*VertElem2)(2,IELH6);
    I11=(*VertElem2)(2,IELH7);
    I12=(*VertElem2)(2,IELH8);

    J1=(*VertElem1)(1,IEL1);
    J2=(*VertElem1)(2,IEL1);
    J3=(*VertElem1)(3,IEL1);
    J4=(*VertElem1)(4,IEL1);
    J5=(*VertElem1)(5,IEL1);
    J6=(*VertElem1)(6,IEL1);
    J7=(*VertElem1)(7,IEL1);
    J8=(*VertElem1)(8,IEL1);

    if(I1>IVT)
    {
      (*LB)(J1)+=0.5*(*LD)(I1);
      (*LB)(J2)+=0.5*(*LD)(I1);
      IVT++;
    }

    if(I2>IVT)
    {
      (*LB)(J2)+=0.5*(*LD)(I2);
      (*LB)(J3)+=0.5*(*LD)(I2);
      IVT++;
    }

    if(I3>IVT)
    {
      (*LB)(J3)+=0.5*(*LD)(I3);
      (*LB)(J4)+=0.5*(*LD)(I3);
      IVT++;
    }

    if(I4>IVT)
    {
      (*LB)(J1)+=0.5*(*LD)(I4);
      (*LB)(J4)+=0.5*(*LD)(I4);
      IVT++;
    }

    if(I5>IVT)
    {
      (*LB)(J1)+=0.5*(*LD)(I5);
      (*LB)(J5)+=0.5*(*LD)(I5);
      IVT++;
    }

    if(I6>IVT)
    {
      (*LB)(J2)+=0.5*(*LD)(I6);
      (*LB)(J6)+=0.5*(*LD)(I6);
      IVT++;
    }

    if(I7>IVT)
    {
      (*LB)(J3)+=0.5*(*LD)(I7);
      (*LB)(J7)+=0.5*(*LD)(I7);
      IVT++;
    }

    if(I8>IVT)
    {
      (*LB)(J4)+=0.5*(*LD)(I8);
      (*LB)(J8)+=0.5*(*LD)(I8);
      IVT++;
    }

    if(I9>IVT)
    {
      (*LB)(J5)+=0.5*(*LD)(I9);
      (*LB)(J6)+=0.5*(*LD)(I9);
      IVT++;
    }

    if(I10>IVT)
    {
      (*LB)(J6)+=0.5*(*LD)(I10);
      (*LB)(J7)+=0.5*(*LD)(I10);
      IVT++;
    }

    if(I11>IVT)
    {
      (*LB)(J7)+=0.5*(*LD)(I11);
      (*LB)(J8)+=0.5*(*LD)(I11);
      IVT++;
    }

    if(I12>IVT)
    {
      (*LB)(J5)+=0.5*(*LD)(I12);
      (*LB)(J8)+=0.5*(*LD)(I12);
      IVT++;
    }
  }
}

VOID TrilinearElement_3D::Prol(DoubleVector *LD,DoubleVector *LB,
			       IntArray2D *VertElem2,IntArray2D *VertElem1,
			       IntArray2D *MidFaces2,IntArray2D *MidFaces1,
			       IntArray2D *NeighElem2,IntArray2D *NeighElem1,
			       UNSIGNED NumVertices2,UNSIGNED NumVertices1,
			       UNSIGNED NumElements2,UNSIGNED NumElements1)
{
//  VertElem2,NeighElem2 and NumElements2:  fine grid information
//  NumVertices1: coarse grid information

  int IELH1,IELH2,IELH3,IELH4,IELH5,IELH6,IELH7,IELH8;
  double DXH1,DXH2,DXH3,DXH4,DXH5,DXH6,DXH7,DXH8;

  for(int i=1;i<=LD->GetLen();i++)
      (*LB)(i)=(*LD)(i);

  for(int IEL1=1;IEL1<=NumElements1;IEL1++)
  {
    DXH1=0.5*(*LD)((*VertElem1)(1,IEL1));
    DXH2=0.5*(*LD)((*VertElem1)(2,IEL1));
    DXH3=0.5*(*LD)((*VertElem1)(3,IEL1));
    DXH4=0.5*(*LD)((*VertElem1)(4,IEL1));
    DXH5=0.5*(*LD)((*VertElem1)(5,IEL1));
    DXH6=0.5*(*LD)((*VertElem1)(6,IEL1));
    DXH7=0.5*(*LD)((*VertElem1)(7,IEL1));
    DXH8=0.5*(*LD)((*VertElem1)(8,IEL1));

    IELH1=IEL1;
    IELH2=(*NeighElem2)(3,IELH1);
    IELH3=(*NeighElem2)(3,IELH2);
    IELH4=(*NeighElem2)(3,IELH3);
    IELH5=(*NeighElem2)(6,IELH1);
    IELH6=(*NeighElem2)(3,IELH5);
    IELH7=(*NeighElem2)(3,IELH6);
    IELH8=(*NeighElem2)(3,IELH7);

    if(((*NeighElem1)(1,IEL1)>IEL1) || ((*NeighElem1)(1,IEL1)==0)) 
	(*LB)((*VertElem2)(3,IELH1))=0.5*(DXH1+DXH2+DXH3+DXH4);

    if(((*NeighElem1)(2,IEL1)>IEL1) || ((*NeighElem1)(2,IEL1)==0)) 
	(*LB)((*VertElem2)(6,IELH1))=0.5*(DXH1+DXH2+DXH5+DXH6);

    if(((*NeighElem1)(3,IEL1)>IEL1) || ((*NeighElem1)(3,IEL1)==0)) 
	(*LB)((*VertElem2)(6,IELH2))=0.5*(DXH2+DXH3+DXH6+DXH7);

    if(((*NeighElem1)(4,IEL1)>IEL1) || ((*NeighElem1)(4,IEL1)==0)) 
	(*LB)((*VertElem2)(6,IELH3))=0.5*(DXH3+DXH4+DXH7+DXH8);

    if(((*NeighElem1)(5,IEL1)>IEL1) || ((*NeighElem1)(5,IEL1)==0)) 
       	(*LB)((*VertElem2)(6,IELH4))=0.5*(DXH1+DXH4+DXH5+DXH8);

    if(((*NeighElem1)(6,IEL1)>IEL1) || ((*NeighElem1)(6,IEL1)==0)) 
	(*LB)((*VertElem2)(3,IELH5))=0.5*(DXH5+DXH6+DXH7+DXH8);


    if((((*NeighElem1)(1,IEL1)>IEL1) || ((*NeighElem1)(1,IEL1)==0)) && 
       (((*NeighElem1)(2,IEL1)>IEL1) || ((*NeighElem1)(2,IEL1)==0))) 
	(*LB)((*VertElem2)(2,IELH1))=DXH1+DXH2;

    if((((*NeighElem1)(1,IEL1)>IEL1) || ((*NeighElem1)(1,IEL1)==0)) && 
       (((*NeighElem1)(3,IEL1)>IEL1) || ((*NeighElem1)(3,IEL1)==0))) 
	(*LB)((*VertElem2)(2,IELH2))=DXH2+DXH3;

    if((((*NeighElem1)(1,IEL1)>IEL1) || ((*NeighElem1)(1,IEL1)==0)) && 
       (((*NeighElem1)(4,IEL1)>IEL1) || ((*NeighElem1)(4,IEL1)==0))) 
	(*LB)((*VertElem2)(2,IELH3))=DXH3+DXH4;

    if((((*NeighElem1)(1,IEL1)>IEL1) || ((*NeighElem1)(1,IEL1)==0)) && 
       (((*NeighElem1)(5,IEL1)>IEL1) || ((*NeighElem1)(5,IEL1)==0))) 
	(*LB)((*VertElem2)(2,IELH4))=DXH1+DXH4;

    if((((*NeighElem1)(5,IEL1)>IEL1) || ((*NeighElem1)(5,IEL1)==0)) && 
       (((*NeighElem1)(2,IEL1)>IEL1) || ((*NeighElem1)(2,IEL1)==0))) 
	(*LB)((*VertElem2)(5,IELH1))=DXH1+DXH5;

    if((((*NeighElem1)(2,IEL1)>IEL1) || ((*NeighElem1)(2,IEL1)==0)) && 
       (((*NeighElem1)(3,IEL1)>IEL1) || ((*NeighElem1)(3,IEL1)==0))) 
	(*LB)((*VertElem2)(5,IELH2))=DXH2+DXH6;

    if((((*NeighElem1)(3,IEL1)>IEL1) || ((*NeighElem1)(3,IEL1)==0)) && 
       (((*NeighElem1)(4,IEL1)>IEL1) || ((*NeighElem1)(4,IEL1)==0))) 
	(*LB)((*VertElem2)(5,IELH3))=DXH3+DXH7;

    if((((*NeighElem1)(4,IEL1)>IEL1) || ((*NeighElem1)(4,IEL1)==0)) && 
       (((*NeighElem1)(5,IEL1)>IEL1) || ((*NeighElem1)(5,IEL1)==0))) 
	(*LB)((*VertElem2)(5,IELH4))=DXH4+DXH8;

    if((((*NeighElem1)(6,IEL1)>IEL1) || ((*NeighElem1)(6,IEL1)==0)) && 
       (((*NeighElem1)(2,IEL1)>IEL1) || ((*NeighElem1)(2,IEL1)==0))) 
	(*LB)((*VertElem2)(2,IELH5))=DXH5+DXH6;

    if((((*NeighElem1)(6,IEL1)>IEL1) || ((*NeighElem1)(6,IEL1)==0)) && 
       (((*NeighElem1)(3,IEL1)>IEL1) || ((*NeighElem1)(3,IEL1)==0))) 
	(*LB)((*VertElem2)(2,IELH6))=DXH6+DXH7;

    if((((*NeighElem1)(6,IEL1)>IEL1) || ((*NeighElem1)(6,IEL1)==0)) && 
       (((*NeighElem1)(4,IEL1)>IEL1) || ((*NeighElem1)(4,IEL1)==0))) 
	(*LB)((*VertElem2)(2,IELH7))=DXH7+DXH8;

    if((((*NeighElem1)(6,IEL1)>IEL1) || ((*NeighElem1)(6,IEL1)==0)) && 
       (((*NeighElem1)(5,IEL1)>IEL1) || ((*NeighElem1)(5,IEL1)==0))) 
	(*LB)((*VertElem2)(2,IELH8))=DXH5+DXH8;

    (*LB)((*VertElem2)(7,IELH1))=0.25*(DXH1+DXH2+DXH3+DXH4+
				       DXH5+DXH6+DXH7+DXH8);
  }
}
