#ifndef FINITEELEMENT3DH

#define FINITEELEMENT3DH

#define NNBAS   27
#define NNAB      21
#define NNDER     10
#define NNVE    8
#define NNEE      12
#define NNAE      6
#define NNVEA     26
#define NNARR     229
#define NNDIM   3
#define MAXMEMORY  2000000

#define Q2  0.5
#define Q8  0.125

#define PARAM 1
#define NON_PARAM 0

#define false 0
#define true  1

#include <LinLib.h>
#include "SquareGrid_3D.h"
#include "NumIntegration_3D.h"

extern std::string progname;

class FiniteElement_3D
{
protected:
    DoubleCompactMatrix *LA;
    DoubleRectMatrix    *LR;
    SquareGrid_3D       *Grid;
    IntArray2D          *VertElem;
    IntArray2D          *MidEdges;
    IntArray2D          *MidFaces;
    int                 NumVertElem;
    int                 NumFaceElem;
    int                 NumEdgeElem;
    int                 NumVertices;
    int                 TotNumEdges;
    int                 TotNumFaces;
    DoubleArray        *DX;
    DoubleArray        *DY;
    DoubleArray        *DZ;
    DoubleArray2D      *DJAC;
    DoubleArray3D      *DBAS;
    DoubleArray3D      *DBAS1;
    IntArray           *BDER;
    IntArray2D         *BDER1;
    IntArray           *KVE;
    IntArray           *KDFG;
    IntArray           *KDFL;
    double              DETJ;
    int                 IDFL;
    int                 NumElemMatrix;
    int                 NumEquations;
    int                 NDIM;
                
public:
    FiniteElement_3D(SquareGrid_3D* NGrid);
    virtual ~FiniteElement_3D(void);
  
    virtual void GetValue(double X1,double X2,double X3)=0;
    virtual void SetGlobalDOF(unsigned int IEL,unsigned int IPAR)=0;
    virtual unsigned int GetDOF(void)=0;
    virtual unsigned int GetTotalDOF(void)=0;
    virtual unsigned int GetIEROW(void)=0;
    virtual int GetElemType(void)=0;
    virtual void PreCalc(double X1,double X2,double X3) {}
    void BubbleSort(IntArray& KV1,IntArray& KV2,unsigned int IDIM);
    virtual DoubleCompactMatrix* GetStiffMatrix(unsigned int ISYMM);
//  virtual DoubleRectMatrix* GetStiffMatrix(FiniteElement* elem2);
    virtual DoubleVector* GetRightSideVector(void);
    int GetNumElemMatrix(void);
    int GetNumEquations(void);
    DoubleArray3D *GetDBAS(void);
    IntArray      *GetKDFG(void);
    IntArray      *GetKDFL(void);
    void          ResetDBAS(void) {*DBAS=0.;}
  
/*  void        MaxError(DoubleVector* DU,unsigned int ICUB,
    double& MaxError,double& MaxValue);
    void        L2Error(DoubleVector* DU,unsigned int ICUB,
    double& L2Error,double& H1Error);
*/  

    void CalcValueCoeff(double xx,double yy,double zz,double dtx,double dty,
                        double dnx,double dny,DoubleVector *sol1,DoubleVector *sol2,
                        int iel,double& dut);

    void CalcStiffMatrix(DoubleCompactMatrix*&  NLA,
                         unsigned int                                   BCON,
                         IntArray2D&                            KAB,
                         unsigned int                                   KABN,
                         unsigned int                                   ICUB,
                         unsigned int                                   ISYMM,
                         unsigned int                                   ICLEAR,
                         unsigned int                                   ILINT);
/*  void CalcStiffMatrix(DoubleRectMatrix*&     NLA,
    FiniteElement*              elem2,
    unsigned int                        BCON,
    IntArray2D&                 KAB,
    unsigned int                        KABN,
    unsigned int                        ICUB,
    unsigned int                        ICLEAR);*/
  
    void CalcRightSide(DoubleVector*&                           LB,
                       unsigned int                                     BCON,
                       IntArray&                                        KB,
                       unsigned int                                     KBN,
                       unsigned int                                     ICUB,
                       unsigned int                                     ICLEAR,
                       unsigned int                                     ILINT);
                     
    virtual void Restrict(DoubleVector *LD,DoubleVector *LB,
                          IntArray2D *VertElem2,IntArray2D *VertElem1,
                          IntArray2D *MidFaces2,IntArray2D *MidFaces1,
                          IntArray2D *NeighElem2,IntArray2D *NeighElem1,
                          unsigned int NumVertices2,unsigned int NumVertices1,
                          unsigned int NumElements2,unsigned int NumElements1)=0;
    virtual void Prol(DoubleVector *LD,DoubleVector *LB,
                      IntArray2D *VertElem2,IntArray2D *VertElem1,
                      IntArray2D *MidFaces2,IntArray2D *MidFaces1,
                      IntArray2D *NeighElem2,IntArray2D *NeighElem1,
                      unsigned int NumVertices2,unsigned int NumVertices1,
                      unsigned int NumElements2,unsigned int NumElements1)=0;
};

inline int FiniteElement_3D::GetNumElemMatrix(void)
{
    return NumElemMatrix;
}

inline int FiniteElement_3D::GetNumEquations(void)
{
    return NumEquations;
}

inline DoubleArray3D *FiniteElement_3D::GetDBAS(void)
{
    return DBAS;
}

inline IntArray *FiniteElement_3D::GetKDFG(void)
{
    return KDFG;
}

inline IntArray *FiniteElement_3D::GetKDFL(void)
{
    return KDFL;
}


#endif
