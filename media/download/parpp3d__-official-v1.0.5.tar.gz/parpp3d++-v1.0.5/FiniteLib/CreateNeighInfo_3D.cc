#include "SquareGrid_3D.h"

VOID SquareGrid_3D::CreateNeighInfo_3D(UNSIGNED IDISP)
{
    int IEL,IAR,IVE1,IVE2,IVE3,IVE4,IVT1,IVT2,IVT3,IVT4;
    int JVE1,JVE2,JVE3,JVE4,JVT1,JVT2,JVT3,JVT4,JEL,JAR,flag;

    if(NeighElem)
	delete NeighElem;
    NeighElem=new IntArray2D(NUMOFFACE,NumElements,"NeighElem");
    (*NeighElem)=-1;
	
    IntArray2D KIAD(4,6);
    KIAD(1,1)=1;
    KIAD(2,1)=2;
    KIAD(3,1)=3;
    KIAD(4,1)=4;
    KIAD(1,2)=1;
    KIAD(2,2)=2;
    KIAD(3,2)=6;
    KIAD(4,2)=5;
    KIAD(1,3)=2;
    KIAD(2,3)=3;
    KIAD(3,3)=7;
    KIAD(4,3)=6;
    KIAD(1,4)=3;
    KIAD(2,4)=4;
    KIAD(3,4)=8;
    KIAD(4,4)=7;
    KIAD(1,5)=4;
    KIAD(2,5)=1;
    KIAD(3,5)=5;
    KIAD(4,5)=8;
    KIAD(1,6)=5;
    KIAD(2,6)=6;
    KIAD(3,6)=7;
    KIAD(4,6)=8;
	
    TotNumFaces=0;
    for(IEL=1;IEL<=NumElements;IEL++)
    {
	for(IAR=1;IAR<=NumFaceElem;IAR++)
	{
	    if((*NeighElem)(IAR,IEL)<0)
	    {
		TotNumFaces++;
		IVE1=KIAD(1,IAR);
		IVE2=KIAD(2,IAR);
		IVE3=KIAD(3,IAR);
		IVE4=KIAD(4,IAR);
				
		IVT1=(*VertElem)(IVE1,IEL);
		IVT2=(*VertElem)(IVE2,IEL);
		IVT3=(*VertElem)(IVE3,IEL);
		IVT4=(*VertElem)(IVE4,IEL);
				
		for(flag=true,JEL=1;JEL<=NumElements;JEL++)
		{
		    if(JEL!=IEL)
		    {
			for(JAR=1;JAR<=NumFaceElem;JAR++)
			{
			    JVE1=KIAD(1,JAR);
			    JVE2=KIAD(2,JAR);
			    JVE3=KIAD(3,JAR);
			    JVE4=KIAD(4,JAR);
							
			    JVT1=(*VertElem)(JVE1,JEL);
			    JVT2=(*VertElem)(JVE2,JEL);
			    JVT3=(*VertElem)(JVE3,JEL);
			    JVT4=(*VertElem)(JVE4,JEL);
							
			    if(((JVT1==IVT1) || (JVT2==IVT1) || 
				(JVT3==IVT1) || (JVT4==IVT1)) &&
			       ((JVT1==IVT2) || (JVT2==IVT2) ||
				(JVT3==IVT2) || (JVT4==IVT2)) &&
			       ((JVT1==IVT3) || (JVT2==IVT3) ||
				(JVT3==IVT3) || (JVT4==IVT3)) &&
			       ((JVT1==IVT4) || (JVT2==IVT4) ||
				(JVT3==IVT4) || (JVT4==IVT4)))
			    {
				(*NeighElem)(IAR,IEL)=JEL;
				(*NeighElem)(JAR,JEL)=IEL;
				flag=false;
				break;
			    }
			}
			if(flag==false)
			    break;
		    }
		}
		if(flag==true)
		    (*NeighElem)(IAR,IEL)=0;
	    }
	}
    }
	
//	if(IDISP==1)
//		delete NeighElem;
}
