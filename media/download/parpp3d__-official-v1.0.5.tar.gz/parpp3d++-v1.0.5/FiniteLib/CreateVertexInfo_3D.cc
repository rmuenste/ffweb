#include "SquareGrid_3D.h"

void SquareGrid_3D::CreateVertexInfo_3D(IntArray2D* KVERT, IntArray2D* KVEL, UNSIGNED flag)
// for flag = 0:
//    computes the maximum number of elements (over the whole grid) a node is part of 
{
    IntArray *arr;
    int IVT,MIN,IEL,IVE,IVEL,JVEL;

    if (Debug) protocol << "DEBUG(" << MyProcID << "): Entering SquareGrid_3D::CreateVertexInfo_3D.\n";

    if(flag==0) {
        arr=new IntArray(KVERT->GetLen());        // will contain the number of elements a 
        *arr=0;                                   // single node (given as index) is part of

        NumElemVert=0;
        for(IEL=1;IEL<=NumElements;IEL++) {
            for(IVE=1;IVE<=NumVertElem;IVE++) {
                // IVE contains the local node number (on a hex grid 1 to 8),
                // IVT contains the global node number,
                IVT=(*KVERT)(IVE,IEL);
                (*arr)(IVT)++;
                if(NumElemVert < (*arr)(IVT)) {
                    NumElemVert=(*arr)(IVT);
                }
            }
        }
        delete arr;
    }

    // SB: Keine Ahnung was hier gemacht wird.
    else if (flag == 1) {
        (*KVEL) = 0;
        for (IEL = 1; IEL <= NumElements; IEL++) {
            for(IVE = 1;IVE <= NumVertElem; IVE++) {
                // IVE contains the local node number (on a hex grid 1 to 8),
                // IVT contains the global node number,
                IVT = (*KVERT)(IVE,IEL);

                for (IVEL = 1; IVEL <= NumElemVert; IVEL++) {
                    if ((*KVEL)(IVEL,IVT) == 0) {
                        (*KVEL)(IVEL,IVT) = IEL;
                        break;
                    }
                }
            }
        }

	// BubbleSort doesn't count 'cos it concerns only very few elements
        for(IVT=1;IVT<=NumVertices;IVT++) {
            for(IVEL=1;IVEL<=NumElemVert;IVEL++) {
                MIN = (*KVEL)(IVEL,IVT);

                if (MIN) {
                    for(JVEL=IVEL+1;JVEL<=NumElemVert;JVEL++) {
                        if((*KVEL)(JVEL,IVT)) {
                            if ( (*KVEL)(JVEL,IVT) < MIN) {
                                (*KVEL)(IVEL,IVT) = (*KVEL)(JVEL,IVT);
                                (*KVEL)(JVEL,IVT) = MIN;
                                MIN = (*KVEL)(IVEL,IVT);
                            }
                        }
                    }
                }
            }
        }
    } // endif (flag == 1)

    if (Debug) protocol << "DEBUG(" << MyProcID << "):  Leaving SquareGrid_3D::CreateVertexInfo_3D.\n";

    return;
}
