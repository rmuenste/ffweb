#include "SquareGrid_3D.h"

VOID SquareGrid_3D::CreateFaceInfo_3D(UNSIGNED ISA,UNSIGNED IND)
{
  int IEL,IAR,IVT1,IVT2,IVT3,IVT4,INPR1,INPR2,INPR3,INPR4,INEIGH,INPR,JAR,JNEIGH;
  double PX1,PX2,PX3,PX4,PY1,PY2,PY3,PY4,PZ1,PZ2,PZ3,PZ4,PAR1,PAR2,PAR3;
	
  IntArray2D KIAD(4,6);
  KIAD(1,1)=1;
  KIAD(2,1)=2;
  KIAD(3,1)=3;
  KIAD(4,1)=4;
  KIAD(1,2)=1;
  KIAD(2,2)=2;
  KIAD(3,2)=6;
  KIAD(4,2)=5;
  KIAD(1,3)=2;
  KIAD(2,3)=3;
  KIAD(3,3)=7;
  KIAD(4,3)=6;
  KIAD(1,4)=3;
  KIAD(2,4)=4;
  KIAD(3,4)=8;
  KIAD(4,4)=7;
  KIAD(1,5)=4;
  KIAD(2,5)=1;
  KIAD(3,5)=5;
  KIAD(4,5)=8;
  KIAD(1,6)=5;
  KIAD(2,6)=6;
  KIAD(3,6)=7;
  KIAD(4,6)=8;
	
  TotNumFaces=0;
  for(IEL=1;IEL<=NumElements;IEL++)
  {
    for(IAR=1;IAR<=NumFaceElem;IAR++)
    {
      INEIGH=(*NeighElem)(IAR,IEL);
      if(INEIGH==0 || INEIGH>=IEL)
      {
	TotNumFaces++;
	(*MidFaces)(IAR,IEL)=TotNumFaces;
				
	if(ISA>=2)
	{
	  IVT1=(*VertElem)(KIAD(1,IAR),IEL);
	  IVT2=(*VertElem)(KIAD(2,IAR),IEL);
	  IVT3=(*VertElem)(KIAD(3,IAR),IEL);
	  IVT4=(*VertElem)(KIAD(4,IAR),IEL);
	  INPR1=(*InfoVertEdge)(IVT1);
	  INPR2=(*InfoVertEdge)(IVT2);
	  INPR3=(*InfoVertEdge)(IVT3);
	  INPR4=(*InfoVertEdge)(IVT4);
				
	  if(INPR1==INPR2 && INPR1==INPR3 && INPR1==INPR4 && INEIGH==0)
	  {
	    INPR=INPR1;
	    (*InfoVertEdge)(IND+TotNumFaces)=INPR;
// for parallel computation
	    AppendMidBoundNode(IVT1,IVT2,IVT3,IVT4,TotNumFaces,INPR);
	  } else {
	    INPR=0;
	    (*InfoVertEdge)(IND+TotNumFaces)=INPR;
// for parallel computation
	    if(INEIGH==0)
	      AppendMidBoundNode(IVT1,IVT2,IVT3,IVT4,TotNumFaces,0);
	  }
	}
	if(ISA>=3)
	{
	  if(INPR1==0)
	  {
	    PX1=(*VertCoord)(1,IVT1);
	    PY1=(*VertCoord)(2,IVT1);
	    PZ1=(*VertCoord)(3,IVT1);
	  } else {
	    PX1=ParX((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),INPR1);
	    PY1=ParY((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),INPR1);
	    PZ1=ParZ((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),INPR1);
	  }
	  if(INPR2==0)
	  {
	    PX2=(*VertCoord)(1,IVT2);
	    PY2=(*VertCoord)(2,IVT2);
	    PZ2=(*VertCoord)(3,IVT2);
	  } else {
	    PX2=ParX((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),INPR1);
	    PY2=ParY((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),INPR1);
	    PZ2=ParZ((*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),INPR1);
	  }
	  if(INPR3==0)
	  {
	    PX3=(*VertCoord)(1,IVT3);
	    PY3=(*VertCoord)(2,IVT3);
	    PZ3=(*VertCoord)(3,IVT3);
	  } else {
	    PX3=ParX((*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),INPR1);
	    PY3=ParY((*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),INPR1);
	    PZ3=ParZ((*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),INPR1);
	  }
	  if(INPR4==0)
	  {
	    PX4=(*VertCoord)(1,IVT4);
	    PY4=(*VertCoord)(2,IVT4);
	    PZ4=(*VertCoord)(3,IVT4);
	  } else {
	    PX4=ParX((*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),INPR1);
	    PY4=ParY((*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),INPR1);
	    PZ4=ParZ((*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),INPR1);
	  }
	  if(INPR==0)
	  {
	    (*MidFaceCoord)(1,TotNumFaces)=0.25*(PX1+PX2+PX3+PX4);
	    (*MidFaceCoord)(2,TotNumFaces)=0.25*(PY1+PY2+PY3+PY4);
	    (*MidFaceCoord)(3,TotNumFaces)=0.25*(PZ1+PZ2+PZ3+PZ4);
	  } else {
	    CalcMidParam((*VertCoord)(1,IVT1),(*VertCoord)(2,IVT1),(*VertCoord)(3,IVT1),
			 (*VertCoord)(1,IVT2),(*VertCoord)(2,IVT2),(*VertCoord)(3,IVT2),
			 (*VertCoord)(1,IVT3),(*VertCoord)(2,IVT3),(*VertCoord)(3,IVT3),
			 (*VertCoord)(1,IVT4),(*VertCoord)(2,IVT4),(*VertCoord)(3,IVT4),
			 PAR1,PAR2,PAR3,INPR);
	    (*MidFaceCoord)(1,TotNumFaces)=ParX(PAR1,PAR2,PAR3,INPR);
	    (*MidFaceCoord)(2,TotNumFaces)=ParY(PAR1,PAR2,PAR3,INPR);
	    (*MidFaceCoord)(3,TotNumFaces)=ParZ(PAR1,PAR2,PAR3,INPR);
	  }
	}
      } else {
	for(JAR=1;JAR<=NumFaceElem;JAR++)
	{
	  JNEIGH=(*NeighElem)(JAR,INEIGH);
	  if(JNEIGH==IEL)
	  {
	    (*MidFaces)(IAR,IEL)=(*MidFaces)(JAR,INEIGH);
	    break;
	  }
	}	
      }
    }
  }
}
