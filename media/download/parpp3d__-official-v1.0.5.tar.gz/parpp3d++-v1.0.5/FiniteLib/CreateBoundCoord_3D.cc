#include "SquareGrid_3D.h"

VOID SquareGrid_3D::CreateBoundCoord_3D()
{
	int IVT,IBCT;
	double PX,PY,PZ;
	
	for(IVT=1;IVT<=NumVertices;IVT++)
	{
		IBCT=(*InfoVertEdge)(IVT);
		if(IBCT!=0)
		{
			PX=ParX((*VertCoord)(1,IVT),(*VertCoord)(2,IVT),(*VertCoord)(3,IVT),IBCT);
			PY=ParY((*VertCoord)(1,IVT),(*VertCoord)(2,IVT),(*VertCoord)(3,IVT),IBCT);
			PZ=ParZ((*VertCoord)(1,IVT),(*VertCoord)(2,IVT),(*VertCoord)(3,IVT),IBCT);
			
			(*VertCoord)(1,IVT)=PX;
			(*VertCoord)(2,IVT)=PY;
			(*VertCoord)(3,IVT)=PZ;
		}
	}
}
