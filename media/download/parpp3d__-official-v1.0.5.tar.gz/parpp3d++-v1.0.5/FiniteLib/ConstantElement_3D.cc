#include "ConstantElement_3D.h"

#define Q4	0.25
#define NNVME	8

void ConstantElement_3D::SetGlobalDOF(unsigned int IEL,unsigned int IPAR)
{
    IntArray	JVG(NNVME),JVL(NNVME);
  
    (*KDFG)(1)=IEL;
    if(IPAR==1)
  	(*KDFL)(1)=1;
}

void ConstantElement_3D::GetValue(DOUBLE X1,DOUBLE X2,DOUBLE X3)
{ 

    if(DETJ>0 && DETJ<1e-70) {
	Err<<"ConstantElement: Element has vanishing area !!!\n";
	exit(1);
    }
    if((*BDER)(2) || (*BDER)(3) || (*BDER)(4) || (*BDER)(5) || (*BDER)(6)) {
	Err<<"ConstantElement: Desired derivates not available !!!\n";
	exit(1);
    }
  
    if((*BDER)(1)) {
	(*DBAS)(1,1,1)=1;
    }
}

void ConstantElement_3D::Restrict(DoubleVector *LD,DoubleVector *LB,
				  IntArray2D *VertElem2,IntArray2D *VertElem1,
				  IntArray2D *MidEdges2,IntArray2D *MidEdges1,
				  IntArray2D *NeighElem2,IntArray2D *NeighElem1,
				  unsigned int NumVertices2,unsigned int NumVertices1,
				  unsigned int NumElements2,unsigned int NumElements1)
{
    int IEL1,IELH1,IELH2,IELH3,IELH4,IELH5,IELH6,IELH7,IELH8;

    for(IEL1=1;IEL1<=NumElements1;IEL1++) {
	IELH1=IEL1;
	IELH2=(*NeighElem2)(3,IELH1);
	IELH3=(*NeighElem2)(3,IELH2);
	IELH4=(*NeighElem2)(3,IELH3);
	IELH5=(*NeighElem2)(6,IELH1);
	IELH6=(*NeighElem2)(6,IELH2);
	IELH7=(*NeighElem2)(6,IELH3);
	IELH8=(*NeighElem2)(6,IELH4);
	// *** Restriction of pressure
    
	(*LB)(IEL1)= (*LD)(IELH1)+(*LD)(IELH2)+(*LD)(IELH3)+(*LD)(IELH4)+
	    (*LD)(IELH5)+(*LD)(IELH6)+(*LD)(IELH7)+(*LD)(IELH8);
    }
}

void ConstantElement_3D::Prol(DoubleVector *LD,DoubleVector *LB,
			      IntArray2D *VertElem2,IntArray2D *VertElem1,
			      IntArray2D *MidEdges2,IntArray2D *MidEdges1,
			      IntArray2D *NeighElem2,IntArray2D *NeighElem1,
			      unsigned int NumVertices2,unsigned int NumVertices1,
			      unsigned int NumElements2,unsigned int NumElements1)
// LD           - coarse grid vector
// LB           - finer grid vector
// NeighElem1   - on coarse grid
// NumElements1 - on coarse grid
// NumVertices1 - on coarse grid
// VertElem1    - on coarse grid


// MidEdges1    - on coarse grid
// MidEdges2, NeighElem2, NumElements2, NumVertices2, VertElem2 ...

{
    int IEL1;					  // loop counter
    int IELH1, IELH2, IELH3, IELH4;		  // auxiliary variables
    int IELH5, IELH6, IELH7, IELH8;		  // auxiliary variables
    double DPH;					  // auxiliary variables

    for (IEL1 = 1; IEL1 <= NumElements1; IEL1++) {
	IELH1 = IEL1; 
	IELH2 = (*NeighElem2)(3, IELH1); 
	IELH3 = (*NeighElem2)(3, IELH2); 
	IELH4 = (*NeighElem2)(3, IELH3); 
	IELH5 = (*NeighElem2)(6, IELH1); 
	IELH6 = (*NeighElem2)(3, IELH5); 
	IELH7 = (*NeighElem2)(3, IELH6); 
	IELH8 = (*NeighElem2)(3, IELH7); 

	// *** Prolongation of pressure
	DPH = (*LD)(IEL1); 
	(*LB)(IELH1) = DPH; 
	(*LB)(IELH2) = DPH; 
	(*LB)(IELH3) = DPH; 
	(*LB)(IELH4) = DPH; 
	(*LB)(IELH5) = DPH; 
	(*LB)(IELH6) = DPH; 
	(*LB)(IELH7) = DPH; 
	(*LB)(IELH8) = DPH; 
    }
}
