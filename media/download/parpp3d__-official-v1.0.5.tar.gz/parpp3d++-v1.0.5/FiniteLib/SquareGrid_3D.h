#ifndef SQUAREGRID3DH

#define SQUAREGRID3DH

#include <LinLib.h>
#include <cinput.h>

// Two variables to enable function tracing.
extern int  MyProcID;
extern bool Debug;

#define NUMOFVERT	8   //NNVE
#define NUMOFEDGE	12  //NNAE
#define NUMOFFACE	6   //NNEE

#define MAXINDEX	200000

#define false 0
#define true  1

class SquareGrid_3D
{
    friend class FiniteElement_3D;
    friend class TrilinearElement_3D;
    friend class ParTrilinearElement_3D;
    friend class ConstantElement_3D;
    friend class RotatedElement_3D;
    friend class NonParamElement_3D;
    friend class NonParamMeanElement_3D;
    friend class ParNonParamElement_3D;
    friend class ParNonParamMeanElement_3D;
    friend class ParRotatedElement_3D;

protected:
    int	NumElements;	// NEL  - number of elements
    int	NumVertices;	// NVT  - number of vertices
    int	NumEdges;	// NMT  - number of edges
    int	NumVertElem;	// NVE  - number of vertices per element
    int	NumElemVert;	// NVEL - number of elements meeting at a vertex
    int	NumBound;	// NBCT - number of boundary components
    int	NumVertBound;	// NVBD - number of vertices on the boundary
// 3-D
    int TotNumEdges;	// NET  -
    int TotNumFaces;	// NAT  - 
    int NumEdgeElem;	// NEE  - 
    int NumFaceElem;	// NAE  - 
    int NumElemEdge;	// NEEL - number of elements meeting at an edge
    int NumEdgeVert;	// NVED - number of vertices meeting at an edge (?)
    int NumFaceVert;	// NVAR - number of vertices meeting at a face
    int NumFaceEdge;	// NEAR - number of edges meeting at a face
    int NumEdgesBound;	// NEBD - number of edges on the boundary
    int NumFacesBound;	// NABD - number of faces (areas) on the boundary
		
    DoubleArray2D	*VertCoord;		// LCORVG
    DoubleArray2D	*MidCoord;		// LCORMG
    IntArray2D		*VertElem;		// LVERT
    IntArray2D		*NeighElem;		// LADJ   - array of adjacent elements
    IntArray2D		*ElemVert;		// LVEL
    IntArray2D		*ElemEdge;		// LMEL
    IntArray		*InfoVertEdge;		// LNPR
    IntArray2D		*InfoVertBound;		// LMM
    IntArray		*VertBound;		// LVBD
    IntArray		*ElemBound;		// LEBD
    IntArray		*PosBoundEntry; 	// LBCT
// 3-D
    DoubleArray2D	*MidFaceCoord;		// LCORAG
    DoubleArray2D	*CopyVertCoord;		// LCORH
    IntArray2D		*MidEdges;		// LEDGE  - array of edges of elements, if necessary
    IntArray2D		*MidFaces;		// LAREA  - array of midpoints of faces, if necessary
    IntArray2D		*ElemMeetEdge;		// LEEL
    IntArray2D		*ElemMeetFace;		// LAEL
    IntArray2D		*VertMeetEdge;		// LVED
    IntArray2D		*FaceMeetEdge;		// LAED
    IntArray2D		*VertMeetFace;		// LVAR
    IntArray2D		*EdgeMeetFace;		// LEAR
    IntArray2D		*ElemMeetVert;		// LEVE
    IntArray2D		*FaceMeetVert;		// LAVE
    IntArray		*MidFacesBound;		// LABD
		
    int     RefineMeshProc(unsigned NFINE, unsigned& NNEL, unsigned& NNVT);
    void    CreateBoundCoord_3D();
    int     KGVVEL(IntArray2D *KVEL1,int s1,IntArray2D *KVEL2,int s2,int NVEL,int IEL);
  
public:
    SquareGrid_3D(VOID);
    virtual ~SquareGrid_3D(VOID);
  
// Hilfsroutinen
    void    RefineMesh(unsigned NFINE, unsigned ISCAD, unsigned ISE, unsigned ISA,
                           unsigned ISEEL, unsigned ISAEL, unsigned ISVEL, unsigned IDISP);
    VOID    CreateNeighInfo_3D(unsigned IDISP);
    VOID    CreateVertexInfo_3D(IntArray2D* KVERT, IntArray2D* KVEL, unsigned flag);
    VOID    CreateEdgeInfo_3D(unsigned ISE);
    VOID    CreateElemMeetEdgeInfo_3D(IntArray2D* KEDGE, IntArray2D* KEEL, unsigned flag);
    VOID    CreateFaceInfo_3D(unsigned ISA, unsigned IND);
    VOID    CreateElemMeetFaceInfo_3D();
    VOID    AdjustGridInfo_3D();
  
    double  ParX(double T1, double T2, double T3, unsigned IBCT);
    double  ParY(double T1, double T2, double T3, unsigned IBCT);
    double  ParZ(double T1, double T2, double T3, unsigned IBCT);

    VOID	CalcMidParam(double X1, double Y1, double Z1, double X2, double Y2, 
                             double Z2, double X3, double Y3, double Z3, double X4, 
                             double Y4, double Z4, double& XT, double& YT, double& ZT, 
                             unsigned IBCT);
    VOID	CalcEdgeParam(double X1, double Y1, double Z1, double X2, double Y2, 
                              double Z2, double& XT, double& YT, double& ZT, 
                              unsigned IBCT);
  						
    virtual double  Solution(double X, double Y, double Z, double T)=0;
    virtual double  SolutionDX(double X, double Y, double Z)=0;
    virtual double  SolutionDY(double X, double Y, double Z)=0;
    virtual double  SolutionDZ(double X, double Y, double Z)=0;
    virtual double  CoeffBX(double X, double Y, double Z)=0;
    virtual double  CoeffBY(double X, double Y, double Z)=0;
    virtual double  CoeffBZ(double X, double Y, double Z)=0;
    virtual double  RightSideCoeff(double X, double Y, double Z, INTEGER IB, 
                                   INTEGER BFIRST)=0;
    virtual double  StiffCoeff(double X, double Y, double Z, INTEGER IA, INTEGER IB, 
                               INTEGER BFIRST)=0;
    virtual void    CoeffA1()=0;
    virtual void    CoeffM()=0;
    int       BoundaryCondition (unsigned int Func, double X, double Y, double Z, double T);

    virtual void AppendBoundNode(int pnode1, int pnode2, int nnode, int info) {}
    virtual void AppendBoundNode(int pnode1, int pnode2, int pnode3, int pnode4, int nnode, int info) {}
    virtual void AppendMidBoundNode(int pnode1, int pnode2, int pnode3, int pnode4, int nnode, int info) {}
  
    void 	ReadParam(CInput& Daten);
    void	ReadCoord(CInput& Daten);
    void	ReadVertElem(CInput& Daten);
    void	ReadInfoVertEdge(CInput& Daten);
  
    void PrintInfoVertEdge(void);
    void PrintVertElem(void);
    void PrintNeighElem(void);
    void PrintVertCoord(void);
    void PrintMidFaces(void);
    void PrintInfo(void);
//    	void AVSGrid(char* name);
//    	void WriteGrid(char* name);

    virtual void BoundaryProjection();
  
// Hauptroutinen
    void	ReadCoarseGrid(const char* aName);
    void	Refine(unsigned NFINE, unsigned ISCAD, unsigned ISE, unsigned ISA,
                       unsigned ISEEL, unsigned ISAEL, unsigned ISVEL, unsigned IDISP);
};

#endif
