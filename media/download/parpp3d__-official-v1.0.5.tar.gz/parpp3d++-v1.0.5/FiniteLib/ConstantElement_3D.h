#ifndef CONSTANTELEMENT3DH

#define CONSTANTELEMENT3DH

#include "FiniteElement_3D.h"

class ConstantElement_3D:public FiniteElement_3D
{
public:
    ConstantElement_3D(SquareGrid_3D *NGrid):FiniteElement_3D(NGrid) {IDFL=1;NDIM=1;}
    ~ConstantElement_3D(void) {}
  
    void         GetValue(DOUBLE X1,DOUBLE X2,DOUBLE X3);
    unsigned int GetDOF(void);
    unsigned int GetTotalDOF(void);
    unsigned int GetIEROW(void);
    int          GetElemType(void);
    void         SetGlobalDOF(unsigned int IEL,unsigned int IPAR);
    void         Restrict(DoubleVector *LD,DoubleVector *LB,
			  IntArray2D *VertElem2,IntArray2D *VertElem1,
			  IntArray2D *MidEdges2,IntArray2D *MidEdges1,
			  IntArray2D *NeighElem2,IntArray2D *NeighElem1,
			  unsigned int NumVertices2,unsigned int NumVertices1,
			  unsigned int NumElements2,unsigned int NumElements1);
    void         Prol(DoubleVector *LD,DoubleVector *LB,
		      IntArray2D *VertElem2,IntArray2D *VertElem1,
		      IntArray2D *MidEdges2,IntArray2D *MidEdges1,
		      IntArray2D *NeighElem2,IntArray2D *NeighElem1,
		      unsigned int NumVertices2,unsigned int NumVertices1,
		      unsigned int NumElements2,unsigned int NumElements1);
    void         ParRestrict(DoubleVector *LD,DoubleVector *LB,
			     IntArray2D *VertElem2,IntArray2D *VertElem1,
			     IntArray2D *MidEdges2,IntArray2D *MidEdges1,
			     IntArray2D *NeighElem2,IntArray2D *NeighElem1,
			     unsigned int NumVertices2,unsigned int NumVertices1,
			     unsigned int NumElements2,unsigned int NumElements1);
    void         ParProl(DoubleVector *LD,           DoubleVector *LB, 
			 IntArray2D   *VertElem2,    IntArray2D   *VertElem1, 
			 IntArray2D   *MidEdges2,    IntArray2D   *MidEdges1, 
			 IntArray2D   *NeighElem2,   IntArray2D   *NeighElem1, 
			 unsigned int  NumVertices2, unsigned int  NumVertices1, 
			 unsigned int  NumElements2, unsigned int  NumElements1); 
};

inline unsigned int ConstantElement_3D::GetDOF(void)
{
	return IDFL;
}

inline unsigned int ConstantElement_3D::GetTotalDOF(void)
{
	return Grid->NumElements;
}

inline unsigned int ConstantElement_3D::GetIEROW(void)
{
	return 10;
}

inline int ConstantElement_3D::GetElemType(void)
{
	return PARAM;
}

#endif
