#ifndef NUMINTEGRATIONH

#define NUMINTEGRATIONH

#include <LinLib.h>

#define NNCUBP	36

#define GAUSS1		1
#define MIDAREA		2
#define TRAPEZ  	3
#define MIDEDGE		4
#define STROUD1		5
#define STROUD2		6
#define GAUSS2		7
#define HAMMER		8
#define GAUSS3		9
#define SARMA       10

class NumIntegration_3D
{
	private:
		DoubleArray2D	*VCubPoint;
		DoubleArray		*VOmega;
		UNSIGNED			VNumCubPoints;
		
	public:
		NumIntegration_3D(UNSIGNED ICUB);
		~NumIntegration_3D(VOID);
		
		DOUBLE CubPoint(UNSIGNED row,UNSIGNED col);
		DOUBLE Omega(UNSIGNED row);
		UNSIGNED NumCubPoints(VOID);
};

inline DOUBLE NumIntegration_3D::CubPoint(UNSIGNED row,UNSIGNED col)
{
	return (*VCubPoint)(row,col);
}

inline DOUBLE NumIntegration_3D::Omega(UNSIGNED row)
{
	return (*VOmega)(row);
}

inline UNSIGNED NumIntegration_3D::NumCubPoints(VOID)
{
	return VNumCubPoints;
}

#endif
