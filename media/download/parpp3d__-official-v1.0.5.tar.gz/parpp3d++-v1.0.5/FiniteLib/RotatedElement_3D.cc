#include "RotatedElement_3D.h"

#define Q8  0.125
#define NNVME   8

VOID RotatedElement_3D::SetGlobalDOF(UNSIGNED IEL,UNSIGNED IPAR)
{
  INTEGER IVE,NKE,IAE;
  IntArray  JVG(NNVEA),JVL(NNVEA);

  for(IVE=1;IVE<=NumVertElem;IVE++) {
    JVG(IVE)=(*VertElem)(IVE,IEL);
    JVL(IVE)=IVE;
  }
  NKE=NumVertElem;
  if(TotNumFaces>0)
  {
    for(IAE=1;IAE<=NumFaceElem;IAE++) {
      JVG(NKE+IAE)=(*MidFaces)(IAE,IEL)+NumVertices;
      JVL(NKE+IAE)=NKE+IAE;
    }
    NKE+=NumFaceElem;
  }

  if(IPAR>=0)
      BubbleSort(JVG,JVL,NKE);

  for(IAE=1;IAE<=NumFaceElem;IAE++) {
    if(TotNumEdges>0)
    (*KDFG)(IAE)=JVG(NKE-NumFaceElem+IAE)-NumVertices;
  }
  if(IPAR==1) {
    for(IAE=1;IAE<=NumFaceElem;IAE++) {
      (*KDFL)(IAE)=JVL(NKE-NumFaceElem+IAE)-NumVertElem;
    }
  }
}

VOID RotatedElement_3D::GetValue(DOUBLE X1,DOUBLE X2,DOUBLE X3)
{
    double XJ1;
    DoubleArray2D   DHELP(6,4);
    int IDFL1;
    double Q3=1.0/3.0;
    double Q6=1.0/6.0;
    double Q23=2.0/3.0;

    if (DETJ>0 && DETJ<1e-70) {
        Err<<"RotatedElement_3D: Element has vanishing area !!!\n";
        exit(1);
    }
    if ((*BDER)(5) || (*BDER)(6) || (*BDER)(7) || (*BDER)(8)) {
        Err<<"RotatedElement_3D: Desired derivates not available !!!\n";
        exit(1);
    }

    if((*BDER)(1)) {
        DHELP(1,1)= Q6*(X1*X1-X2*X2)-Q3*(X1*X1-X3*X3)-Q2*X3+Q6;
        DHELP(2,1)=-Q3*(X1*X1-X2*X2)+Q6*(X1*X1-X3*X3)-Q2*X2+Q6;
        DHELP(3,1)= Q6*(X1*X1-X2*X2)+Q6*(X1*X1-X3*X3)+Q2*X1+Q6;
        DHELP(4,1)=-Q3*(X1*X1-X2*X2)+Q6*(X1*X1-X3*X3)+Q2*X2+Q6;
        DHELP(5,1)= Q6*(X1*X1-X2*X2)+Q6*(X1*X1-X3*X3)-Q2*X1+Q6;
        DHELP(6,1)= Q6*(X1*X1-X2*X2)-Q3*(X1*X1-X3*X3)+Q2*X3+Q6;
    }

    if((*BDER)(2) || (*BDER)(3) || (*BDER)(4)) {
        DHELP(1,2)=-Q3*X1;
        DHELP(2,2)=-Q3*X1;
        DHELP(3,2)= Q23*X1+Q2;
        DHELP(4,2)=-Q3*X1;
        DHELP(5,2)= Q23*X1-Q2;
        DHELP(6,2)=-Q3*X1;

        DHELP(1,3)=-Q3*X2;
        DHELP(2,3)= Q23*X2-Q2;
        DHELP(3,3)=-Q3*X2;
        DHELP(4,3)= Q23*X2+Q2;
        DHELP(5,3)=-Q3*X2;
        DHELP(6,3)=-Q3*X2;

        DHELP(1,4)= Q23*X3-Q2;
        DHELP(2,4)=-Q3*X3;
        DHELP(3,4)=-Q3*X3;
        DHELP(4,4)=-Q3*X3;
        DHELP(5,4)=-Q3*X3;
        DHELP(6,4)= Q23*X3+Q2;
    }

  if((*BDER)(1)) {
    for(IDFL1=1;IDFL1<=NNAE;IDFL1++)
    (*DBAS)(1,IDFL1,1)=DHELP(IDFL1,1);
  }
  XJ1=1.0/DETJ;
  if((*BDER)(2)) {
    for(IDFL1=1;IDFL1<=NNAE;IDFL1++)
    (*DBAS)(1,IDFL1,2)=XJ1*(
      DHELP(IDFL1,2)*((*DJAC)(2,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(2,3))
      -DHELP(IDFL1,3)*((*DJAC)(2,1)*(*DJAC)(3,3)-(*DJAC)(3,1)*(*DJAC)(2,3))
      +DHELP(IDFL1,4)*((*DJAC)(2,1)*(*DJAC)(3,2)-(*DJAC)(3,1)*(*DJAC)(2,2)));
  }
  if((*BDER)(3)) {
    for(IDFL1=1;IDFL1<=NNAE;IDFL1++)
    (*DBAS)(1,IDFL1,3)=XJ1*(
      -DHELP(IDFL1,2)*((*DJAC)(1,2)*(*DJAC)(3,3)-(*DJAC)(3,2)*(*DJAC)(1,3))
      +DHELP(IDFL1,3)*((*DJAC)(1,1)*(*DJAC)(3,3)-(*DJAC)(3,1)*(*DJAC)(1,3))
      -DHELP(IDFL1,4)*((*DJAC)(1,1)*(*DJAC)(3,2)-(*DJAC)(3,1)*(*DJAC)(1,2)));
  }
  if((*BDER)(4)) {
    for(IDFL1=1;IDFL1<=NNAE;IDFL1++)
    (*DBAS)(1,IDFL1,4)=XJ1*(
      DHELP(IDFL1,2)*((*DJAC)(1,2)*(*DJAC)(2,3)-(*DJAC)(2,2)*(*DJAC)(1,3))
      -DHELP(IDFL1,3)*((*DJAC)(1,1)*(*DJAC)(2,3)-(*DJAC)(2,1)*(*DJAC)(1,3))
      +DHELP(IDFL1,4)*((*DJAC)(1,1)*(*DJAC)(2,2)-(*DJAC)(2,1)*(*DJAC)(1,2)));
  }
}

VOID RotatedElement_3D::Restrict(DoubleVector *LD,DoubleVector *LB,
                 IntArray2D *VertElem2,IntArray2D *VertElem1,
                 IntArray2D *MidFaces2,IntArray2D *MidFaces1,
                 IntArray2D *NeighElem2,IntArray2D *NeighElem1,
                 UNSIGNED NumVertices2,UNSIGNED NumVertices1,
                 UNSIGNED NumElements2,UNSIGNED NumElements1)
{
//  VertElem2,NeighElem2 and NumElements2:  fine grid information
//  NumVertices1: coarse grid information

  int IELH1,IELH2,IELH3,IELH4,IELH5,IELH6,IELH7,IELH8,IEL1;
  int IA1,IA2,IA3,IA4,IA5,IA6;

  double DY1,DY2,DY3,DY4,DY5,DY6,DY7,DY8,DY9,DY10,DY11,DY12;
  double DY13,DY14,DY15,DY16,DY17,DY18,DY19,DY20,DY21,DY22,DY23,DY24;
  double DY25,DY26,DY27,DY28,DY29,DY30,DY31,DY32,DY33,DY34,DY35,DY36;
  double A1,A2,A3,A4,A5,A6,A7;

  A1= 11.0/24.0;
  A2= 7.0/48.0;
  A3=-5.0/48.0;
  A4=-1.0/24.0;
  A5= 11.0/24.0;
  A6= 1.0/12.0;
  A7=-1.0/24.0;

  *LB=0;

  for(IEL1=1;IEL1<=NumElements1;IEL1++)
  {
    IA1=(*MidFaces1)(1,IEL1);
    IA2=(*MidFaces1)(2,IEL1);
    IA3=(*MidFaces1)(3,IEL1);
    IA4=(*MidFaces1)(4,IEL1);
    IA5=(*MidFaces1)(5,IEL1);
    IA6=(*MidFaces1)(6,IEL1);

    IELH1=IEL1;
    IELH2=(*NeighElem2)(3,IELH1);
    IELH3=(*NeighElem2)(3,IELH2);
    IELH4=(*NeighElem2)(3,IELH3);
    IELH5=(*NeighElem2)(6,IELH1);
    IELH6=(*NeighElem2)(3,IELH5);
    IELH7=(*NeighElem2)(3,IELH6);
    IELH8=(*NeighElem2)(3,IELH7);

    DY1= (*LD)((*MidFaces2)(1,IELH1));
    DY2= (*LD)((*MidFaces2)(1,IELH2));
    DY3= (*LD)((*MidFaces2)(1,IELH3));
    DY4= (*LD)((*MidFaces2)(1,IELH4));
    DY5= (*LD)((*MidFaces2)(2,IELH1));
    DY6= (*LD)((*MidFaces2)(5,IELH2));
    DY7= (*LD)((*MidFaces2)(5,IELH6));
    DY8= (*LD)((*MidFaces2)(2,IELH5));
    DY9= (*LD)((*MidFaces2)(2,IELH2));
    DY10=(*LD)((*MidFaces2)(5,IELH3));
    DY11=(*LD)((*MidFaces2)(5,IELH7));
    DY12=(*LD)((*MidFaces2)(2,IELH6));
    DY13=(*LD)((*MidFaces2)(2,IELH3));
    DY14=(*LD)((*MidFaces2)(5,IELH4));
    DY15=(*LD)((*MidFaces2)(5,IELH8));
    DY16=(*LD)((*MidFaces2)(2,IELH7));
    DY17=(*LD)((*MidFaces2)(2,IELH4));
    DY18=(*LD)((*MidFaces2)(5,IELH1));
    DY19=(*LD)((*MidFaces2)(5,IELH5));
    DY20=(*LD)((*MidFaces2)(2,IELH8));
    DY21=(*LD)((*MidFaces2)(1,IELH5));
    DY22=(*LD)((*MidFaces2)(1,IELH6));
    DY23=(*LD)((*MidFaces2)(1,IELH7));
    DY24=(*LD)((*MidFaces2)(1,IELH8));
    DY25=(*LD)((*MidFaces2)(3,IELH1));
    DY26=(*LD)((*MidFaces2)(3,IELH2));
    DY27=(*LD)((*MidFaces2)(3,IELH3));
    DY28=(*LD)((*MidFaces2)(3,IELH4));
    DY29=(*LD)((*MidFaces2)(6,IELH1));
    DY30=(*LD)((*MidFaces2)(6,IELH2));
    DY31=(*LD)((*MidFaces2)(6,IELH3));
    DY32=(*LD)((*MidFaces2)(6,IELH4));
    DY33=(*LD)((*MidFaces2)(3,IELH5));
    DY34=(*LD)((*MidFaces2)(3,IELH6));
    DY35=(*LD)((*MidFaces2)(3,IELH7));
    DY36=(*LD)((*MidFaces2)(3,IELH8));

    if((*NeighElem1)(1,IEL1)!=0) {
      (*LB)(IA1)= (*LB)(IA1)
    +A1*(DY1+DY2+DY3+DY4)
    +A2*(DY5+DY6+DY9+DY10+DY13+DY14+DY17+DY18)
    +A3*(DY7+DY8+DY11+DY12+DY15+DY16+DY19+DY20)
    +A4*(DY21+DY22+DY23+DY24)
    +A5*(DY25+DY26+DY27+DY28)
    +A6*(DY29+DY30+DY31+DY32)
    +A7*(DY33+DY34+DY35+DY36);
    }


    if((*NeighElem1)(2,IEL1)!=0) {
      (*LB)(IA2)= (*LB)(IA2)
    +A1*(DY5+DY6+DY7+DY8)
    +A2*(DY1+DY2+DY9+DY12+DY21+DY22+DY18+DY19)
    +A3*(DY3+DY4+DY10+DY11+DY23+DY24+DY17+DY20)
    +A4*(DY13+DY14+DY15+DY16)
    +A5*(DY25+DY29+DY30+DY33)
    +A6*(DY26+DY28+DY34+DY36)
    +A7*(DY27+DY31+DY32+DY35);
    }


    if((*NeighElem1)(3,IEL1)!=0) {
      (*LB)(IA3)= (*LB)(IA3)
    +A1*(DY9+DY10+DY11+DY12)
    +A2*(DY2+DY3+DY6+DY7+DY22+DY23+DY13+DY16)
    +A3*(DY1+DY4+DY5+DY8+DY21+DY24+DY14+DY15)
    +A4*(DY17+DY18+DY19+DY20)
    +A5*(DY26+DY30+DY31+DY34)
    +A6*(DY25+DY27+DY33+DY35)
    +A7*(DY28+DY29+DY32+DY36);
    }


    if((*NeighElem1)(4,IEL1)!=0) {
      (*LB)(IA4)= (*LB)(IA4)
    +A1*(DY13+DY14+DY15+DY16)
    +A2*(DY3+DY4+DY10+DY11+DY23+DY24+DY17+DY20)
    +A3*(DY1+DY2+DY9+DY12+DY21+DY22+DY18+DY19)
    +A4*(DY5+DY6+DY7+DY8)
    +A5*(DY27+DY31+DY32+DY35)
    +A6*(DY26+DY28+DY34+DY36)
    +A7*(DY25+DY29+DY30+DY33);
    }


    if((*NeighElem1)(5,IEL1)!=0) {
      (*LB)(IA5)= (*LB)(IA5)
    +A1*(DY17+DY18+DY19+DY20)
    +A2*(DY1+DY4+DY5+DY8+DY21+DY24+DY14+DY15)
    +A3*(DY2+DY3+DY6+DY7+DY22+DY23+DY13+DY16)
    +A4*(DY9+DY10+DY11+DY12)
    +A5*(DY28+DY29+DY32+DY36)
    +A6*(DY25+DY27+DY33+DY35)
    +A7*(DY26+DY30+DY31+DY34);
    }


    if((*NeighElem1)(6,IEL1)!=0) {
      (*LB)(IA6)= (*LB)(IA6)
    +A1*(DY21+DY22+DY23+DY24)
    +A2*(DY7+DY8+DY11+DY12+DY15+DY16+DY19+DY20)
    +A3*(DY5+DY6+DY9+DY10+DY13+DY14+DY17+DY18)
    +A4*(DY1+DY2+DY3+DY4)
    +A5*(DY33+DY34+DY35+DY36)
    +A6*(DY29+DY30+DY31+DY32)
    +A7*(DY25+DY26+DY27+DY28);
    }
  }
}

VOID RotatedElement_3D::Prol(DoubleVector *LD,DoubleVector *LB,
                 IntArray2D *VertElem2,IntArray2D *VertElem1,
                 IntArray2D *MidFaces2,IntArray2D *MidFaces1,
                 IntArray2D *NeighElem2,IntArray2D *NeighElem1,
                 UNSIGNED NumVertices2,UNSIGNED NumVertices1,
                 UNSIGNED NumElements2,UNSIGNED NumElements1)
{
//  VertElem2,NeighElem2 and NumElements2:  fine grid information
//  NumVertices1: coarse grid information

  int IEL1,IELH1,IELH2,IELH3,IELH4,IELH5,IELH6,IELH7,IELH8;
  double DY1,DY2,DY3,DY4,DY5,DY6;
  double A1,A2,A3,A4,A5,A6,A7;

  A1= 11.0/24.0;
  A2= 7.0/48.0;
  A3=-5.0/48.0;
  A4=-1.0/24.0;
  A5= 11.0/24.0;
  A6= 1.0/12.0;
  A7=-1.0/24.0;

  *LB=0;

  for(IEL1=1;IEL1<=NumElements1;IEL1++)
  {
    DY1=(*LD)((*MidFaces1)(1,IEL1));
    DY2=(*LD)((*MidFaces1)(2,IEL1));
    DY3=(*LD)((*MidFaces1)(3,IEL1));
    DY4=(*LD)((*MidFaces1)(4,IEL1));
    DY5=(*LD)((*MidFaces1)(5,IEL1));
    DY6=(*LD)((*MidFaces1)(6,IEL1));

    IELH1=IEL1;
    IELH2=(*NeighElem2)(3,IELH1);
    IELH3=(*NeighElem2)(3,IELH2);
    IELH4=(*NeighElem2)(3,IELH3);
    IELH5=(*NeighElem2)(6,IELH1);
    IELH6=(*NeighElem2)(3,IELH5);
    IELH7=(*NeighElem2)(3,IELH6);
    IELH8=(*NeighElem2)(3,IELH7);

    if((*NeighElem1)(1,IEL1)!=0) {
      (*LB)((*MidFaces2)(1,IELH1))=(*LB)((*MidFaces2)(1,IELH1))+
    A1*DY1+A2*DY2+A3*DY3+A3*DY4+A2*DY5+A4*DY6;
      (*LB)((*MidFaces2)(1,IELH2))=(*LB)((*MidFaces2)(1,IELH2))+
    A1*DY1+A2*DY2+A2*DY3+A3*DY4+A3*DY5+A4*DY6;
      (*LB)((*MidFaces2)(1,IELH3))=(*LB)((*MidFaces2)(1,IELH3))+
    A1*DY1+A3*DY2+A2*DY3+A2*DY4+A3*DY5+A4*DY6;
      (*LB)((*MidFaces2)(1,IELH4))=(*LB)((*MidFaces2)(1,IELH4))+
    A1*DY1+A3*DY2+A3*DY3+A2*DY4+A2*DY5+A4*DY6;
    }


    if((*NeighElem1)(2,IEL1)!=0) {
      (*LB)((*MidFaces2)(2,IELH1))=(*LB)((*MidFaces2)(2,IELH1))+
    A2*DY1+A1*DY2+A3*DY3+A4*DY4+A2*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH2))=(*LB)((*MidFaces2)(5,IELH2))+
    A2*DY1+A1*DY2+A2*DY3+A4*DY4+A3*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH6))=(*LB)((*MidFaces2)(5,IELH6))+
    A3*DY1+A1*DY2+A2*DY3+A4*DY4+A3*DY5+A2*DY6;
      (*LB)((*MidFaces2)(2,IELH5))=(*LB)((*MidFaces2)(2,IELH5))+
    A3*DY1+A1*DY2+A3*DY3+A4*DY4+A2*DY5+A2*DY6;
    }


    if((*NeighElem1)(3,IEL1)!=0) {
      (*LB)((*MidFaces2)(2,IELH2))=(*LB)((*MidFaces2)(2,IELH2))+
    A2*DY1+A2*DY2+A1*DY3+A3*DY4+A4*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH3))=(*LB)((*MidFaces2)(5,IELH3))+
    A2*DY1+A3*DY2+A1*DY3+A2*DY4+A4*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH7))=(*LB)((*MidFaces2)(5,IELH7))+
    A3*DY1+A3*DY2+A1*DY3+A2*DY4+A4*DY5+A2*DY6;
      (*LB)((*MidFaces2)(2,IELH6))=(*LB)((*MidFaces2)(2,IELH6))+
    A3*DY1+A2*DY2+A1*DY3+A3*DY4+A4*DY5+A2*DY6;
    }


    if((*NeighElem1)(4,IEL1)!=0) {
      (*LB)((*MidFaces2)(2,IELH3))=(*LB)((*MidFaces2)(2,IELH3))+
    A2*DY1+A4*DY2+A2*DY3+A1*DY4+A3*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH4))=(*LB)((*MidFaces2)(5,IELH4))+
    A2*DY1+A4*DY2+A3*DY3+A1*DY4+A2*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH8))=(*LB)((*MidFaces2)(5,IELH8))+
    A3*DY1+A4*DY2+A3*DY3+A1*DY4+A2*DY5+A2*DY6;
      (*LB)((*MidFaces2)(2,IELH7))=(*LB)((*MidFaces2)(2,IELH7))+
    A3*DY1+A4*DY2+A2*DY3+A1*DY4+A3*DY5+A2*DY6;
    }


    if((*NeighElem1)(5,IEL1)!=0) {
      (*LB)((*MidFaces2)(2,IELH4))=(*LB)((*MidFaces2)(2,IELH4))+
    A2*DY1+A3*DY2+A4*DY3+A2*DY4+A1*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH1))=(*LB)((*MidFaces2)(5,IELH1))+
    A2*DY1+A2*DY2+A4*DY3+A3*DY4+A1*DY5+A3*DY6;
      (*LB)((*MidFaces2)(5,IELH5))=(*LB)((*MidFaces2)(5,IELH5))+
    A3*DY1+A2*DY2+A4*DY3+A3*DY4+A1*DY5+A2*DY6;
      (*LB)((*MidFaces2)(2,IELH8))=(*LB)((*MidFaces2)(2,IELH8))+
    A3*DY1+A3*DY2+A4*DY3+A2*DY4+A1*DY5+A2*DY6;
    }


    if((*NeighElem1)(6,IEL1)!=0) {
      (*LB)((*MidFaces2)(1,IELH5))=(*LB)((*MidFaces2)(1,IELH5))+
    A4*DY1+A2*DY2+A3*DY3+A3*DY4+A2*DY5+A1*DY6;
      (*LB)((*MidFaces2)(1,IELH6))=(*LB)((*MidFaces2)(1,IELH6))+
    A4*DY1+A2*DY2+A2*DY3+A3*DY4+A3*DY5+A1*DY6;
      (*LB)((*MidFaces2)(1,IELH7))=(*LB)((*MidFaces2)(1,IELH7))+
    A4*DY1+A3*DY2+A2*DY3+A2*DY4+A3*DY5+A1*DY6;
      (*LB)((*MidFaces2)(1,IELH8))=(*LB)((*MidFaces2)(1,IELH8))+
    A4*DY1+A3*DY2+A3*DY3+A2*DY4+A2*DY5+A1*DY6;
    }


    (*LB)((*MidFaces2)(3,IELH1))=A5*DY1+A5*DY2+A6*DY3+A7*DY4+A6*DY5+A7*DY6;
    (*LB)((*MidFaces2)(3,IELH2))=A5*DY1+A6*DY2+A5*DY3+A6*DY4+A7*DY5+A7*DY6;
    (*LB)((*MidFaces2)(3,IELH3))=A5*DY1+A7*DY2+A6*DY3+A5*DY4+A6*DY5+A7*DY6;
    (*LB)((*MidFaces2)(3,IELH4))=A5*DY1+A6*DY2+A7*DY3+A6*DY4+A5*DY5+A7*DY6;

    (*LB)((*MidFaces2)(6,IELH1))=A6*DY1+A5*DY2+A7*DY3+A7*DY4+A5*DY5+A6*DY6;
    (*LB)((*MidFaces2)(6,IELH2))=A6*DY1+A5*DY2+A5*DY3+A7*DY4+A7*DY5+A6*DY6;
    (*LB)((*MidFaces2)(6,IELH3))=A6*DY1+A7*DY2+A5*DY3+A5*DY4+A7*DY5+A6*DY6;
    (*LB)((*MidFaces2)(6,IELH4))=A6*DY1+A7*DY2+A7*DY3+A5*DY4+A5*DY5+A6*DY6;

    (*LB)((*MidFaces2)(3,IELH5))=A7*DY1+A5*DY2+A6*DY3+A7*DY4+A6*DY5+A5*DY6;
    (*LB)((*MidFaces2)(3,IELH6))=A7*DY1+A6*DY2+A5*DY3+A6*DY4+A7*DY5+A5*DY6;
    (*LB)((*MidFaces2)(3,IELH7))=A7*DY1+A7*DY2+A6*DY3+A5*DY4+A6*DY5+A5*DY6;
    (*LB)((*MidFaces2)(3,IELH8))=A7*DY1+A6*DY2+A7*DY3+A6*DY4+A5*DY5+A5*DY6;
  }
}

