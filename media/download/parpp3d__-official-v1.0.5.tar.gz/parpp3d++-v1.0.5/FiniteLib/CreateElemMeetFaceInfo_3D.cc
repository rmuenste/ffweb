#include "SquareGrid_3D.h"

void SquareGrid_3D::CreateElemMeetFaceInfo_3D()
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering SquareGrid_3D::CreateElemMeetFaceInfo_3D.\n";
        protocol.mFlush();
    }

    int IAT;
	
    for (int IEL = 1; IEL <= NumElements; IEL++) {
	for (int IAE = 1; IAE <= NumFaceElem; IAE++) {
	    IAT = (*MidFaces)(IAE, IEL); 
            if ((*ElemMeetFace)(1, IAT) == 0) {
		(*ElemMeetFace)(1, IAT) = IEL; 
	    } else {
		(*ElemMeetFace)(2, IAT) = IEL; 
	    }
				
	}
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving SquareGrid_3D::CreateElemMeetFaceInfo_3D.\n";
        protocol.mFlush();
    }

    return;
}
