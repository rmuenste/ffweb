#include "SquareGrid_3D.h"

SquareGrid_3D::SquareGrid_3D(VOID)
{
    NumElements=NumVertices=NumEdges=NumVertElem=0;
    NumElemVert=NumBound=NumVertBound=0;
    TotNumEdges=TotNumFaces=NumEdgeElem=0;
    NumFaceElem=NumElemEdge=NumEdgeVert=0;
    NumFaceVert=NumFaceEdge=0;
    NumEdgesBound=NumFacesBound=0;
	
    VertCoord=0;
    MidCoord=0;
    VertElem=0;
    MidEdges=0;
    NeighElem=0;
    ElemVert=0;
    ElemEdge=0;
    InfoVertEdge=0;
    InfoVertBound=0;
    VertBound=0;
    ElemBound=0;
    PosBoundEntry=0;
    MidFaceCoord=0;
    MidEdges=0;
    MidFaces=0;
    ElemMeetEdge=0;
    ElemMeetFace=0;
    VertMeetEdge=0;
    FaceMeetEdge=0;
    VertMeetFace=0;
    EdgeMeetFace=0;
    ElemMeetVert=0;
    FaceMeetVert=0;
    MidFacesBound=0;
    CopyVertCoord=0;
}

SquareGrid_3D::~SquareGrid_3D(VOID)
{
    if(VertCoord)
	delete VertCoord;
    if(MidCoord)
	delete MidCoord;
    if(VertElem)
	delete VertElem;
    if(MidEdges)
	delete MidEdges;
    if(NeighElem)
	delete NeighElem;
    if(ElemVert)
	delete ElemVert;
    if(ElemEdge)
	delete ElemEdge;
    if(InfoVertEdge)
	delete InfoVertEdge;
    if(InfoVertBound)
	delete InfoVertBound;
    if(VertBound)
	delete VertBound;
    if(ElemBound)
	delete ElemBound;
    if(PosBoundEntry)
	delete PosBoundEntry;
    if(MidFaceCoord)
	delete MidFaceCoord;
    if(MidEdges)
	delete MidEdges;
    if(MidFaces)
	delete MidFaces;
    if(ElemMeetEdge)
	delete ElemMeetEdge;
    if(ElemMeetFace)
	delete ElemMeetFace;
    if(VertMeetEdge)
	delete VertMeetEdge;
    if(FaceMeetEdge)
	delete FaceMeetEdge;
    if(VertMeetFace)
	delete VertMeetFace;
    if(EdgeMeetFace)
	delete EdgeMeetFace;
    if(ElemMeetVert)
	delete ElemMeetVert;
    if(FaceMeetVert)
	delete FaceMeetVert;
    if(MidFacesBound)
	delete MidFacesBound;
    if(CopyVertCoord)
	delete CopyVertCoord;
}

VOID SquareGrid_3D::ReadCoord(CInput& Daten)
{
    Daten.GoToNextLine();
    Daten.GoToNextLine();
    for(INTEGER i=1;i<=NumVertices;i++) {
	Daten>>(*VertCoord)(1,i);
	Daten>>(*VertCoord)(2,i);
	Daten>>(*VertCoord)(3,i);
    }
}

VOID SquareGrid_3D::ReadVertElem(CInput& Daten)
{
    Daten.GoToNextLine();
    Daten.GoToNextLine();
    for(INTEGER i=1;i<=NumElements;i++) {
	for(INTEGER j=1;j<=NumVertElem;j++) {
	    Daten>>(*VertElem)(j,i);
	}
	if(i!=NumElements)
	    Daten.GoToNextLine();
    }
}

VOID SquareGrid_3D::ReadInfoVertEdge(CInput& Daten)
{
    Daten.GoToNextLine();
    Daten.GoToNextLine();
    for(INTEGER i=1;i<=NumVertices;i++) {
	Daten>>(*InfoVertEdge)(i);
    }
}

VOID SquareGrid_3D::ReadParam(CInput& Daten)
{
    Daten.GoToNextLine();
    Daten.GoToNextLine();
    Daten>>NumElements;
    Daten>>NumVertices;
    Daten>>NumBound;
    Daten>>NumVertElem;
    Daten>>NumEdgeElem;
    Daten>>NumFaceElem;
}



VOID SquareGrid_3D::ReadCoarseGrid(const char* aName)
{
    CInput Daten(aName);
    INTEGER Len;
	
    ReadParam(Daten);

    if(VertCoord) {
	Len=VertCoord->GetLen();
	if(Len!=2*NumVertices) {
	    delete VertCoord;
	    VertCoord=0;
	}
    }
    if(NumVertices) {
	VertCoord=new DoubleArray2D(3,NumVertices,"VertCoord");
	(*VertCoord)=0;
    }
	
    if(VertElem) {
	Len=VertElem->GetLen();
	if(Len!=NUMOFVERT*NumElements) {
	    delete VertElem;
	    VertElem=0;
	}
    }
    if(NumElements) {
	VertElem=new IntArray2D(NUMOFVERT,NumElements,"VertElem");
	(*VertElem)=0;
    }
	
    if(InfoVertEdge) {
	Len=InfoVertEdge->GetLen();
	if(Len!=NumVertices+NumEdges) {
	    delete InfoVertEdge;
	    InfoVertEdge=0;
	}
    }
    if(NumVertices) {
	InfoVertEdge=new IntArray(NumVertices,"InfoVertEdge");
	(*InfoVertEdge)=0;
    }
	
    ReadCoord(Daten);
    ReadVertElem(Daten);
    ReadInfoVertEdge(Daten);
}

