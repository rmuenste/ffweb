#include "Task.h"

void Task::PreSmooth(MultiCompactMatrix* A, DoubleVector *LX, 
		     DoubleVector *LB, unsigned int Steps,
		     double AMin, double AMax)
{
    unsigned int sm_steps = Steps; 

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::PreSmooth.\n";
        protocol.mFlush();
    }

//      for (int i = 0; i < (MaxLevel - ActiveLevel); i++)
//  	sm_steps *= 2; 
  
    Prot.SetFlag(NO); 

    if (Param->Smoother == 1)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->JacobiSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, E[ActiveLevel]); 
    else if (Param->Smoother == 2)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->SORSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, E[ActiveLevel]); 
    else if (Param->Smoother == 3)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->ILUSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, E[ActiveLevel]); 
    //  else if (Param->Smoother == 4)
    //  ((ParCompactMatrix*)((*A)[ActiveLevel]))->ParCG(*LX, *LB, Steps, 1e-10, this); 
    else if (Param->Smoother == 4)
	MultiDriverSmooth(*RotElement, A, LX, LB, l2norm(LX), 1, 1e-9, ActiveLevel, AMin, AMax); 
 
  //MPI_Barrier(MPI_COMM_WORLD); 

    if (MyProcID == 0) 
	Prot.SetFlag(YES); 

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::PreSmooth.\n";
        protocol.mFlush();
    }

    return;
}

void Task::PostSmooth(MultiCompactMatrix* A, DoubleVector *LX, 
		      DoubleVector *LB, unsigned int Steps, 
		      double AMin, double AMax)
{
    unsigned int sm_steps = Steps; 

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::PostSmooth.\n";
        protocol.mFlush();
    }

//      for (int i = 0; i < (MaxLevel - ActiveLevel); i++)
//  	sm_steps *= 2; 
  
    Prot.SetFlag(NO); 

    if (Param->Smoother == 1)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->JacobiSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, E[ActiveLevel]); 
    else if (Param->Smoother == 2)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->SORSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, E[ActiveLevel]); 
    else if (Param->Smoother == 3)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->ILUSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, E[ActiveLevel]); 
    //else if (Param->Smoother == 4)
    //  ((ParCompactMatrix*)((*A)[ActiveLevel]))
    //   ->ParCG(*LX, *LB, Steps, 1e-10, this); 
    else if (Param->Smoother == 4)
	MultiDriverSmooth(*RotElement, A, LX, LB, l2norm(LX), 1, 1e-9, ActiveLevel, AMin, AMax); 
  


    //MPI_Barrier(MPI_COMM_WORLD); 

    if (MyProcID == 0) 
	Prot.SetFlag(YES); 

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::PostSmooth.\n";
        protocol.mFlush();
    }

    return;
}

void Task::MultiPreSmooth(MultiCompactMatrix* A,DoubleVector *LX,
			  DoubleVector *LB,unsigned int Steps)
{
  unsigned int sm_steps=Steps;

  //for(int i=0;i<(MaxLevel-ActiveLevel);i++)
  //  sm_steps*=2;
//    sm_steps=3;

  Prot.SetFlag(NO);

//    if(Param->Smoother==1)
//        ((ParCompactMatrix*)((*A)[ActiveLevel]))
//            ->JacobiSmooth(*LX,*LB,sm_steps,Param->MGOmega,this,E[ActiveLevel]);
//    else if(Param->Smoother==2)
//        ((ParCompactMatrix*)((*A)[ActiveLevel]))
//            ->SORSmooth(*LX,*LB,sm_steps,Param->MGOmega,this,E[ActiveLevel]);
//    else if(Param->Smoother==3)
    ((ParCompactMatrix*)((*A)[ActiveLevel]))
      ->ILUSmooth(*LX,*LB,sm_steps,Param->MGOmega,this,E[ActiveLevel]);

  //MPI_Barrier(MPI_COMM_WORLD);

  if(MyProcID==0) 
    Prot.SetFlag(YES);
}

void Task::MultiPostSmooth(MultiCompactMatrix* A,DoubleVector *LX,
		      DoubleVector *LB,unsigned int Steps)
{
  unsigned int sm_steps=Steps;

//    for(int i=0;i<(MaxLevel-ActiveLevel);i++)
//      sm_steps*=2;
  
  //sm_steps=3;

  Prot.SetFlag(NO);

//    if(Param->Smoother==1)
//        ((ParCompactMatrix*)((*A)[ActiveLevel]))
//            ->JacobiSmooth(*LX,*LB,sm_steps,Param->MGOmega,this,E[ActiveLevel]);
//    else if(Param->Smoother==2)
//        ((ParCompactMatrix*)((*A)[ActiveLevel]))
//            ->SORSmooth(*LX,*LB,sm_steps,Param->MGOmega,this,E[ActiveLevel]);
//    else if(Param->Smoother==3)
    ((ParCompactMatrix*)((*A)[ActiveLevel]))
      ->ILUSmooth(*LX,*LB,sm_steps,Param->MGOmega,this,E[ActiveLevel]);

  //MPI_Barrier(MPI_COMM_WORLD);

   if(MyProcID==0) 
    Prot.SetFlag(YES);

}

void Task::ConstPreSmooth(MultiCompactMatrix* A, DoubleVector *LX, 
			  DoubleVector *LB, unsigned int Steps)
{
    unsigned int sm_steps = Steps; 

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::ConstPreSmooth.\n";
        protocol.mFlush();
    }

//      for (int i = 0; i < (MaxLevel - ActiveLevel); i++)
//  	sm_steps *= 2; 

  //  Prot << "EConst = \n" << *EConst[ActiveLevel] << "\n"; 
  
//  Prot << "PreSmooth: Steps=" << sm_steps << " BoundCond: " << Param->BoundCond << "\n"; 
    Prot.SetFlag(NO); 

    if (Param->Smoother == 1)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->ConstJacobiSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, EConst[ActiveLevel]); 
    else if (Param->Smoother == 2)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->ConstSORSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, EConst[ActiveLevel]); 
    else if (Param->Smoother == 3)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->ConstILUSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, EConst[ActiveLevel]); 

    //MPI_Barrier(MPI_COMM_WORLD); 

    if (MyProcID == 0) 
	Prot.SetFlag(YES); 

    //    Prot<<"After PreSmooth: LX=\n"<<*LX<<"\n";

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::ConstPreSmooth.\n";
        protocol.mFlush();
    }

    return;
}

void Task::ConstPostSmooth(MultiCompactMatrix* A, DoubleVector *LX, 
			   DoubleVector *LB, unsigned int Steps)
{
    unsigned int sm_steps = Steps; 

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::ConstPostSmooth.\n";
        protocol.mFlush();
    }

//      for (int i = 0; i < (MaxLevel - ActiveLevel); i++)
//  	sm_steps *= 2; 
  
    Prot.SetFlag(NO);

    if (Param->Smoother == 1)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->ConstJacobiSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, EConst[ActiveLevel]); 
    else if (Param->Smoother == 2)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->ConstSORSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, EConst[ActiveLevel]); 
    else if (Param->Smoother == 3)
	((ParCompactMatrix*)((*A)[ActiveLevel]))->ConstILUSmooth(*LX, *LB, sm_steps, Param->MGOmega, this, EConst[ActiveLevel]); 


    //MPI_Barrier(MPI_COMM_WORLD);

    if (MyProcID == 0) 
	Prot.SetFlag(YES);

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::ConstPostSmooth.\n";
        protocol.mFlush();
    }

    return;
}

void Task::UpdateDiagonal()
{
//   blink *temp;
    int ILEV;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::UpdateDiagonal.\n";
	protocol.mFlush();
    }
  
//  int savelevel=ActiveLevel;

    for (ILEV = MinLevel; ILEV <= MaxLevel; ILEV++) {
	if (E[ILEV] == NULL)
	    E[ILEV] = new DoubleVector((*A)[ILEV]->GetNumDiag());

	*E[ILEV] = 0;

	for(int IEQ = 1; IEQ <= (*A)[ILEV]->GetNumDiag(); IEQ++) {
	    (*E[ILEV])(IEQ) = (*A)[ILEV]->Data((*A)[ILEV]->Diag(IEQ));
	}
    
	ActiveLevel = ILEV;
	SetBoundValues(E[ILEV]);
	Communicate();
	GetBoundValuesMult(E[ILEV]);

//      real_nodeBase=Mreal_nodeBase[ILEV];
//      for(temp=real_nodeBase->get_first();temp;temp=real_nodeBase->get_next(temp))
//      {
//  	if(temp->type==REAL_BOUND)
//          {
//  	    Prot<<"Update Diagonal: node="<<temp->node<<" E="<<(*E[ILEV])(temp->node)<<"\n";
//  	    (*E[ILEV])(temp->node)=1.0;
//          }
//      }

	MPI_Barrier(MPI_COMM_WORLD);
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::UpdateDiagonal.\n";
	protocol.mFlush();
    }

//    MPI_Barrier(MPI_COMM_WORLD);
//  ActiveLevel=savelevel;
  
    return;
}

void Task::ConstUpdateDiagonal()
{
  for(int ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
    if(EConst[ILEV]==NULL)
	EConst[ILEV]=new DoubleVector((*C)[ILEV]->GetNumDiag());
    *EConst[ILEV]=0;
    for(int IEQ=1;IEQ<=(*C)[ILEV]->GetNumDiag();IEQ++) {
      (*EConst[ILEV])(IEQ)=(*C)[ILEV]->Data((*C)[ILEV]->Diag(IEQ));
    }
    
    myElemBase=MmyElemBase[ILEV];

    elemlist* list;
    for(list=myElemBase->get_neighlist()->get_first();list;
	list=myElemBase->get_neighlist()->get_next(list))
    {
      elemlink *node;
      for(node=list->base->get_first();node;
	  node=list->base->get_next(node))
      {
	(*EConst[ILEV])(node->elem)+=node->normal;
      }
    }    
  }

  //  MPI_Barrier(MPI_COMM_WORLD);
}

void Task::NeumannUpdateDiagonal()
{
  for(int ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
    if(E[ILEV]==NULL)
	E[ILEV]=new DoubleVector((*A)[ILEV]->GetNumDiag());
    *E[ILEV]=0;
    for(int IEQ=1;IEQ<=(*A)[ILEV]->GetNumDiag();IEQ++) {
      (*E[ILEV])(IEQ)=(*A)[ILEV]->Data((*A)[ILEV]->Diag(IEQ));
    }
    
    ActiveLevel=ILEV;
    SetNeumannBoundValues(E[ILEV]);
    CommunicateNeumann();
    GetNeumannBoundValuesMult(E[ILEV]);
  }

  //  MPI_Barrier(MPI_COMM_WORLD);
}

void Task::InitILU(MultiCompactMatrix* B)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::InitILU.\n";
        protocol.mFlush();
    }

    DoubleCompactMatrix* D;
    for(int ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
	SetLevel(ILEV);
	D=(*B)[ILEV];
	D->CuthillMcKee();
    //Prot<<"EConst=\n"<<*EConst[ILEV]<<"\n";
    //D->PermAll(E[ILEV]);
    //D->PermAll();
    //D->ILU(1,alpha,1e-12,*MElemInfo[ILEV]);
    //D->ILU(1,alpha,1e-12);

//      Prot<<"Normal-Matrix !!\n";
//      int end,row,col;
//      for(row=1;row<=D->GetNumDiag();row++)
//      {
//  	end=D->Diag(row+1)-1;
//  	for(col=D->Diag(row);col<=end;col++)
//          {
//  	    Prot<<"The value at row "<<row<<" ,column "<<D->Col(col)<<" = ";
//  	    Prot<<D->Data(col)<<"\n";
//          }
//      }
//      Prot<<"ILU-Matrix !!\n";
//      for(row=1;row<=D->GetNumDiag();row++)
//      {
//  	end=D->ILUDiag(row+1)-1;
//  	for(col=D->ILUDiag(row);col<=end;col++)
//          {
//  	    Prot<<"The value at row "<<row<<" ,column "<<D->ILUCol(col)<<" = ";
//  	    Prot<<D->ILUData(col)<<"\n";
//          }
//      }
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::InitILU.\n";
        protocol.mFlush();
    }
}

void Task::ILU(MultiCompactMatrix* B,DoubleVector** D,double alpha)
{
   for(int ILEV=MinLevel;ILEV<=MaxLevel;ILEV++) {
      SetLevel(ILEV);
      (*B)[ILEV]->PermAll(D[ILEV]);
      (*B)[ILEV]->ILU(1,alpha,1e-12);
   }
}

void ParGrid::CopyBoundaryData(DoubleVector *LB)
{
  int IBD;
//   double X,Y,Z;
  
  VertBound=MVertBound[ActiveLevel];
  for(IBD=1;IBD<=MNumVertBound[ActiveLevel];IBD++) 
      (*LB)((*VertBound)(IBD))=0;
}

void Task::ExactSol(MultiCompactMatrix* A,DoubleVector *LX,DoubleVector *LB) 
{
//	Prot<<"Exact Sol f=\n"<<*LB<<"\n";
//	Prot<<"Exact Sol sol=\n"<<*LX<<"\n";
//	Prot<<"Exact Sol A[MinLevel]=\n"<<*(*A)[MinLevel]<<"\n";
	
  Prot.SetFlag(NO);
  if(solver==1)
      (*A)[MinLevel]->Jacobi(*LX,*LB,200,(double)1e-9,0.8);
  else if(solver==2)
      (*A)[MinLevel]->SOR(*LX,*LB,200,(double)1e-9,(double)1.3);
  else if(solver==3)
      (*A)[MinLevel]->GaussSeidel(*LX,*LB,50,(double)1e-9);
  else if(solver==4)
      (*A)[MinLevel]->NeumannCG(*LX,*LB,100,(double)1e-9,(double)1.3);
  else {
    DoubleCompactMatrix *mA=(*A)[MinLevel];
    DoubleFullMatrix M(mA->GetNumDiag(),mA->GetNumDiag());
	
    M=0;
    for(int i=1;i<=mA->GetNumDiag();i++)
    {
      for(int j=mA->Diag(i);j<=mA->Diag(i+1)-1;j++)
	  M(i,mA->Col(j))=mA->Data(j);
    }
    M.LR_Zerlegung(LB,LX);
  }

  if(MyProcID==0) 
    Prot.SetFlag(YES);
	
//	Prot<<"Exact Sol sol=\n"<<*LX<<"\n";
}
