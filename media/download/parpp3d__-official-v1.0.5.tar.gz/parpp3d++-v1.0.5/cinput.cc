#include "cinput.h"

CInput::CInput(const char *aName) 
{
    infile   = new std::ifstream(aName);
    filename = aName;

#ifdef VERBOSE_DEBUG
    STD_COUT << "Opening file " << filename << "\n";
#endif
    if (! *infile ) {
//    if (! infile->is_open()) {
        CInput::mAbortProgram("Could not open file '" + filename + "'", FILE_OPEN_ERROR);
    }

    return;
}

CInput::~CInput()
{
#ifdef VERBOSE_DEBUG
    STD_COUT << "Closing file " << filename << "\n";
#endif
    delete infile;
    return;
}

void CInput::mCloseFile()
{
    infile->close();

    return;
}

void CInput::GoToNextLine(void)
{
    bool oneslashfound;
    char c;

    while (true) {
	// Skip the rest of the current line
	while (infile->get(c)) {
	    if (c == '\n') break; 
	}

	// Check whether the next line contains only a C++ style comment
	oneslashfound = false;
	while (infile->get(c)) {
	    // Search for a '//', but ignore a single '/'
	    if (c == '/') {
		if (oneslashfound == false)
		    oneslashfound = true;
		else
		    break;			  // '//' found, skip rest of line

	    } else if (isspace(c)) {
		if (oneslashfound == true) {	  // '/ ' found, put both back into stream and exit
		    infile->putback(c);
		    infile->putback('/');
		    return;
		}

	    } else {
		infile->putback(c);		  // Different character found, put it back into stream and exit
		if (oneslashfound == true)
		    infile->putback('/');
		return;
	    }
	}

	if (infile->eof()) break;
    }

    return;
}


void CInput::mStatus()
{
    STD_COUT << "Reading from file <" << filename << ">.\n";

    return;
}


void CInput::mAbortProgram(const std::string errorMessage, const int errorNumber)
{
    std::string message = progname + " (process " + int_to_string(MyProcID) + "):\n"
                        + "  " + errorMessage + "\n" 
                        + "  Program aborted.\n";

    // Send error message to stderr
    STD_CERR << message;
    protocol  << message;

    // Clean up MPI environment and exit program.
    MPI_Abort(MPI_COMM_WORLD, errorNumber);
}
