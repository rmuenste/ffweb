#include "Task.h"

extern double TCoarse,TCoarseCom;

void Task::Communicate(void)
{
    int len[MAX_PROC+1];
    DoubleVector *Ptr;

    SendBound     = MSendBound[ActiveLevel];
    SendBoundData = MSendBoundData[ActiveLevel];
    RecvBound     = MRecvBound[ActiveLevel];
    RecvBoundData = MRecvBoundData[ActiveLevel];
    myBase        = MmyBase[ActiveLevel];

    blist* temp_list;
    DVector_blink *temp_vectlist;
    int data;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::Communicate.\n";
	protocol.mFlush();
    }

    for(int Proc=0;Proc<nProcs;Proc++)
    {
	if (MyProcID != Proc) {
	    for(temp_list=myBase->get_neighlist()->get_first(), temp_vectlist=SendBoundData->get_first();
		temp_list;
		temp_list=myBase->get_neighlist()->get_next(temp_list), temp_vectlist=SendBoundData->get_next(temp_vectlist))
	    {
		if (temp_vectlist) {
		    if(temp_list->neigh == Proc+1) {
			Ptr = temp_vectlist->ptr;
			if (Ptr) {
			    data = Ptr->GetLen();
			    MyCom->SyncSend(temp_list->neigh,data);
			} else {
			    Prot<<"???? Ptr==0  MyProcID "<<MyProcID<<"\n";
			    protocol << progname << " (process " << MyProcID << "):\n"
				     << "  Error in Task::Communicate: Ptr == 0\n";
			}
		    }
		} else {
		    Prot<<"???? SendBoundData temp_vectlist==0 MyProcID "<<MyProcID<<"\n";
		    protocol << progname << " (process " << MyProcID << "):\n"
			     << "  Error in Task::Communicate: SendBoundData temp_vectlist==0\n";
		}
	    }
	} // end if (MyProcID != Proc)

	if(MyProcID==Proc) {
	    for(temp_list=myBase->get_neighlist()->get_first();
		temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
	    {
		MyCom->SyncRecieve(temp_list->neigh,&data);
		//	  MyCom->Sync(temp_list->neigh);
		len[temp_list->neigh]=data;
	    }
	}

	if(MyProcID!=Proc) {
	    for(temp_list=myBase->get_neighlist()->get_first(),
		    temp_vectlist=SendBoundData->get_first();
		temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list),
		    temp_vectlist=SendBoundData->get_next(temp_vectlist))
	    {
		if(temp_vectlist)
		{
		    if(temp_list->neigh==Proc+1)
		    {
			Ptr=temp_vectlist->ptr;
			if (Ptr) {
			    MyCom->SyncSend(temp_list->neigh,Ptr);
			} else {
			    Prot<<"???? Ptr==0  MyProcID "<<MyProcID<<"\n";
			    protocol << progname << " (process " << MyProcID << "):\n"
				     << "  Error in Task::Communicate: Ptr == 0\n";
			}
		    }
		} else {
		    Prot<<"???? SendBoundData temp_vectlist==0 MyProcID "<<MyProcID<<"\n";
		    protocol << progname << " (process " << MyProcID << "):\n"
			     << "  Error in Task::Communicate: SendBoundData temp_vectlist==0\n";
		}
	    }
	}

	if(MyProcID==Proc) {
	    for(temp_list=myBase->get_neighlist()->get_first(),
		    temp_vectlist=RecvBoundData->get_first();
		temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list),
		    temp_vectlist=RecvBoundData->get_next(temp_vectlist))
	    {
		if(temp_vectlist)
		{
		    Ptr=new DoubleVector(len[temp_list->neigh]);
		    MyCom->SyncRecieve(temp_list->neigh,Ptr);
		    //	      MyCom->Sync(temp_list->neigh);
		    if(Ptr) {
			SetBoundData(Ptr,temp_vectlist->ptr);
			delete Ptr;
		    } else {
			Prot<<"!!!! Ptr==0  Data from "<<temp_list->neigh<<" MyProcID "<<MyProcID<<"\n";
			protocol << progname << " (process " << MyProcID << "):\n"
				 << "  Error in Task::Communicate: Ptr == 0, Data from " << temp_list->neigh << "\n";
		    }
		} else {
		    Prot<<"???? RecvBoundData temp_vectlist==0 MyProcID "<<MyProcID<<"\n";
		    protocol << progname << " (process " << MyProcID << "):\n"
			     << "  Error in Task::Communicate: RecvBoundData temp_vectlist==0\n";
		}
	    }
	}
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::Communicate.\n";
	protocol.mFlush();
    }

    return;
}

void Task::CommunicateElem(void)
{
    int len[MAX_PROC+1];
    DoubleVector *Ptr;

    SendElemBound     = MSendElemBound[ActiveLevel];
    SendElemBoundData = MSendElemBoundData[ActiveLevel];
    RecvElemBound     = MRecvElemBound[ActiveLevel];
    RecvElemBoundData = MRecvElemBoundData[ActiveLevel];
    myElemBase        = MmyElemBase[ActiveLevel];

    elemlist* temp_list;
    DVector_blink *temp_vectlist;
    int data;

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "): Entering Task::CommunicateElem.\n";
//  	protocol.mFlush();
//      }

    for (int Proc=0; Proc < nProcs; Proc++) {
	if (MyProcID != Proc) {
	    for(temp_list=myElemBase->get_neighlist()->get_first(),
		    temp_vectlist=SendElemBoundData->get_first();
		temp_list;temp_list=myElemBase->get_neighlist()->get_next(temp_list),
		    temp_vectlist=SendElemBoundData->get_next(temp_vectlist))
	    {
		if(temp_vectlist)
		{
		    if(temp_list->neigh==Proc+1)
		    {
			Ptr=temp_vectlist->ptr;
			if(Ptr)
			{
			    data=Ptr->GetLen();
			    MyCom->SyncSend(temp_list->neigh,data);
			} else {
			    Prot<<"???? Ptr==0  MyProcID "<<MyProcID<<"\n";
			    protocol << progname << " (process " << MyProcID << "):\n"
				     << "  Error in Task::CommunicateElem: Ptr == 0\n";
			}
		    }
		} else {
		    Prot<<"???? SendElemBoundData temp_vectlist==0 MyProcID "<<MyProcID<<"\n";
		    protocol << progname << " (process " << MyProcID << "):\n"
			     << "  Error in Task::CommunicateElem: SendElemBoundData temp_vectlist==0\n";
		}
	    }
	}

	if (MyProcID == Proc) {
	    for (temp_list=myElemBase->get_neighlist()->get_first();
		temp_list;temp_list=myElemBase->get_neighlist()->get_next(temp_list))
	    {
		MyCom->SyncRecieve(temp_list->neigh,&data);
		//	  MyCom->Sync(temp_list->neigh);
		len[temp_list->neigh]=data;
	    }
	}

	if (MyProcID != Proc) {
	    for(temp_list=myElemBase->get_neighlist()->get_first(),
		    temp_vectlist=SendElemBoundData->get_first();
		temp_list;temp_list=myElemBase->get_neighlist()->get_next(temp_list),
		    temp_vectlist=SendElemBoundData->get_next(temp_vectlist))
	    {
		if(temp_vectlist) {
		    if(temp_list->neigh == Proc+1) {
			Ptr = temp_vectlist->ptr;
			if (Ptr) {
			    MyCom->SyncSend(temp_list->neigh,Ptr);
			} else {
			    Prot<<"???? Ptr==0  MyProcID "<<MyProcID<<"\n";
			    protocol << progname << " (process " << MyProcID << "):\n"
				     << "  Error in CommunicateElem: Ptr == 0\n";
			}
		    }
		} else {
		    Prot<<"???? SendElemBoundData temp_vectlist==0 MyProcID "<<MyProcID<<"\n";
		    protocol << progname << " (process " << MyProcID << "):\n"
			     << "  Error in Task::CommunicateElem: SendElemBoundData temp_vectlist==0\n";
		}
	    }
	}

	if (MyProcID == Proc) {
	    for(temp_list=myElemBase->get_neighlist()->get_first(),
		    temp_vectlist=RecvElemBoundData->get_first();
		temp_list;temp_list=myElemBase->get_neighlist()->get_next(temp_list),
		    temp_vectlist=RecvElemBoundData->get_next(temp_vectlist))
	    {
		if(temp_vectlist)
		{
		    Ptr=new DoubleVector(len[temp_list->neigh]);
		    MyCom->SyncRecieve(temp_list->neigh,Ptr);
		    //	      MyCom->Sync(temp_list->neigh);
		    if(Ptr) {
			SetBoundData(Ptr,temp_vectlist->ptr);
			delete Ptr;
		    } else {
			Prot<<"!!!! Ptr==0  Data from "<<temp_list->neigh<<" MyProcID "<<MyProcID<<"\n";
			protocol << progname << " (process " << MyProcID << "):\n"
				 << "  Error in Task::CommunicateElem: Ptr == 0, Data from " << temp_list->neigh << "\n";
		    }
		} else {
		    Prot<<"???? RecvElemBoundData temp_vectlist==0 MyProcID "<<MyProcID<<"\n";
		    protocol << progname << " (process " << MyProcID << "):\n"
			     << "  Error in Task::CommunicateElem: RecvElemBoundData temp_vectlist==0\n";
		}
	    }
	}
    }

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CommunicateElem.\n";
//  	protocol.mFlush();
//      }

    return;
}

void Task::CommunicateProlRest(DoubleVector *x)
{

  if(Param->BoundCond==1)
  {
    SetBoundValues(x);
    Communicate();
    GetBoundValuesMult(x);
  } else {
    SetNeumannBoundValues(x);
    CommunicateNeumann();
    GetNeumannBoundValuesMult(x);
  }
}


void Task::CommunicateExact(DoubleVector *v)
{
  int i,len;
//   int j;
  DoubleVector *ptr;

  double TSolve=0;
  DateTime Clock,ClockHelp;


#ifdef COM_MSG
  Prot<<"Communicate-exact !!\n";
#endif

  Clock.SetTime();


  if(MyProcID+1 != MASTER)
  {
    MyCom->SyncSend(MASTER,(int)v->GetLen());
    MyCom->SyncSend(MASTER,v);

#ifdef COM_MSG
    Prot<<"Communicate-exact Send to master  MyProcID "<<MyProcID<<"\n";
#endif

    MyCom->SyncRecieve(MASTER,&len);
    //    MyCom->Sync(MASTER);
    ptr=new DoubleVector(len);
    MyCom->SyncRecieve(MASTER,ptr);
    //    MyCom->Sync(MASTER);
    *v=*ptr;
    delete ptr;

#ifdef COM_MSG
    Prot<<"Communicate-exact Recieve from master  MyProcID "<<MyProcID<<"\n";
#endif

  } else {
    for(i=1;i<=nProcs;i++)
    {
      if(i!=MASTER) {
	MyCom->SyncRecieve(i,&len);
	//	MyCom->Sync(i);
	ptr=new DoubleVector(len);
	MyCom->SyncRecieve(i,ptr);
	//	MyCom->Sync(i);
	CoarseGrid->SetVector(i,ptr);
	delete ptr;
      }
    }

    ClockHelp.SetTime();
    CoarseGrid->SetVector(MASTER,v);
    CoarseGrid->SolveExact(solver);
    TSolve=ClockHelp.GetTimeDiff();

    for(i=1;i<=nProcs;i++)
    {
      if(i!=MASTER) {
	ptr=CoarseGrid->GetVector(i);
	MyCom->SyncSend(i,(int)ptr->GetLen());
	MyCom->SyncSend(i,ptr);
	delete ptr;
      }
    }
    ptr=CoarseGrid->GetVector(MASTER);
    *v=*ptr;
    delete ptr;
  }

  TCoarse=Clock.GetTimeDiff();
  TCoarseCom=TCoarse-TSolve;

}


int Task::StopCriterion(double newDefect, double epsDefect)
{
    int crit, i;

#ifdef COM_MSG
    Prot<<"Stop-Criterion !!\n";
#endif

    if (MyProcID + 1 != MASTER) {
        MyCom->SyncRecieve(MASTER, &crit);
    } else {
        if (newDefect <= MACHINE_EPS ||   // As soon as we have reached machine precision we can stop iterationing.
	    newDefect <= epsDefect)
            crit = CRIT_TRUE;
        else
            crit = CRIT_FALSE;

        for (i = 1; i <= nProcs; i++) {
            if (i != MASTER) {
		MyCom->SyncSend(i, crit);
            }
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    return crit;
}


int Task::StopCriterion(double newDefect, double oldDefect, double change,
			double epsDefect, double dampingRate, double epsChange)
{
    int crit, i;

#ifdef COM_MSG
    Prot<<"Stop-Criterion !!\n";
#endif

    if (MyProcID + 1 != MASTER) {
        MyCom->SyncRecieve(MASTER, &crit);
    } else {
        if (newDefect <= MACHINE_EPS ||   // As soon as we have reached machine precision we can stop iterationing.
	   (newDefect <= epsDefect  &&  newDefect <= oldDefect * dampingRate  &&  change <= epsChange))
            crit = CRIT_TRUE;
        else
            crit = CRIT_FALSE;

        for (i = 1; i <= nProcs; i++) {
            if (i != MASTER) {
		MyCom->SyncSend(i, crit);
            }
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    return crit;
}


void Task::CommunicateUpwind(DoubleVector *v1,DoubleVector *v2,DoubleVector *v3)
{
  int i,len;
//   int j;
  DoubleVector *ptr;

#ifdef COM_MSG
  Prot<<"Communicate-exact !!\n";
#endif

  if(MyProcID+1 != MASTER)
  {
    MyCom->SyncSend(MASTER,(int)v1->GetLen());
    MyCom->SyncSend(MASTER,v1);
    MyCom->SyncSend(MASTER,(int)v2->GetLen());
    MyCom->SyncSend(MASTER,v2);
    MyCom->SyncSend(MASTER,(int)v3->GetLen());
    MyCom->SyncSend(MASTER,v3);

#ifdef COM_MSG
    Prot<<"Communicate-exact Send to master  MyProcID "<<MyProcID<<"\n";
#endif
  } else {
    for(i=1;i<=nProcs;i++)
    {
      if(i!=MASTER) {
	MyCom->SyncRecieve(i,&len);
	//	MyCom->Sync(i);
	ptr=new DoubleVector(len);
	MyCom->SyncRecieve(i,ptr);
	//	MyCom->Sync(i);
	CoarseGrid->SetUpwindVec1(i,ptr);
	delete ptr;
	MyCom->SyncRecieve(i,&len);
	//	MyCom->Sync(i);
	ptr=new DoubleVector(len);
	MyCom->SyncRecieve(i,ptr);
	//	MyCom->Sync(i);
	CoarseGrid->SetUpwindVec2(i,ptr);
	delete ptr;
	MyCom->SyncRecieve(i,&len);
	//	MyCom->Sync(i);
	ptr=new DoubleVector(len);
	MyCom->SyncRecieve(i,ptr);
	//	MyCom->Sync(i);
	CoarseGrid->SetUpwindVec3(i,ptr);
	delete ptr;

      }
    }
    CoarseGrid->SetUpwindVec1(MASTER,v1);
    CoarseGrid->SetUpwindVec2(MASTER,v2);
    CoarseGrid->SetUpwindVec3(MASTER,v3);
  }
}



//  OLD VERSION: change 23.11.95

//  void Task::CommunicateExact(DoubleVector *v)
//  {
//    int i,j,len;
//    DoubleVector *ptr;

//  #ifdef COM_MSG
//    Prot<<"Communicate-exact !!\n";
//  #endif

//    if(MyProcID+1 != MASTER)
//    {
//      MyCom->SendForward(MyProcID,(int)v->GetLen());
//      MyCom->SendForward(MyProcID,v);

//  #ifdef COM_MSG
//      Prot<<"Communicate-exact Send to master  MyProcID "<<MyProcID<<"\n";
//  #endif

//      for(int i=MyProcID+1;i<nProcs;i++)
//      {
//        MyCom->RecieveBackward(i,&len);
//        ptr=new DoubleVector(len);
//        MyCom->RecieveBackward(i,ptr);
//        MyCom->SendForward(i,len);
//        MyCom->SendForward(i,ptr);
//        delete ptr;
//      }

//      MyCom->RecieveForward(MyProcID,&len);
//      ptr=new DoubleVector(len);
//      MyCom->RecieveForward(MyProcID,ptr);
//      *v=*ptr;
//      delete ptr;

//  #ifdef COM_MSG
//      Prot<<"Communicate-exact Recieve from master  MyProcID "<<MyProcID<<"\n";
//  #endif

//      for(int i=MyProcID+1;i<nProcs;i++)
//      {
//        MyCom->RecieveForward(i,&len);
//        ptr=new DoubleVector(len);
//        MyCom->RecieveForward(i,ptr);
//        MyCom->SendBackward(i,len);
//        MyCom->SendBackward(i,ptr);
//        delete ptr;
//      }

//    } else {
//      for(i=1;i<=nProcs;i++)
//      {
//        if(i!=MASTER) {
//  	MyCom->RecieveBackward(i-1,&len);
//  	ptr=new DoubleVector(len);
//  	MyCom->RecieveBackward(i-1,ptr);
//  	CoarseGrid->SetVector(i,ptr);
//  	delete ptr;
//        }
//      }
//      CoarseGrid->SetVector(MASTER,v);
//      CoarseGrid->SolveExact(solver);
//      for(i=1;i<=NumCoarseElements;i++)
//      {
//        if(i!=MASTER) {
//  	ptr=CoarseGrid->GetVector(i);
//  	MyCom->SendBackward(i-1,(int)ptr->GetLen());
//  	MyCom->SendBackward(i-1,ptr);
//  	delete ptr;
//        }
//      }
//      ptr=CoarseGrid->GetVector(MASTER);
//      *v=*ptr;
//      delete ptr;
//    }
//  }


void Task::CommunicateConstExact(DoubleVector *v)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::CommunicateConstExact.\n";
        protocol.mFlush();
    }

  int i,len;
//   int j;
  DoubleVector *ptr;

  double TSolve=0;
  DateTime Clock,ClockHelp;

#ifdef COM_MSG
  Prot<<"Communicate-exact !!\n";
#endif


  Clock.SetTime();

  if(MyProcID+1 != MASTER)
  {
    MyCom->SyncSend(MASTER,(int)v->GetLen());
    MyCom->SyncSend(MASTER,v);

#ifdef COM_MSG
    Prot<<"Communicate-exact Send to master  MyProcID "<<MyProcID<<"\n";
#endif

    MyCom->SyncRecieve(MASTER,&len);
    //    MyCom->Sync(MASTER);
    ptr=new DoubleVector(len);
    MyCom->SyncRecieve(MASTER,ptr);
    //    MyCom->Sync(MASTER);
    *v=*ptr;
    delete ptr;

#ifdef COM_MSG
    Prot<<"Communicate-exact Recieve from master  MyProcID "<<MyProcID<<"\n";
#endif

  } else {
    for(i=1;i<=nProcs;i++)
    {
      if(i!=MASTER) {
	MyCom->SyncRecieve(i,&len);
	//	MyCom->Sync(i);
	ptr=new DoubleVector(len);
	MyCom->SyncRecieve(i,ptr);
	//	MyCom->Sync(i);
	CoarseGrid->SetConstVector(i,ptr);
	delete ptr;
      }
    }

    ClockHelp.SetTime();
    CoarseGrid->SetConstVector(MASTER,v);
    CoarseGrid->SolveConstExact(solver);
    TSolve=ClockHelp.GetTimeDiff();

    for(i=1;i<=nProcs;i++)
    {
      if(i!=MASTER) {
	ptr=CoarseGrid->GetConstVector(i);
	MyCom->SyncSend(i,(int)ptr->GetLen());
	MyCom->SyncSend(i,ptr);
	delete ptr;
      }
    }
    ptr=CoarseGrid->GetConstVector(MASTER);
    *v=*ptr;
    delete ptr;
  }
  TCoarse=Clock.GetTimeDiff();
  TCoarseCom=TCoarse-TSolve;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CommunicateConstExact.\n";
        protocol.mFlush();
    }
}



//  OLD VERSION: change 23.11.95

//  void Task::CommunicateConstExact(DoubleVector *v)
//  {
//    int i,j,len;
//    DoubleVector *ptr;

//  #ifdef COM_MSG
//    Prot<<"Communicate-exact !!\n";
//  #endif

//    if(MyProcID+1 != MASTER)
//    {
//      MyCom->SendForward(MyProcID,(int)v->GetLen());
//      MyCom->SendForward(MyProcID,v);

//  #ifdef COM_MSG
//      Prot<<"Communicate-exact Send to master  MyProcID "<<MyProcID<<"\n";
//  #endif

//      for(int i=MyProcID+1;i<nProcs;i++)
//      {
//        MyCom->RecieveBackward(i,&len);
//        ptr=new DoubleVector(len);
//        MyCom->RecieveBackward(i,ptr);
//        MyCom->SendForward(i,len);
//        MyCom->SendForward(i,ptr);
//        delete ptr;
//      }

//      MyCom->RecieveForward(MyProcID,&len);
//      ptr=new DoubleVector(len);
//      MyCom->RecieveForward(MyProcID,ptr);
//      *v=*ptr;
//      delete ptr;

//  #ifdef COM_MSG
//      Prot<<"Communicate-exact Recieve from master  MyProcID "<<MyProcID<<"\n";
//  #endif

//      for(int i=MyProcID+1;i<nProcs;i++)
//      {
//        MyCom->RecieveForward(i,&len);
//        ptr=new DoubleVector(len);
//        MyCom->RecieveForward(i,ptr);
//        MyCom->SendBackward(i,len);
//        MyCom->SendBackward(i,ptr);
//        delete ptr;
//      }

//    } else {
//      for(i=1;i<=nProcs;i++)
//      {
//        if(i!=MASTER) {
//  	MyCom->RecieveBackward(i-1,&len);
//  	ptr=new DoubleVector(len);
//  	MyCom->RecieveBackward(i-1,ptr);
//  	CoarseGrid->SetConstVector(i,ptr);
//  	delete ptr;
//        }
//      }
//      CoarseGrid->SetConstVector(MASTER,v);
//      CoarseGrid->SolveConstExact(solver);
//      for(i=1;i<=NumCoarseElements;i++)
//      {
//        if(i!=MASTER) {
//  	ptr=CoarseGrid->GetConstVector(i);
//  	MyCom->SendBackward(i-1,(int)ptr->GetLen());
//  	MyCom->SendBackward(i-1,ptr);
//  	delete ptr;
//        }
//      }
//      ptr=CoarseGrid->GetConstVector(MASTER);
//      *v=*ptr;
//      delete ptr;
//    }
//  }


void Task::CommunicateNeumann(void)
{
  int len[MAX_PROC+1];
  DoubleVector *Ptr;

  SendNeumannBound     = MSendNeumannBound[ActiveLevel];
  SendNeumannBoundData = MSendNeumannBoundData[ActiveLevel];
  RecvNeumannBound     = MRecvNeumannBound[ActiveLevel];
  RecvNeumannBoundData = MRecvNeumannBoundData[ActiveLevel];
  myBase               = MmyBase[ActiveLevel];

  blist* temp_list;
  DVector_blink *temp_vectlist;
  int data;

  for(int Proc=0;Proc<nProcs;Proc++)
  {
    for(temp_list=myBase->get_neighlist()->get_first(),
	  temp_vectlist=SendNeumannBoundData->get_first();
	temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list),
		    temp_vectlist=SendNeumannBoundData->get_next(temp_vectlist))
    {
      if(temp_vectlist)
      {
	if(temp_list->neigh==Proc+1)
	{
	  Ptr=temp_vectlist->ptr;
	  if(Ptr)
	  {
	    data=Ptr->GetLen();
	    MyCom->Send(temp_list->neigh,data);
	  } else {
	      Prot<<"???? Ptr==0  MyProcID "<<MyProcID<<"\n";
	      protocol << progname << " (process " << MyProcID << "):\n"
		       << "  Error in Task::CommunicateNeumann: Ptr == 0\n";
	  }
	}
      } else {
	  Prot<<"???? Communicate temp_vectlist==0 MyProcID "<<MyProcID<<"\n";
	  protocol << progname << " (process " << MyProcID << "):\n"
		   << "  Error in Task::CommunicateNeumann: temp_vectlist==0\n";
      }
    }


    for(temp_list=myBase->get_neighlist()->get_first();
	temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
    {
      if(MyProcID==Proc)
      {
	MyCom->Recieve(temp_list->neigh,&data);
	MyCom->Sync(temp_list->neigh);
	len[temp_list->neigh]=data;
      }
    }

    for(temp_list=myBase->get_neighlist()->get_first(),
	  temp_vectlist=SendNeumannBoundData->get_first();
	temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list),
		    temp_vectlist=SendNeumannBoundData->get_next(temp_vectlist))
    {
      if(temp_vectlist)
      {
	if(temp_list->neigh==Proc+1)
	{
	  Ptr=temp_vectlist->ptr;
	  if(Ptr)
	  {
	    MyCom->Send(temp_list->neigh,Ptr);
	  } else
	      Prot<<"???? Ptr==0  MyProcID "<<MyProcID<<"\n";
	}
      } else
	  Prot<<"???? Neumann temp_vectlist==0 MyProcID "<<MyProcID<<"\n";
    }

    for(temp_list=myBase->get_neighlist()->get_first(),
	  temp_vectlist=RecvNeumannBoundData->get_first();
	temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list),
		    temp_vectlist=RecvNeumannBoundData->get_next(temp_vectlist))
    {
      if(temp_vectlist)
      {
	if(MyProcID==Proc)
	{
	  Ptr=new DoubleVector(len[temp_list->neigh]);
	  MyCom->Recieve(temp_list->neigh,Ptr);
	  MyCom->Sync(temp_list->neigh);
	  if(Ptr) {
	    SetBoundData(Ptr,temp_vectlist->ptr);
	    delete Ptr;
	  } else
	      Prot<<"!!!! Ptr==0  Data from "<<temp_list->neigh<<" MyProcID "<<MyProcID<<"\n";
	}
      } else
	  Prot<<"???? RecvNeumannBoundData temp_vectlist==0 MyProcID "<<MyProcID<<"\n";
    }
  }
}


//  void Task::CommunicateSP(DOUBLE& temp)
//  {
//    int i,j,len,index;
//    DOUBLE sum=temp;
//    DoubleArray2D *ptr;

//    if(MyProcID+1!=MASTER)
//    {
//      if(MyProcID+1<nProcs) {
//        MyCom->RecieveBackward(MyProcID+1,&sum);
//        sum+=temp;
//      //      Err<<"MyProcID="<<MyProcID<<" Recieved data from "<<i<<"\n";
//      }
//      MyCom->SendForward(MyProcID,sum);
//      MyCom->SyncForward();

//  //      Err<<"MyProcID="<<MyProcID<<" Send data forward to "<<i<<"\n";

//      MyCom->RecieveForward(MyProcID,&sum);
//  //    Err<<"MyProcID="<<MyProcID<<" Recieved data from "<<MyProcID<<"\n";
//      if(MyProcID+1<nProcs)
//      {
//  	MyCom->SendBackward(MyProcID+1,sum);
//  	MyCom->SyncBackward();
//  //	Err<<"MyProcID="<<MyProcID<<" Send data backward to "<<MyProcID+1<<"\n";
//      }
//      temp=sum;
//    } else {
//      MyCom->RecieveBackward(i-1,&sum);
//      temp+=sum;
//  //	Err<<"MyProcID="<<MyProcID<<" Recieved data from "<<i-1<<"\n";

//      MyCom->SendBackward(MyProcID+1,temp);
//      MyCom->SyncBackward();
//  //    Err<<"MyProcID="<<MyProcID<<" Send data forward to "<<MyProcID+1<<"\n";
//    }
//  }


//OLD VERSION 2.12.95

void Task::CommunicateSP(DOUBLE& temp)
{
//     int i,j,len,index;
    DOUBLE sum=temp,recv=0;
//     DoubleArray2D *ptr;

  //  Prot<<"SP: temp="<<temp<<"\n";

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::CommunicateSP.\n";
	protocol.mFlush();
    }

    MPI_Allreduce(&sum,&recv,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
    temp=recv;
//  MPI_Barrier(MPI_COMM_WORLD);
    //Prot<<"SP: recv="<<recv<<"\n";


//    if(MyProcID+1!=MASTER)
//    {
//        MyCom->Send(MASTER,sum);

//        MyCom->Recieve(MASTER,&sum);
//        MyCom->Sync(MASTER);
//        //    Prot<<"SP: MyProcID="<<MyProcID<<" Recieved data="<<sum<<" from MASTER\n";
//        temp=sum;
//    } else {
//        for(i=1;i<=nProcs;i++)
//        {
//            if(i!=MASTER) {
//                MyCom->Recieve(i,&sum);
//                MyCom->Sync(i);
//                temp+=sum;
//                //	Prot<<"SP: MyProcID="<<MyProcID<<" Recieved data="<<sum<<" from "<<i-1<<"\n";
//            }
//        }
//        for(i=1;i<=nProcs;i++) {
//            MyCom->Send(i,temp);
//        }
//    }
    //MPI_Barrier(MPI_COMM_WORLD);

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CommunicateSP.\n";
	protocol.mFlush();
    }

    return;
}


void Task::CommunicateSPInfo()
{
    int i,len,send;
    DoubleArray2D *ptr;
//     DoubleArray2D *ptr2;
    DateTime SPClock;
    double ComTime = 0,SetTime = 0;

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "): Entering Task::CommunicateSPInfo.\n";
//  	protocol.mFlush();
//      }

    if(MyProcID+1 != MASTER)
    {
	ptr=GetSPInfo();
	send=ptr->GetLen();
//    Prot<<"MyProcID="<<MyProcID<<" SendForward my own data !!\n";

	SPClock.SetTime();

	MyCom->SyncSend(MASTER,send);
	MyCom->SyncSend(MASTER,ptr);
	delete ptr;

    } else {
	for(i=1;i<=NumCoarseElements;i++)
	{
	    if(i!=MASTER) {
		SPClock.SetTime();
		MyCom->SyncRecieve(i,&len);
		//	MyCom->Sync(i);
		ptr=new DoubleArray2D(3,len/3);
		MyCom->SyncRecieve(i,ptr);
		//	MyCom->Sync(i);
		ComTime+=SPClock.GetTimeDiff();

		SPClock.SetTime();
		SetSPInfo(ptr,i);
		SetTime+=SPClock.GetTimeDiff();
		delete ptr;
	    }
	}
	Prot<<"Time for spinfo-com: "<<ComTime<<" seconds\n";
	Prot<<"Time for spinfo-set: "<<SetTime<<" seconds\n";
#ifdef CONTROL_MSG
	Prot<<"\n\n SetSPInfo : \n\n";
	SPInfo->print_list();
#endif
    }

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CommunicateSPInfo.\n";
//  	protocol.mFlush();
//      }

    return;
}


void Task::CommunicateBoundInfo()
{
    int len[MAX_PROC+1];
    DoubleArray2D *Ptr[MAX_PROC+1],*Ptr2;

    blist* temp_list;
    IntArray_blink *temp_nodelist;
//   int s;
    int i;

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "): Entering Task::CommunicateBoundInfo.\n";
//  	protocol.mFlush();
//      }

    for(int Proc=0;Proc<nProcs;Proc++)
    {
	if(MyProcID!=Proc) {
	    for(temp_list=myBase->get_neighlist()->get_first(),
		    temp_nodelist=SendBound->get_first();
		temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list),
		    temp_nodelist=SendBound->get_next(temp_nodelist))
	    {
		if(temp_nodelist!=NULL)
		{
		    if(temp_list->neigh==Proc+1)
		    {
			Ptr[temp_list->neigh]=GetBoundInfo(temp_nodelist->ptr);
			if(Ptr[temp_list->neigh])
			{
			    i=Ptr[temp_list->neigh]->GetCols();
			    MyCom->SyncSend(temp_list->neigh,i);
			    //Prot<<"MyProcID="<<MyProcID<<" Send len to "<<temp_list->neigh-1<<"\n";
			} else
			    Prot<<"???? BoundInfo ptr==0 MyProcID "<<MyProcID<<" neigh="<<temp_list->neigh<<"\n";
		    }
		} else
		    Prot<<"???? BoundInfo temp_nodelist==0 neigh="<<temp_list->neigh<<" MyProcID "<<MyProcID<<"\n";
	    }
	}

	if(MyProcID==Proc)
	{

	    for(temp_list=myBase->get_neighlist()->get_first();
		temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
	    {
		MyCom->SyncRecieve(temp_list->neigh,&i);
		//Prot<<"MyProcID="<<MyProcID<<" Receive len from "<<temp_list->neigh-1<<"\n";
		//	    MyCom->Sync(temp_list->neigh);
		len[temp_list->neigh]=i;

		//	Prot<<"Got len="<<len[temp_list->neigh]<<" from "<<temp_list->neigh-1<<"\n";
	    }
	}

	if(MyProcID!=Proc) {
	    for(temp_list=myBase->get_neighlist()->get_first();
		temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
	    {
		if(Ptr[temp_list->neigh]!=NULL)
		{
		    if(temp_list->neigh==Proc+1) {
			MyCom->SyncSend(temp_list->neigh,Ptr[temp_list->neigh]);
			//Prot<<"MyProcID="<<MyProcID<<" Send array to neigh="<<temp_list->neigh-1<<"\n";
			delete Ptr[temp_list->neigh];
		    }
		}
	    }
	}


	if(MyProcID==Proc) {
	    for(temp_list=myBase->get_neighlist()->get_first();
		temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
	    {
		Ptr2=new DoubleArray2D(3,len[temp_list->neigh]);
		MyCom->SyncRecieve(temp_list->neigh,Ptr2);
		//MyCom->Sync(temp_list->neigh);
		//Prot<<"MyProcID="<<MyProcID<<" Receive array from neigh="<<temp_list->neigh-1<<"\n";
		//Prot.Flush();

		SetBoundInfo(Ptr2,temp_list->neigh);

		delete Ptr2;
	    }
	}
    }

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CommunicateBoundInfo.\n";
//  	protocol.mFlush();
//      }

    return;
}


void Task::CommunicateNeumannBoundInfo()
{
    int len[MAX_PROC+1];
    DoubleArray2D *Ptr[MAX_PROC+1],*Ptr2;

    blist* temp_list;
    IntArray_blink *temp_nodelist;
//   int s;
    int i;

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "): Entering Task::CommunicateNeumannBoundInfo.\n";
//  	protocol.mFlush();
//      }

    for(int Proc=0;Proc<nProcs;Proc++)
    {
	for(temp_list=myBase->get_neighlist()->get_first(),
		temp_nodelist=SendNeumannBound->get_first();
	    temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list),
		temp_nodelist=SendNeumannBound->get_next(temp_nodelist))
	{
	    if(temp_nodelist)
	    {
		Ptr[temp_list->neigh]=GetBoundInfo(temp_nodelist->ptr);
		if(Ptr[temp_list->neigh])
		{
		    if(temp_list->neigh==Proc+1)
		    {
			i=Ptr[temp_list->neigh]->GetCols();
			MyCom->Send(temp_list->neigh,i);
		    }
		} else
		    Prot<<"???? NeumannBoundInfo ptr==0 MyProcID "<<MyProcID<<" neigh="<<temp_list->neigh-1<<"\n";
	    } else
		Prot<<"???? NeumannBoundInfo temp_nodelist==0 MyProcID "<<MyProcID<<"\n";
	}

	for(temp_list=myBase->get_neighlist()->get_first();
	    temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
	{
	    if(MyProcID==Proc)
	    {
		MyCom->Recieve(temp_list->neigh,&i);
		MyCom->Sync(temp_list->neigh);
		len[temp_list->neigh]=i;
	    }
	}

	for(temp_list=myBase->get_neighlist()->get_first();
	    temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
	{
	    if(Ptr[temp_list->neigh])
	    {
		if(temp_list->neigh==Proc+1)
		    MyCom->Send(temp_list->neigh,Ptr[temp_list->neigh]);
	    }
	}

	for(temp_list=myBase->get_neighlist()->get_first();
	    temp_list;temp_list=myBase->get_neighlist()->get_next(temp_list))
	{
	    if(MyProcID==Proc)
	    {
		Ptr2=new DoubleArray2D(3,len[temp_list->neigh]);
		MyCom->Recieve(temp_list->neigh,Ptr2);
		MyCom->Sync(temp_list->neigh);

		SetNeumannBoundInfo(Ptr2,temp_list->neigh);

		delete Ptr2;
		delete Ptr[temp_list->neigh];
	    }
	}
    }

//      if (Debug) {
//  	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CommunicateNeumannBoundInfo.\n";
//  	protocol.mFlush();
//      }

    return;
}

void Task::CommunicateElemBoundInfo()
{
    int len[MAX_PROC+1];
    DoubleArray2D *Ptr[MAX_PROC+1],*Ptr2;

    elemlist* temp_list;
    // Mit myElemBase->get_neighlist() erhaelt man eine unsortierte Liste derjenigen Prozesse, mit
    // denen kommuniziert wird. Die Ziffer temp_list->neigh gibt die Prozessnummer an, angefangen bei 1 (!)
    // Die Prozesse werden vom System jedoch von 0 an gezaehlt (MyProcID >= 0)!

    IntArray_blink *temp_nodelist,*temp_nodelist2;
//   int s;
    int i;

    if (Debug) {
      protocol << "DEBUG(" << MyProcID << "): Entering Task::CommunicateElemBoundInfo.\n";
      protocol.mFlush();
    }

    for (i=0; i<=MAX_PROC; i++) {
	len[i] = 0;
    }

    for(int Proc=0;Proc<nProcs;Proc++)
    {
	if(MyProcID!=Proc) {
	    for(temp_list=myElemBase->get_neighlist()->get_first(),
		    temp_nodelist=SendElemBound->get_first(),
		    temp_nodelist2=SendFaceBound->get_first();
		temp_list;temp_list=myElemBase->get_neighlist()->get_next(temp_list),
		    temp_nodelist=SendElemBound->get_next(temp_nodelist),
		    temp_nodelist2=SendFaceBound->get_next(temp_nodelist2))
	    {
		if(temp_nodelist)
		{
		    if(temp_list->neigh==Proc+1)
		    {
// protocol << "MyProcID=" << MyProcID << " Arraygroesse: " << temp_nodelist->ptr->GetLen() << "\n";
			Ptr[temp_list->neigh]=GetElemBoundInfo(temp_nodelist->ptr,temp_nodelist2->ptr);
			if(Ptr[temp_list->neigh])
			{
			    i=Ptr[temp_list->neigh]->GetCols();
			    MyCom->SyncSend(temp_list->neigh,i);
// protocol << "MyProcID=" << MyProcID << " Send len of size " << i << " to " << temp_list->neigh - 1 << "\n";
// if (i > 1e3) {
//      protocol << "TREFFER!!!!\n";
// }
			    //	    Prot<<"MyProcID="<<MyProcID<<" Send len to "<<temp_list->neigh-1<<"\n";
			} else
			    Prot<<"???? ElemBoundInfo ptr==0 MyProcID "<<MyProcID<<" neigh="<<temp_list->neigh-1<<"\n";
		    }
		} else
		    Prot<<"???? ElemBoundInfo temp_nodelist==0 MyProcID "<<MyProcID<<"\n";
	    }
	}

	if(MyProcID==Proc) {
	    for(temp_list=myElemBase->get_neighlist()->get_first();
		temp_list;temp_list=myElemBase->get_neighlist()->get_next(temp_list))
	    {

// protocol << "MyProcID=" << MyProcID << " Wait for len from " << temp_list->neigh - 1 << "\n";
		//	Prot<<"MyProcID="<<MyProcID<<" Wait for len from "<<temp_list->neigh-1<<"\n";

		MyCom->SyncRecieve(temp_list->neigh,&i);
		//	  MyCom->Sync(temp_list->neigh);
		len[temp_list->neigh]=i;

// protocol <<"Got len=" << len[temp_list->neigh] << " from " << temp_list->neigh - 1 << "\n";
		//	Prot<<"Got len="<<len[temp_list->neigh]<<" from "<<temp_list->neigh-1<<"\n";
	    }
	}

	if(MyProcID!=Proc) {
	    for(temp_list=myElemBase->get_neighlist()->get_first();
		temp_list;temp_list=myElemBase->get_neighlist()->get_next(temp_list))
	    {
		if(Ptr[temp_list->neigh])
		{
		    if(temp_list->neigh==Proc+1)
		    {
// protocol << "Tracing: Process " << MyProcID << " is sending data to node " << temp_list->neigh - 1<< "\n"
//          << "Tracing:     length 3 x " << Ptr[temp_list->neigh]->GetCols() << "(" << temp_list->neigh - 1<< ")\n";
			MyCom->SyncSend(temp_list->neigh,Ptr[temp_list->neigh]);
			delete Ptr[temp_list->neigh];
// protocol << "Tracing: After SyncSend to process " << temp_list->neigh - 1<< "\n";
		    }
		}
	    }
	}

        if(MyProcID==Proc) {
            for(temp_list=myElemBase->get_neighlist()->get_first();
                temp_list;temp_list=myElemBase->get_neighlist()->get_next(temp_list))
            {
// protocol << "Tracing: Process " << MyProcID << " is receiving data from node " << temp_list->neigh-1 << "\n"
//          << "Tracing:     length 3 x " << len[temp_list->neigh] << "\n";
//if (temp_list->neigh != 256) {
                Ptr2=new DoubleArray2D(3,len[temp_list->neigh]);

// protocol << "Tracing: Before SyncRecieve from process " << temp_list->neigh-1 << "\n";
// protocol << "Tracing:     We've reserved memory of size " << Ptr2->GetCols() << " to store data.\n";
                MyCom->SyncRecieve(temp_list->neigh,Ptr2);
                //        MyCom->Sync(temp_list->neigh);
// protocol << "Tracing: After SyncRecieve from process " << temp_list->neigh-1 << "\n";

                //Prot<<"Ptr2=\n"<<*Ptr2<<"\n";
                SetElemBoundInfo(Ptr2,temp_list->neigh);
// protocol << "Tracing: After SetElemBoundInfo for process " << temp_list->neigh-1 << "\n";

                delete Ptr2;
//}
            }
        }
    }

    if (Debug) {
      protocol << "DEBUG(" << MyProcID << "):  Leaving Task::CommunicateElemBoundInfo.\n";
      protocol.mFlush();
    }

    return;
}

int Task::GetNodeType(int a, int& numneigh)
{

    blink *temp=MInfoList[ActiveLevel+1]->find_node(a);

    if(temp) {
        numneigh=temp->numneigh;
        return temp->type;
    }

    numneigh = 0;
    return REAL_BOUND;
}

int Task::GetNodeType(int a)
{
  int type=(*MFaceInfo[ActiveLevel])(a);

  if(type==0 || type==NEUMANN_BOUND)
    return REAL_BOUND;
  else
    return type;

//    blink *temp=MmyBase[ActiveLevel]->find_node(a);


//    if(temp)
//    {
//      return temp->type;
//    }
//    return REAL_BOUND;
}

int Task::GetNodeTypeSmooth(int a)
{
  int type=(*MFaceInfo[ActiveLevel])(a);

  if(type==0)
    return ART_BOUND;
  else
    return REAL_BOUND;


//    blink *temp=MmyBase[ActiveLevel]->find_node(a);


//    if(temp)
//    {
//      return temp->type;
//    }
//    return REAL_BOUND;
}

int Task::GetElemTypeSmooth(int a)
{
  IntArray *arr=MElemInfo[ActiveLevel];
  int type=(*arr)(a);

  if(type==0)
    return ART_BOUND;
  else
    return REAL_BOUND;
}

int Task::GetNeuNodeType(int a)
{
  int type=(*MFaceInfo[ActiveLevel])(a);

  if(type==0)
    return REAL_BOUND;
  else {
    return type;
  }

//    blink *temp=MmyBase[ActiveLevel]->find_node(a);


//    if(temp)
//    {
//      return temp->type;
//    }
//    return REAL_BOUND;
}

int Task::GetKonRealNodeType(int a)
{
  blink *temp=Mkonreal_nodeBase[ActiveLevel]->find_node(a);

  if(temp)
    return temp->type;
  return NOT_FOUND;
}


int Task::GetKonNodeType(int a)
{
  blink *temp=Mkonreal_nodeBase[ActiveLevel]->find_node(a);

  if(temp)
    return temp->type;
  return ART_BOUND;
}

int Task::GetNodeTypeCoarse(int a)
{
  int type=(*MFaceInfo[ActiveLevel-1])(a);

  if(type==0)
    return REAL_BOUND;
  else
    return type;


//    blink *temp=MmyBase[ActiveLevel-1]->find_node(a);


//    if(temp)
//    {
//      return temp->type;
//    }

//    return REAL_BOUND;
}

double Task::l2norm(DoubleVector *x)
{
    return sqrt(((ParVector*)x)->ScalProd(*x,this));
}

double Task::constl2norm(DoubleVector *x)
{
    return sqrt(((ParVector*)x)->ConstScalProd(*x,this));
}

void Task::Filter(DoubleVector *x)
{
    ParVector mean(x->GetLen());
    DOUBLE rmean;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::ConstFilter.\n";
	protocol.mFlush();
    }

    mean = 1.0;
    rmean = mean.ScalProd(*x, this);
    rmean /= GetGlobalDOF();

    for (int IEQ = 1; IEQ <= x->GetLen(); IEQ++)
	(*x)(IEQ) -= rmean;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::Filter.\n";
	protocol.mFlush();
    }

    return;
}

void Task::ConstFilter(DoubleVector *x)
{
    ParVector mean(x->GetLen());
    DOUBLE rmean;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::ConstFilter.\n";
	protocol.mFlush();
    }

    mean = 1.0;
    rmean = mean.ConstScalProd(*x, this);
    rmean /= GetConstGlobalDOF();

    for (int IEQ = 1; IEQ <= x->GetLen(); IEQ++)
	(*x)(IEQ) -= rmean;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::ConstFilter.\n";
	protocol.mFlush();
    }

    return;
}


void Task::SetFaceInfo(int level)
{
    blist *node_list;
    blink *p;
    IntArray* arr = new IntArray(MTotNumFaces[level]);
     MFaceInfo[level] = arr;
    *MFaceInfo[level] = 0;
//   int iel,iar,iat;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::SetFaceInfo.\n";
	protocol.mFlush();
    }

    // Generate list of articial boundary faces.
    for (node_list = MmyBase[level]->get_neighlist()->get_first();
	node_list; node_list = MmyBase[level]->get_neighlist()->get_next(node_list)) {
	for (p = node_list->base->get_first(); p; p = node_list->base->get_next(p)) {
	    (*arr)(p->node) = p->type;
	}
    }

    // Generate list of real boundary faces on the Neumann boundary.
    for (p = real_nodeBase->get_first(); p; p = real_nodeBase->get_next(p)) {
	if (p->type == NEUMANN_BOUND)
	    (*arr)(p->node) = NEUMANN_BOUND;
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::SetFaceInfo.\n";
	protocol.mFlush();
    }

    return;
}


void Task::SetElemInfo(int level)
{
    elemlist *node_list;
    elemlink *p;
    IntArray* arr=new IntArray(MNumElements[level]);
    MElemInfo[level]=arr;
    *MElemInfo[level]=0;
//   int iel,iar,iat;

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "): Entering Task::SetElemInfo.\n";
	protocol.mFlush();
    }

    for(node_list=MmyElemBase[level]->get_neighlist()->get_first();
	node_list;node_list=MmyElemBase[level]->get_neighlist()->get_next(node_list))
    {
	for(p=node_list->base->get_first();p;p=node_list->base->get_next(p))
	{
	    (*arr)(p->elem)=1;
	}
    }

    if (Debug) {
	protocol << "DEBUG(" << MyProcID << "):  Leaving Task::SetElemInfo.\n";
	protocol.mFlush();
    }

    return;
}
