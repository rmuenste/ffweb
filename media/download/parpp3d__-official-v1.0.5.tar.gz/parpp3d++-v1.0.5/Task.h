#ifndef TASKH

#define TASKH

#define TIMESTEP_HAS_BEEN_TOO_LARGE 1

#include <limits.h>
#include <LinLib.h>
#include <SquareGrid_3D.h>
#include <TrilinearElement_3D.h>
#include <RotatedElement_3D.h>
#include <ConstantElement_3D.h>
#include <ParFiniteElement_3D.h>
#include "FeatDomainBound.h"
#include <cmath>
#include <cctype>
#include "ParVector.h"
#include "String.h"
//#include "PerformInfo.h"
#include "Const.h"
#include <string>                                 // for string class
#include <iomanip>                              // for setw, setfill, scientific etc.
#include "Errorcodes.h"				  // for error codes
#include <typecasts.h>				  // for int_to_string, double_to_string

extern std::string progname;
//extern PerformInfo Perform;
extern int MyProcID,nProcs;


class Task:public FeatDomainBound
{
private:
    MComTool *MyCom;
    double   GlobalDOF;
    double   ConstGlobalDOF;

    unsigned nr_digits,first_step,nr_files;
    char line[200],aString[20];
    char format[40];
    char end_string[40];
    char *fileseq,*file;

// global variable for benchmark problem
//      double dfw,daw; // lift and drag forces
    double dnu;     // viscosity

// for postprocess
    int presselem1,presselem2; 
    int PressElem[4];
    int PressElem2[4];

    // variables for computing drag / lift coefficients
    int       NumDragBound, NumDragBound2;
    IntArray *DragBound;
    IntArray *ElemDragBound;
    // The three following arrays are not necessary, actually, because
    // they are (until now, March 2000) only queried on the finest
    // multigrid level (i.e. MaxLevel)
    int       MNumDragBound[10];
    IntArray *MDragBound[10];
    IntArray *MElemDragBound[10];
    int       MNumDragBound2[10];		  // for a second drag/lift computation
    IntArray *MDragBound2[10];
    IntArray *MElemDragBound2[10];

public:
    Task(Daten *mParam);
    ~Task(void);

// main-loop
    void       *Run(void);
    void        Test(void);

    int         ParMultiRefine(const char* grid);
    void        InitMatrices(void);
//     void     SetDirNames(double h, double k);
    void        Communicate(void);
    void        CommunicateElem(void);
    void        CommunicateNeumann(void);
    void        CommunicateSP(double& temp);
    void        CommunicateBoundInfo(void);
    void        CommunicateElemBoundInfo(void);
    void        CommunicateNeumannBoundInfo(void);
    void        CommunicateSPInfo(void);

    void        CommunicateExact(DoubleVector *v);
    void        CommunicateConstExact(DoubleVector *v);
    void        CommunicateUpwind(DoubleVector *v1,DoubleVector *v2,DoubleVector *v3);
    void        CommunicateProlRest(DoubleVector *x);
    int         StopCriterion(double newDefect, double epsDefect);
    int         StopCriterion(double newDefect, double oldDefect, double change,
			      double epsDefect, double dampingRate, double epsChange);

    double      l2norm(DoubleVector *x);
    double      constl2norm(DoubleVector *x);
    void        Filter(DoubleVector *x);
    void        ConstFilter(DoubleVector *x);

    void        SetCoeffInfo(int level);

    void        SetDragLiftInfo(IntArray2D *DragLiftInfo);
    void        CalcLiftDrag(DoubleVector *sol1, DoubleVector *sol2, DoubleVector *sol3, DoubleVector *p,
                             FiniteElement_3D *elem, 
			     double& dfw1, double& daw1, double& dfw2, double& daw2);

    void        CheckBound(double dnu,double& dpf1,double& dpf2);

    int         TestNeumann(int node);
    int         TestNeumannMid(int node,int node1,int node2,int node3,int node4);

    void        SetFaceInfo(int level);
    void        SetElemInfo(int level);
    int         GetNodeType(int a,int& numneigh);
    int         GetNodeType(int a);
    int         GetNodeTypeSmooth(int a);
    int         GetElemTypeSmooth(int a);
    int         GetNeuNodeType(int a);
    int         GetNodeTypeCoarse(int a);
    int         GetKonNodeType(int a);
    int         GetKonRealNodeType(int a);
    double      GetGlobalDOF(void) {return GlobalDOF;}
    double      GetConstGlobalDOF(void) {return ConstGlobalDOF;}

    void        SetCElemInfo(DoubleVector *M);
    void        CVectMult(DoubleCompactMatrix *C,DoubleVector& x,DoubleVector& f,double& T);
    void        ConToRot(DoubleVector *vect1,
                         DoubleVector *vect2,unsigned int level);
    void        RotToCon(DoubleVector *vect1,
                         DoubleVector *vect2,unsigned int level);

    void        SetMGBurgers();
    void        SetMGPressure();


    void        PreSmooth (MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB, 
			   unsigned int Steps, double AMin, double AMax); 
    void        PostSmooth(MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB,
			   unsigned int Steps, double AMin, double AMax); 
    void        MultiPreSmooth (MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB,  
				unsigned int Steps); 
    void        MultiPostSmooth(MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB, 
                                unsigned int Steps); 
    void        ConstPreSmooth (MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB,
				unsigned int Steps); 
    void        ConstPostSmooth(MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB, 
                                unsigned int Steps); 

    void        ExactSol(MultiCompactMatrix* A, DoubleVector *LX, DoubleVector *LB);
    void        UpdateDiagonal();
    void        ConstUpdateDiagonal();
    void        NeumannUpdateDiagonal();
    void        InitILU(MultiCompactMatrix* A);
    void        ILU(MultiCompactMatrix* A,DoubleVector **D,double alpha);

    double      MaxError(DoubleVector *x,double& PosX,double& PosY);
    void        CalcAspectRatio();
    void        CalcAnisotropyDegree();
    void        CalcVolumes();

// for post-process
    void           CommunicatePostProcessInfo();
    DoubleArray2D* GetPostProcInfo(int level);
    void           OutputVector(DoubleVector *ptr,int level);
    void           CommunicatePostProcessInfoConst();
    DoubleArray2D* GetPostProcInfoConst(int level);
    void           OutputConstVector(DoubleVector *ptr,int level);

    void           CoeffA1(void)    { Coeff    = COEFFA1; }
    void           CoeffA2(void)    { Coeff    = COEFFA2; }
    void           CoeffA3(void)    { Coeff    = COEFFA3; }
    void           CoeffA4(void)    { Coeff    = COEFFA4; }
    void           CoeffM(void)     { Coeff    = COEFFM; }
    void           CoeffP1(void)    { Coeff    = COEFFP1; }
    void           CoeffP2(void)    { Coeff    = COEFFP2; }
    void           CoeffN(void)     { Coeff    = COEFFN; }
    void           CoeffRHS(void)   { CoeffRhs = COEFF_RHS; }
    void           CoeffRHSV1(void) { CoeffRhs = COEFF_RHSV1; }
    void           CoeffRHSV2(void) { CoeffRhs = COEFF_RHSV2; }
    void           CoeffRHSV3(void) { CoeffRhs = COEFF_RHSV3; }
    void           CoeffL2(void)    { CoeffRhs = COEFF_L2; }
    void           CoeffL2V1(void)  { CoeffRhs = COEFF_L2V1; }
    void           CoeffL2V2(void)  { CoeffRhs = COEFF_L2V2; }
    void           CoeffL2V3(void)  { CoeffRhs = COEFF_L2V3; }

    void           UpWind(DoubleCompactMatrix& LA,DoubleVector& u1,
			  DoubleVector& u2,DoubleVector& u3,
			  double UPSAM);
    void           UpWind(FiniteElement_3D& Elem,MultiCompactMatrix& A,
			  DoubleVector& u1,
			  DoubleVector& u2,DoubleVector& u3,
			  double UPSAM);

    void           IntpolNonToKon(DoubleVector *u1,DoubleVector *u2,
				  DoubleVector *u3,DoubleVector *u4,DoubleVector *u5,
				  DoubleVector *v1,DoubleVector *v2,
				  DoubleVector *v3,DoubleVector *v4,DoubleVector *v5,
				  int Level);
    void           IntpolConToKon(DoubleVector& p,DoubleVector& lp);
#ifdef INCLUDE_VORTICITY
    void           Vorticity     (DoubleVector& u1,DoubleVector& u2,DoubleVector& u3,
				  DoubleVector& px,DoubleVector& py,DoubleVector& pz,
				  double a1);
#endif

    void           AVSGridOutput(int level);
    void           AVSOutput(DoubleVector *sol1, DoubleVector *sol2, DoubleVector *sol3,
			     DoubleVector *p,    DoubleVector *conc, ParFiniteElement_3D *elem,
			     int level,          unsigned int ITE);
    void           AVSSurfaceGrid();
    void           WriteGrid(const char* name, int level);

    void           GMVGridOutput(int level);
    void           GMVOutput    (DoubleVector *sol1, DoubleVector *sol2, DoubleVector *sol3,
				 DoubleVector *p,    DoubleVector *conc, ParFiniteElement_3D *elem,
				 int level,          unsigned int ITE,   double time);


    char          *get_filename(int num);
    void           get_seq();
    void           WriteSolVector(unsigned int ITE,int level,ParFiniteElement_3D *elem);
    void           ReadSolVector(int level,ParFiniteElement_3D *elem);

    void           ReadSolution (double& DTime, double& Dt);
    void           WriteSolution(const unsigned int currentSolFileNr, const double DTime, const double Dt);

#ifdef INCLUDE_TEMPERATURE
    void           WriteSolutionBouss(double DTime,double Dt,int ITE);
    void           ReadSolutionBouss(double& DTime,double& Dt);
#endif
    void           ReadCoarseSolution(double& DTime,double& Dt,ParFiniteElement_3D *elem,
				      FiniteElement_3D *conelem);
    void           Info();
    void           CleanUp();
    void           PostProcess(DoubleVector *p,double time);

    void           BoundaryProjection();

    void           Build_B(MultiRectMatrix& B1,MultiRectMatrix& B2,
			   MultiRectMatrix& B3,
			   MultiCompactMatrix& A);
    void           B_Mult(DoubleVector& p,DoubleVector& f1,DoubleVector& f2,
			  DoubleVector& f3,double a1,double a2);
    void           BT_Mult(DoubleVector& u1,DoubleVector& u2,DoubleVector& u3,
			   DoubleVector& p,double a1);
    void           BuildProjMatrix(MultiCompactMatrix& C,MultiVector& M,
				   MultiRectMatrix& B1,MultiRectMatrix& B2,
				   MultiRectMatrix& B3);
    MultiCompactMatrix *GetProjMatrix();
    MultiVector        *GetLumpedMassMat(MultiCompactMatrix& M);
    MultiVector        *GetPureLumpedMassMat(MultiCompactMatrix& M);

    double         L2NormDiff(DoubleVector& vnew, DoubleVector& vold); 
    double         L2Norm    (DoubleVector& vnew); 
    double         Norm      (DoubleVector& vnew, DoubleVector& vold, int NEQ); 
    double         Divergenz (DoubleVector *v1, DoubleVector *v2, DoubleVector *v3); 
    void           L2Projection(ParFiniteElement_3D& Elem, DoubleVector* LumpM, 
				DoubleVector*& vnew, unsigned int ICUB); 
    void           L2ProjectionNonLinear(ParFiniteElement_3D& Elem,
					 DoubleCompactMatrix* M,
					 DoubleVector*& vnew1, DoubleVector*& vnew2,
					 double EpsCG, double OmegaCG,
					 unsigned int MaxItCG, unsigned int ICUB);

    void CalcChorMatrixStart(ParFiniteElement_3D& RotElem,
			     MultiCompactMatrix *A,
			     MultiCompactMatrix *M,
			     MultiVector        *LumpM,
			     MultiVector        *PureLumpM,
			     DoubleVector       *vold1,
			     DoubleVector       *vold2,
			     DoubleVector       *vold3,
			     DoubleVector       *P,
			     DoubleVector       *f1,
			     DoubleVector       *f2,
			     DoubleVector       *f3,
			     double             k);
    void CalcChorMatrix(ParFiniteElement_3D& RotElem,
			MultiCompactMatrix *A,
			MultiCompactMatrix *M,
			MultiVector        *LumpM,
			MultiVector        *PureLumpM,
			DoubleVector       *vold1,
			DoubleVector       *vold2,
			DoubleVector       *vold3,
			DoubleVector       *P,
			DoubleVector       *f1,
			DoubleVector       *f2,
			DoubleVector       *f3,
			double             k);
    void CalcFracMatrixStart(ParFiniteElement_3D& RotElem,
			     MultiCompactMatrix *A,
			     MultiCompactMatrix *M,
			     MultiVector        *LumpM,
			     MultiVector        *PureLumpM,
			     DoubleVector       *vold1,
			     DoubleVector       *vold2,
			     DoubleVector       *vold3,
			     DoubleVector       *P,
			     DoubleVector       *f1,
			     DoubleVector       *f2,
			     DoubleVector       *f3,
			     double             theta1,
			     double             theta2,
			     double             theta3,
			     double             theta4);
    void CalcFracMatrix(ParFiniteElement_3D& RotElem,
			MultiCompactMatrix *A,
			MultiCompactMatrix *M,
			MultiVector        *LumpM,
			MultiVector        *PureLumpM,
			DoubleVector       *vold1,
			DoubleVector       *vold2,
			DoubleVector       *vold3,
			DoubleVector       *P,
			DoubleVector       *f1,
			DoubleVector       *f2,
			DoubleVector       *f3,
			double             theta1,
			double             theta2,
			double             theta3,
			double             theta4);
#ifdef INCLUDE_TEMPERATURE
    void CalcBoussMatrixStart(ParFiniteElement_3D& RotElem,
			      MultiCompactMatrix *A,
			      MultiCompactMatrix *M,
			      MultiVector        *PureLumpM,
			      DoubleVector       *vold1,
			      DoubleVector       *vold2,
			      DoubleVector       *vold3,
			      DoubleVector       *Conc,
			      DoubleVector       *f1,
			      double             theta1,
			      double             theta2,
			      double             theta3,
			      double             theta4);
#endif
    void Chorin    (ParFiniteElement_3D& RotElem, FiniteElement_3D& ConElem,
		    MultiCompactMatrix *A,
		    MultiCompactMatrix *M,
		    MultiCompactMatrix *C,
		    MultiVector  *LumpM,
		    MultiVector  *PureLumpM,
		    DoubleVector *vold1,   DoubleVector *vold2,   DoubleVector *vold3, DoubleVector *P,
		    DoubleVector *f1,      DoubleVector *f2,      DoubleVector *f3,
		    DoubleVector *defect1, DoubleVector *defect2, DoubleVector *defect3,
		    DoubleVector *w1,
		    DoubleVector *neumann1,
		    DoubleVector *q,
		    double        Dt);
    void Fractional(ParFiniteElement_3D& RotElem, FiniteElement_3D& ConElem,
		    MultiCompactMatrix *A,
		    MultiCompactMatrix *M,
		    MultiCompactMatrix *C,
		    MultiVector        *LumpM,
		    MultiVector        *PureLumpM,
		    DoubleVector *vold1,   DoubleVector *vold2,   DoubleVector *vold3, DoubleVector *P,
		    DoubleVector *f1,      DoubleVector *f2,      DoubleVector *f3,
		    DoubleVector *defect1, DoubleVector *defect2, DoubleVector *defect3,
		    DoubleVector       *w1,
		    DoubleVector       *neumann1,
		    DoubleVector       *q,
		    const double       K);
    void CrankNicolson(ParFiniteElement_3D& RotElem,
                       FiniteElement_3D& ConElem,
                       MultiCompactMatrix *A,
                       MultiCompactMatrix *M,
                       MultiCompactMatrix *C,
                       MultiVector        *LumpM,
                       MultiVector        *PureLumpM,
		       DoubleVector *vold1,   DoubleVector *vold2,   DoubleVector *vold3, DoubleVector *P,
		       DoubleVector *f1,      DoubleVector *f2,      DoubleVector *f3,
		       DoubleVector *defect1, DoubleVector *defect2, DoubleVector *defect3,
                       DoubleVector       *w1,
                       DoubleVector       *neumann1,
                       DoubleVector       *q,
		       const double       K);
//      void Chorin1(ParFiniteElement_3D& RotElem,
//                   FiniteElement_3D& ConElem,
//                   MultiCompactMatrix* A,
//                   MultiCompactMatrix* M,
//                   MultiVector* LumpM,
//                   MultiCompactMatrix* C,
//                   DoubleVector* vold1,
//                   DoubleVector* vold2,
//                   DoubleVector* vold3);
#ifdef INCLUDE_TEMPERATURE
    void Bouss(ParFiniteElement_3D& RotElem,
               MultiCompactMatrix *A,
               MultiCompactMatrix *M,
               MultiVector        *PureLumpM,
               DoubleVector       *vold1,
               DoubleVector       *vold2,
               DoubleVector       *vold3,
               DoubleVector       *Conc,
               DoubleVector       *f1,
               double             Dt);
#endif
    void DiscreteProjection(ParFiniteElement_3D& RotElem,
			    FiniteElement_3D& ConElem,
			    MultiCompactMatrix* A,
			    MultiCompactMatrix* M,
			    MultiVector* LumpM,
			    MultiVector* PureLumpM,
			    MultiCompactMatrix* C,
			    DoubleVector* vold1,
			    DoubleVector* vold2,
			    DoubleVector* vold3);
    short int ErrorControl(MultiVector* LumpM, double K, double eps, double currentTime, double endTime);
    void      PrintTimeStatistics(void);
    void LaplaceTest();
    void TestGrid();
};

#endif
