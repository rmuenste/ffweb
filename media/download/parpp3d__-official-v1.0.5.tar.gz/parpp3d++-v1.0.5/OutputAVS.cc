#include "Task.h"

void Task::AVSOutput(DoubleVector *sol1, DoubleVector *sol2, DoubleVector *sol3,
                     DoubleVector *p,    DoubleVector *conc, ParFiniteElement_3D *elem,
                     int level,          unsigned int ITE)
{
    int i, j;
    std::string filename = Param->OutputBaseDir + Param->AVSSolutionFile;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering Task::AVSOutput.\n";
        protocol.mFlush();
    }

    //  Append current timestep to filename ('t': timestep)
    filename += ".t" + int_to_string (ITE, "0", 3);

    // Append current processor id to filename ('p': processor)
    filename += ".p" + int_to_string (MyProcID, "0", 3);

    // Append avs extension
    filename += ".inp";

    // Finally get write handle for this very file...
    COutput outfile(filename.c_str(), ACTIVE);

    level = MIN(level, Param->NFine);

    // Determine the values on the current multigrid level.
    NumElements = MNumElements[level];
    NumVertices = MNumVertices[level];
    VertCoord   = MVertCoord[level];
    VertElem    = MVertElem[level];


    // Begin to fill the file.
    int fields = 4;
#ifdef INCLUDE_TEMPERATURE
    fields++;
#endif
#ifdef INCLUDE_VORTICITY
    fields+=4;
#endif

    outfile << NumVertices << " " << NumElements << " " << fields << " 0 0\n"; 
    for (i = 1; i <= NumVertices; i++)
        outfile << i <<" " << (*VertCoord)(1,i) << "  " << (*VertCoord)(2,i) << " " << (*VertCoord)(3,i) << "\n";

    for (i = 1;  i <= NumElements; i++) {
        outfile << i << " 1 hex ";
        for (j = 1;  j <= NUMOFVERT;  j++)
            outfile << " " << (*VertElem)(j,i) << " ";
        outfile << "\n";
    }

    DoubleVector *LT1[MAXARRAY];
    DoubleVector *LT2[MAXARRAY];
    DoubleVector *LT3[MAXARRAY];
    DoubleVector *LT4[MAXARRAY];
    DoubleVector *LT5[MAXARRAY];
    LT1[MaxLevel] = sol1;
    LT2[MaxLevel] = sol2;
    LT3[MaxLevel] = sol3;
    DoubleVector rot_p(TotNumFaces);
    ConToRot(p, &rot_p, MaxLevel); 
    LT4[MaxLevel] = &rot_p; 
    LT5[MaxLevel] = conc; 

//      for (int alevel = MaxLevel - 1; alevel >= level; alevel--) {
//          LT1[alevel] = new DoubleVector(MTotNumFaces[alevel]); 
//          LT2[alevel] = new DoubleVector(MTotNumFaces[alevel]); 
//          LT3[alevel] = new DoubleVector(MTotNumFaces[alevel]); 
//          LT4[alevel] = new DoubleVector(MTotNumFaces[alevel]); 
//          LT5[alevel] = new DoubleVector(MTotNumFaces[alevel]); 
//      }

//      for (int alevel = MaxLevel - 1; alevel >= level; alevel--) {
//          ActiveLevel = alevel; 
//          elem->ParRestrict(LT1[alevel+1],LT1[alevel],
//                            MVertElem[alevel+1],MVertElem[alevel],
//                            MMidFaces[alevel+1],MMidFaces[alevel],
//                            MNeighElem[alevel+1],MNeighElem[alevel],
//                            MNumVertices[alevel+1],MNumVertices[alevel],
//                            MNumElements[alevel+1],MNumElements[alevel],
//                            this);
//          elem->ParRestrict(LT2[alevel+1],LT2[alevel],
//                            MVertElem[alevel+1],MVertElem[alevel],
//                            MMidFaces[alevel+1],MMidFaces[alevel],
//                            MNeighElem[alevel+1],MNeighElem[alevel],
//                            MNumVertices[alevel+1],MNumVertices[alevel],
//                            MNumElements[alevel+1],MNumElements[alevel],
//                            this);
//          elem->ParRestrict(LT3[alevel+1],LT3[alevel],
//                            MVertElem[alevel+1],MVertElem[alevel],
//                            MMidFaces[alevel+1],MMidFaces[alevel],
//                            MNeighElem[alevel+1],MNeighElem[alevel],
//                            MNumVertices[alevel+1],MNumVertices[alevel],
//                            MNumElements[alevel+1],MNumElements[alevel],
//                            this);
//          elem->ParRestrict(LT4[alevel+1],LT4[alevel],
//                            MVertElem[alevel+1],MVertElem[alevel],
//                            MMidFaces[alevel+1],MMidFaces[alevel],
//                            MNeighElem[alevel+1],MNeighElem[alevel],
//                            MNumVertices[alevel+1],MNumVertices[alevel],
//                            MNumElements[alevel+1],MNumElements[alevel],
//                            this);
//          elem->ParRestrict(LT5[alevel+1],LT5[alevel],
//                            MVertElem[alevel+1],MVertElem[alevel],
//                            MMidFaces[alevel+1],MMidFaces[alevel],
//                            MNeighElem[alevel+1],MNeighElem[alevel],
//                            MNumVertices[alevel+1],MNumVertices[alevel],
//                            MNumElements[alevel+1],MNumElements[alevel],
//                            this);
//      }

//      DoubleVector v1(NumVertices);
//      DoubleVector v2(NumVertices);
//      DoubleVector v3(NumVertices);
//      DoubleVector v4(NumVertices);
//      DoubleVector v5(NumVertices);
//      SetLevel(level);
//      IntpolNonToKon(LT1[level],LT2[level],LT3[level],LT4[level],LT5[level],&v1,&v2,&v3,&v4,&v5,level);

//      for (int alevel = MaxLevel - 1; alevel >= level; alevel--) {
//          delete LT1[alevel];
//          delete LT2[alevel];
//          delete LT3[alevel];
//          delete LT4[alevel];
//          delete LT5[alevel];
//      }

    // Interpolate non-conforme solution to conform.
    DoubleVector v1(MNumVertices[MaxLevel]);      // velocity in x direction
    DoubleVector v2(MNumVertices[MaxLevel]);      // velocity in y direction
    DoubleVector v3(MNumVertices[MaxLevel]);      // velocity in z direction
    DoubleVector v4(MNumVertices[MaxLevel]);      // pressure
    DoubleVector v5(MNumVertices[MaxLevel]);      // temperature

    SetLevel(MaxLevel);
    IntpolNonToKon(LT1[MaxLevel], LT2[MaxLevel], LT3[MaxLevel], LT4[MaxLevel], LT5[MaxLevel], &v1, &v2, &v3, &v4, &v5, MaxLevel);

#ifdef INCLUDE_VORTICITY
    // calculate vorticity
    DoubleVector vorx(MNumElements[MaxLevel]);
    DoubleVector vory(MNumElements[MaxLevel]);
    DoubleVector vorz(MNumElements[MaxLevel]);
    Vorticity(*sol1, *sol2, *sol3, vorx, vory, vorz, -1.);

    // some space for vorticity output fields
    DoubleVector v6(MNumVertices[MaxLevel]);      // vorx
    DoubleVector v7(MNumVertices[MaxLevel]);      // vory
    DoubleVector v8(MNumVertices[MaxLevel]);      // vorz

    SetLevel(MaxLevel);
    IntpolConToKon(vorx,v6);  // Interpolate from element to corner
    IntpolConToKon(vory,v7);	
    IntpolConToKon(vorz,v8);	
#endif


    // Back again: writing to file.
    // Determine the values on the current multigrid level.
    outfile << fields;
    for (i = 1; i <= fields; i++) {
	outfile << " 1";
    }
    outfile << "\n";

    outfile << "v1, m / s\n"; 
    outfile << "v2, m / s\n"; 
    outfile << "v3, m / s\n"; 
    outfile << "p, pa\n"; 
#ifdef INCLUDE_TEMPERATURE
    outfile << "Temp, kelvin \n"; 
#endif
#ifdef INCLUDE_VORTICITY
    outfile << "Vort_x, none\n"; 
    outfile << "Vort_y, none\n"; 
    outfile << "Vort_z, none\n"; 
    outfile << "Vort_total, none\n"; 
#endif
    for (i = 1; i <= MNumVertices[level]; i++) {
        outfile << i<<" " << v1(i) << " " << v2(i) << " " << v3(i) << " " << v4(i);
#ifdef INCLUDE_TEMPERATURE
	outfile << " " << v5(i) << "\n"; 
#endif
#ifdef INCLUDE_VORTICITY
	outfile << " " << v6(i) << " " << v7(i) << " " << v8(i) 
		<< " " << sqrt(v6(i)*v6(i) + v7(i)*v7(i) + v8(i)*v8(i)) << "\n"; 
#endif
	outfile << "\n"; 
    }
    outfile.mCloseFile();

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving Task::AVSOutput.\n";
        protocol.mFlush();
    }

    return;
}

void Task::AVSGridOutput(int level)
{
    int i, j;

//    int NumElements, NumVertices, VertCoord, VertElem;

    // Don't write a grid file with a finer grid than the maximum
    // output level.
    if (level > Param->AVSOutputLevel)
        return;

    //  String filename="/hwwt3e_tmp/rus/lhd/oswal/AVS/grid.";
    //String filename= "./991021/grid.";
    std::string filename = Param->OutputBaseDir + Param->AVSGridFile;

    // Append current processor id to filename ('p': processor)
    filename += ".p" + int_to_string (MyProcID, "0", 3) + ".inp";
    COutput outfile(filename.c_str(), ACTIVE);

    // Determine the values on the current multigrid level.
//    NumElements = MNumElements[level];
//    NumVertices = MNumVertices[level];
//    VertCoord   = MVertCoord[level];
//    VertElem    = MVertElem[level];

    outfile<<NumVertices<<" "<<NumElements<<" 0 0 0\n";
    for (i=1; i<=NumVertices; i++)
        outfile<<i<<" "<<(*VertCoord)(1,i)<<"  "<<(*VertCoord)(2,i)<<" "<<(*VertCoord)(3,i)<<"\n";

    for (i=1; i<=NumElements; i++) {
        outfile<<i<<" "<<MyProcID<<" hex ";
        for (j=1; j<=NUMOFVERT; j++)
            outfile<<" "<<(*VertElem)(j,i)<<" ";
        outfile<<"\n";
    }
    outfile.mCloseFile();

    return;
}

void Task::AVSSurfaceGrid()
{
    int i, j, k;

    int flaghalb;
    //  String filename="/hwwt3e_tmp/rus/lhd/oswal/AVS/grid.";
    std::string filename="/nfs/hwwfs1/rus/lhd/oswal/AVS/grid.";
    filename+=MyProcID;
    filename+=".inp";
    COutput outfile(filename.c_str(), ACTIVE);
    IntArray     flag(NumVertices);
    int elem=0;
//     int vert=0;

    flag=0;

    IntArray2D KIAD(4,6);
    KIAD(1,1)=1;
    KIAD(2,1)=2;
    KIAD(3,1)=3;
    KIAD(4,1)=4;
    KIAD(1,2)=1;
    KIAD(2,2)=2;
    KIAD(3,2)=6;
    KIAD(4,2)=5;
    KIAD(1,3)=2;
    KIAD(2,3)=3;
    KIAD(3,3)=7;
    KIAD(4,3)=6;
    KIAD(1,4)=3;
    KIAD(2,4)=4;
    KIAD(3,4)=8;
    KIAD(4,4)=7;
    KIAD(1,5)=4;
    KIAD(2,5)=1;
    KIAD(3,5)=5;
    KIAD(4,5)=8;
    KIAD(1,6)=5;
    KIAD(2,6)=6;
    KIAD(3,6)=7;
    KIAD(4,6)=8;

    for (i=1; i<=NumElements; i++) {
        for (j=1;j<=6;j++) {
            if ((*NeighElem)(j,i)==0) {
                flaghalb=1;
                for (k=1; k<=4; k++)
                    if ((*VertCoord)(1,(*VertElem)(KIAD(k,j),i))<0.5)
                        flaghalb = 1;
                if (flaghalb == 1) {
                    for (k=1; k<=4; k++)
                        flag(KIAD(k,j))=1;
                    elem++;
                }
            }
        }
    }

    outfile<<NumVertices<<" "<<elem<<" 0 0 0\n";
    for (i=1; i<=NumVertices; i++)
        outfile<<i<<" "<<(*VertCoord)(1,i)<<"  "<<(*VertCoord)(2,i)<<" "<<(*VertCoord)(3,i)<<"\n";

    for (i=1; i<=NumElements; i++) {
        for (j=1; j<=6; j++) {
            if ((*NeighElem)(j,i)==0) {
                flaghalb=1;
                for (k=1; k<=4; k++)
                    if ((*VertCoord)(1,(*VertElem)(KIAD(k,j),i))<0.5)
                        flaghalb=1;
                if (flaghalb==1) {
                    outfile<<i<<" "<<i<<" quad ";
                    for (k=1; k<=4; k++)
                        outfile<<" "<<(*VertElem)(KIAD(k,j),i)<<" ";
                    outfile<<"\n";
                }
            }
        }
    }

//	outfile<<"1 1\n";
//	outfile<<" , \n";
//	for (int IEQ=1;IEQ<=NumVertices;IEQ++)
//		outfile<<IEQ<<" 1.0\n";
}


void Task::WriteGrid(const char* name, int level)
{
    //  String filename="/hwwt3e_tmp/rus/lhd/oswal/AVS/feat.";
    std::string filename = name;

    // Append current processor id to filename ('p': processor)
    filename += ".p" + int_to_string (MyProcID, "0", 3);

    // Append our standard grid extension
    filename += ".tri";

    COutput gridfile(filename.c_str(), ACTIVE);

    gridfile << " Coarse mesh 3D\n"
	     << " refined and written by " << progname << "\n";
    gridfile << "  " << MNumElements[level] << " "
	     << "  " << MNumVertices[level] << " "
	     << "  " << NumBound << " "
	     << "  " << MNumVertElem[level] << " "
	     << "  " << MNumEdgeElem[level] << " "
	     << "  " << MNumFaceElem[level] << "  NEL NVT NBCT NVE NEE NAE\n";
    gridfile << "DCORVG\n";
    for (unsigned int i = 1; i <= MNumVertices[level]; i++)
        gridfile << "\t" << double_to_string((*MVertCoord[level])(1, i), "f", 16) << " "
		 << "\t" << double_to_string((*MVertCoord[level])(2, i), "f", 16) << " "
		 << "\t" << double_to_string((*MVertCoord[level])(3, i), "f", 16) << "\n";

    gridfile << "KVERT\n";
    for (unsigned int i = 1; i <= MNumElements[level]; i++) {
        for (unsigned int j = 1; j <= MNumVertElem[level]; j++)
            gridfile <<  int_to_string((*MVertElem[level])(j, i), " ", 7) << " ";
        gridfile << "\n";
    }

    gridfile << "KNPR\n";
    for (unsigned int i = 1; i <= MNumVertices[level]; i++) {
        gridfile << (*MInfoVertEdge[level])(i) << " ";
	if (!(i % 20))
	    gridfile << "\n";
    }
    gridfile << "\n";
    gridfile.mCloseFile();

    return;
}


void Task::WriteSolVector(unsigned int ITE,int level,ParFiniteElement_3D *elem)
{
    int i;
    //  String filename="/hwwt3e_tmp/rus/lhd/oswal/AVS/sol.";
    // String filename="/nfs/hwwfs1/rus/lhd/oswal/AVS/sol.";
    String filename="AVS/sol.";
    filename+="t";
    filename+=ITE;
    filename+=".";
    filename+=MyProcID;
    filename+=".inp";
    Output	  outfile(filename,YES);

    NumElements=MNumElements[level];
    TotNumFaces=MTotNumFaces[level];
    NumVertices=MNumVertices[level];
    VertCoord=MVertCoord[level];
    VertElem=MVertElem[level];


    DoubleVector *LT1[MAXARRAY];
    DoubleVector *LT2[MAXARRAY];
    DoubleVector *LT3[MAXARRAY];
    LT1[MaxLevel]=Sol1;
    LT2[MaxLevel]=Sol2;
    LT3[MaxLevel]=Sol3;
    int alevel;
    for (alevel=MaxLevel-1; alevel>=level; alevel--) {
        LT1[alevel]=new DoubleVector(MTotNumFaces[alevel]);
        LT2[alevel]=new DoubleVector(MTotNumFaces[alevel]);
        LT3[alevel]=new DoubleVector(MTotNumFaces[alevel]);
    }
    for (alevel=MaxLevel-1;alevel>=level;alevel--) {
        ActiveLevel=alevel;
        elem->ParRestrict(LT1[alevel+1],LT1[alevel],
                          MVertElem[alevel+1],MVertElem[alevel],
                          MMidFaces[alevel+1],MMidFaces[alevel],
                          MNeighElem[alevel+1],MNeighElem[alevel],
                          MNumVertices[alevel+1],MNumVertices[alevel],
                          MNumElements[alevel+1],MNumElements[alevel],
                          this);
        elem->ParRestrict(LT2[alevel+1],LT2[alevel],
                          MVertElem[alevel+1],MVertElem[alevel],
                          MMidFaces[alevel+1],MMidFaces[alevel],
                          MNeighElem[alevel+1],MNeighElem[alevel],
                          MNumVertices[alevel+1],MNumVertices[alevel],
                          MNumElements[alevel+1],MNumElements[alevel],
                          this);
        elem->ParRestrict(LT3[alevel+1],LT3[alevel],
                          MVertElem[alevel+1],MVertElem[alevel],
                          MMidFaces[alevel+1],MMidFaces[alevel],
                          MNeighElem[alevel+1],MNeighElem[alevel],
                          MNumVertices[alevel+1],MNumVertices[alevel],
                          MNumElements[alevel+1],MNumElements[alevel],
                          this);
    }

    DoubleVector *v1=LT1[level];
    DoubleVector *v2=LT2[level];
    DoubleVector *v3=LT3[level];

    for (i=1; i<=TotNumFaces; i++)
        outfile<<(*v1)(i)<<" "<<(*v2)(i)<<" "<<(*v3)(i)<<"\n";

    for (alevel=MaxLevel-1;alevel>=level;alevel--) {
        delete LT1[alevel];
        delete LT2[alevel];
        delete LT3[alevel];
    }

    return;
}
