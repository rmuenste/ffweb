#include "CCoarseGrid.h"

double PHIP(double x);
double PHIM(double x);

int  CCoarseGrid::GetMakroInfo(UNSIGNED mnum,int& pNumElements,
                               int& pNumVertices,
                               int& pNumEdges,int& pNumVertElem,
                               int& pNumEdgeElem,int& pNumFaceElem,
                               int& pNumBound,int& pNumVertBound,
                               DoubleArray2D*& pVertCoord,
                               IntArray2D*& pVertElem,
                               IntArray*& pInfoVertEdge,
                               IntArray2D*& pInfoVertBound,
                               IntArray*& pBoundInfo,node_base*& nodes,
                               blist_base*& real_b_nodes,
                               node_base*& midnodes,
                               node_base*& midneighnodes,
                               blist_base*& real_b_midnodes,
                               blist_base*& info_list,
                               int& pNumCoarseElements,
                               Daten *PParam,MComTool *MyCom)
{
    int i,iel,cutsize,facecount,count,offset,IVE,node,n,n2,j,k;
    int IEQ;
    int numneigh,numelem,iel2,vert,sum;

    Param=PParam;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::GetMakroInfo.\n";
        protocol.mFlush();
    }

    Prot<<"NumElements="<<NumElements<<"\n";
    Prot<<"NumVertices="<<NumVertices<<"\n";
    Prot<<"TotNumFaces="<<TotNumFaces<<"\n";

    if (nProcs < NumElements) {
        Refine(0,1,1,3,0,0,0,1);
        IntArray Partition(NumElements);
        IntArray Vertices(NumVertices);
        IntArray Faces(TotNumFaces);
        IntArray MapVertices(NumVertices);


        if (MyProcID + 1 == MASTER) {
	    // Shall we compute the partition information or read it?
            if (Param->PartitionCR == 0) {
		// Compute it
		protocol << " Computing partition information. "; protocol.mFlush();
		if (Debug) protocol << '\n';

		if (nProcs == 1) {
		    Partition = 0;
		    if (Debug) protocol << ' ';
		    protocol << "Done.\n"; protocol.mFlush();

		    WritePartition(Partition);
		} else {
		    // Compute number of inner faces
		    count = 0;
		    for (iel = 1;  iel <= NumElements;  iel++) {
			for (i = 1;  i <= 6;  i++) {
			    if ((*NeighElem)(i,iel) != 0)
				count++;
			}
		    }

		    // Allocate memory for structures that are filled by partition library
		    int *edge_p = new int[NumElements+1];
		    int *edge   = new int[count+1];
		    int *part   = new int[NumElements];

		    // We currently do not assign weight to edges.
//                  int *weight = new int[count+1];
//                  IntArray2D *NeighWeight = new IntArray2D(6, NumElements);
//                  *NeighWeight = -1;


		    for (iel = 1, offset = 0; iel <= NumElements; iel++) {
			edge_p[iel-1] = offset;
			for (i = 1; i <= 6; i++) {
			    int neigh = (*NeighElem)(i,iel);
			    if (neigh != 0) {
				edge[offset] = neigh - 1;

//                              // We currently do not assign weight to edges.
//                              for (j = 1; j <= 6; j++) {
//                                  if ((*NeighElem)(j,neigh) == iel) {
//                                      if ((*NeighWeight)(j,neigh) == -1) {
//                                          weight[offset] = CalcWeight(iel,neigh);
//                                          (*NeighWeight)(i,iel)   = weight[offset];
//                                          (*NeighWeight)(j,neigh) = weight[offset];
//                                      } else {
//                                          weight[offset] = (*NeighWeight)(j,neigh);
//                                      }
//                                      break;
//                                  }
//                              }
				offset++;
			    }
			}
		    }
		    edge_p[NumElements] = count;

		    // Which partition tool to use?
		    if (Param->PartitionTool == 0) {
			// use party 1.1
			float *xx, *yy, *zz;
			xx = new float[NumElements];
			yy = new float[NumElements];
			zz = new float[NumElements];

			for (iel = 1; iel <= NumElements; iel++) {
			    xx[iel-1] = 0.125 * ( (*VertCoord)(1,(*VertElem)(1,iel)) + (*VertCoord)(1,(*VertElem)(2,iel)) +
						  (*VertCoord)(1,(*VertElem)(3,iel)) + (*VertCoord)(1,(*VertElem)(4,iel)) +
						  (*VertCoord)(1,(*VertElem)(5,iel)) + (*VertCoord)(1,(*VertElem)(6,iel)) +
						  (*VertCoord)(1,(*VertElem)(7,iel)) + (*VertCoord)(1,(*VertElem)(8,iel)));
			    yy[iel-1] = 0.125 * ( (*VertCoord)(2,(*VertElem)(1,iel)) + (*VertCoord)(2,(*VertElem)(2,iel)) +
						  (*VertCoord)(2,(*VertElem)(3,iel)) + (*VertCoord)(2,(*VertElem)(4,iel)) +
						  (*VertCoord)(2,(*VertElem)(5,iel)) + (*VertCoord)(2,(*VertElem)(6,iel)) +
						  (*VertCoord)(2,(*VertElem)(7,iel)) + (*VertCoord)(2,(*VertElem)(8,iel)));
			    zz[iel-1] = 0.125 * ( (*VertCoord)(3,(*VertElem)(1,iel)) + (*VertCoord)(3,(*VertElem)(2,iel)) +
						  (*VertCoord)(3,(*VertElem)(3,iel)) + (*VertCoord)(3,(*VertElem)(4,iel)) +
						  (*VertCoord)(3,(*VertElem)(5,iel)) + (*VertCoord)(3,(*VertElem)(6,iel)) +
						  (*VertCoord)(3,(*VertElem)(7,iel)) + (*VertCoord)(3,(*VertElem)(8,iel)));
			}
			party_lib("all", "kl", 3, NumElements, NULL, xx, yy, zz, edge_p, edge, NULL,
				  nProcs, 2.0, 1, part, &cutsize, 0);

			delete xx;
			delete yy;
			delete zz;

		    } else if (Param->PartitionTool == 1  ||  Param->PartitionTool == 2) {
			// use metis-4.0
			int options[5];
			options[0] = 0;           // => use default values
			options[1] = 100;
			options[2] = 4;
			options[3] = 1;
			options[4] = 1;
			int numbering  = 0;       // c-style numbering is assumed that starts from 0
			int weightflag = 0;
			int nparts     = nProcs;  // The number of parts to partition the graph

			if (Param->PartitionTool == 1) {
			    // Partition a graph into k equal-size parts using multilevel recursive
			    // bisection. It provides the functionality of the pmetis program. The
			    // objective of the partitioning is to minimize the edgecut
			    int *edgecut   = new int[count];
			    METIS_PartGraphRecursive(&NumElements, edge_p, edge,
						     NULL, NULL, &weightflag,
						     &numbering, &nparts, options, edgecut, part);
			    delete edgecut;
			} else {
			    // Partition a graph into k equal-size parts using the multilevel k-way
			    // partitioning algorithm. The objective of the partitioning is to minimize
			    // the total communication volume.
			    int *volume = new int[count];
			    METIS_PartGraphVKway(&NumElements, edge_p, edge,
						 NULL, NULL, &weightflag,
						 &numbering, &nparts, options, volume, part);
			    delete volume;
			}
		    } else {
			// unknown partition tool
			protocol << progname << " (process " << MyProcID << "):\n"
				 << "  Unknown partition tool specified.\n"
				 << "  Program aborted.\n";
		    }

		    // Integrate partition information into our structures, write it to disk
		    // and delete unneeded partition data.
		    for (i = 1; i <= NumElements; i++) {
			Partition(i) = part[i-1];
		    }
//  		    for (i = 601; i <= NumElements; i++) {
//  			Partition(i) = part[i];
//  		    }

		    if (Debug) protocol << ' ';
		    protocol << "Done.\n Writing partition information to disk. ";
		    if (Debug) protocol << '\n';
		    protocol.mFlush();

		    WritePartition(Partition);
		    if (Debug) protocol << ' ';
		    protocol << "Done.\n"; protocol.mFlush();

		    delete edge_p;
		    delete edge;
		    delete part;

// We currently do not assign weight to edges.
//                  delete weight;
//                  delete NeighWeight;
		} // end else condition from if (nProcs == 1)

	    } else {
		// Read it from file.
		protocol << " Reading partition information. "; protocol.mFlush();
		if (Debug) protocol << '\n';
		ReadPartition(Partition);
		if (Debug) protocol << ' ';
		protocol << "Done.\n"; protocol.mFlush();
	    }


            Prot<<"Before send !!\n";
            Prot.Flush();

            for(i=1;i<=nProcs;i++)
                if(i!=MASTER)
                    MyCom->SyncSend(i,&Partition);
        } else {
            MyCom->SyncRecieve(MASTER,&Partition);
        }

        Prot<<"Before MPI_Barrier !!\n";
        Prot.Flush();

        MPI_Barrier(MPI_COMM_WORLD);

        if (MyProcID + 1 == MASTER) {
            CVertCount = new IntArray(nProcs); 
            *CVertCount = 0; 
            CElemCount = new IntArray(nProcs); 
            *CElemCount = 0; 
            CFaceCount = new IntArray(nProcs); 
            *CFaceCount = 0; 
            int MaxVertCount = 0; 
            int MaxElemCount = 0; 
            int MaxFaceCount = 0; 

            for (j = 1; j <= nProcs; j++) {
                Vertices = 0; Faces = 0; 
                for (iel = 1; iel <= NumElements; iel++) {
                    if (Partition(iel) == j - 1) {
                        (*CElemCount)(j)++; 
                        for (i = 1; i <= NUMOFVERT; i++) {
                            if (Vertices((*VertElem)(i, iel)) == 0) {
                                Vertices((*VertElem)(i, iel)) = 1; 
                                (*CVertCount)(j)++; 
                            }
                        }
                        for (i = 1; i <= NUMOFFACE; i++) {
                            if (Faces((*MidFaces)(i, iel)) == 0) {
                                Faces((*MidFaces)(i, iel)) = 1; 
                                (*CFaceCount)(j)++; 
                            }
                        }
                    }
                }
                if ((*CVertCount)(j) > MaxVertCount)
                    MaxVertCount = (*CVertCount)(j); 
                if ((*CElemCount)(j) > MaxElemCount)
                    MaxElemCount = (*CElemCount)(j); 
                if ((*CFaceCount)(j) > MaxFaceCount)
                    MaxFaceCount = (*CFaceCount)(j); 
            }

            Prot << "MaxFaceCount=" << MaxFaceCount << "\n"; 
            Prot.Flush(); 

            //
            // Mapper for coarse grid solver
            //
            CVertMap=new IntArray2D(MaxVertCount,nProcs);
            CElemMap=new IntArray2D(MaxElemCount,nProcs);
            CFaceMap=new IntArray2D(MaxFaceCount,nProcs);
            for(j=1;j<=nProcs;j++) {
                count=1;Vertices=0;Faces=0;numelem=1;facecount=1;
                for(iel=1;iel<=NumElements;iel++) {
                    if(Partition(iel)==j-1) {
                        (*CElemMap)(numelem++,j)=iel;
                        for(i=1;i<=NUMOFVERT;i++) {
                            if(Vertices((*VertElem)(i,iel))==0) {
                                Vertices((*VertElem)(i,iel))=count;
                                (*CVertMap)(count++,j)=(*VertElem)(i,iel);
                            }
                        }
                        for(i=1;i<=NUMOFFACE;i++) {
                            if(Faces((*MidFaces)(i,iel))==0) {
                                Faces((*MidFaces)(i,iel))=facecount;
                                (*CFaceMap)(facecount++,j)=(*MidFaces)(i,iel);
                            }
                        }
                    }
                }
            }

//              Prot<<"Map vertices=\n";
//              for(i=1;i<=nProcs;i++) {
//                  Prot<<"Proc: "<<i<<"\n";
//                  for(j=1;j<=(*CVertCount)(i);j++)
//                      Prot<<"    "<<j<<" --> "<<(*CVertMap)(j,i)<<"\n";
//              }
//              Prot<<"Map elem=\n";
//              for(i=1;i<=nProcs;i++) {
//                  Prot<<"Proc: "<<i<<"\n";
//                  for(j=1;j<=(*CElemCount)(i);j++)
//                      Prot<<"    "<<j<<" --> "<<(*CElemMap)(j,i)<<"\n";
//              }
//              Prot<<"Map faces=\n";
//              for(i=1;i<=nProcs;i++) {
//                  Prot<<"Proc: "<<i<<"\n";
//                  for(j=1;j<=(*CFaceCount)(i);j++)
//                      Prot<<"    "<<j<<" --> "<<(*CFaceMap)(j,i)<<"\n";
//              }
        }


        Vertices=0;
        count=1,numelem=0;
        for(iel=1;iel<=NumElements;iel++) {
            if(Partition(iel)==MyProcID) {
                numelem++;
                for(i=1;i<=NUMOFVERT;i++) {
                    if(Vertices((*VertElem)(i,iel))==0) {
                        Vertices((*VertElem)(i,iel))=count;
                        MapVertices(count++)=(*VertElem)(i,iel);
                    }
                }
            }
        }

        //
        // local grid mapping
        //
        Prot<<"NumElements="<<numelem<<" NumVertices="<<count-1<<"\n";
        Prot.Flush();

        pNumElements=numelem;
        pNumVertices=count-1;
        pNumEdges=0;  // we needn't such stuff
        pNumVertElem=NumVertElem;
        pNumBound=1;
        pNumVertBound=NUMOFVERT;
        pNumCoarseElements=numelem;
        pNumEdgeElem=NumEdgeElem;
        pNumFaceElem=NumFaceElem;

        pVertCoord=new DoubleArray2D(3,pNumVertices,"VertCoord");
        for(i=1;i<=pNumVertices;i++)
        {
            (*pVertCoord)(1,i)=(*VertCoord)(1,MapVertices(i));
            (*pVertCoord)(2,i)=(*VertCoord)(2,MapVertices(i));
            (*pVertCoord)(3,i)=(*VertCoord)(3,MapVertices(i));
        }

        numelem=0;
        pVertElem=new IntArray2D(NUMOFVERT,pNumElements,"VertElem");
        for(iel=1;iel<=NumElements;iel++) {
            if(Partition(iel)==MyProcID) {
                numelem++;
                for(i=1;i<=NUMOFVERT;i++)
                    (*pVertElem)(i,numelem)=Vertices((*VertElem)(i,iel));
            }
        }


        pInfoVertEdge=new IntArray(pNumVertices,"InfoVertEdge");
        for(i=1;i<=pNumVertices;i++)
        {
            (*pInfoVertEdge)(i)=(*InfoVertEdge)(MapVertices(i));  // boundary component one(1)
        }

        pBoundInfo=new IntArray(NumFaceElem,"BoundInfo");
        *pBoundInfo=0;

        Prot<<"Before neigh !!\n";
        Prot.Flush();

        IntArray Neigh(nProcs);
        Neigh=0;
        IntArray2D NumNeigh(pNumVertices,nProcs);
        NumNeigh=0;
        for(iel=1;iel<=pNumElements;iel++) {
            for(i=1;i<=NUMOFVERT;i++) {
                vert=MapVertices((*pVertElem)(i,iel));
//      Prot<<"vert="<<vert<<"\n";
                for(iel2=1;iel2<=NumElements;iel2++) {
                    for(j=1;j<=NUMOFVERT;j++) {
                        if((*VertElem)(j,iel2)==vert)
//            Prot<<"Check node="<<(*pVertElem)(i,iel)<<" neigh="<<Partition(iel2)+1<<"\n";
//            Prot.Flush();
                            if(Partition(iel2)!=MyProcID) {
                                Neigh(Partition(iel2)+1)=1;
                                NumNeigh((*pVertElem)(i,iel),Partition(iel2)+1)=1;
                            }
                    }
                }
            }
        }

        Prot<<"After neigh !!\n";
        Prot.Flush();

        for(iel=1;iel<=NumElements;iel++) {
            if(Partition(iel)==MyProcID) {
                for(i=1;i<=NumFaceElem;i++) {
//          Prot<<"NeighElem("<<i<<","<<iel<<")="<<(*NeighElem)(i,iel)<<"\n";
                    if((*NeighElem)(i,iel)>0) {
                        if(Partition((*NeighElem)(i,iel))!=MyProcID) {
//               Prot<<"(*NeighElem)("<<i<<","<<iel<<")="<<(*NeighElem)(i,iel)<<" Partition("<<(*NeighElem)(i,iel)<<")="<<Partition((*NeighElem)(i,iel))<<"\n";
                            Neigh(Partition((*NeighElem)(i,iel))+1)=2;
                        }
                    }
                }
            }
        }

        Prot<<"After neigh(2) !!\n";
        Prot.Flush();

        numneigh=0;
        for(iel=1;iel<=nProcs;iel++) {
            if(Neigh(iel)!=0) {
                numneigh++;
                //      Prot<<"neigh="<<iel<<" num="<<Neigh(iel)<<"\n";
            }
        }
        Prot<<"Num. of neigh: "<<numneigh<<"\n";
        Prot.Flush();

        for(i=1;i<=pNumVertices;i++) {
            for(sum=0,j=1;j<=nProcs;j++)
                sum+=NumNeigh(i,j);
            NumNeigh(i,1)=sum;
            //      Prot<<"vert("<<i<<")="<<sum<<"\n";
        }

        // create neigh informations
        nodes=new node_base;
        midnodes=new node_base;
        midneighnodes=new node_base;
        info_list=new blist_base;

        for(iel=1;iel<=nProcs;iel++) {
            if(Neigh(iel)==2) {
                if(iel<MyProcID+1) {
                    nodes->new_neigh(iel,1);
                    midnodes->new_neigh(iel,1);
                    midneighnodes->new_neigh(iel,1);
                } else {
                    nodes->new_neigh(iel,0);
                    midnodes->new_neigh(iel,0);
                    midneighnodes->new_neigh(iel,0);
                }
            } else if(Neigh(iel)==1) {
                nodes->new_neigh(iel,0);
            }
        }

        //create bound node list
        blist *temp_list;

        for(temp_list=nodes->get_neighlist()->get_first();temp_list;temp_list=nodes->get_neighlist()->get_next(temp_list))
        {
            n=temp_list->neigh;
            for(iel=1;iel<=pNumElements;iel++) {
                for(i=1;i<=NUMOFVERT;i++) {
                    vert=MapVertices((*pVertElem)(i,iel));
                    for(iel2=1;iel2<=NumElements;iel2++) {
                        if((Partition(iel2)+1)==n) {
                            for(j=1;j<=NUMOFVERT;j++) {
                                if((*VertElem)(j,iel2)==vert) {
                                    //              Prot<<"Add node="<<(*pVertElem)(i,iel)<<" neigh="<<n<<" X="<<(*pVertCoord)(1,(*pVertElem)(i,iel))<<" Y="<<(*pVertCoord)(2,(*pVertElem)(i,iel))<<" Z="<<(*pVertCoord)(3,(*pVertElem)(i,iel))<<"\n";
                                    if((*InfoVertEdge)(vert)==0) {
                                        temp_list->base->append((*pVertElem)(i,iel),ART_BOUND,7);
                                        info_list->append((*pVertElem)(i,iel),ART_BOUND,7);
                                    } else {
                                        temp_list->base->append((*pVertElem)(i,iel),REAL_BOUND,NumNeigh((*pVertElem)(i,iel),1));
                                        info_list->append((*pVertElem)(i,iel),REAL_BOUND,NumNeigh((*pVertElem)(i,iel),1));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        real_b_nodes = new blist_base; 
        real_b_midnodes = new blist_base; 
        for (iel = 1; iel <= pNumElements; iel++) {
            for (i = 1; i <= NUMOFVERT; i++)
            {
                if ((*pInfoVertEdge)((*pVertElem)(i, iel)) != 0)
                    if (Param->Func == 1 || Param->Func == 5 || Param->Func == 7) {
			//    x < 2.5 || y = 0 || y = 0.41 || z = 0 || z = 0.41
			// i.e. front, top, lateral and bottom boundaries of the channel
			// as well as the cylinder boundary.
                        if (  fabs((*pVertCoord)(1, (*pVertElem)(i, iel)) - 2.5)  > 1e-8
                           || fabs((*pVertCoord)(2, (*pVertElem)(i, iel)) - 0.41) < 1e-8
                           || fabs((*pVertCoord)(2, (*pVertElem)(i, iel)))        < 1e-8
                           || fabs((*pVertCoord)(3, (*pVertElem)(i, iel)) - 0.41) < 1e-8
                           || fabs((*pVertCoord)(3, (*pVertElem)(i, iel)))        < 1e-8)
                            real_b_nodes->append((*pVertElem)(i, iel), REAL_BOUND); 
                    } else if (Param->Func == 6) {
                        if(fabs((*pVertCoord)(3,(*pVertElem)(i,iel)) - Param->RohrLength) > 1e-8)
                            real_b_nodes->append((*pVertElem)(i,iel),REAL_BOUND);
                    } else
                        real_b_nodes->append((*pVertElem)(i,iel),REAL_BOUND);
            }
        }

        // construct midneighlist

        IntArray2D *KIAD=new IntArray2D(4,6);
        (*KIAD)(1,1)=1;
        (*KIAD)(2,1)=2;
        (*KIAD)(3,1)=3;
        (*KIAD)(4,1)=4;
        (*KIAD)(1,2)=1;
        (*KIAD)(2,2)=2;
        (*KIAD)(3,2)=6;
        (*KIAD)(4,2)=5;
        (*KIAD)(1,3)=2;
        (*KIAD)(2,3)=3;
        (*KIAD)(3,3)=7;
        (*KIAD)(4,3)=6;
        (*KIAD)(1,4)=3;
        (*KIAD)(2,4)=4;
        (*KIAD)(3,4)=8;
        (*KIAD)(4,4)=7;
        (*KIAD)(1,5)=4;
        (*KIAD)(2,5)=1;
        (*KIAD)(3,5)=5;
        (*KIAD)(4,5)=8;
        (*KIAD)(1,6)=5;
        (*KIAD)(2,6)=6;
        (*KIAD)(3,6)=7;
        (*KIAD)(4,6)=8;

        blist *temp;
        int IVT1,IVT2,IVT3,IVT4,iar,neigh;
        for (iel = 1;  iel <= NumElements;  iel++) {
            if (Partition(iel) == MyProcID) {
                for(iar = 1;  iar <= NumFaceElem;  iar++) {
                    neigh = (*NeighElem)(iar,iel);

                    if(neigh > 0) {
                        if(Partition(neigh) != MyProcID) {
                            IVT1 = (*VertElem)((*KIAD)(1,iar),iel);
                            IVT2 = (*VertElem)((*KIAD)(2,iar),iel);
                            IVT3 = (*VertElem)((*KIAD)(3,iar),iel);
                            IVT4 = (*VertElem)((*KIAD)(4,iar),iel);
                            temp = midneighnodes->find_neighlist(Partition(neigh)+1);
                            if(temp) {
                                temp->base->append(1,ART_BOUND,Vertices(IVT1),Vertices(IVT2),Vertices(IVT3),Vertices(IVT4));
                            } else
                                Prot<<"MidNeighNodes: can't find neigh="<<Partition(neigh)+1<<"\n";
                        }
                    }
                }
            }
        }
        delete KIAD;

        Prot<<"Before CheckPartition !!\n";
        Prot.Flush();
        CheckPartition(nodes,MyCom,pVertCoord);
        Prot<<"After CheckPartition !!\n";
        Prot.Flush();

    } else if (nProcs == NumElements) {
        Refine(0,1,1,3,0,0,0,1);

	// Pro forma write a parition file to disk
        IntArray Partition(NumElements);
	for (i = 1; i <= NumElements; i++) {
	    Partition(i) = i;
	}
	protocol << " Writing partition information to disk. "; protocol.mFlush();
	if (Debug) protocol << '\n';
	WritePartition(Partition);
	if (Debug) protocol << ' ';
	protocol << "Done.\n"; protocol.mFlush();

        pNumElements=1;
        pNumVertices=NumVertElem;
        pNumEdges=0;  // we needn't such stuff
        pNumVertElem=NumVertElem;
        pNumBound=1;
        pNumVertBound=NUMOFVERT;
        pNumCoarseElements=NumElements;
        pNumEdgeElem=NumEdgeElem;
        pNumFaceElem=NumFaceElem;

        pVertCoord=new DoubleArray2D(3,NumVertElem,"VertCoord");
        for(i=1;i<=NumVertElem;i++)
        {
            (*pVertCoord)(1,i)=(*VertCoord)(1,(*VertElem)(i,mnum+1));
            (*pVertCoord)(2,i)=(*VertCoord)(2,(*VertElem)(i,mnum+1));
            (*pVertCoord)(3,i)=(*VertCoord)(3,(*VertElem)(i,mnum+1));
        }

        // only one element
        pVertElem=new IntArray2D(NumVertElem,1,"VertElem");
        for(i=1;i<=NumVertElem;i++)
        {
            //Prot<<"i="<<i<<"\n";
            (*pVertElem)(i,1)=i;
        }
        pInfoVertEdge=new IntArray(pNumVertices,"InfoVertEdge");
        pBoundInfo=new IntArray(NumFaceElem,"BoundInfo");
        Refine(0,1,1,0,0,0,0,1);
        Prot<<"After Refine (1) !!\n";
        for(i=1;i<=pNumVertices;i++)
        {
            (*pInfoVertEdge)(i)=(*InfoVertEdge)((*VertElem)(i,mnum+1));  // boundary component one(1)
        }
        for(i=1;i<=NumFaceElem;i++)
        {
            (*pBoundInfo)(i)=(*NeighElem)(i,mnum+1);

//              if((*NeighElem)(i,mnum+1)==0)
//                  (*pBoundInfo)(i)=0;
//              else
//                  (*pBoundInfo)(i)=1;
        }

        if(MyProcID+1==MASTER) {
            CVertCount=new IntArray(nProcs);
            *CVertCount=0;
            CElemCount=new IntArray(nProcs);
            *CElemCount=0;
            CFaceCount=new IntArray(nProcs);
            *CFaceCount=0;

            CVertMap=new IntArray2D(8,nProcs);
            CElemMap=new IntArray2D(1,nProcs);
            CFaceMap=new IntArray2D(6,nProcs);

            for(j=1;j<=nProcs;j++) {
                (*CElemCount)(j)=1;
                (*CVertCount)(j)=8;
                (*CFaceCount)(j)=6;
                (*CElemMap)(1,j)=j;

                for(i=1;i<=NUMOFVERT;i++)
                    (*CVertMap)(i,j)=(*VertElem)(i,j);

                for(i=1;i<=NUMOFFACE;i++)
                    (*CFaceMap)(i,j)=(*MidFaces)(i,j);

            }

//              Prot<<"Map vertices=\n";
//              for(i=1;i<=nProcs;i++) {
//                  Prot<<"Proc: "<<i<<"\n";
//                  for(j=1;j<=(*CVertCount)(i);j++)
//                      Prot<<"    "<<j<<" --> "<<(*CVertMap)(j,i)<<"\n";
//              }
//              Prot<<"Map elem=\n";
//              for(i=1;i<=nProcs;i++) {
//                  Prot<<"Proc: "<<i<<"\n";
//                  for(j=1;j<=(*CElemCount)(i);j++)
//                      Prot<<"    "<<j<<" --> "<<(*CElemMap)(j,i)<<"\n";
//              }
//              Prot<<"Map faces=\n";
//              for(i=1;i<=nProcs;i++) {
//                  Prot<<"Proc: "<<i<<"\n";
//                  for(j=1;j<=(*CFaceCount)(i);j++)
//                      Prot<<"    "<<j<<" --> "<<(*CFaceMap)(j,i)<<"\n";
//              }
        }

        // create neigh informations
        nodes=new node_base;
        midnodes=new node_base;
        midneighnodes=new node_base;
        info_list=new blist_base;
        for(i=1;i<=NumFaceElem;i++)
        {
            if((*NeighElem)(i,mnum+1))
            {
                if((*NeighElem)(i,mnum+1) < mnum+1)
                {
                    nodes->new_neigh((*NeighElem)(i,mnum+1),1);
                    midnodes->new_neigh((*NeighElem)(i,mnum+1),1);
                    midneighnodes->new_neigh((*NeighElem)(i,mnum+1),1);
                } else {
                    nodes->new_neigh((*NeighElem)(i,mnum+1),0);
                    midnodes->new_neigh((*NeighElem)(i,mnum+1),0);
                    midneighnodes->new_neigh((*NeighElem)(i,mnum+1),0);
                }
            }
        }

        for(IVE=1;IVE<=NumVertElem;IVE++)
        {
            IEQ=(*VertElem)(IVE,mnum+1);
            for(i=1;i<=NumElements;i++)
            {
                if(i!=mnum+1)
                {
                    for(j=1;j<=NUMOFVERT;j++)
                        if((*VertElem)(j,i)==IEQ)
                            nodes->new_neigh(i,0);
                }
            }
        }

        //create bound node list
        blist *temp_list,*temp_list2;

        for(temp_list=nodes->get_neighlist()->get_first();temp_list;temp_list=nodes->get_neighlist()->get_next(temp_list))
        {
            n=temp_list->neigh;
            for(i=1;i<=NUMOFVERT;i++)
            {
                node=(*VertElem)(i,mnum+1);
                if(node!=0)
                {
                    for(j=1;j<=NUMOFVERT;j++)
                    {
                        if((*VertElem)(j,n)==node)
                        {
                            if((*InfoVertEdge)(node)==0)
                            {
                                temp_list->base->append(i,ART_BOUND,7);
                                info_list->append(i,ART_BOUND,7);
                            } else {
                                numneigh=0;
                                for(temp_list2=nodes->get_neighlist()->get_first();temp_list2;temp_list2=nodes->get_neighlist()->get_next(temp_list2))
                                {
                                    n2=temp_list2->neigh;
                                    for(k=1;k<=NUMOFVERT;k++)
                                        if((*VertElem)(k,n2)==node)
                                            numneigh++;
                                }
                                temp_list->base->append(i,REAL_BOUND,numneigh);
                                info_list->append(i,REAL_BOUND,numneigh);
                            }
                        }
                    }
                }
            }
        }

        real_b_nodes    = new blist_base;
        real_b_midnodes = new blist_base;
        for(i=1;i<=NUMOFVERT;i++)
        {
            if((*InfoVertEdge)((*VertElem)(i,mnum+1))!=0)
                if (Param->Func == 1  ||  Param->Func == 5  ||  Param->Func == 7) {
                    if (  fabs((*VertCoord)(1,(*VertElem)(i,mnum+1)) - 2.5)  > 1e-8
                       || fabs((*VertCoord)(2,(*VertElem)(i,mnum+1)) - 0.41) < 1e-8
                       || fabs((*VertCoord)(2,(*VertElem)(i,mnum+1)))        < 1e-8
                       || fabs((*VertCoord)(3,(*VertElem)(i,mnum+1)) - 0.41) < 1e-8
                       || fabs((*VertCoord)(3,(*VertElem)(i,mnum+1)))        < 1e-8)
                        real_b_nodes->append(i,REAL_BOUND);
                }  else if(Param->Func==6) {
                    std::string message
                        = progname + " (process " + int_to_string(MyProcID) + "):\n"
                        + "  Warning:\n"
                        + "    Variable iel is used before it is defined.\n"
			+ "    This is not really a good idea.\n"
                        + "  Program aborted in CCoarseGrid::GetMakroInfo.\n";

                    STD_CERR << message;
                    protocol  << message;

                    MPI_Abort(MPI_COMM_WORLD, BETA_TEST_ERROR);
                    if(fabs((*pVertCoord)(3,(*pVertElem)(i,iel))-Param->RohrLength)>1e-8)
                        real_b_nodes->append((*pVertElem)(i,iel),REAL_BOUND);
                } else
                    real_b_nodes->append(i,REAL_BOUND);
        }

        IntArray2D *KIAD=new IntArray2D(4,6);
        (*KIAD)(1,1)=1;
        (*KIAD)(2,1)=2;
        (*KIAD)(3,1)=3;
        (*KIAD)(4,1)=4;
        (*KIAD)(1,2)=1;
        (*KIAD)(2,2)=2;
        (*KIAD)(3,2)=6;
        (*KIAD)(4,2)=5;
        (*KIAD)(1,3)=2;
        (*KIAD)(2,3)=3;
        (*KIAD)(3,3)=7;
        (*KIAD)(4,3)=6;
        (*KIAD)(1,4)=3;
        (*KIAD)(2,4)=4;
        (*KIAD)(3,4)=8;
        (*KIAD)(4,4)=7;
        (*KIAD)(1,5)=4;
        (*KIAD)(2,5)=1;
        (*KIAD)(3,5)=5;
        (*KIAD)(4,5)=8;
        (*KIAD)(1,6)=5;
        (*KIAD)(2,6)=6;
        (*KIAD)(3,6)=7;
        (*KIAD)(4,6)=8;

        blist *temp;
//        int IVT1, IVT2, IVT3, IVT4;
        int iar, neigh;
        for(iel=1;iel<=NumElements;iel++)
        {
            if(iel==MyProcID+1) {
                for(iar=1;iar<=NumFaceElem;iar++)
                {
                    neigh=(*NeighElem)(iar,iel);
                    if(neigh>0)
                    {
                        temp=midneighnodes->find_neighlist(neigh);
                        if(temp) {
                            temp->base->append(1,ART_BOUND,(*KIAD)(1,iar),(*KIAD)(2,iar),
                                               (*KIAD)(3,iar),(*KIAD)(4,iar));
                        } else
                            Prot<<"MidNeighNodes: can't find neigh="<<MyProcID+1<<"\n";
                    }
                }
            }
        }

    } else {
        protocol << "The number of processes surpasses the number of elements.\n";
        protocol << "Program aborted.\n";
        return false;
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::GetMakroInfo.\n";
        protocol.mFlush();
    }

    return true;
}

void CCoarseGrid::CheckPartition(node_base* nodes,MComTool *MyCom,DoubleArray2D *arr2d)
{
    int len[MAX_PROC+1];
    DoubleArray2D *Ptr[MAX_PROC+1],*Ptr2;

    blist* temp_list;
    IntArray_blink *temp_nodelist;
    int i;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::CheckPartition.\n";
        protocol.mFlush();
    }

    bIntArraylist_base    *SendBound=0;
    bIntArraylist_base    *RecvBound=0;

    nodes->build_array_all(SendBound);
    nodes->build_array_all(RecvBound);

    //Prot<<"myBase=\n";
    //nodes->printNodes();
    //Prot<<"\nSendBound:\n";
    //SendBound->print_list();
    //Prot<<"\nRecvBound:\n";
    //RecvBound->print_list();

    //Prot<<"After build arrays !!\n";
    //Prot.Flush();

    for(int Proc=0;Proc<nProcs;Proc++)
    {
        if(MyProcID!=Proc) {
            for(temp_list=nodes->get_neighlist()->get_first(),
                    temp_nodelist=SendBound->get_first();
                temp_list;temp_list=nodes->get_neighlist()->get_next(temp_list),
                    temp_nodelist=SendBound->get_next(temp_nodelist))
            {
                if(temp_nodelist!=NULL)
                {
                    if(temp_list->neigh==Proc+1)
                    {
                        //Prot<<"Before GetBoundInfo !!\n";
                        //Prot.Flush();
                        Ptr[temp_list->neigh]=GetBoundInfo(temp_nodelist->ptr,nodes,arr2d);
                        if(Ptr[temp_list->neigh])
                        {
                            i=Ptr[temp_list->neigh]->GetCols();
                            MyCom->SyncSend(temp_list->neigh,i);
                            //Prot<<"MyProcID="<<MyProcID<<" Send len to "<<temp_list->neigh-1<<"\n";
                            //Prot.Flush();
                        } else
                            Prot<<"???? BoundInfo ptr==0 MyProcID "<<MyProcID<<" neigh="<<temp_list->neigh<<"\n";
                    }
                } else
                    Prot<<"???? BoundInfo temp_nodelist==0 neigh="<<temp_list->neigh<<" MyProcID "<<MyProcID<<"\n";
            }
        }

        if(MyProcID==Proc)
        {

            for(temp_list=nodes->get_neighlist()->get_first();
                temp_list;temp_list=nodes->get_neighlist()->get_next(temp_list))
            {
                MyCom->SyncRecieve(temp_list->neigh,&i);
                //Prot<<"MyProcID="<<MyProcID<<" Receive len from "<<temp_list->neigh-1<<"\n";
                //Prot.Flush();
                //          MyCom->Sync(temp_list->neigh);
                len[temp_list->neigh]=i;

                //      Prot<<"Got len="<<len[temp_list->neigh]<<" from "<<temp_list->neigh-1<<"\n";
            }
        }

        if(MyProcID!=Proc) {
            for(temp_list=nodes->get_neighlist()->get_first();
                temp_list;temp_list=nodes->get_neighlist()->get_next(temp_list))
            {
                if(Ptr[temp_list->neigh]!=NULL)
                {
                    if(temp_list->neigh==Proc+1) {
                        MyCom->SyncSend(temp_list->neigh,Ptr[temp_list->neigh]);
                        //Prot<<"MyProcID="<<MyProcID<<" Send array to neigh="<<temp_list->neigh-1<<"\n";
                        //Prot.Flush();
                        delete Ptr[temp_list->neigh];
                    }
                }
            }
        }


        if(MyProcID==Proc) {
            for(temp_list=nodes->get_neighlist()->get_first();
                temp_list;temp_list=nodes->get_neighlist()->get_next(temp_list))
            {
                Ptr2=new DoubleArray2D(3,len[temp_list->neigh]);
                MyCom->SyncRecieve(temp_list->neigh,Ptr2);
                //MyCom->Sync(temp_list->neigh);
                //Prot<<"MyProcID="<<MyProcID<<" Receive array from neigh="<<temp_list->neigh-1<<"\n";
                //Prot.Flush();

                SetBoundInfo(Ptr2,temp_list->neigh,RecvBound,nodes,arr2d);

                delete Ptr2;
            }
        }
        MPI_Barrier(MPI_COMM_WORLD);
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::CheckPartition.\n";
        protocol.mFlush();
    }

    return;
}

DoubleArray2D* CCoarseGrid::GetBoundInfo(IntArray *arr,node_base* myBase,
                                         DoubleArray2D *arr2d)
{
    DoubleArray2D *temp;
    blink *link;
    int i;

    if(arr)
    {
        temp=new DoubleArray2D(3,arr->GetLen());
        for(i=1;i<=arr->GetLen();i++)
        {
            link=myBase->find_node((*arr)(i));
            if(link==NULL)
            {
                Prot<<"\nlink==NULL\n";
                protocol << progname << " (process " << MyProcID << "):\n"
                         << "  Program aborted by process no. " << MyProcID << " in CCoarseGrid::GetBoundInfo\n";
                MPI_Finalize();
                exit(0);
            }
            (*temp)(1,i)=(*arr2d)(1,link->node);
            (*temp)(2,i)=(*arr2d)(2,link->node);
            (*temp)(3,i)=(*arr2d)(3,link->node);
        }
#ifdef CONTROL_MSG
        Prot<<"GetBoundInfo MidCoord: temp=\n"<<*temp<<"\n\n";
#endif

        return temp;
    }

    return NULL;
}

void CCoarseGrid::SetBoundInfo(DoubleArray2D *arr,int neigh,
                               bIntArraylist_base *RecvBound,node_base* myBase,
                               DoubleArray2D *arr2d)
{
    IntArray *target;
    DoubleArray2D *temp_coord;
    long i,j,len;
    int temp;
    DOUBLE X,Y,Z;
    blink *link;

    IntArray_blink *temp_link;

    for(temp_link=RecvBound->get_first();temp_link;temp_link=RecvBound->get_next(temp_link))
        if(temp_link->neigh==neigh)
            break;

    if(temp_link==NULL)
        return;

    target=temp_link->ptr;
    len=target->GetLen();

#ifdef CONTROL_MSG
    if(arr)
        Prot<<"SetBoundInfo : neigh="<<neigh<<" arr=\n"<<*arr<<"\n target=\n"<<*target<<"\n\n";
    else
        Prot<<"SetBoundInfo : neigh"<<neigh<<" arr==NULL !!\n\n";
#endif

    temp_coord=new DoubleArray2D(3,len);
    for(i=1;i<=len;i++)
    {
        link=myBase->find_node((*target)(i));
        (*temp_coord)(1,i)=(*arr2d)(1,link->node);
        (*temp_coord)(2,i)=(*arr2d)(2,link->node);
        (*temp_coord)(3,i)=(*arr2d)(3,link->node);
    }

    if(len==arr->GetCols())
    {
        for(i=1;i<len;i++)
        {
            for(j=i+1;j<=len;j++)
            {
                X=(*temp_coord)(1,j);
                Y=(*temp_coord)(2,j);
                Z=(*temp_coord)(3,j);

                if(fabs((*arr)(1,i)-X)<1e-4 && fabs((*arr)(2,i)-Y)<1e-4
                   && fabs((*arr)(3,i)-Z)<1e-4)
                {
                    temp=(*target)(i);(*target)(i)=(*target)(j);(*target)(j)=temp;
                    (*temp_coord)(1,j)=(*temp_coord)(1,i);
                    (*temp_coord)(2,j)=(*temp_coord)(2,i);
                    (*temp_coord)(3,j)=(*temp_coord)(3,i);
                }
            }
        }


        // verify

        for(i=1;i<=len;i++)
        {
            link=myBase->find_node((*target)(i));
            (*temp_coord)(1,i)=(*arr2d)(1,link->node);
            (*temp_coord)(2,i)=(*arr2d)(2,link->node);
            (*temp_coord)(3,i)=(*arr2d)(3,link->node);
        }

        //    Prot<<"neigh="<<neigh<<"\n";
        for(i=1;i<=len;i++)
        {
            if(fabs((*temp_coord)(1,i)-(*arr)(1,i))>1e-7 ||
               fabs((*temp_coord)(2,i)-(*arr)(2,i))>1e-7 ||
               fabs((*temp_coord)(3,i)-(*arr)(3,i))>1e-7) {
                Prot<<"CheckPartition ERROR neigh="<<neigh<<"   ("<<i<<")own  X="<<(*temp_coord)(1,i)<<" Y="<<(*temp_coord)(2,i)<<" Z="<<(*temp_coord)(3,i)<<"\n   ("<<i<<")recv X="<<(*arr)(1,i)<<" Y="<<(*arr)(2,i)<<" Z="<<(*arr)(3,i)<<"\n\n";
		protocol << progname << " (process " << MyProcID << "):\n"
			 << "  Error in CCoarseGrid::SetBoundInfo.\n"
			 << "  ERROR neigh="<<neigh<<"   ("<<i<<")own  X="<<(*temp_coord)(1,i)<<" Y="<<(*temp_coord)(2,i)<<" Z="<<(*temp_coord)(3,i)<<"\n   ("<<i<<")recv X="<<(*arr)(1,i)<<" Y="<<(*arr)(2,i)<<" Z="<<(*arr)(3,i)<<"\n\n";
            }
        }

        delete temp_coord;
    } else {
        Prot<<"\n\nCheckPartition !!! SetBoundInfo : Arrays have different length !!!!!\n\n";
	protocol << progname << " (process " << MyProcID << "):\n"
		 << "  Error in CCoarseGrid::SetBoundInfo.\n"
		 <<" !!! SetBoundInfo : Arrays have different length !!!!!\n\n";
    }
}

int  CCoarseGrid::CalcWeight(int iel,int neigh)
{
    double x1, y1, z1;
    double x2, y2, z2;
    double steig, steig2;
    double diff;
//      int weight;

    // We currently do not assign weight to edges.
    return 1;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::CalcWeight.!!\n";
        protocol.mFlush();
    }

    CalcMidpoint(iel,x1,y1,z1);
    CalcMidpoint(neigh,x2,y2,z2);

    diff = x2 - x1;
    if (fabs(diff) < 1e-10)
        steig = 1e10;
    else
        steig = (y2 - y1) / diff;
    diff = x2 - 0.5;
    if (fabs(diff) < 1e-10)
        steig2 = 1e10;
    else
        steig2 = (y2 - 0.15) / diff;

    // good choice
    //if(fabs(steig-steig2)<2) {
    //    return 2;
    //} else {
    //    return 1;
    //}

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::CalcWeight.\n";
        protocol.mFlush();
    }

    if(fabs(z1-z2)<0.05)
        return 1;
    else
        return 10;

    //return 1.0/sqrt(pow(x1-x2,2)+pow(y1-y2,2)+pow(z1-z2,2));

    diff=sqrt(pow(x1-0.5,2)+pow(y1-0.15,2));
    if(diff<0.8)
        return 4;
    else
        return 1;
}

void CCoarseGrid::CalcMidpoint(int iel,double& x,double& y,double& z)
{
    int    I1,I2,I3,I4,I5,I6,I7,I8;
    double X1,X2,X3,X4,X5,X6,X7,X8;
    double Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8;
    double Z1,Z2,Z3,Z4,Z5,Z6,Z7,Z8;

    I1=(*VertElem)(1,iel);
    I2=(*VertElem)(2,iel);
    I3=(*VertElem)(3,iel);
    I4=(*VertElem)(4,iel);
    I5=(*VertElem)(5,iel);
    I6=(*VertElem)(6,iel);
    I7=(*VertElem)(7,iel);
    I8=(*VertElem)(8,iel);

    X1=(*VertCoord)(1,I1);
    X2=(*VertCoord)(1,I2);
    X3=(*VertCoord)(1,I3);
    X4=(*VertCoord)(1,I4);
    X5=(*VertCoord)(1,I5);
    X6=(*VertCoord)(1,I6);
    X7=(*VertCoord)(1,I7);
    X8=(*VertCoord)(1,I8);

    Y1=(*VertCoord)(2,I1);
    Y2=(*VertCoord)(2,I2);
    Y3=(*VertCoord)(2,I3);
    Y4=(*VertCoord)(2,I4);
    Y5=(*VertCoord)(2,I5);
    Y6=(*VertCoord)(2,I6);
    Y7=(*VertCoord)(2,I7);
    Y8=(*VertCoord)(2,I8);

    Z1=(*VertCoord)(3,I1);
    Z2=(*VertCoord)(3,I2);
    Z3=(*VertCoord)(3,I3);
    Z4=(*VertCoord)(3,I4);
    Z5=(*VertCoord)(3,I5);
    Z6=(*VertCoord)(3,I6);
    Z7=(*VertCoord)(3,I7);
    Z8=(*VertCoord)(3,I8);

    x=(X1+X2+X3+X4+X5+X6+X7+X8)*0.125;
    y=(Y1+Y2+Y3+Y4+Y5+Y6+Y7+Y8)*0.125;
    z=(Z1+Z2+Z3+Z4+Z5+Z6+Z7+Z8)*0.125;
}

void CCoarseGrid::SetBound(DoubleCompactMatrix* LA)
{
    INTEGER     IVT,ICOL,IEQ;

    for(IVT=1;IVT<=NumVertBound;IVT++) {
        IEQ=(*VertBound)(IVT);
        (*LA).Data((*LA).Diag(IEQ))=1;
        for(ICOL=(*LA).Diag(IEQ)+1;ICOL<=(*LA).Diag(IEQ+1)-1;ICOL++)
            (*LA).Data(ICOL)=0;
    }
}

void CCoarseGrid::SetLumpedBound(DoubleVector& vect)
{
    INTEGER     IVT,IEQ;

    for(IVT=1;IVT<=NumVertBound;IVT++) {
        IEQ=(*VertBound)(IVT);
        vect(IEQ)=0.0;
    }
}

void CCoarseGrid::WritePartition(IntArray& Partition)
{
    int i;                                        // loop counter
    std::string filename = Param->PartitionBaseDir + Param->PartitionFile;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::WritePartition.\n";
        protocol.mFlush();
    }

    // Finally get write handle for this very file.
    COutput outfile(filename.c_str(), ACTIVE);

    outfile << NumElements << "\n";

    for (i = 1; i <= NumElements; i++) {
        outfile << Partition(i) << "\n";
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::WritePartition.\n";
        protocol.mFlush();
    }

    return;
}

void CCoarseGrid::ReadPartition(IntArray& Partition)
{
    int i;                                        // loop counter
    int vNumElements;                             // contains number of elements provided within file
    std::string filename = Param->PartitionBaseDir + Param->PartitionFile;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::ReadPartition.\n";
        protocol.mFlush();
    }

    // Finally get read handle for this very file.
    CInput infile(filename.c_str());

    // Read the number of elements from partition file.
    // Check whether this number matches our current configuration.
    infile >> vNumElements;
    if (vNumElements != NumElements) {
	std::string message
	    = progname + " (process " + int_to_string(MyProcID) + "):\n"
	    + "  Inconsistent data discovered while reading the partition file:\n"
	    + "  Cause of error:\n"
	    + "    The number of elements specified within this file does\n"
	    + "    not match the number within the coarse grid file.\n"
	    + "  Program aborted in CCoarseGrid::ReadPartition.\n";

	STD_CERR << message;
	protocol  << message;

        MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
    }
    infile.GoToNextLine();

    for (i = 1; i <= NumElements; i++) {
        infile >> Partition(i);

	// We have to ensure that the number of partitions
	// matches the current number of processes.
	if (Partition(i)+1 > nProcs) {
	    std::string message
		= progname + " (process " + int_to_string(MyProcID) + "):\n"
		+ "  Inconsistent data discovered in partition file:\n"
		+ "  Cause of error:\n"
		+ "    There are more partitions than processes.\n"
		+ "  Program aborted in CCoarseGrid::ReadPartition.\n";

	    STD_CERR << message;
	    protocol  << message;

	    MPI_Abort(MPI_COMM_WORLD, ILLEGAL_INPUT_ERROR);
	}

        infile.GoToNextLine();
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::ReadPartition.\n";
        protocol.mFlush();
    }

    return;
}



void CCoarseGrid::InitMatrices(Daten *PParam,UNSIGNED BCON,IntArray2D& KAB,
                               UNSIGNED KABN,UNSIGNED ICUB,
                               UNSIGNED ISYMM,UNSIGNED ICLEAR,UNSIGNED ILINT)
{
//     int IVT,IMID,IADJ,IVEL,IDISP,IBDP,ICHECK,ILEV;
    int IEQ;
    double X, Y, Z;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::InitMatrices.\n";
        protocol.mFlush();
    }

    if (MyProcID+1 == MASTER) {
        Param    = PParam;
        ElemType = Param->ElemType;

        A = 0;

        if (ElemType == 1) {
            Element = new TrilinearElement_3D(this);
            Refine(0,1,1,0,0,0,0,1);

            if (VertBound)
                delete VertBound;

            // Determine size of new array.
            NumVertBound=0;
            for (IEQ=1; IEQ <= NumVertices; IEQ++) {
                if ((*InfoVertEdge)(IEQ) != 0) {
                    NumVertBound++;
                }
            }
            VertBound = new IntArray(NumVertBound,"VertBound");

            // Initialize array.
            NumVertBound=0;
            for(IEQ = 1; IEQ <= NumVertices; IEQ++) {
                if ((*InfoVertEdge)(IEQ) != 0) {
                    NumVertBound++;
                    (*VertBound)(NumVertBound)=IEQ;
                }
            }
            Prot<<"NumVertBound="<<NumVertBound<<"\n";
        } else {
//          Element=new RotatedElement_3D(this);
            Element = new NonParamElement_3D(this);
            Refine(0,1,1,3,0,0,0,1);

//             Prot<<"MidFaces=\n"<<*MidFaces<<"\n";
//             Prot<<"MidFaceCoord=\n"<<*MidFaceCoord<<"\n";

            if(VertBound)
                delete VertBound;

            // Determine size of VertBound, an array which contains the numbers
            // of those faces which reside on the "real" boundary.
	    // At the same time, set up an array which contains information 
	    // about Neumann Boundary values for the coarse grid matrix (which 
	    // resides on process 1)
            NumVertBound=0;
            for (IEQ = 1; IEQ <= TotNumFaces; IEQ++) {
                if ((*InfoVertEdge)(IEQ+NumVertices) != 0) {
		    X = (*MidFaceCoord)(1,IEQ);
		    Y = (*MidFaceCoord)(2,IEQ);
		    Z = (*MidFaceCoord)(3,IEQ);
		    if (BoundaryCondition(Param->Func, X, Y, Z, 0) == 1) {
			NumVertBound++;
		    } else {
			(*InfoVertEdge)(IEQ+NumVertices) = 0;
		    }
                }
            } // end for(IEQ = 1; IEQ <= TotNumFaces; IEQ++)

            // Use this calculated value to allocate the memory we need.
            VertBound = new IntArray(NumVertBound, "VertBound");

            // Write the numbers of those faces which reside on the "real" boundary
            // to this new array.
            NumVertBound = 0;
            for(IEQ = 1; IEQ <= TotNumFaces; IEQ++) {
                if ((*InfoVertEdge)(IEQ+NumVertices) != 0) {
                    NumVertBound++;
                    (*VertBound)(NumVertBound) = IEQ;
                }
            }
        }

        CoeffA1();
        Element->CalcStiffMatrix(A,TRUE,KAB,KABN,ICUB,ISYMM,ICLEAR,ILINT);
        if(Param->BoundCond==1)
            SetBound(A);
        A->CuthillMcKee();
        A->PermAll();
        A->ILU(1,0.0,1e-12);


        A2=new DoubleCompactMatrix(*A);
        *A2=*A;
        f=Element->GetRightSideVector();
        sol=Element->GetRightSideVector();
        v1=Element->GetRightSideVector();
        v2=Element->GetRightSideVector();
        v3=Element->GetRightSideVector();
        *sol=0;
        *f=0;
        *v1=0;
        *v2=0;
        *v3=0;
        const_sol=new DoubleVector(NumElements);
        const_f=new DoubleVector(NumElements);
        *const_sol=0;
        *const_f=0;

        //
        // build projection-matrix
        //

        Build_B(B1,B2,B3,A);

        //  Prot<<"B1=\n"<<*B1<<"\n";
        //  Prot<<"B2=\n"<<*B2<<"\n";
        //  Prot<<"B3=\n"<<*B3<<"\n";

        IntArray2D      Mass(2,1);

        M=new DoubleCompactMatrix(*A);
        Mass(1,1)=1;
        Mass(2,1)=1;
        CoeffM();
        Element->CalcStiffMatrix(M,TRUE,Mass,1,2,ISYMM,TRUE,ILINT);

        LumpM=GetLumpedMassMat(*M);
        SetLumpedBound(*LumpM);
        Mass(1,1)=1;
        Mass(2,1)=1;
        CoeffM();
        Element->CalcStiffMatrix(M,TRUE,Mass,1,ICUB,ISYMM,TRUE,ILINT);

        //  Prot<<"LumpM=\n";
        //  OutputVector((*LumpM)[Param->NFine],Param->NFine);

        // calc projection-matrix
        C=GetProjMatrix();
        *C=0;
        BuildProjMatrix(C,LumpM,B1,B2,B3);

//  	C->PrintRowSum();
// 	C->PrintMaxRowSum();
//      C->ShowSparseMatrix();

        C->CuthillMcKee();
        C->PermAll();
        C->ILU(1,0.0,1e-12);

        delete B1;
        delete B2;
        delete B3;
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::InitMatrices.\n";
        protocol.mFlush();
    }

    return;
}

void CCoarseGrid::SetTimeMatrix(double k)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::SetTimeMatrix.\n";
        protocol.mFlush();
    }

    if (MyProcID + 1 == MASTER) {
        *A = *A2; 
        UpWind(*A, *v1, *v2, *v3, Param->UpSam); 
//    *A *= k; 
        A->AddMultConst(*M, k, 1.0);		  //  A = k * A + M
//    for (int i = 1; i <= LumpM->GetLen(); i++)
//      A->Data(A->Diag(i)) += (*LumpM)(i); 
        if (Param->BoundCond == 1)
            SetBound(A); 
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::SetTimeMatrix.\n"; 
        protocol.mFlush(); 
    }

    return; 
}

void CCoarseGrid::SetUpwindVec1(int mnum,DoubleVector *ptr)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::SetUpwindVec1.\n";
        protocol.mFlush();
    }

    if(ElemType==1)
    {
        for(int i=1;i<=(*CVertCount)(mnum);i++)
        {
            (*v1)((*CVertMap)(i,mnum))=(*ptr)(i);
        }
    } else {
        for(int i=1;i<=(*CFaceCount)(mnum);i++)
        {
            (*v1)((*CFaceMap)(i,mnum))=(*ptr)(i);
        }
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::SetUpwindVec1.\n";
        protocol.mFlush();
    }

    return;
}

void CCoarseGrid::SetUpwindVec2(int mnum,DoubleVector *ptr)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::SetUpwindVec2.\n";
        protocol.mFlush();
    }

    if(ElemType==1)
    {
        for(int i=1;i<=(*CVertCount)(mnum);i++)
        {
            (*v2)((*CVertMap)(i,mnum))=(*ptr)(i);
        }
    } else {
        for(int i=1;i<=(*CFaceCount)(mnum);i++)
        {
            (*v2)((*CFaceMap)(i,mnum))=(*ptr)(i);
        }
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::SetUpwindVec2.\n";
        protocol.mFlush();
    }

    return;
}

void CCoarseGrid::SetUpwindVec3(int mnum,DoubleVector *ptr)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::SetUpwindVec3.\n";
        protocol.mFlush();
    }

    if(ElemType==1)
    {
        for(int i=1;i<=(*CVertCount)(mnum);i++)
        {
            (*v3)((*CVertMap)(i,mnum))=(*ptr)(i);
        }
    } else {
        for(int i=1;i<=(*CFaceCount)(mnum);i++)
        {
            (*v3)((*CFaceMap)(i,mnum))=(*ptr)(i);
        }
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::SetUpwindVec3.\n";
        protocol.mFlush();
    }

    return;
}


void CCoarseGrid::SetVector(int mnum,DoubleVector *ptr)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::SetVector.\n";
        protocol.mFlush();
    }

    if(ElemType==1)
    {
        for(int i=1;i<=(*CVertCount)(mnum);i++)
        {
            (*f)((*CVertMap)(i,mnum))=(*ptr)(i);
            (*sol)((*CVertMap)(i,mnum))=(*ptr)(i);
        }
    } else {
        for(int i=1;i<=(*CFaceCount)(mnum);i++)
        {
            (*f)((*CFaceMap)(i,mnum))=(*ptr)(i);
            (*sol)((*CFaceMap)(i,mnum))=(*ptr)(i);
        }
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::SetVector.\n";
        protocol.mFlush();
    }

    return;
}

void CCoarseGrid::SetConstVector(int mnum,DoubleVector *ptr)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::SetConstVector.\n";
        protocol.mFlush();
    }

    for(int i=1;i<=(*CElemCount)(mnum);i++)
    {
        (*const_f)((*CElemMap)(i,mnum))=(*ptr)(i);
        (*const_sol)((*CElemMap)(i,mnum))=(*ptr)(i);
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::SetConstVector.\n";
        protocol.mFlush();
    }

    return;
}

DoubleVector* CCoarseGrid::GetVector(int mnum)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::GetVector.\n";
        protocol.mFlush();
    }

    if(ElemType==1) {
        DoubleVector* ptr=new DoubleVector((*CVertCount)(mnum));
        for(int i=1;i<=(*CVertCount)(mnum);i++) {
            (*ptr)(i)=(*sol)((*CVertMap)(i,mnum));
        }
        if (Debug) {
            protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::GetVector.\n";
            protocol.mFlush();
        }

        return ptr;
    } else {
        DoubleVector* ptr = new DoubleVector((*CFaceCount)(mnum));
        for(int i = 1; i <= (*CFaceCount)(mnum); i++) {
            (*ptr)(i) = (*sol)((*CFaceMap)(i,mnum));
        }
        if (Debug) {
            protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::GetVector.\n";
            protocol.mFlush();
        }

        return ptr;
    }
}

DoubleVector* CCoarseGrid::GetConstVector(int mnum)
{
    DoubleVector* ptr=new DoubleVector((*CElemCount)(mnum));

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::GetConstVector.\n";
        protocol.mFlush();
    }

    for(int i=1;i<=(*CElemCount)(mnum);i++)
    {
        (*ptr)(i)=(*const_sol)((*CElemMap)(i,mnum));
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::GetConstVector.\n";
        protocol.mFlush();
    }

    return ptr;
}

void CCoarseGrid::SolveExact(int solver)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::SolveExact.\n";
        protocol.mFlush();
    }

//  Prot<<"A=\n"<<*A<<"\n";
//  Prot<<"Solve exact f=\n"<<*f<<"\n";
//  Prot<<"Solve exact sol=\n"<<*sol<<"\n";

//  Output Temp("comp2",YES);
//  for(int i=1;i<=A->GetNumData();i++)
//    Temp<<A->Data(i)<<"\n";

//  Prot<<"exact solver="<<Param->Solver<<"\n";

    Prot.SetFlag(NO); 
    ProtAdd.SetFlag(NO); 

    // Jacobi: 200 iterations at max.
    // SOR, GS, CG: 100
    if (solver == 1)
        A->Jacobi(*sol, *f, Param->SolverMaxIt_burg, (double)1e-9, (double)0.8); 
    else if (solver == 2)
        A->SOR(*sol, *f, Param->SolverMaxIt_burg, (double)1e-9, (double)1.3); 
    else if (solver == 3)
        A->GaussSeidel(*sol, *f, Param->SolverMaxIt_burg, (double)1e-9); 
    else if (solver == 4)
        A->CG(*sol, *f, Param->SolverMaxIt_burg, (double)1e-9, (double)1.3); 

    if (MyProcID == 0) {
        Prot.SetFlag(YES); 
//    ProtAdd.SetFlag(YES); 
    }

//  Prot<<"Solve exact sol=\n"<<*sol<<"\n";

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::SolveExact.\n";
        protocol.mFlush();
    }

    return;
}

void CCoarseGrid::SolveConstExact(int solver)
{
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::SolveConstExact.\n";
        protocol.mFlush();
    }

//  Prot<<"C=\n"<<*C<<"\n";
    //  Prot<<"Solve exact f=\n"<<*const_f<<"\n";
//  Prot<<"Solve exact sol=\n"<<*const_sol<<"\n";

    Prot.SetFlag(NO);
    ProtAdd.SetFlag(NO);

    // Jacobi: 200 iterations at max
    // SOR: 500
    // GS: 50
    // CG: 100
    if (solver == 1)
        C->Jacobi(*const_sol, *const_f, Param->SolverMaxIt_press, (double)1e-9, (double)1.3); 
    else if (solver == 2)
        C->SOR(*const_sol, *const_f, Param->SolverMaxIt_press, (double)1e-9, (double)1.3); 
    else if (solver == 3)
        C->GaussSeidel(*const_sol, *const_f, Param->SolverMaxIt_press, (double)1e-9); 
    else if (solver == 4)
        C->CG(*const_sol, *const_f, Param->SolverMaxIt_press, (double)1e-9, (double)1.3); 
    else if (solver == 5)
        C->BiCGStab(*const_sol, *const_f, Param->SolverMaxIt_press, (double)1e-9, (double)1.3); 

    if (MyProcID == 0) {
        Prot.SetFlag(YES); 
//    ProtAdd.SetFlag(YES); 
    }

//  Prot<<"Solve exact sol=\n"<<*sol<<"\n";
    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::SolveConstExact.\n";
        protocol.mFlush();
    }

    return;
}

VOID CCoarseGrid::Build_B(DoubleRectMatrix * & B1, DoubleRectMatrix * & B2, 
                          DoubleRectMatrix * & B3, DoubleCompactMatrix * & A)
{
    int ILD, IEL, IAT, IAREA, IVT1, IVT2, IVT3, IVT4, IADJ, IVE, IVT; 
//      int ILEV, IMID; 
    double P1X, P1Y, P1Z, P2X, P2Y, P2Z, P3X, P3Y, P3Z, P4X, P4Y, P4Z, DNX, DNY, DNZ; 
//      double AX1, AY1, AZ1; 
    double AX2, AY2, AZ2; 
    double AX3, AY3, AZ3; 
    double AX4, AY4, AZ4; 
    double AX, AY, AZ, DHN; 
    double PXC, PYC, PZC, PXA, PYA, PZA, DNAR1, DNAR2, DFAC; 
    DoubleRectMatrix *B, *BT, *BTT; 

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::Build_B.\n";
        protocol.mFlush();
    }

    B1 = new DoubleRectMatrix(2 * A->GetNumDiag(), A->GetNumDiag()); 
    B2 = new DoubleRectMatrix(2 * A->GetNumDiag(), A->GetNumDiag()); 
    B3 = new DoubleRectMatrix(2 * A->GetNumDiag(), A->GetNumDiag()); 

    B = B1; 
    BT = B2; 
    BTT = B3; 
    ILD = 0; 
    for (IEL = 1; IEL <= NumElements; IEL++) {
        PXC = 0.; 
        PYC = 0.; 
        PZC = 0.; 

        for (IVE = 1; IVE <= 8; IVE++) {
            IVT = (*VertElem)(IVE, IEL); 
            PXC += (*VertCoord)(1, IVT); 
            PYC += (*VertCoord)(2, IVT); 
            PZC += (*VertCoord)(3, IVT); 
        }

        PXC *= 0.125; 
        PYC *= 0.125; 
        PZC *= 0.125; 

        for (IAT = 1; IAT <= 6; IAT++) {
            IADJ = (*NeighElem)(IAT, IEL); 
            if (!(IADJ > 0 && IADJ < IEL)) {
                IAREA = (*MidFaces)(IAT, IEL); 

                if (IAT == 1)
                {
                    IVT1 = (*VertElem)(1, IEL); 
                    IVT2 = (*VertElem)(2, IEL); 
                    IVT3 = (*VertElem)(3, IEL); 
                    IVT4 = (*VertElem)(4, IEL); 
                }
                if (IAT == 2)
                {
                    IVT1 = (*VertElem)(1, IEL); 
                    IVT2 = (*VertElem)(2, IEL); 
                    IVT3 = (*VertElem)(6, IEL); 
                    IVT4 = (*VertElem)(5, IEL); 
                }
                if (IAT == 3)
                {
                    IVT1 = (*VertElem)(2, IEL); 
                    IVT2 = (*VertElem)(3, IEL); 
                    IVT3 = (*VertElem)(6, IEL); 
                    IVT4 = (*VertElem)(7, IEL); 
                }
                if (IAT == 4)
                {
                    IVT1 = (*VertElem)(3, IEL); 
                    IVT2 = (*VertElem)(4, IEL); 
                    IVT3 = (*VertElem)(8, IEL); 
                    IVT4 = (*VertElem)(7, IEL); 
                }
                if (IAT == 5)
                {
                    IVT1 = (*VertElem)(4, IEL); 
                    IVT2 = (*VertElem)(1, IEL); 
                    IVT3 = (*VertElem)(5, IEL); 
                    IVT4 = (*VertElem)(8, IEL); 
                }
                if (IAT == 6)
                {
                    IVT1 = (*VertElem)(5, IEL); 
                    IVT2 = (*VertElem)(6, IEL); 
                    IVT3 = (*VertElem)(7, IEL); 
                    IVT4 = (*VertElem)(8, IEL); 
                }

                P1X = (*VertCoord)(1, IVT1); 
                P1Y = (*VertCoord)(2, IVT1); 
                P1Z = (*VertCoord)(3, IVT1); 
                P2X = (*VertCoord)(1, IVT2); 
                P2Y = (*VertCoord)(2, IVT2); 
                P2Z = (*VertCoord)(3, IVT2); 
                P3X = (*VertCoord)(1, IVT3); 
                P3Y = (*VertCoord)(2, IVT3); 
                P3Z = (*VertCoord)(3, IVT3); 
                P4X = (*VertCoord)(1, IVT4); 
                P4Y = (*VertCoord)(2, IVT4); 
                P4Z = (*VertCoord)(3, IVT4); 

                PXA = (P1X + P2X + P3X + P4X) * 0.25; 
                PYA = (P1Y + P2Y + P3Y + P4Y) * 0.25; 
                PZA = (P1Z + P2Z + P3Z + P4Z) * 0.25; 

                AX2 = P2X - P1X; 
                AY2 = P2Y - P1Y; 
                AZ2 = P2Z - P1Z; 
                AY3 = P3Y - P1Y; 
                AX3 = P3X - P1X; 
                AZ3 = P3Z - P1Z; 
                AY4 = P4Y - P1Y; 
                AX4 = P4X - P1X; 
                AZ4 = P4Z - P1Z; 

                AX =PXC - PXA; 
                AY =PYC - PYA; 
                AZ =PZC - PZA; 

                DNX=(AY3*AZ2)-(AZ3*AY2);
                DNY=(AZ3*AX2)-(AX3*AZ2);
                DNZ=(AX3*AY2)-(AY3*AX2);
                DNAR1=sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

                DNX=(AY4*AZ3)-(AZ4*AY3);
                DNY=(AZ4*AX3)-(AX4*AZ3);
                DNZ=(AX4*AY3)-(AY4*AX3);
                DNAR2=sqrt(DNX*DNX+DNY*DNY+DNZ*DNZ);

                DFAC=0.5*(DNAR1+DNAR2)/DNAR2;
                DNX =DFAC*DNX;
                DNY =DFAC*DNY;
                DNZ =DFAC*DNZ;

                DHN=DNX*AX+DNY*AY+DNZ*AZ;
                if(DHN<0.) {
                    DNX=-DNX;
                    DNY=-DNY;
                    DNZ=-DNZ;
                }

                ILD++;
                B->Diag(IAREA)=BT->Diag(IAREA)=BTT->Diag(IAREA)=ILD;
                B->Col(ILD)=BT->Col(ILD)=BTT->Col(ILD)=IEL;
                B->Data(ILD)=DNX;
                BT->Data(ILD)=DNY;
                BTT->Data(ILD)=DNZ;

                if(IADJ>0)
                {
                    ILD++;
                    B->Col(ILD)=BT->Col(ILD)=BTT->Col(ILD)=IADJ;
                    B->Data(ILD)=-DNX;
                    BT->Data(ILD)=-DNY;
                    BTT->Data(ILD)=-DNZ;
                }
            }
        }
    }
    B->Diag(TotNumFaces+1)=BT->Diag(TotNumFaces+1)=BTT->Diag(TotNumFaces+1)=ILD+1;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::Build_B.\n";
        protocol.mFlush();
    }

    return;
}


DoubleCompactMatrix* CCoarseGrid::GetProjMatrix()
{
    int NC,IEL,IAT,IADJ,IEQ,BSORT,IHELP,ICOL;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::GetProjMatrix.\n";
        protocol.mFlush();
    }

    DoubleCompactMatrix *mat=new DoubleCompactMatrix(7*NumElements,NumElements);

    NC=0;
    mat->Diag(1)=1;

    for(IEL=1;IEL<=NumElements;IEL++)
    {
        NC++;
        mat->Col(NC)=IEL;
        for(IAT=1;IAT<=6;IAT++)
        {
            IADJ=(*NeighElem)(IAT,IEL);
            if(IADJ!=0)
            {
                NC++;
                mat->Col(NC)=IADJ;
            }
        }
        mat->Diag(IEL+1)=NC+1;
    }

// SB: Argg! BubbleSort
    DateTime SortTime;
    SortTime.SetTime();

    for(IEQ=1;IEQ<=NumElements;IEQ++)
    {
        do {
            BSORT=true;
            for(ICOL=mat->Diag(IEQ)+1;ICOL<=mat->Diag(IEQ+1)-2;ICOL++)
            {
                if(mat->Col(ICOL) > mat->Col(ICOL+1))
                {
                    IHELP=mat->Col(ICOL);
                    mat->Col(ICOL)=mat->Col(ICOL+1);
                    mat->Col(ICOL+1)=IHELP;
                    BSORT=false;
                }
            }
        } while(BSORT==false);
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::GetProjMatrix.\n";
        protocol.mFlush();
    }

    return mat;
}

VOID CCoarseGrid::BuildProjMatrix(DoubleCompactMatrix* mat,DoubleVector* Mvect,
                                  DoubleRectMatrix* B,DoubleRectMatrix* BT,
                                  DoubleRectMatrix* BTT)
{
    int IEL,IAT,IAREA,IADJ,ILD1,ILD2,ILDB1,ILDC,INPR,ILDB2;
//      int INP;
    double DH1,DH2;
    DoubleCompactMatrix *C;
    DoubleRectMatrix *B1,*B2,*B3;
    DoubleVector *M;

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::BuildProjMatrix.\n";
        protocol.mFlush();
    }

    C=mat;
    M=Mvect;
    B1=B;
    B2=BT;
    B3=BTT;
    *C=0;

    for(IEL=1;IEL<=NumElements;IEL++)
    {
        for(IAT=1;IAT<=6;IAT++)
        {
            IAREA=(*MidFaces)(IAT,IEL);
            IADJ=(*NeighElem)(IAT,IEL);

            INPR=(*InfoVertEdge)(IAREA+NumVertices);

            if(INPR==0)
            {
                ILD1=C->Diag(IEL);
                ILD2=C->Diag(IEL+1)-1;

                for(ILDB1=B1->Diag(IAREA);ILDB1<=B1->Diag(IAREA+1)-1;ILDB1++)
                {
                    if(B1->Col(ILDB1)==IEL)
                        break;
                }
                if(ILDB1 > B1->Diag(IAREA+1)-1)
                {
                    std::string message
                        = progname + " (process " + int_to_string(MyProcID) + "):\n"
                        + "  Unrecoverable error discovered:\n"
                        + "    Error in B1: IEL=" + int_to_string(IEL) + " IAREA=" + int_to_string(IAREA,0) + "\n"
                        + "  Program aborted in CCoarseGrid::BuildProjMatrix.\n";

                    STD_CERR << message;
                    protocol  << message;

                    MPI_Abort(MPI_COMM_WORLD, BUILD_PROJ_MATRIX_ERROR);
                }
                DH1=pow(B1->Data(ILDB1),2.0)+pow(B2->Data(ILDB1),2.0)+pow(B3->Data(ILDB1),2);

                C->Data(ILD1)+=DH1/(*M)(IAREA);

                if(IADJ!=0)
                {
                    for(ILDB2=B1->Diag(IAREA);ILDB2<=B1->Diag(IAREA+1)-1;ILDB2++)
                    {
                        if(B1->Col(ILDB2)==IADJ)
                            break;
                    }
                    if(ILDB2 > B1->Diag(IAREA+1)-1)
                    {
                        std::string message
                            = progname + " (process " + int_to_string(MyProcID) + "):\n"
                            + "  Unrecoverable error discovered:\n"
                            + "    Error in B2\n"
                            + "  Program aborted in CCoarseGrid::BuildProjMatrix.\n";

                        STD_CERR << message;
                        protocol  << message;

                        MPI_Abort(MPI_COMM_WORLD, BUILD_PROJ_MATRIX_ERROR);
                    }
                    for(ILDC=ILD1+1;ILDC<=ILD2;ILDC++)
                    {
                        if(C->Col(ILDC)==IADJ)
                            break;
                    }
                    if(ILDC > ILD2)
                    {
                        std::string message
                            = progname + " (process " + int_to_string(MyProcID) + "):\n"
                            + "  Unrecoverable error discovered:\n"
                            + "    Error in C\n"
                            + "  Program aborted in CCoarseGrid::BuildProjMatrix.\n";

                        STD_CERR << message;
                        protocol  << message;

                        MPI_Abort(MPI_COMM_WORLD, BUILD_PROJ_MATRIX_ERROR);
                    }
                    DH2=B1->Data(ILDB1)*B1->Data(ILDB2)+B2->Data(ILDB1)*B2->Data(ILDB2)
                        +B3->Data(ILDB1)*B3->Data(ILDB2);
                    C->Data(ILDC)=DH2/(*M)(IAREA);
                }
            }
        }
    } // end for(IEL=1;IEL<=NumElements;IEL++)

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::BuildProjMatrix.\n";
        protocol.mFlush();
    }

    return;
}

DoubleVector *CCoarseGrid::GetLumpedMassMat(DoubleCompactMatrix& M)
{
    int IEQ;
//     int ICOL;
//     double DMH;

    DoubleVector *vect=new DoubleVector(M.GetNumDiag());

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::GetLumpedMassMat.\n";
        protocol.mFlush();
    }

    for(IEQ=1;IEQ<=M.GetNumDiag();IEQ++)
    {
        //DMH=0;
        //for(ICOL=M.Diag(IEQ);ICOL<=M.Diag(IEQ+1)-1;ICOL++)
        //DMH+=M.Data(ICOL);
        //(*vect)(IEQ)=DMH;
        (*vect)(IEQ)=M.Data(M.Diag(IEQ));
    }

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::GetLumpedMassMat.\n";
        protocol.mFlush();
    }

    return vect;
}

void CCoarseGrid::UpWind(DoubleCompactMatrix& LA,DoubleVector& u1,DoubleVector& u2,
                         DoubleVector& u3,double UPSAM)
{
    double RE=1.0/Param->EpsEqu;

    int IEL,II,IVT,IAR,IV1,IV2,IV3,IV4,IA1,IA2,IA,JJ,JAR,IM0,I;
    double XE,YE,ZE,XNHH,YNHH,ZNHH,DINN,DNFACT,DMEAN;
    DoubleArray2D XN(4,6),YN(4,6),ZN(4,6),DLEN(4,6),UMEAN1(4,6),UMEAN2(4,6),UMEAN3(4,6);
    double XV[9],YV[9],ZV[9],H1,H2,H3,H4,ELMH,XA[7],YA[7],ZA[7];
    double XVE[9],YVE[9],ZVE[9],FLUX[5],DLAM[5],UU1[7],UU2[7],UU3[7];
    int IAREA[7],IM[5];
    IntArray2D ISTORE(6,6);
    DoubleArray2D ELMA(6,6);

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "): Entering CCoarseGrid::UpWind.\n";
        protocol.mFlush();
    }

    for(IEL=1;IEL<=NumElements;IEL++)
    {
// *** XE,YE,ZE will be coordinates of the center of the element
        XE=0.0;
        YE=0.0;
        ZE=0.0;
//-----------------------------------------------------------------------
// *** 1. Loop over all 8 vertices
//
        for(II=1;II<=8;II++)
        {
            IVT=(*VertElem)(II,IEL);
            XV[II]=(*VertCoord)(1,IVT);
            YV[II]=(*VertCoord)(2,IVT);
            ZV[II]=(*VertCoord)(3,IVT);
            XE=XE+XV[II];
            YE=YE+YV[II];
            ZE=ZE+ZV[II];
        }

        XE=0.125*XE;
        YE=0.125*YE;
        ZE=0.125*ZE;

        for(II=1;II<=8;II++)
        {
            XVE[II]=XV[II]-XE;
            YVE[II]=YV[II]-YE;
            ZVE[II]=ZV[II]-ZE;
        }
//
//-----------------------------------------------------------------------
// *** 2. Loop over all 6 U-nodes
//
        for(II=1;II<=6;II++)
        {
            IAR=(*MidFaces)(II,IEL);
            IAREA[II]=IAR;

            if(II==1) {
                IV1=1;
                IV2=2;
                IV3=3;
                IV4=4;
                XA[II]=(XV[IV1]+XV[IV2]+XV[IV3]+XV[IV4])*0.25;
                YA[II]=(YV[IV1]+YV[IV2]+YV[IV3]+YV[IV4])*0.25;
                ZA[II]=(ZV[IV1]+ZV[IV2]+ZV[IV3]+ZV[IV4])*0.25;
            }

            if(II==2) {
                IV1=1;
                IV2=2;
                IV3=6;
                IV4=5;
                XA[II]=(XV[IV1]+XV[IV2]+XV[IV3]+XV[IV4])*0.25;
                YA[II]=(YV[IV1]+YV[IV2]+YV[IV3]+YV[IV4])*0.25;
                ZA[II]=(ZV[IV1]+ZV[IV2]+ZV[IV3]+ZV[IV4])*0.25;
            }

            UU1[II]=u1(IAR);
            UU2[II]=u2(IAR);
            UU3[II]=u3(IAR);
        }

//-----------------------------------------------------------------------
// *** 3. Loop over all 6 U-nodes
//
        for(II=1;II<=6;II++)
        {
            IAR=IAREA[II];
            IA1=LA.Diag(IAR);
            IA2=LA.Diag(IAR+1)-1;

            for(JJ=1;JJ<=6;JJ++)
            {
                JAR=IAREA[JJ];

                for(IA=IA1;IA<=IA2;IA++)
                {
                    if(LA.Col(IA)==JAR)
                        break;
                }
                if(IA>IA2)
                {
                    std::string message
                        = progname + " (process " + int_to_string(MyProcID) + "):\n"
                        + "  Unrecoverable error discovered:\n"
                        + "    Error in Upwind: entry index IA not found !! "
                        + " IA ="  + int_to_string(IA)
                        + " IA1=" + int_to_string(IA1)
                        + " IA2=" + int_to_string(IA2)
                        + " JAR=" + int_to_string(JAR)
                        + " IAR=" + int_to_string(IAR) + "\n"
                        + "    LA.Diag(" + int_to_string(IAR) + ")=" + int_to_string(LA.Diag(IAR)) + "\n"
                        + "    LA.Diag(" + int_to_string(IAR+1) + ")=" + int_to_string(LA.Diag(IAR+1)) + "\n"
                        + "  Program aborted in CCoarseGrid::Upwind.\n";
//                      for(int i=1;i<=LA.GetNumDiag();i++) {
//                          Err<<"LA.Diag("<<i<<")="<<LA.Diag(i)<<"\n";
//                      }

                    STD_CERR << message;
                    protocol  << message;

                    MPI_Abort(MPI_COMM_WORLD, UPWIND_ERROR);
                } else {
                    ISTORE(II,JJ)=IA;
                    ELMA(II,JJ)=0.0;
                }
            }
        }

        XN(1,1)=YVE[1]*ZVE[2]-ZVE[1]*YVE[2];
        YN(1,1)=ZVE[1]*XVE[2]-XVE[1]*ZVE[2];
        ZN(1,1)=XVE[1]*YVE[2]-YVE[1]*XVE[2];

        XNHH=XA[2]-XA[1];
        YNHH=YA[2]-YA[1];
        ZNHH=ZA[2]-ZA[1];
        DINN=XN(1,1)*XNHH+YN(1,1)*YNHH+ZN(1,1)*ZNHH;
        if(DINN<0.0)
            DNFACT=-1.0;
        else
            DNFACT= 1.0;

        if(DNFACT<0.0) {
            XN(1,1)=-XN(1,1);
            YN(1,1)=-YN(1,1);
            ZN(1,1)=-ZN(1,1);
        }

        XN(2,1)=DNFACT*(YVE[2]*ZVE[3]-ZVE[2]*YVE[3]);
        YN(2,1)=DNFACT*(ZVE[2]*XVE[3]-XVE[2]*ZVE[3]);
        ZN(2,1)=DNFACT*(XVE[2]*YVE[3]-YVE[2]*XVE[3]);

        XN(3,1)= DNFACT*(YVE[3]*ZVE[4]-ZVE[3]*YVE[4]);
        YN(3,1)= DNFACT*(ZVE[3]*XVE[4]-XVE[3]*ZVE[4]);
        ZN(3,1)= DNFACT*(XVE[3]*YVE[4]-YVE[3]*XVE[4]);

        XN(4,1)= DNFACT*(YVE[4]*ZVE[1]-ZVE[4]*YVE[1]);
        YN(4,1)= DNFACT*(ZVE[4]*XVE[1]-XVE[4]*ZVE[1]);
        ZN(4,1)= DNFACT*(XVE[4]*YVE[1]-YVE[4]*XVE[1]);

        XN(1,2)=-XN(1,1);
        YN(1,2)=-YN(1,1);
        ZN(1,2)=-ZN(1,1);

        XN(2,2)=-DNFACT*(YVE[2]*ZVE[6]-ZVE[2]*YVE[6]);
        YN(2,2)=-DNFACT*(ZVE[2]*XVE[6]-XVE[2]*ZVE[6]);
        ZN(2,2)=-DNFACT*(XVE[2]*YVE[6]-YVE[2]*XVE[6]);

        XN(3,2)=-DNFACT*(YVE[6]*ZVE[5]-ZVE[6]*YVE[5]);
        YN(3,2)=-DNFACT*(ZVE[6]*XVE[5]-XVE[6]*ZVE[5]);
        ZN(3,2)=-DNFACT*(XVE[6]*YVE[5]-YVE[6]*XVE[5]);

        XN(4,2)=-DNFACT*(YVE[5]*ZVE[1]-ZVE[5]*YVE[1]);
        YN(4,2)=-DNFACT*(ZVE[5]*XVE[1]-XVE[5]*ZVE[1]);
        ZN(4,2)=-DNFACT*(XVE[5]*YVE[1]-YVE[5]*XVE[1]);

        XN(1,3)=-XN(2,1);
        YN(1,3)=-YN(2,1);
        ZN(1,3)=-ZN(2,1);

        XN(2,3)=-DNFACT*(YVE[3]*ZVE[7]-ZVE[3]*YVE[7]);
        YN(2,3)=-DNFACT*(ZVE[3]*XVE[7]-XVE[3]*ZVE[7]);
        ZN(2,3)=-DNFACT*(XVE[3]*YVE[7]-YVE[3]*XVE[7]);

        XN(3,3)=-DNFACT*(YVE[7]*ZVE[6]-ZVE[7]*YVE[6]);
        YN(3,3)=-DNFACT*(ZVE[7]*XVE[6]-XVE[7]*ZVE[6]);
        ZN(3,3)=-DNFACT*(XVE[7]*YVE[6]-YVE[7]*XVE[6]);

        XN(4,3)=-XN(2,2);
        YN(4,3)=-YN(2,2);
        ZN(4,3)=-ZN(2,2);

        XN(1,4)=-XN(3,1);
        YN(1,4)=-YN(3,1);
        ZN(1,4)=-ZN(3,1);

        XN(2,4)=-DNFACT*(YVE[4]*ZVE[8]-ZVE[4]*YVE[8]);
        YN(2,4)=-DNFACT*(ZVE[4]*XVE[8]-XVE[4]*ZVE[8]);
        ZN(2,4)=-DNFACT*(XVE[4]*YVE[8]-YVE[4]*XVE[8]);

        XN(3,4)=-DNFACT*(YVE[8]*ZVE[7]-ZVE[8]*YVE[7]);
        YN(3,4)=-DNFACT*(ZVE[8]*XVE[7]-XVE[8]*ZVE[7]);
        ZN(3,4)=-DNFACT*(XVE[8]*YVE[7]-YVE[8]*XVE[7]);

        XN(4,4)=-XN(2,3);
        YN(4,4)=-YN(2,3);
        ZN(4,4)=-ZN(2,3);

        XN(1,5)=-XN(4,1);
        YN(1,5)=-YN(4,1);
        ZN(1,5)=-ZN(4,1);

        XN(2,5)=-XN(4,2);
        YN(2,5)=-YN(4,2);
        ZN(2,5)=-ZN(4,2);

        XN(3,5)=-DNFACT*(YVE[5]*ZVE[8]-ZVE[5]*YVE[8]);
        YN(3,5)=-DNFACT*(ZVE[5]*XVE[8]-XVE[5]*ZVE[8]);
        ZN(3,5)=-DNFACT*(XVE[5]*YVE[8]-YVE[5]*XVE[8]);

        XN(4,5)=-XN(2,4);
        YN(4,5)=-YN(2,4);
        ZN(4,5)=-ZN(2,4);

        XN(1,6)=-XN(3,2);
        YN(1,6)=-YN(3,2);
        ZN(1,6)=-ZN(3,2);

        XN(2,6)=-XN(3,5);
        YN(2,6)=-YN(3,5);
        ZN(2,6)=-ZN(3,5);

        XN(3,6)=-XN(3,4);
        YN(3,6)=-YN(3,4);
        ZN(3,6)=-ZN(3,4);

        XN(4,6)=-XN(3,3);
        YN(4,6)=-YN(3,3);
        ZN(4,6)=-ZN(3,3);

        DLEN(1,1)=sqrt(pow(XN(1,1),2)+pow(YN(1,1),2)+pow(ZN(1,1),2));
        DLEN(2,1)=sqrt(pow(XN(2,1),2)+pow(YN(2,1),2)+pow(ZN(2,1),2));
        DLEN(3,1)=sqrt(pow(XN(3,1),2)+pow(YN(3,1),2)+pow(ZN(3,1),2));
        DLEN(4,1)=sqrt(pow(XN(4,1),2)+pow(YN(4,1),2)+pow(ZN(4,1),2));

        DLEN(1,2)=DLEN(1,1);
        DLEN(2,2)=sqrt(pow(XN(2,2),2)+pow(YN(2,2),2)+pow(ZN(2,2),2));
        DLEN(3,2)=sqrt(pow(XN(3,2),2)+pow(YN(3,2),2)+pow(ZN(3,2),2));
        DLEN(4,2)=sqrt(pow(XN(4,2),2)+pow(YN(4,2),2)+pow(ZN(4,2),2));

        DLEN(1,3)=DLEN(2,1);
        DLEN(2,3)=sqrt(pow(XN(2,3),2)+pow(YN(2,3),2)+pow(ZN(2,3),2));
        DLEN(3,3)=sqrt(pow(XN(3,3),2)+pow(YN(3,3),2)+pow(ZN(3,3),2));
        DLEN(4,3)=DLEN(2,2);

        DLEN(1,4)=DLEN(3,1);
        DLEN(2,4)=sqrt(pow(XN(2,4),2)+pow(YN(2,4),2)+pow(ZN(2,4),2));
        DLEN(3,4)=sqrt(pow(XN(3,4),2)+pow(YN(3,4),2)+pow(ZN(3,4),2));
        DLEN(4,4)=DLEN(2,3);

        DLEN(1,5)=DLEN(4,1);
        DLEN(2,5)=DLEN(4,2);
        DLEN(3,5)=sqrt(pow(XN(3,5),2)+pow(YN(3,5),2)+pow(ZN(3,5),2));
        DLEN(4,5)=DLEN(4,4);

        DLEN(1,6)=DLEN(3,2);
        DLEN(2,6)=DLEN(3,5);
        DLEN(3,6)=DLEN(3,4);
        DLEN(4,6)=DLEN(3,3);


        DMEAN=0.5;

        UMEAN1(1,1)=DMEAN*(UU1[2]+UU1[1]);
        UMEAN2(1,1)=DMEAN*(UU2[2]+UU2[1]);
        UMEAN3(1,1)=DMEAN*(UU3[2]+UU3[1]);

        UMEAN1(2,1)=DMEAN*(UU1[3]+UU1[1]);
        UMEAN2(2,1)=DMEAN*(UU2[3]+UU2[1]);
        UMEAN3(2,1)=DMEAN*(UU3[3]+UU3[1]);

        UMEAN1(3,1)=DMEAN*(UU1[4]+UU1[1]);
        UMEAN2(3,1)=DMEAN*(UU2[4]+UU2[1]);
        UMEAN3(3,1)=DMEAN*(UU3[4]+UU3[1]);

        UMEAN1(4,1)=DMEAN*(UU1[5]+UU1[1]);
        UMEAN2(4,1)=DMEAN*(UU2[5]+UU2[1]);
        UMEAN3(4,1)=DMEAN*(UU3[5]+UU3[1]);

        UMEAN1(1,2)=UMEAN1(1,1);
        UMEAN2(1,2)=UMEAN2(1,1);
        UMEAN3(1,2)=UMEAN3(1,1);

        UMEAN1(2,2)=DMEAN*(UU1[3]+UU1[2]);
        UMEAN2(2,2)=DMEAN*(UU2[3]+UU2[2]);
        UMEAN3(2,2)=DMEAN*(UU3[3]+UU3[2]);

        UMEAN1(3,2)=DMEAN*(UU1[6]+UU1[2]);
        UMEAN2(3,2)=DMEAN*(UU2[6]+UU2[2]);
        UMEAN3(3,2)=DMEAN*(UU3[6]+UU3[2]);

        UMEAN1(4,2)=DMEAN*(UU1[5]+UU1[2]);
        UMEAN2(4,2)=DMEAN*(UU2[5]+UU2[2]);
        UMEAN3(4,2)=DMEAN*(UU3[5]+UU3[2]);

        UMEAN1(1,3)=UMEAN1(2,1);
        UMEAN2(1,3)=UMEAN2(2,1);
        UMEAN3(1,3)=UMEAN3(2,1);

        UMEAN1(2,3)=DMEAN*(UU1[4]+UU1[3]);
        UMEAN2(2,3)=DMEAN*(UU2[4]+UU2[3]);
        UMEAN3(2,3)=DMEAN*(UU3[4]+UU3[3]);

        UMEAN1(3,3)=DMEAN*(UU1[6]+UU1[3]);
        UMEAN2(3,3)=DMEAN*(UU2[6]+UU2[3]);
        UMEAN3(3,3)=DMEAN*(UU3[6]+UU3[3]);

        UMEAN1(4,3)=UMEAN1(2,2);
        UMEAN2(4,3)=UMEAN2(2,2);
        UMEAN3(4,3)=UMEAN3(2,2);

        UMEAN1(1,4)=UMEAN1(3,1);
        UMEAN2(1,4)=UMEAN2(3,1);
        UMEAN3(1,4)=UMEAN3(3,1);

        UMEAN1(2,4)=DMEAN*(UU1[5]+UU1[4]);
        UMEAN2(2,4)=DMEAN*(UU2[5]+UU2[4]);
        UMEAN3(2,4)=DMEAN*(UU3[5]+UU3[4]);

        UMEAN1(3,4)=DMEAN*(UU1[6]+UU1[4]);
        UMEAN2(3,4)=DMEAN*(UU2[6]+UU2[4]);
        UMEAN3(3,4)=DMEAN*(UU3[6]+UU3[4]);

        UMEAN1(4,4)=UMEAN1(2,3);
        UMEAN2(4,4)=UMEAN2(2,3);
        UMEAN3(4,4)=UMEAN3(2,3);

        UMEAN1(1,5)=UMEAN1(4,1);
        UMEAN2(1,5)=UMEAN2(4,1);
        UMEAN3(1,5)=UMEAN3(4,1);

        UMEAN1(2,5)=UMEAN1(4,2);
        UMEAN2(2,5)=UMEAN2(4,2);
        UMEAN3(2,5)=UMEAN3(4,2);

        UMEAN1(3,5)=DMEAN*(UU1[6]+UU1[5]);
        UMEAN2(3,5)=DMEAN*(UU2[6]+UU2[5]);
        UMEAN3(3,5)=DMEAN*(UU3[6]+UU3[5]);

        UMEAN1(4,5)=UMEAN1(2,4);
        UMEAN2(4,5)=UMEAN2(2,4);
        UMEAN3(4,5)=UMEAN3(2,4);

        UMEAN1(1,6)=UMEAN1(3,2);
        UMEAN2(1,6)=UMEAN2(3,2);
        UMEAN3(1,6)=UMEAN3(3,2);

        UMEAN1(2,6)=UMEAN1(3,5);
        UMEAN2(2,6)=UMEAN2(3,5);
        UMEAN3(2,6)=UMEAN3(3,5);

        UMEAN1(3,6)=UMEAN1(3,4);
        UMEAN2(3,6)=UMEAN2(3,4);
        UMEAN3(3,6)=UMEAN3(3,4);

        UMEAN1(4,6)=UMEAN1(3,3);
        UMEAN2(4,6)=UMEAN2(3,3);
        UMEAN3(4,6)=UMEAN3(3,3);

        for(II=1;II<=6;II++)
        {
            IM0=II;
            if(II==1) {
                IM[1]=2;
                IM[2]=3;
                IM[3]=4;
                IM[4]=5;
            }

            if(II==2) {
                IM[1]=1;
                IM[2]=3;
                IM[3]=6;
                IM[4]=5;
            }

            if(II==3) {
                IM[1]=1;
                IM[2]=4;
                IM[3]=6;
                IM[4]=2;
            }

            if(II==4) {
                IM[1]=1;
                IM[2]=5;
                IM[3]=6;
                IM[4]=3;
            }

            if(II==5) {
                IM[1]=1;
                IM[2]=2;
                IM[3]=6;
                IM[4]=4;
            }

            if(II==6) {
                IM[1]=2;
                IM[2]=5;
                IM[3]=4;
                IM[4]=3;
            }

            for(I=1;I<=4;I++)
            {
                FLUX[I]=0.5*(XN(I,II)*UMEAN1(I,II)+YN(I,II)*UMEAN2(I,II)+ZN(I,II)*UMEAN3(I,II));

                if(UPSAM>=0.0)
                {
                    if(FLUX[I]>=0.0)
                        DLAM[I]=PHIP(UPSAM*RE*FLUX[I]/sqrt(DLEN(I,II)));
                    else
                        DLAM[I]=PHIM(UPSAM*RE*FLUX[I]/sqrt(DLEN(I,II)));
                } else {
                    DLAM[I]=0.0;
                    if(FLUX[I]>=0.0)
                        DLAM[I]=1.0;
                }
            }
            H1=FLUX[1]*(1.0-DLAM[1]);
            H2=FLUX[2]*(1.0-DLAM[2]);
            H3=FLUX[3]*(1.0-DLAM[3]);
            H4=FLUX[4]*(1.0-DLAM[4]);
            ELMA(IM0,IM0)  =-H1-H2-H3-H4;
            ELMA(IM0,IM[1])= H1;
            ELMA(IM0,IM[2])= H2;
            ELMA(IM0,IM[3])= H3;
            ELMA(IM0,IM[4])= H4;
        }

//-----------------------------------------------------------------------
// *** 4. Loop over all 4 U-nodes:  Addding ELMA(.,.) to matrix A
//
        for(II=1;II<=6;II++)
        {
            for(JJ=1;JJ<=6;JJ++)
            {
                ELMH=ELMA(II,JJ);
                if(fabs(ELMH)>1e-15)
                {
                    IA=ISTORE(II,JJ);
                    LA.Data(IA)+=ELMH;
                }
            }
        }
    } // end for(IEL=1;IEL<=NumElements;IEL++)

    if (Debug) {
        protocol << "DEBUG(" << MyProcID << "):  Leaving CCoarseGrid::UpWind.\n";
        protocol.mFlush();
    }

    return;
}
