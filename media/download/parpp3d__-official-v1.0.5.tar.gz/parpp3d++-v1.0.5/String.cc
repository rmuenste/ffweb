#include "String.h"

String::String(void)
{
  len=0;
  str=0;
}

String::String(const char *str1)
{
  len=strlen(str1);
  str=new char[len+1];
  strcpy(str,str1);
}

String::~String(void)
{
  if(str!=NULL)
    delete str;
}

String& String::operator=(String& astr)
{
  if(len) {
    delete str;
    str=new char[astr.len+1];
    len=astr.len;
    strcpy(str,astr.str);
  } else {
    str=new char[astr.len+1];
    len=astr.len;
    strcpy(str,astr.str);
  }
	
  return *this;
}

String& String::operator=(const char *astr)
{
  if(len) {
    delete str;
		str=new char[strlen(astr)+1];
    len=strlen(astr);
		strcpy(str,astr);
	} else {
		str=new char[strlen(astr)+1];
		len=strlen(astr);
		strcpy(str,astr);
	}
	
	return *this;
}

String& String::operator+=(String& astr)
{
	char *newstr;
	
	newstr=new char[len+astr.len+1];
	
	if(len) {
		strcpy(newstr,str);
		strcpy(newstr+len,astr.str);
		delete str;
		str=newstr;
		len=strlen(newstr);
	} else {
		strcpy(newstr,astr.str);
		str=newstr;
		len=strlen(newstr);
	}
	return *this;
}

String& String::operator+=(const char *astr)
{
	char *newstr;
	
	newstr=new char[len+strlen(astr)+1];
	
	if(len) {
		strcpy(newstr,str);
		strcpy(newstr+len,astr);	
		delete str;
		str=newstr;
		len=strlen(newstr);
	} else {
		strcpy(newstr,astr);	
		str=newstr;
		len=strlen(newstr);
	}
	return *this;
}

String& String::operator+=(unsigned aNumber)
{
	char *newstr,*buf;
	
	buf=new char[20];
	sprintf(buf,"%03d",aNumber);
	newstr=new char[len+strlen(buf)+1];
	
	if(len) {
		strcpy(newstr,str);
		strcpy(newstr+len,buf);	
		delete str;
		delete buf;
		str=newstr;
		len=strlen(newstr);
	} else {
		strcpy(newstr,buf);	
		delete buf;
		str=newstr;
		len=strlen(newstr);
	}
	return *this;
}

String& String::operator+=(int aNumber)
{
	char *newstr,*buf;
	
	buf=new char[20];
	sprintf(buf,"%d",aNumber);
	newstr=new char[len+strlen(buf)+1];
	
	if(len) {
		strcpy(newstr,str);
		strcpy(newstr+len,buf);	
		delete str;
		delete buf;
		str=newstr;
		len=strlen(newstr);
	} else {
		strcpy(newstr,buf);	
		delete buf;
		str=newstr;
		len=strlen(newstr);
	}
	return *this;
}

void String::Info(void)
{
	printf("Laenge=%d\n",len);
	printf("String=%s\n",str);
}
