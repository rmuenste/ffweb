
#ifndef POSTGRIDH

#define POSTGRIDH

#include <MultiGrid_3D.h>
#include <math.h>
#include <ParCompactMatrix.h>
#include "String.h"
#include "Const.h"
#include "blist.h"
#include "Daten.h"


class PostGrid:public MultiGrid_3D
{
protected:
    // Globale Daten
    Daten *Param;
    bIntArraylist_base    *MPostProcess[MAXARRAY];
    bIntArraylist_base    *PostProcess;
    bIntArraylist_base    *MPostProcessConst[MAXARRAY];
    bIntArraylist_base    *PostProcessConst;
    DoubleVector          *MVector[MAXARRAY];
    DoubleVector          *MConstVector[MAXARRAY];

public:
    PostGrid(UNSIGNED NFine,Daten *Pparam);
    ~PostGrid(VOID) {}

    void      CoeffA1(void) {}
    void      CoeffM(void) {}  
    double    Solution   (double X, double Y, double Z, double T) { STD_COUT << "PostGrid:Solution is called! Should not happen!\n"; return 0; } 
    double    SolutionDX (double X, double Y, double Z) { STD_COUT << "PostGrid:SolutionDX is called! Should not happen!\n"; return 0; }
    double    SolutionDY (double X, double Y, double Z) { STD_COUT << "PostGrid:SolutionDY is called! Should not happen!\n"; return 0; }
    double    SolutionDZ (double X, double Y, double Z) { STD_COUT << "PostGrid:SolutionDZ is called! Should not happen!\n"; return 0; }
    double    CoeffBX    (double X, double Y, double Z) { return 0; }
    double    CoeffBY    (double X, double Y, double Z) { return 0; }
    double    CoeffBZ    (double X, double Y, double Z) { return 0; }
    double    RightSideCoeff(double X, double Y, double Z, int IB, int BFIRST) { STD_COUT << "PostGrid:RightSideCoeff is called! Should not happen!\n"; return 0; }
    double    StiffCoeff    (double X, double Y, double Z,
                             int IA, int IB, int BFIRST) { STD_COUT << "PostGrid:StiffCoeff is called! Should not happen!\n"; return 0; }
    void      ExactSol(MultiCompactMatrix* A,DoubleVector *LX,
		       DoubleVector *LB,DoubleVector *LD) {}
    void      PreSmooth(MultiCompactMatrix* A,DoubleVector *LX,
			DoubleVector *LB,DoubleVector *LD,UNSIGNED Steps) {}
    void      PostSmooth(MultiCompactMatrix* A,DoubleVector *LX,
			 DoubleVector *LB,DoubleVector *LD,UNSIGNED Steps) {}
    void      CopyBoundaryData(DoubleVector *LB) {}

//      void      BoundaryProjection();

    void      InitGrid(const char *name);
    void      SetPostProcessInfo(DoubleArray2D *arr,int neigh,int level);
    void      SetPostProcessInfoConst(DoubleArray2D *arr,int neigh,int level);
    void      SetVector(DoubleVector *ptr,int neigh,int level);
    void      SetConstVector(DoubleVector *ptr,int neigh,int level);
    void      OutputVector(int level);
    void      OutputConstVector(int level);
};

#endif
