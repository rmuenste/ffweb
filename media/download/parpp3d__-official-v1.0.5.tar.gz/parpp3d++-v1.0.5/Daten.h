#ifndef DATEN_H

#define DATEN_H

#define BURGERS  1
#define PRESSURE 2


class Daten {
public:
    unsigned int Func;
    std::string  GridFile;

    // === Restart section ========================================================================== //
    unsigned int Restart;
    unsigned int RestartITE;
    std::string  RestartBaseDir;
    std::string  RestartSolFile;
    unsigned int SolFileFrequency;
    unsigned int SolFileNumber;
    std::string  SolFilePrefix;

    // === Partition section ======================================================================== //
    unsigned int PartitionTool;
    unsigned int PartitionCR;
    std::string  PartitionBaseDir;
    std::string  PartitionFile;

    // === equation parameters and some for discretization ========================================== //
    double       EpsEqu;
    unsigned int NFine;
    unsigned int ElemType;
    unsigned int BoundCond;
    unsigned int ICUB;
    unsigned int ICUBRHS;
    unsigned int ICUBMAX;
    unsigned int ICUBL2;
    unsigned int Lump;
    unsigned int Stab;
    double       UpSam;

    // === parameters for solving burgers equation ================================================== //
    unsigned int MinFixpItU;
    unsigned int MaxFixpItU;
//      double       OmgMin;
//      double       OmgMax;
    double       OmgIni;
    unsigned int MinIItU;
    unsigned int MaxIItU;
    double       EpsUChange;
    double       EpsUDefect;
    double       DampUMG;
    double       AMinU;
    double       AMaxU;
    unsigned int PreSteps_burg;
    unsigned int PostSteps_burg;
    unsigned int Solver_burg;
    unsigned int SolverMaxIt_burg;
    unsigned int Smoother_burg;
    unsigned int Cycle_burg;
    double       MGOmega_burg;
    unsigned int SolverType_burg;

    // === parameters for solving pressure poisson equation ========================================= //
    unsigned int MinIItP;
    unsigned int MaxIItP;
    double       EpsPChange;
    double       EpsDivergence;
    double       DampPMG;
    double       AMinP;
    double       AMaxP;
    unsigned int PreSteps_press;
    unsigned int PostSteps_press;
    unsigned int Smoother_press;
    unsigned int SolverType_press;
    unsigned int Solver_press;
    unsigned int SolverMaxIt_press;
    unsigned int Cycle_press;
    double       MGOmega_press;
    unsigned int ProlType_press;

    unsigned     EqType;
    unsigned int PreSteps, PostSteps, Solver, Smoother, Cycle;
    double       MGOmega;
    unsigned int SolverType;

    // === Time iteration parameter ================================================================= //
    int          Method;
    unsigned int MaxTimeIterations;
    double       TEnd;
    double       EpsNS;
    double       DtStart;
    unsigned int TStepControlITE;
    double       Dt;
    double       DtMin;
    double       DtMax;
    double       TInitPhase;
    double       EPSADI;
    double       EPSADL;

    // === Output format, location and frequency ==================================================== //
    std::string  OutputBaseDir;
    unsigned int AVSOutputLevel;
    float        DtAVS;
    std::string  AVSGridFile;
    std::string  AVSSolutionFile;
    unsigned int GMVOutputLevel;
    float        DtGMV;
    std::string  GMVGridFile;
    std::string  GMVSolutionFile;




//      double   XStep;

//      double   Delta;
//      double   Omgega;
//      double   EpsCG;

//      unsigned int MaxItCG;

//      double   Eps;




    // values for pipe flow
    double DiffRohr, Diff5, Diff4, Diff3, Diff2, Diff1;
    int    NumLagenZ, NumLagenRohrZ;
    double StartX, EndX, StartY, EndY, StartZ, StepZ, RohrLength;
};

#endif
