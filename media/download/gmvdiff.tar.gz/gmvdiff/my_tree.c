#include "my_types.h"
#include "my_tree.h"
#include <stdlib.h>
#include <stdio.h>
Daten_Typ Dist_Sum(Daten_Typ *K1,Daten_Typ *K2,Anz_Typ Dim)
{
  Zaehler_Typ i;
  Daten_Typ Erg,D;
  Erg=0.0;
  for(i=0;i<Dim;i++) 
    {
      D=K1[i]-K2[i];
      Erg+=M_abs(D);
    }
  return Erg;
}

Daten_Typ Dist_Max(Daten_Typ *K1,Daten_Typ *K2,Anz_Typ Dim)
{
  Zaehler_Typ i;
  Daten_Typ Erg,D;
  Erg=0.0;
  for(i=0;i<Dim;i++)
    {
      D=K1[i]-K2[i];
      D=M_abs(D);
      Erg=M_max(Erg,D);
    }
  return Erg;
}

static inline Daten_Typ Rel_Error(Daten_Typ A,Daten_Typ B) {
  Daten_Typ D,Scale;
  D=A-B;
  if((Scale=((M_abs(A)+M_abs(B))/2.0))>0.0) D/=Scale;
  return M_abs(D);
}

Daten_Typ Rel_Dist_Max(Daten_Typ *K1,Daten_Typ *K2,Anz_Typ Dim)
{
  Zaehler_Typ i;
  Daten_Typ Erg,D; 
  for(Erg=0,i=0;i<Dim;i++) {
    D=Rel_Error(*(K1++),*(K2++));
    Erg=M_max(Erg,D);
  }
  return Erg;
}

Daten_Typ Rel_Dist_Sum(Daten_Typ *K1,Daten_Typ *K2,Anz_Typ Dim)
{
  Zaehler_Typ i;
  Daten_Typ Erg; 
  for(Erg=0,i=0;i<Dim;i++)
    Erg+=Rel_Error(*(K1++),*(K2++));
  return Erg;
}

void Searchbox(Daten_Typ * P, Daten_Typ Eps, Daten_Typ * Box, Anz_Typ Dim) 
{
  Zaehler_Typ i,j;
  Daten_Typ D;
  Eps=M_max(Eps,0.0);
  for(i=0,j=Dim;i<Dim;i++,j++) {
    D=P[i];
    Box[i]=D-Eps;
    Box[j]=D+Eps;
  }
}

void Rel_Searchbox(Daten_Typ * P, Daten_Typ Eps, Daten_Typ * Box, Anz_Typ Dim)
{
  Zaehler_Typ i,j;
  Daten_Typ D,S1,S2;
  Eps=M_max(Eps,0.0);Eps=M_min(Eps,1.999999);
  S1=(2.0-Eps)/(2.0+Eps);S2=1.0/S1;
  for(i=0,j=Dim;i<Dim;i++,j++) {
    D=P[i];
    if(D>0.0) {
      Box[i]=S1*D;Box[j]=S2*D;
    } else if (D<0.0) {
      Box[i]=S2*D;Box[j]=S1*D;
    } else {
      Box[i]=0.0;Box[j]=0.0;
    }
  }
}

Bool_Typ Eps_Umgebung(Daten_Typ *K1, Daten_Typ *K2,Daten_Typ *Epsilon,
		      Anz_Typ Dim,
		      Daten_Typ (*func)(Daten_Typ *,Daten_Typ *, Anz_Typ))
{
  Daten_Typ D=(*func)(K1,K2,Dim);
  if(D<(*Epsilon)) {
    *Epsilon=D;
    return 1;
  } else return 0; 
}

static void error_report(const char * s)
{
  fprintf(stderr,"%s\n",s);
  exit(EXIT_FAILURE);
}
static Anz_Typ gb_Calc(Anz_Typ Dim) { return 1<<Dim; }

static void gb_Hinzufuegen(Index_Typ ** Liste,Anz_Typ *Num,Index_Typ E)
{
  Index_Typ * Dummy;
  Dummy=(Index_Typ *)realloc(*Liste,sizeof(Index_Typ)*((*Num)+1));
  if(Dummy==NULL)
    error_report("Kein Speicher mehr f�r Listen frei!");
  Dummy[(*Num)++]=E;
  *Liste=Dummy;
}

static gb_Node * gb_create_node(gb_Tree *T,Index_Typ *List,Anz_Typ NList)
{
  Anz_Typ Dim,NDim,*NLM;
  Zaehler_Typ i,j;
  Index_Typ I,**LM;
  gb_Node *N;
  
  if(!NList) return NULL;
  Dim=T->Dim;
  NDim=gb_Calc(Dim);
  N=(gb_Node *)calloc(1,sizeof(gb_Node));
  if(!N) error_report("Kein Speicher mehr frei!");
  if(NList==1) {
    N->Flag=GB_LEAF;
    N->Idx=List[0];
    N->C=NULL;
    N->Next=NULL;
  } else {
    N->Flag=GB_BRANCH;
    N->Idx=0;
    NLM=(Anz_Typ *)calloc(NDim,sizeof(Anz_Typ));
    if(!NLM) error_report("Kein Speicher mehr frei!");
    LM=(Index_Typ **)calloc(NDim,sizeof(Index_Typ *));
    if(!LM) error_report("Kein Speicher mehr frei!");
    N->C=(Daten_Typ *)calloc(Dim,sizeof(Daten_Typ));
    if(!(N->C)) error_report("Kein Speicher mehr frei!");
    N->Next=(gb_Node **)calloc(NDim,sizeof(gb_Node *));
    if(!(N->Next)) error_report("Kein Speicher mehr frei!");
    /* Bestimme Schwerpunkt aller Punkte */
    for(j=0;j<Dim;j++) {
      N->C[j]=0.0;
      for(i=0;i<NList;i++)
	N->C[j]+=(T->K[j])[List[i]];
      N->C[j]/=NList;
    }
    /* Nun sortiere ich die einzelnen Punkte in die Listen ein */
    for(i=0;i<NList;i++) {
      /* Berechne, in welche Liste der Knoten soll */
      for(I=0,j=0;j<Dim;j++) 
	if((T->K[j])[List[i]]>=(N->C[j])) I=I|(1<<j);
      /* F�ge in die berechnete Liste ein */
      gb_Hinzufuegen(&(LM[I]),&(NLM[I]),List[i]);
    }
    /* Ich teste nun auf den Fall einer Endlosrekursion */
    for(i=0;i<NDim;i++)
      if(NLM[i]==NList) {
	for(j=0;j<NList;j++) {
#ifdef USE_LONG_INT
	  fprintf(stderr,"%lu\n",List[j]);
#else
	  fprintf(stderr,"%u\n",List[j]);
#endif
	}
	error_report("Endlosrekursion erreicht!");
      }
    /* Nun verzweige ich rekursiv */
    for(i=0;i<NDim;i++) N->Next[i]=gb_create_node(T,LM[i],NLM[i]);
    /* Freigeben der tempor�ren Datenstrukturen */
    free(NLM);
    for(i=0;i<NDim;i++) free(LM[i]);
    free(LM);
  }
  return N;
}
/* Erzeuge einen neuen Baum.
   1. Parameter = Anzahl der Koordinaten
   2. Parameter = Liste mit Zeigern auf Koordinatenarrays,
                  deren Nummerierung mit 1 anfaengt.
   3. Parameter = Anzahl der Dimensionen.
   Vorsicht: Die beschriebenen Punkte muessen disjunkt sein, da
             ansonsten die Funktion nicht abbricht!
*/
gb_Tree * gb_create (Anz_Typ Num,Daten_Typ * const *K,Anz_Typ Dim)
{
  gb_Tree *T;
  Zaehler_Typ i;
  Index_Typ *List;
  if(gb_Calc(Dim)<=0) error_report("Zu hohe Dimension!");
  T=(gb_Tree *)calloc(1,sizeof(gb_Tree));
  if(T==NULL) 
    error_report("Konnte keinen Speicher f�r einen Baum allozieren!");
  T->Box=(Daten_Typ *)calloc(Dim*2,sizeof(Daten_Typ));
  if(T->Box==NULL)
    error_report("Kein Speicher f�r die Suchbox frei!");
  T->K=(Daten_Typ **)calloc(Dim,sizeof(Daten_Typ *));
  if(T->K==NULL)
    error_report("Kein Speicher f�r die Koordinatenarrays frei!");
  for(i=0;i<Dim;i++) T->K[i]=K[i];
  T->Dim=Dim;
  T->Anz_K=Num;
  List=(Index_Typ *)calloc(Num,sizeof(Index_Typ));
  if(List==NULL)
    error_report("Kein Speicher mehr frei!");
  for(i=1;i<=Num;i++) List[i-1]=i;
  T->N=gb_create_node(T,List,Num);
  free(List);
  return T;
}
/* Bestimme die Dimension des Zerteilten Raumes */
Anz_Typ gb_Get_Dim(gb_Tree * T)
{
  return T->Dim;
}

/* private Hilfsfunktion f�r das Suchen im Baum (noch nicht fertig!) */
static Index_Typ gb_localize(gb_Node * N,Daten_Typ *P,
			     Daten_Typ (*func)(Daten_Typ *,Daten_Typ *, Anz_Typ),
			     Daten_Typ *Eps,Daten_Typ *PO,gb_Tree *T)
{
  Index_Typ I,B,L,UE,OE,Mask,Idx,Dummy;
  Zaehler_Typ j;
  Bool_Typ Uebertrag;
  /* M�gliche F�lle:
     1.) N ist Nullpointer -> return 0
     2.) Blatt ohne enthaltenem Punkt -> return 0=N->Idx
     3.) Blatt mit enthaltenem Punkt -> return N->Idx, wenn in Epsumgebung
     4.) Zweig. Mache Octreevergleich mit der Suchbox und gebe den Wert
         von gb_localize angewendet auf die jeweiligen
         n�chsten Knoten zur�ck.
  */
  if(N==NULL) return 0;
  if(N->Flag==GB_LEAF) {
    for(j=0;j<T->Dim;j++) PO[j]=(T->K[j])[N->Idx];
    return (Eps_Umgebung(P,PO,Eps,T->Dim,func) ? N->Idx : 0);
  }
  else { 
    for(UE=OE=0,j=0;j<T->Dim;j++) {
      /* Wann genau ist die Suchbox total �ber oder unter den Ebenen? */
      if((T->Box[j])>=(N->C[j])) OE=OE|(1<<j);
      if((T->Box[j+(T->Dim)])<=(N->C[j])) UE=UE| (1<<j);
    }
    /* Erzeuge Bitmaske der Variablen Bits */
    Mask=((1<<(T->Dim))-1)^(UE|OE);
    I=Idx=0;
    do {
      Dummy=gb_localize(N->Next[I|OE],P,func,Eps,PO,T);
      if(Dummy) Idx=Dummy;
      /* Incrementiere I innerhalb der variablen Bits */
      for(j=0,Uebertrag=1;j<T->Dim;j++,Uebertrag<<=1) {
	L=1<<j;
	if(L&Mask) {
	  /* Extrahiere altes Bit */
	  B=I&L;
	  I=I^B;
	  /* Bilde XOR f�r neues Bit */
	  I=I|(B^Uebertrag);
	  /* Und nun AND f�r den neuen �bertrag */
	  Uebertrag=Uebertrag&B;
	}
      }
    } while (I);
    return Idx;
  }
}
/* Suche einen Punkt im Baum. Es wird die Knotennummer zurueckgegeben.
   Falls der Knoten nicht gefunden wird, wird 0 zurueckgegeben.
*/
Index_Typ gb_search(gb_Tree * T,Daten_Typ *P,
		    Daten_Typ (*func)(Daten_Typ *,Daten_Typ *, Anz_Typ),
		    void (*Boxfunc)(Daten_Typ *,Daten_Typ,Daten_Typ *,Anz_Typ),
		    Daten_Typ Eps)
{
  Daten_Typ *PO;
  Index_Typ Pos;

  if(T->Anz_K==0) return 0;
  (*Boxfunc)(P,Eps,T->Box,T->Dim);
  PO=(Daten_Typ *)calloc(T->Dim,sizeof(Daten_Typ));
  Pos=gb_localize(T->N,P,func,&Eps,PO,T);
  free(PO);
  if(Pos==0) return 0;
  return Pos;
}

/* Zerstoere Knoten rekursiv (private Funktion )*/

static void gb_destroy_Node(gb_Node *N, Anz_Typ D)
{
  Zaehler_Typ i;
  if(N!=NULL)
    {
      if((N->Flag)==GB_BRANCH) {
	for(i=0;i<D;i++) 
	  {
	    gb_destroy_Node(N->Next[i],D);
	    free(N->Next[i]);
	  }
	free(N->Next);N->Next=NULL;
	free(N->C);N->C=NULL;
      }
    }
}

/* Gebe allen allozierten Speicher wieder frei */
void gb_destroy(gb_Tree **Tin)
{
  gb_Tree * T;
  T=*(Tin);
  gb_destroy_Node(T->N,gb_Calc(T->Dim));
  free(T->N);T->N=NULL;
  free(T->K);
  free(T->Box);
  free(T);*(Tin)=NULL;
}
