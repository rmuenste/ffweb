#include "my_types.h"
#include "my_tree_advanced.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

Daten_Typ Dist_Sum(Daten_Typ *K1,Daten_Typ *K2,Anz_Typ Dim)
{
  Zaehler_Typ i;
  Daten_Typ Erg,D;
  Erg=0.0;
  for(i=0;i<Dim;i++) 
    {
      D=K1[i]-K2[i];
      Erg+=M_abs(D);
    }
  return Erg;
}

Daten_Typ Dist_Max(Daten_Typ *K1,Daten_Typ *K2,Anz_Typ Dim)
{
  Zaehler_Typ i;
  Daten_Typ Erg,D;
  Erg=0.0;
  for(i=0;i<Dim;i++)
    {
      D=K1[i]-K2[i];
      D=M_abs(D);
      Erg=M_max(Erg,D);
    }
  return Erg;
}

static inline Daten_Typ Rel_Error(Daten_Typ A,Daten_Typ B) {
  Daten_Typ D,Scale;
  D=A-B;
  if((Scale=((M_abs(A)+M_abs(B))/2.0))>0.0) D/=Scale;
  return M_abs(D);
}

Daten_Typ Rel_Dist_Max(Daten_Typ *K1,Daten_Typ *K2,Anz_Typ Dim)
{
  Zaehler_Typ i;
  Daten_Typ Erg,D; 
  for(Erg=0,i=0;i<Dim;i++) {
    D=Rel_Error(*(K1++),*(K2++));
    Erg=M_max(Erg,D);
  }
  return Erg;
}

Daten_Typ Rel_Dist_Sum(Daten_Typ *K1,Daten_Typ *K2,Anz_Typ Dim)
{
  Zaehler_Typ i;
  Daten_Typ Erg; 
  for(Erg=0,i=0;i<Dim;i++)
    Erg+=Rel_Error(*(K1++),*(K2++));
  return Erg;
}

void Searchbox(Daten_Typ * P, Daten_Typ Eps, Daten_Typ * Box, Anz_Typ Dim) 
{
  Zaehler_Typ i,j;
  Daten_Typ D;
  Eps=M_max(Eps,0.0);
  for(i=0,j=Dim;i<Dim;i++,j++) {
    D=P[i];
    Box[i]=D-Eps;
    Box[j]=D+Eps;
  }
}

void Rel_Searchbox(Daten_Typ * P, Daten_Typ Eps, Daten_Typ * Box, Anz_Typ Dim)
{
  Zaehler_Typ i,j;
  Daten_Typ D,S1,S2;
  Eps=M_max(Eps,0.0);Eps=M_min(Eps,1.999999);
  S1=(2.0-Eps)/(2.0+Eps);S2=1.0/S1;
  for(i=0,j=Dim;i<Dim;i++,j++) {
    D=P[i];
    if(D>0.0) {
      Box[i]=S1*D;Box[j]=S2*D;
    } else if (D<0.0) {
      Box[i]=S2*D;Box[j]=S1*D;
    } else {
      Box[i]=0.0;Box[j]=0.0;
    }
  }
}

Bool_Typ Eps_Umgebung(Daten_Typ *K1, Daten_Typ *K2,Daten_Typ *Epsilon,
		      Anz_Typ Dim,
		      Daten_Typ (*func)(Daten_Typ *,Daten_Typ *, Anz_Typ))
{
  Daten_Typ D=(*func)(K1,K2,Dim);
  if(D<(*Epsilon)) {
    *Epsilon=D;
    return 1;
  } else return 0; 
}

static void error_report(const char * s)
{
  fprintf(stderr,"%s\n",s);
  exit(EXIT_FAILURE);
}
/*
  static Index_Typ gb_ring_map(Index_Typ I,Anz_Typ N) {
  while(I<0) I+=N;
  return I%N;
  }

  static void gb_Hinzufuegen(Index_Typ ** Liste,Anz_Typ *Num,Index_Typ E) {
  Index_Typ * Dummy;
  if(Liste==NULL)
  error_report("Fehlerhafter Parameter bei der Listenerzeugung!");
  Dummy=(Index_Typ *)realloc(*Liste,sizeof(Index_Typ)*((*Num)+1));
  if(Dummy==NULL)
  error_report("Kein Speicher mehr f�r Listen frei!");
  Dummy[(*Num)++]=E;
  *Liste=Dummy;
  }

  static void gb_Entferne(Index_Typ **Liste,Anz_Typ *Num,Index_Typ Pos) {
  Zaehler_Typ i;
  Index_Typ * D;
  if(Liste==NULL)
  error_report("Fehlerhafter Parameter bei der Listenerzeugung!");
  (*Num)--;
  D=*Liste;
  for(i=Pos;i<(*Num);i++) D[i]=D[i+1];
  // *Liste=(Index_Typ *)realloc(D,sizeof(Index_Typ)*((*Num)+1)); 
  }
*/
/* Erzeugt rekursiv die Knoten des Baumes */
static gb_Node * gb_create_node(gb_Tree *T,Index_Typ *List,Anz_Typ NList,
				Index_Typ *Dim_Aktiv,Anz_Typ NDim_Aktiv,
				Daten_Typ *Mitte,Anz_Typ *Decide)
{
  Index_Typ * Dim_List;
  Daten_Typ Ratio,Dummy;
  Anz_Typ NLM[2];
  Zaehler_Typ i,j,k;
  Index_Typ I,*LM[2];
  gb_Node *N;
  
  if(!NList) return NULL;
  N=(gb_Node *)calloc(1,sizeof(gb_Node));
  if(!N) error_report("Kein Speicher mehr frei!");
  if(NList==1) {
    N->Flag=GB_LEAF;
    N->Idx=List[0];
  } else {
    N->Flag=GB_BRANCH;
    for(i=0;i<2;i++) LM[i]=NULL;  
    /* Ich berechne nun f�r die aktiven Koordinaten Mittel-
       werte und versuche damit die Punkte zu trennen.
       Falls dies misslingt, streiche ich diese Dimension
       aus der Liste. Danach bestimme ich die beste Dimension
       f�r eine Trennung und baue die neuen Listen auf.
       Falls ich jedoch keine geeignete Dimension finden kann,
       so hat das Programm untrennbare Punkte gefunden und
       meldet die Endlosrekursion.
       Gelingt die Trennung, so gehe ich rekursiv weiter.
    */
    for(i=0;i<NDim_Aktiv;i++) {
      j=Dim_Aktiv[i];
      Mitte[j]=0.0;
      Decide[j]=0;
    }
    for(k=0;k<NDim_Aktiv;k++) {
      j=Dim_Aktiv[k];
      for(i=0;i<NList;i++)
	Mitte[j]+=(T->K[j])[List[i]];
      Mitte[j]/=NList;
    }
    /* Der Schwerpunkt steht nun in "Mitte"! 
       Nun berechnem wir, die Anzahl der Elemente, die in den
       einzelnen Listen landen w�rden. */
    for(k=0;k<NDim_Aktiv;k++) {
      j=Dim_Aktiv[k];
      for(i=0;i<NList;i++)
	if((T->K[j])[List[i]]>=Mitte[j]) (Decide[j])++;
    }
    /* Anschlie�end entfernen wir alle nicht mehr aktiven Dimensionen */
    Dim_List=(Index_Typ *)calloc(T->Dim,sizeof(Index_Typ));
    if(Dim_List==NULL) error_report("Kein Speicher mehr frei!");
    for(k=0,i=0;k<NDim_Aktiv;k++) {
      j=Dim_Aktiv[k];
      if((Decide[j]!=0)&&(Decide[j]!=NList)) {
	/* Rette diese Dimension wenn n�tig */
	Dim_List[i]=j;
	i++;
      }
    }
    NDim_Aktiv=i;
    Dim_Aktiv=Dim_List;
    /* Teste, ob wir nicht mehr trennbare Punkte haben */
    if(!NDim_Aktiv) {
      for(j=0;j<NList;j++) {
#ifdef USE_LONG_INT
	fprintf(stderr,"%lu\n",List[j]);
#else
	fprintf(stderr,"%u\n",List[j]);
#endif
      }
      error_report("Endlosrekursion erreicht!");
    }
    /* Nun bestimmen wir die beste der aktiven Dimensionen
       f�r eine Trennung */
    N->Split_Dim=Dim_Aktiv[0];
    Ratio=(Decide[N->Split_Dim]/NList)-0.5;
    Ratio=M_abs(Ratio);
    for(k=1;k<NDim_Aktiv;k++) {
      j=Dim_Aktiv[k];
      Dummy=(Decide[j]/NList)-0.5;
      Dummy=M_abs(Dummy);
      if(Dummy<Ratio) {
	N->Split_Dim=j;
	Ratio=Dummy;
      }
    }
    N->C=Mitte[N->Split_Dim];
    /* Initialisierung der neuen Listen (die Gr��e alter Listen
       wird automatisch beim n�chsten Einf�gen eines Elementes
       korrigiert) */
    j=N->Split_Dim;
    for(i=0;i<2;i++)
      NLM[i]=0;
    LM[0]=calloc(NList-Decide[j],sizeof(Index_Typ));
    LM[1]=calloc(Decide[j],sizeof(Index_Typ));
    if((LM[0]==NULL)||(LM[1]==NULL)) 
      error_report("Kein Speicher mehr frei!");
    /* Einsortieren */
    for(i=0;i<NList;i++) {
      I=((T->K[j])[List[i]]>=(N->C))? 1 : 0;
      LM[I][NLM[I]]=List[i];
      NLM[I]++;
    }
    /* Nun verzweige ich rekursiv */
    for(i=0;i<2;i++)
      N->Next[i]=gb_create_node(T,LM[i],NLM[i],Dim_List,NDim_Aktiv,Mitte,Decide);
    /* Freigeben der tempor�ren Datenstrukturen */
    for(i=0;i<2;i++) free(LM[i]);
    free(Dim_List);
  }
  return N;
}
/* Erzeuge einen neuen Baum.
   1. Parameter = Anzahl der Koordinaten
   2. Parameter = Liste mit Zeigern auf Koordinatenarrays,
                  deren Nummerierung mit 1 anfaengt.
   3. Parameter = Anzahl der Dimensionen.
   Vorsicht: Die beschriebenen Punkte muessen disjunkt sein, da
             ansonsten die Funktion nicht abbricht!
*/
gb_Tree * gb_create (Anz_Typ Num,Daten_Typ * const *K,Anz_Typ Dim)
{
  gb_Tree *T;
  Zaehler_Typ i;
  Index_Typ *List;
  Index_Typ *Dim_List;
  Daten_Typ *Mitte;
  Anz_Typ *Decide;

  T=(gb_Tree *)calloc(1,sizeof(gb_Tree));
  if(T==NULL) 
    error_report("Konnte keinen Speicher f�r einen Baum allozieren!");
  T->Box=(Daten_Typ *)calloc(Dim*2,sizeof(Daten_Typ));
  if(T->Box==NULL)
    error_report("Kein Speicher f�r die Suchbox frei!");
  T->K=(Daten_Typ **)calloc(Dim,sizeof(Daten_Typ *));
  if(T->K==NULL)
    error_report("Kein Speicher f�r die Koordinatenarrays frei!");
  for(i=0;i<Dim;i++) T->K[i]=K[i];
  T->Dim=Dim;
  T->Anz_K=Num;
  List=(Index_Typ *)calloc(Num,sizeof(Index_Typ));
  Dim_List=(Index_Typ *)calloc(Dim,sizeof(Index_Typ));
  Mitte=(Daten_Typ *)calloc(Dim,sizeof(Daten_Typ));
  Decide=(Anz_Typ *)calloc(Dim,sizeof(Anz_Typ));
  if((List==NULL)||(Dim_List==NULL)||(Mitte==NULL))
    error_report("Kein Speicher mehr frei!");
  for(i=1;i<=Num;i++) List[i-1]=i;
  for(i=0;i<Dim;i++) Dim_List[i]=i;
  T->N=gb_create_node(T,List,Num,Dim_List,Dim,Mitte,Decide);
  free(Decide);
  free(Mitte);
  free(Dim_List);
  free(List);
  return T;
}
/* Bestimme die Dimension des Zerteilten Raumes */
Anz_Typ gb_Get_Dim(gb_Tree * T)
{
  return T->Dim;
}

/* private Hilfsfunktion f�r das Suchen im Baum */
/* noch anzupassen! */
static Index_Typ gb_localize(gb_Node * N,Daten_Typ *P,
			     Daten_Typ (*func)(Daten_Typ *,Daten_Typ *, Anz_Typ),
			     Daten_Typ *Eps,Daten_Typ *PO,gb_Tree *T)
{
  Index_Typ I,Dummy,Idx;
  Zaehler_Typ j;
  /* M�gliche F�lle:
     1.) N ist Nullpointer -> return 0
     2.) Blatt ohne enthaltenem Punkt -> return 0=N->Idx
     3.) Blatt mit enthaltenem Punkt -> return N->Idx
     4.) Zweig. Mache Octreevergleich und gebe den Wert
         von gb_localize angewendet auf den jeweiligen
         n�chsten Knoten zur�ck.
  */
  if(N==NULL) return 0;
  if(N->Flag==GB_LEAF) {
    for(j=0;j<T->Dim;j++) PO[j]=(T->K[j])[N->Idx];
    return (Eps_Umgebung(P,PO,Eps,T->Dim,func) ? N->Idx : 0);
  }
  else {
    j=N->Split_Dim;
    if((T->Box[j])>=(N->C)) I=0;
    else if ((T->Box[j+T->Dim])<=(N->C)) I=1;
    else I=2;
    switch(I) {
    case 0: return gb_localize(N->Next[1],P,func,Eps,PO,T);
    case 1: return gb_localize(N->Next[0],P,func,Eps,PO,T);
    }
    Idx=gb_localize(N->Next[0],P,func,Eps,PO,T);
    Dummy=gb_localize(N->Next[1],P,func,Eps,PO,T);
    if(Dummy) Idx=Dummy;
    return Idx;
  }
}
/* Suche einen Punkt im Baum. Es wird die Knotennummer zurueckgegeben.
   Falls der Knoten nicht gefunden wird, wird 0 zurueckgegeben.
*/
Index_Typ gb_search(gb_Tree * T,Daten_Typ *P,
		    Daten_Typ (*func)(Daten_Typ *,Daten_Typ *, Anz_Typ),
		    void (*Boxfunc)(Daten_Typ *,Daten_Typ,Daten_Typ *,Anz_Typ),
		    Daten_Typ Eps)
{
  Daten_Typ *PO;
  Index_Typ Pos;

  if(T->Anz_K==0) return 0;
  (*Boxfunc) (P,Eps,T->Box,T->Dim);
  PO=(Daten_Typ *)calloc(T->Dim,sizeof(Daten_Typ));
  Pos=gb_localize(T->N,P,func,&Eps,PO,T);
  free(PO);
  if(Pos==0) return 0;
  return Pos;
}

/* Zerstoere Knoten rekursiv (private Funktion) */

static void gb_destroy_Node(gb_Node *N)
{
  Zaehler_Typ i;
  if(N!=NULL)
    {
      if((N->Flag)==GB_BRANCH) {
	for(i=0;i<2;i++) {
	  gb_destroy_Node(N->Next[i]);
	  N->Next[i]=NULL;
	}
      }
    }
}

/* Gebe allen allozierten Speicher wieder frei */
void gb_destroy(gb_Tree **Tin)
{
  gb_Tree * T;
  T=*(Tin);
  gb_destroy_Node(T->N);
  free(T->N);T->N=NULL;
  free(T->K);T->K=NULL;
  free(T->Box);
  free(T);*(Tin)=NULL;
}
