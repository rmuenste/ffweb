#ifndef MY_THREE_H
#define MY_THREE_H


#include "my_types.h"

/* Hier werden diverse Distanzma�e definiert */
Daten_Typ Dist_Sum(Daten_Typ * A, Daten_Typ * B, Anz_Typ Dim);
Daten_Typ Dist_Max(Daten_Typ * A, Daten_Typ * B, Anz_Typ Dim);
Daten_Typ Rel_Dist_Sum(Daten_Typ * A,Daten_Typ * B, Anz_Typ Dim);
Daten_Typ Rel_Dist_Max(Daten_Typ * A,Daten_Typ * B, Anz_Typ Dim);
/* Nun die dazugeh�rigen Suchboxfunktionen */
void Searchbox(Daten_Typ * P, Daten_Typ Eps, Daten_Typ * Box, Anz_Typ Dim);
void Rel_Searchbox(Daten_Typ * P, Daten_Typ Eps, Daten_Typ * Box, Anz_Typ Dim);
/* Nun teste ich, ob zwei Punkte eine Distanz kleiner
   als ein gegebenes Epsilon in irgendeinem Ma� 
   voneinander haben. */
Bool_Typ Eps_Umgebung(Daten_Typ * A, Daten_Typ * B, Daten_Typ * Eps, Anz_Typ Dim,
		      Daten_Typ (*Measure)(Daten_Typ *,Daten_Typ *, Anz_Typ));
    
 
/* Praefix ist gb fuer geometrische Bisektion */
#define GB_LEAF 0
#define GB_BRANCH 1

typedef struct gb_Node{
  int Flag; /* GB_LEAF/GB_BRANCH */
  Index_Typ Idx; /* Wird nur bei Flag==GB_LEAF benutzt */
  Index_Typ Split_Dim; /* Die Dimension, entlang der aufgespalten wird */
  Daten_Typ C; /* Bezeichnet das Zentrum des Baumes in der 
		  angegebenen Dimension wenn Flag==GB_BRANCH */
  /* Liste der Nachfolgerknoten. Wenn Flag==GB_LEAF => Next=NULL */
  struct gb_Node *Next[2];
} gb_Node;

typedef struct gb_Tree{
  Anz_Typ Dim; /* Wieviele Dimensionen ? */
  Daten_Typ *Box; /* 2*Dim Koordinaten reserviert f�r Suchboxen */
  Anz_Typ Anz_K; /* Wieviele gueltige Koordinaten ? */
  Daten_Typ ** K; /* Listen mit den einzelnen Koordinaten.
                     Die Koordinaten fangen ab dem 2. Element an */
  gb_Node * N;
} gb_Tree;

/* Erzeuge einen neuen Baum.
   1. Parameter = Anzahl der Koordinaten
   2. Parameter = Liste mit Zeigern auf Koordinatenarrays,
                  deren Nummerierung mit 1 anfaengt.
   3. Parameter = Anzahl der Dimensionen.
   Vorsicht: Die beschriebenen Punkte muessen disjunkt sein, da
             ansonsten die Funktion nicht abbricht!
	     Zudem werden die einzelnen Koordinatenarrays nicht
	     kopiert (aus Effizienzgr�nden).
*/
gb_Tree * gb_create (Anz_Typ Anzahl, Daten_Typ * const * Koordinaten,
		     Anz_Typ Dim);
/* Bestimme die Dimension des Zerteilten Raumes */
Anz_Typ gb_Get_Dim(gb_Tree * Zeiger_auf_Baum);
/* Suche einen Punkt im Baum. Es wird die Knotennummer zurueckgegeben.
   Falls der Knoten nicht gefunden wird, wird 0 zurueckgegeben.
*/
Index_Typ gb_search(gb_Tree * T, Daten_Typ * P,
		    Daten_Typ (*Distfunc)(Daten_Typ *,Daten_Typ *, Anz_Typ),
		    void (*Boxfunc)(Daten_Typ *,Daten_Typ,Daten_Typ *,Anz_Typ),
		    Daten_Typ Epsilon);
/* Gebe allen allozierten Speicher wieder frei */
void gb_destroy(gb_Tree ** Zeiger_auf_Zeiger_auf_Baum);

#endif
