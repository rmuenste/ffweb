#ifndef MY_TYPES_H
#define MY_TYPES_H

#define M_abs(x)         ((x) < 0 ? -(x) : (x))
#define M_max(x,y)      ((x) < (y) ? (y) : (x))
#define M_min(x,y)      ((x) < (y) ? (x) : (y))

typedef int Bool_Typ;
#define TRUE 1
#define FALSE 0

#ifndef USE_LONG_DOUBLE
typedef double Daten_Typ;
#else
typedef long double Daten_Typ;
#endif

#ifndef USE_LONG_INT
typedef unsigned int Index_Typ;
#else
typedef unsigned long int Index_Typ;
#endif
typedef Index_Typ Zaehler_Typ;
typedef Index_Typ Anz_Typ;

#endif
