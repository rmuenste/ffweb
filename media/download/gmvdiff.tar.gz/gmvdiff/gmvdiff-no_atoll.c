#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

/* Hier stehen die forgeschritteneren Sachen */
#define STDC_HEADERS  1
#include "getline.h"

#include <string.h>
#include <ctype.h>


#include <regex.h>

/* Hier werden meine eigenen Datentypen definiert */
#include "my_types.h"
#include "my_tree.h"

const char temp_path[]="/tmp";
const Daten_Typ Eps_Dist=0.5E-2;

#define NUM_COMPRESS 3
const char * Data_Compress[NUM_COMPRESS][2]={
  {"Z","uncompress -c --"},
  {"gz","gzip -dc --"},
  {"bz2","bzip2 -dc --"}
};
/* Nun noch ein paar globale Flags, die das Programm-
   verhalten beeinflussen sollen.
*/
Bool_Typ Flag_Fast=FALSE,Flag_Zero=FALSE;
Anz_Typ Dim=3;

/* Die Datentypen, die alle Gitter und Daten speichern */
typedef struct
{
  Anz_Typ Anz_Nodes;
  Daten_Typ *K[3];
} Nodes_Typ;

typedef struct 
{
  Nodes_Typ Nodes;
  /* wird hier nicht verwendet: Cells_Typ Cells; */	
} Gitter_Typ;

typedef struct
{
  Gitter_Typ Gitter;
  Daten_Typ *V[3];
  Anz_Typ Num_Fields;
  char ** Field_Names;
  Daten_Typ **Data_Fields;
} Dataset_Typ;

void Add_Field_Name(const char * s,Anz_Typ *n,char ***name) {
  (*n)++;
  *name=(char **) realloc(*name,sizeof(char *)*(*n));
  (*name)[(*n)-1]=strdup(s);
}

Index_Typ Search_Field_Name(const char *s,Anz_Typ n,char **name) {
  Zaehler_Typ i;
  for(i=0;i<n;i++)
    if(strcmp(s,name[i])==0) return i;
  return n;
}

void Lese_Daten(FILE *f,Anz_Typ Anz,Daten_Typ *Daten) {
  Zaehler_Typ i;
  if(Daten==NULL)
    {
      for(i=0;i<Anz;i++) fscanf(f,"%*f");
    }
  else
    {
      for(i=0;i<Anz;i++,Daten++)
#ifndef USE_LONG_DOUBLE 
	fscanf(f,"%lf",Daten);
#else
	fscanf(f,"%Lf",Daten);
#endif
    }
}

void Schreibe_Daten(FILE *f,Anz_Typ Anz,Daten_Typ *Daten) {
  Zaehler_Typ i;
  if(Daten==NULL)
    {
      for(i=0;i<Anz;i++) fprintf(f,"%.8f\n",0.0);
    }
  else
    {
      for(i=0;i<Anz;i++,Daten++)
#ifndef USE_LONG_DOUBLE
	fprintf(f,"%.10E\n",*Daten);
#else
	fprintf(f,"%.16LE\n",*Daten);
#endif
    }
}

void Lese_Anz(FILE *f,Anz_Typ *Anz) {
  if(Anz==NULL) fscanf(f,"%*u");
  else
#ifndef USE_LONG_INT
    fscanf(f,"%u",Anz);
#else
  fscanf(f,"%lu",Anz);
#endif
}
void Schreibe_Anz(FILE *f,Anz_Typ Anz) {
#ifndef USE_LONG_INT
  fprintf(f,"%u\n",Anz);
#else
  fprintf(f,"%lu\n",Anz);
#endif
}

/* Schneide f�hrende und nachfolgende Leerzeichen ab.
   Zeilenendezeichen werden am Ende auch abgeschnitten.
*/
char * trim_line(char *s) {
  Anz_Typ len,num_pos,i;
  if(s==NULL) return NULL;
  len=strlen(s);
  if(len>0)
    if(s[len-1]=='\n') s[--len]=(unsigned char)(0);
  if(len>0)
    while(s[len-1]==' ') s[--len]=(unsigned char)(0);
  num_pos=0;
  if(len>0) {
    while(s[num_pos]==' ') num_pos++;
    for(i=0;i<(len-num_pos);i++) s[i]=s[i+num_pos];
    s[len-num_pos]='\0';
  }
  return s;
}

/* Gibt den Offset des n�chsten Parameters zur�ck.
   Im Fehlerfall wird 0 zur�ckgegeben.
   Zudem werden die Flags gesetzt.
*/
int Get_Flags(int argc,char **argv) {
  int c;
  extern int optind;
  while((c=getopt(argc,argv,"fz2"))!=EOF) {
    switch(c) {
    case 'f': Flag_Fast=TRUE;break;
    case 'z': Flag_Zero=TRUE;break;
    case '2': Dim=2;break;
    case '?': return 0;
    }
  }
  return optind;
}

/* Test, ob eine Datei existiert */
Bool_Typ Datei_Existiert(const char *Name)
{
  FILE *f;
  f=fopen(Name,"r");
  if(f==NULL) return FALSE;
  fclose(f);
  return TRUE;
}

/* �ffnet auch komprimierte Dateien zum Lesen.
   Es kann auch eine optionale Standarderweiteung
   angegeben werden (ohne Punkt)
*/

FILE * my_fopen(const char *filename,const char *std_ext) {
  Anz_Typ Len_File,Len_StdExt,Max_Len_CmpExt,
    Max_Len_Cmp,Temp_Path_Len,Dummy;
  Zaehler_Typ i,j;
  Bool_Typ Add_Slash;
  Anz_Typ Buffer_Len;
  char * Buffer[2],*Sys_Buffer,*fname=NULL;
  FILE *f=NULL;
  static unsigned int Counter=0;

  Temp_Path_Len=strlen(temp_path);
  Add_Slash=(temp_path[Temp_Path_Len-1]=='/' ? FALSE : TRUE);
  if (Temp_Path_Len==0) Add_Slash=FALSE;
  Len_File=strlen(filename);
  Len_StdExt=strlen(std_ext);
  Max_Len_CmpExt=Max_Len_Cmp=0;
  for(i=0;i<NUM_COMPRESS;i++) {
    Dummy=strlen(Data_Compress[i][0]);
    Max_Len_CmpExt=M_max(Max_Len_CmpExt,Dummy);
    Dummy=strlen(Data_Compress[i][1]);
    Max_Len_Cmp=M_max(Max_Len_Cmp,Dummy);
  }
  Buffer_Len=Temp_Path_Len+(Add_Slash ?1:0)+Len_File+Len_StdExt
    +Max_Len_CmpExt+2+Max_Len_Cmp+3+26+1;
  Buffer[0]=(char *)calloc(Buffer_Len,sizeof(char));
  Buffer[1]=(char *)calloc(Buffer_Len,sizeof(char));
  Sys_Buffer=(char *)calloc(Buffer_Len,sizeof(char));
  /* Zuerst bearbeite ich die Standardf�lle */
  snprintf(Buffer[0],Buffer_Len,"%s",filename);
  if(Datei_Existiert(Buffer[0])) {
    fname=Buffer[0];
    goto next;
  }
  snprintf(Buffer[1],Buffer_Len,"%s.%s",filename,std_ext);
  if(Datei_Existiert(Buffer[1])) {
    fname=Buffer[1];
    goto next;
  }
  /* Nun suche ich nach komprimierten Dateien */
  i=0;
  while(i<NUM_COMPRESS) {
    snprintf(Buffer[0],Buffer_Len,"%s.%s",
	     filename,Data_Compress[i][0]);
    snprintf(Buffer[1],Buffer_Len,"%s.%s.%s",
	     filename,std_ext,Data_Compress[i][0]);
    for(j=0;j<2;j++)
      if(Datei_Existiert(Buffer[j])) {
	fname=Buffer[j];
	goto unpack;
      }  
    /**/
    i++;
  }
  goto skip;
  /**/
 unpack:snprintf(Sys_Buffer,Buffer_Len,"%s %s >%s%s%ld_%d",
		 Data_Compress[i][1],fname,temp_path,
		 (Add_Slash ?"/":""),getpid,Counter);
  system(Sys_Buffer);
  snprintf(Sys_Buffer,Buffer_Len,"%s%s%ld_%d",temp_path,
		 (Add_Slash ?"/":""),getpid,Counter);
  fname=Sys_Buffer;
  Counter++;
 next: f=fopen(fname,"r");
 skip:free(Buffer[0]);free(Buffer[1]);free(Sys_Buffer);
  return f;
}
/* R�umt tempor�re Dateien auf */
void cleanup_temps(void) {
  Anz_Typ Temp_Path_Len;
  Bool_Typ Add_Slash;
  Anz_Typ Buffer_Len;
  char * Sys_Buffer;

  Temp_Path_Len=strlen(temp_path);
  Add_Slash=(temp_path[Temp_Path_Len-1]=='/' ? FALSE : TRUE);
  if (Temp_Path_Len==0) Add_Slash=FALSE;
  Buffer_Len=Temp_Path_Len+(Add_Slash ?1:0)+8+25+1;
  Sys_Buffer=(char *)calloc(Buffer_Len,sizeof(char));
  snprintf(Sys_Buffer,Buffer_Len,"rm -f %s%s%ld_*",
	   temp_path,(Add_Slash ?"/":""),getpid);
  system(Sys_Buffer);
  free(Sys_Buffer);
}

signed int mygetline(char **line, size_t *line_chars_allocated, FILE *stream)
{
  signed int line_length;
  line_length = getline (line, line_chars_allocated, stream);
  if (line_length <= 0) {
    if (*line) {
      free (*line);
      *line=NULL;
      *line_chars_allocated=0;
    }
  }
  return line_length;
}

/* Liest solange weiter, bis entweder das Ende der Datei erreicht ist,
   oder man eine nichtleere Zeile erreicht hat. Diese wird dann noch
   getrimmt.
   R�ckgabwert: Flag, ob das Zeilenende oder Fehler erreicht wurde.
*/
Bool_Typ getline_trimmed(char **line,size_t *line_chars_allocated,FILE *f) {
  signed int line_length;
  if((line==NULL)||(line_chars_allocated==NULL)) {
    fprintf(stderr,"Parameterfehler in getline_trimmed!\n");
    return TRUE;
  }
  do {
    line_length=mygetline(line,line_chars_allocated,f);
    /* Zeilenende */
    if(line_length<0) break;
    if((*line)!=NULL) {
      trim_line(*line);
    }
  } while((*line)==NULL ? 1 :strlen(*line)==0);
  return (((*line)==NULL)||(line_length<0)? TRUE : FALSE);
}

/* �ffne eine GMV-Datei und teste auf ascii Format. */
FILE * gmv_open(const char *filename) {
  FILE *f;
  size_t chars_allocated=0;
  char * line=NULL;
  /* Debug */ fprintf(stderr,"Versuche %s zu �ffnen!\n",filename);
  f=my_fopen(filename,"gmv");
  if(f==NULL) return NULL;
  /* Debug */ fprintf(stderr,"Datei ist nun offen!\n");
  mygetline(&line,&chars_allocated,f);
  if (strncasecmp(line, "gmvinput ascii", 14) != 0) {
    fprintf (stderr,"Fehler: Keine (ascii) GMV-Datei!\n");
    free(line);
    fclose(f);
    return NULL;
  }
  free(line);
  /* Debug */ fprintf(stderr,"Header war in Ordnung!\n"); fflush(stderr);
  return f;
}

Bool_Typ Scan_Name(FILE *f,const char *st) {
  size_t len,n=0;
  char *s=NULL;
  Bool_Typ Test=FALSE;
  if(st==NULL) return TRUE;
  len=strlen(st);
  while(Test==FALSE) {
    Test=(getline_trimmed(&s,&n,f)==TRUE ?TRUE:Test);
    if(s!=NULL) {
      Test=(strncasecmp(s,st,len)!=0 ? Test : TRUE);
    }
  }
  if(s==NULL) return TRUE;
  free(s);
  return FALSE;
}
/* Gekapselte Routine zum Schlie�en der GMV-Datei */
void gmv_close(FILE *f) {
  fclose(f);
}

Bool_Typ gmv_Lese_Nodes(FILE *f,Nodes_Typ *Nodes) {
  Bool_Typ Test=FALSE;
  char * s=NULL,* s1;
  regex_t posix_regexp;
  size_t n=0,n1;
  size_t   nmatch = 5;
  regmatch_t matchptr[5];
  Anz_Typ Anz_Nodes;
  Zaehler_Typ i;
  FILE *f1;
  /* Debug */ fprintf(stderr,"gmv_Lese_Nodes\n");
  /* Debug */ fprintf(stderr,"Suche Nodeszeile...");
  while(Test==FALSE) {
    Test=(getline_trimmed(&s,&n,f)?TRUE:Test);
    if(s!=NULL) {
      Test=(strncasecmp(s,"nodes ",6)!=0 ? Test : TRUE);
    }
  }
  /* Debug */ fprintf(stderr," gefunden!\n");
  if(s==NULL) return TRUE;
  /* Nun teste ich auf Fromfile */
  regcomp (&posix_regexp, "[[:space:]]*nodes[[:space:]]+fromfile[[:space:]]+\"([^[:space:]]+)\"", REG_EXTENDED);
  if (0 == regexec (&posix_regexp, s, nmatch, matchptr, 0)) {
    n1= matchptr[1].rm_eo - matchptr[1].rm_so;
    s1=(char *)calloc(n1+1,sizeof(char));
    strncpy(s1,&s[matchptr[1].rm_so],n1);
    s1[n1]='\0';
    free(s);
    regfree(&posix_regexp);
    f1=gmv_open(s1);
    if(f1==NULL) {
      fprintf(stderr,"Datei %s nicht gefunden!",s1);
      free(s1);
      return TRUE;
    }
    free(s1);
    if(gmv_Lese_Nodes(f1,Nodes)==TRUE) { 
      gmv_close(f1);
      return TRUE;
    } else return FALSE;
  }
  else {
    regfree(&posix_regexp);
#ifdef USE_LONG_INT
    Anz_Nodes=atol(&s[6]);
#else
    Anz_Nodes=atoi(&s[6]);
#endif
    if(atol(&s[6])<0) {
      free(s);
      return TRUE;
    }
    free(s);
    Nodes->Anz_Nodes=Anz_Nodes;
    for(i=0;i<Dim;i++)
      Nodes->K[i]=(Daten_Typ *)calloc(Anz_Nodes+1,sizeof(Daten_Typ));
    for(i=0;i<3;i++) {
      if(i<Dim) Lese_Daten(f,Anz_Nodes,Nodes->K[i]+1);
      else Lese_Daten(f,Anz_Nodes,NULL);
    }
  }
  return FALSE;
}
Bool_Typ gmv_Ignoriere_Zellen(FILE *f){
  Bool_Typ Test=FALSE;
  char * s=NULL;
  regex_t posix_regexp;
  size_t n=0;
  size_t   nmatch = 5;
  regmatch_t matchptr[5];
  Anz_Typ Anz_Cells;
  Zaehler_Typ i;
  while(Test==FALSE) {
    Test=(getline_trimmed(&s,&n,f)==TRUE ?TRUE:Test);
    if(s!=NULL) {
      Test=(strncasecmp(s,"cells ",6)!=0 ? Test : TRUE);
    }
  }
  if(s==NULL) return TRUE;
  /* Nun teste ich auf Fromfile */
  regcomp (&posix_regexp, "[[:space:]]*cells[[:space:]]+fromfile[[:space:]]+\"([^[:space:]]+)\"", REG_EXTENDED);
  if (0 == regexec (&posix_regexp, s, nmatch, matchptr, 0)) {
    regfree(&posix_regexp);
    free(s);
    return FALSE;
  }
  else {
    regfree(&posix_regexp);
#ifdef USE_LONG_INT
    Anz_Cells=atol(&s[6]);
#else
    Anz_Cells=atoi(&s[6]);
#endif
    if(atol(&s[6])<0) {
      free(s);
      return TRUE;
    }
    for(i=0;i<Anz_Cells*2;i++)
      getline_trimmed(&s,&n,f);
  }
  return FALSE;
}

/* Liest ein Gitter ein (da wir keine Zellinformationen
   ben�tigen, werden diese �berlesen).
*/
Bool_Typ gmv_Lese_Gitter(FILE *f,Gitter_Typ *Gitter) {
  /* Debug */ fprintf(stderr,"gmv_Lese_Gitter (Beginn)\n");
  /* Debug */ fprintf(stderr,"Nodes Lesen...\n");
  if(gmv_Lese_Nodes(f,&(Gitter->Nodes))==TRUE) return TRUE;
  /* Debug */ fprintf(stderr,"Cells Lesen...\n");
  if(gmv_Ignoriere_Zellen(f)==TRUE) return TRUE;
  /* Debug */ fprintf(stderr,"gmv_Lese_Gitter (Ende)\n");
  return FALSE;
}

/* Extrahiert aus :"fieldname" 1 den Feldnamen */
char * Extract_Field_Name(const char *s){
  char * s1;
  size_t n1,nmatch=5;
  int n;
  regex_t posix_regexp;
  regmatch_t matchptr[5];
  if(s==NULL) return NULL;
  regcomp (&posix_regexp, "[[:space:]]*([^[:space:]]+)", REG_EXTENDED);
  if (0 == regexec (&posix_regexp, s, nmatch, matchptr, 0)) {
    n1=matchptr[1].rm_eo - matchptr[1].rm_so;
    s1=(char *) calloc(n1+1,sizeof(char));
    strncpy(s1,s+matchptr[1].rm_so,n1);
    n=atoi(s+matchptr[1].rm_eo);
    /* Debug */ fprintf(stderr,"Feldname: %s, Typ %d\n",s1,n);
    regfree (&posix_regexp);
    if(n!=1) {
      fprintf(stderr,"Fehler: Nur Node-Datenfelder erlaubt!\n");
      free(s1);
      return NULL;
    }
    return s1;
  } else return NULL;
}

Bool_Typ gmv_Lese_Dataset(FILE *f,Dataset_Typ *DSet) {
  Zaehler_Typ i;
  char *s=NULL,*s1;
  size_t n=0;
  off_t Pos;

  /* Debug */ fprintf(stderr,"gmv_Lese_Dataset (Beginn)\n");
  /* Debug */ fprintf(stderr,"Einlesen der Gitterinformation...\n");
  if(gmv_Lese_Gitter(f,&(DSet->Gitter))==TRUE) return TRUE;
  /* Debug */ fprintf(stderr,"Gitter gelesen!\n");
  /* Hier kommt noch so einiges */
  Pos=ftello(f);
  for(i=0;i<3;i++) DSet->V[i]=NULL;
  if(Scan_Name(f,"velocity 1")==FALSE) {
    /* Debug */ fprintf(stderr,"Geschwindigkeitsfeld gefunden!\n");
    /* Lese nun die Geschwindigkeitsfelder ein */
    /* Debug */ fprintf(stderr,"Lesen des Geschwindigkeitsfeldes...\n");
    for(i=0;i<Dim;i++)
      DSet->V[i]=(Daten_Typ *) calloc(DSet->Gitter.Nodes.Anz_Nodes+1,
				      sizeof(Daten_Typ));
    for(i=0;i<3;i++) {
      if(i<Dim)
	Lese_Daten(f,DSet->Gitter.Nodes.Anz_Nodes,DSet->V[i]+1);
      else
	Lese_Daten(f,DSet->Gitter.Nodes.Anz_Nodes,NULL);
    }
  } else {
    /* Debug */ fprintf(stderr,"Kein Geschwindigkeitsfeld gefunden!\n");
    fseeko(f,Pos,SEEK_SET);
  }
  /* Debug */ fprintf(stderr,"Fertig!\n");
  /**/
  DSet->Num_Fields=0;
  DSet->Field_Names=0;
  DSet->Data_Fields=NULL;
  Pos=ftello(f);
  if(Scan_Name(f,"variable")==TRUE) {
    /* Debug */ fprintf(stderr,"Kein Variablenblock gefunden!\n");
    fseeko(f,Pos,SEEK_SET);
    return TRUE;
  }
  /* Debug */ fprintf(stderr,"Variablenblock gefunden!\n");
  /* Nun werden nacheinander die anderen Datenfelder
     identifiziert und eingelesen
  */
  DSet->Num_Fields=0;
  DSet->Field_Names=0;
  DSet->Data_Fields=NULL;
  if(getline_trimmed(&s,&n,f)==TRUE) return TRUE;
  while(strncasecmp(s,"endvars",7)!=0) {
    /* Bearbeite neues Datenfeld */
    /* Extrahiere den Feldnamen */
    s1=Extract_Field_Name(s);
    if(s1==NULL) {
      free(s);
      return TRUE;
    }
    /* Debug */ fprintf(stderr,"Datenfeld: %s\n",s1);
    Add_Field_Name(s1,&(DSet->Num_Fields),&(DSet->Field_Names));
    free(s1);
    DSet->Data_Fields=(Daten_Typ **)
      realloc(DSet->Data_Fields,DSet->Num_Fields*sizeof(Daten_Typ *));
    DSet->Data_Fields[DSet->Num_Fields-1]= (Daten_Typ *)
      calloc(DSet->Gitter.Nodes.Anz_Nodes+1,sizeof(Daten_Typ));
    Lese_Daten(f,DSet->Gitter.Nodes.Anz_Nodes,
	       DSet->Data_Fields[DSet->Num_Fields-1]+1);
    /**/
    if(getline_trimmed(&s,&n,f)==TRUE) return TRUE;
  }
  free(s);
  /**/
  return FALSE;
}

void gmv_Schreibe_Header(FILE *f) {
  fprintf(f,"gmvinput ascii\n");
}

void gmv_Schreibe_Dataset(FILE *f,Dataset_Typ *DSet,const char *Mesh_File) {
  Zaehler_Typ i;
  Anz_Typ N;
  /* Schreibe zuerst den Fromfileverweis auf das Mesh */
  fprintf(f,"nodes fromfile \"%s\"\n",Mesh_File);
  fprintf(f,"cells fromfile \"%s\"\n",Mesh_File);
  N=DSet->Gitter.Nodes.Anz_Nodes;
  /* Falls ein Geschwindigkeitsfeld vorhanden ist, so schreibe dieses */
  if(DSet->V[0]!=NULL) {
    fprintf(f,"velocity 1\n");
    for(i=0;i<3;i++)
      Schreibe_Daten(f,N,(i<Dim?DSet->V[i]+1:NULL));
  }
  /* Nun schreibe alle �brigen Datenfelder */
  if(DSet->Num_Fields>0) {
    fprintf(f,"variable\n");
    for(i=0;i<DSet->Num_Fields;i++) {
      fprintf(f,"%s 1\n",DSet->Field_Names[i]);
      Schreibe_Daten(f,N,DSet->Data_Fields[i]+1);
    }
    fprintf(f,"endvars\n");
  }
}

void gmv_Schreibe_Footer(FILE *f) {
  fprintf(f,"endgmv\n");
}

Daten_Typ My_Diff(Daten_Typ A,Daten_Typ B) {
  return A-B;
}

void my_select(Daten_Typ *Source,Daten_Typ *Dest, Index_Typ *Map,Anz_Typ n) {
  Zaehler_Typ i;
  for(i=0;i<n;i++)
    Dest[i+1]=(Map[i]!=0 ? Source[Map[i]] : 0.0);
}

void map(Daten_Typ *Source1,Daten_Typ *Source2,Daten_Typ *Dest,
	 Index_Typ *Map1,Index_Typ *Map2,Anz_Typ n,
	 Daten_Typ (*func)(Daten_Typ,Daten_Typ)){
  Zaehler_Typ i;
  for(i=0;i<n;i++)
    Dest[i+1]=(*func)((Map1[i]!=0 ? Source1[Map1[i]] : 0.0),
		      (Map2[i]!=0 ? Source2[Map2[i]] : 0.0));
}

void Gen_Map(Nodes_Typ *S,Nodes_Typ *D,Index_Typ *Map,Bool_Typ Fast){
  Zaehler_Typ i,j;
  Anz_Typ M;
  gb_Tree *Tree;
  Daten_Typ P[3];

  if(Fast==TRUE) {
    M=M_min(S->Anz_Nodes,D->Anz_Nodes);
    for(i=0;i<M;i++) Map[i]=i+1;
    for(i=M;i<D->Anz_Nodes;i++) Map[i]=0;
  } else {
    /* Debug */ fprintf(stderr,"Erzeuge Baum...\n");
    Tree=gb_create(S->Anz_Nodes,S->K,Dim);
    /* Debug */ fprintf(stderr,"Baum erzeugt!\n");
    for(i=0;i<D->Anz_Nodes;i++) {
      for(j=0;j<Dim;j++) P[j]=D->K[j][i+1];
      Map[i]=gb_search(Tree,P,&Dist_Sum,&Searchbox,Eps_Dist);
    }
    /* Debug */ fprintf(stderr,"Zerst�re Baum...\n");
    gb_destroy(&Tree);
    /* Debug */ fprintf(stderr,"Baum zerst�rt!\n");
  }
}

/* ############################################## */
int main(int argc,char **argv) {
  int Pos,ENofA=3;
  FILE *f;
  Dataset_Typ DSet1,DSet2,DSet_Out;
  Zaehler_Typ i;
  Anz_Typ N;
  Index_Typ *Idx[2],j;

  if(!(Pos=Get_Flags(argc,argv))) {
    fprintf(stderr,"Fehlerhafte Optionen!\n");
    return EXIT_FAILURE;
  }
  if(Flag_Zero) ENofA--;
  ENofA+=Pos;
  if(ENofA!=argc) {
    fprintf(stderr,"Falsche Anzahl von Parametern!\n");
    fprintf(stderr,"Syntax: %s [-f][-2] Data1 Data2 Mesh\n",argv[0]);
    fprintf(stderr,"             or\n");
    fprintf(stderr,"        %s [-f][-2] -z Data1 Mesh\n",argv[0]);
    fprintf(stderr," -f : Fast-Mapping.Knotennummern bleiben erhalten!\n");
    fprintf(stderr," -z : Nehme einen Nulldatensatz f�r Data2 an.\n");
    fprintf(stderr," -2 : Verwende intern nur 2D-Koordinaten.\n");
    return EXIT_FAILURE;
  }
  /* Einlesen der Daten */
  f=gmv_open(argv[Pos]);
  if(f==NULL) {
    fprintf(stderr,"Fehler bei Parameter Data1!\n");
    return EXIT_FAILURE;
  }
  if(gmv_Lese_Dataset(f,&DSet1)==TRUE) {
    fprintf(stderr,"Fehler bei Lesen von %s!\n",argv[Pos]);
    return EXIT_FAILURE;
  }
  gmv_close(f);
  Pos++;
  if(Flag_Zero==FALSE) {
    f=gmv_open(argv[Pos]);
    if(f==NULL) {
      fprintf(stderr,"Fehler bei Parameter Data2!\n");
      return EXIT_FAILURE;
    }
    if(gmv_Lese_Dataset(f,&DSet2)==TRUE) {
      fprintf(stderr,"Fehler bei Lesen von %s!\n",argv[Pos]);
      return EXIT_FAILURE;
    }
    gmv_close(f);
    Pos++;
  }
  f=gmv_open(argv[Pos]);
  if(f==NULL) {
    fprintf(stderr,"Fehler bei Parameter Mesh!\n");
    return EXIT_FAILURE;
  }
  if(gmv_Lese_Gitter(f,&(DSet_Out.Gitter))==TRUE) {
    fprintf(stderr,"Fehler bei Lesen von %s!\n",argv[Pos]);
    return EXIT_FAILURE;
  }
  gmv_close(f);
  /* Daten gelesen! */
  N=DSet_Out.Gitter.Nodes.Anz_Nodes;
  /* Aufbau der IndexListen */
  Idx[0]=(Index_Typ *)calloc(N,sizeof(Index_Typ));
  Gen_Map(&(DSet1.Gitter.Nodes),&(DSet_Out.Gitter.Nodes),Idx[0],Flag_Fast);
  if(Flag_Zero==FALSE) {
    Idx[1]=(Index_Typ *)calloc(N,sizeof(Index_Typ));
    Gen_Map(&(DSet2.Gitter.Nodes),&(DSet_Out.Gitter.Nodes),Idx[1],Flag_Fast);
  }
  /* Nun bestimme ich die Datenfelder, die in DSet_Out
     vorhanden sein sollen und f�lle sie mit Daten.
  */
  /* Soll ich ein Vektorfeld verwenden ? */
  if((DSet1.V[0]==NULL)||((DSet2.V[0]==NULL)&&(Flag_Zero==FALSE))) {
    /* Kein Vektorfeld */
    for(i=0;i<3;i++) DSet_Out.V[i]=NULL;
  } else {
    for(i=0;i<Dim;i++) {
      DSet_Out.V[i]=(Daten_Typ *)calloc(N+1,sizeof(Daten_Typ));
      if(Flag_Zero==TRUE)
	my_select(DSet1.V[i],DSet_Out.V[i],Idx[0],N);
      else
	map(DSet1.V[i],DSet2.V[i],DSet_Out.V[i],Idx[0],Idx[1],N,&My_Diff);
    }
  }
  DSet_Out.Num_Fields=0;
  DSet_Out.Field_Names=NULL;
  DSet_Out.Data_Fields=NULL;
  /* Nun gehe ich durch die einzelnen Datenfelder */
  for(i=0;i<DSet1.Num_Fields;i++) {
    j=i;
    if(Flag_Zero==FALSE)
      j=Search_Field_Name(DSet1.Field_Names[i],DSet2.Num_Fields,
			  DSet2.Field_Names);
    if((Flag_Zero==TRUE)||(j<DSet2.Num_Fields)) {
      /* F�ge ein Datenfeld an */
      Add_Field_Name(DSet1.Field_Names[i],&(DSet_Out.Num_Fields),
		     &(DSet_Out.Field_Names));
      DSet_Out.Data_Fields=(Daten_Typ **) 
	realloc(DSet_Out.Data_Fields,sizeof(Daten_Typ *)*DSet_Out.Num_Fields);
      DSet_Out.Data_Fields[DSet_Out.Num_Fields-1]=(Daten_Typ *)
	calloc(N+1,sizeof(Daten_Typ));
      if(Flag_Zero==TRUE)
	my_select(DSet1.Data_Fields[i],
	       DSet_Out.Data_Fields[DSet_Out.Num_Fields-1],Idx[0],N);
      else
	map(DSet1.Data_Fields[i],DSet2.Data_Fields[j],
	    DSet_Out.Data_Fields[DSet_Out.Num_Fields-1],
	    Idx[0],Idx[1],N,&My_Diff);
    }
  }
  /* Zum Abschlu� schreibe ich noch das erhaltene DataSet */
  gmv_Schreibe_Header(stdout);
  gmv_Schreibe_Dataset(stdout,&DSet_Out,argv[Pos]);
  gmv_Schreibe_Footer(stdout);
  /* Ende */
  cleanup_temps();
  return EXIT_SUCCESS;
}
