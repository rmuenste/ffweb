#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

struct RGB
{
  double r,g,b;
};

struct Spline_Data
{
  double x1;
  double a1,c1,a2,c2;
};

/* Ausgabepuffer fuer die Farbpalette */
struct RGB Palette[256];
/* Puffer fuer die Gradiationskurve */
double Gradient[256];
/* Puffer fuer den jeweiligen Dateinamen */
char *Name,*Templat;

void fill_spline_buffer(struct Spline_Data *Data,double x,double y)
{
  Data->x1=x;
  /* Von Maple berechnete Formeln */
  Data->a1=0.5*(y-x)/(x*x*(x-1));
  Data->c1=0.5*(x*(x+y)-2*y)/(x*(x-1));
  Data->a2=0.5*(y-x)/(x*(1+x*(x-2)));
  Data->c2=0.5*((x+y-3)*x+y)/(x*(x-1));
}

double eval_spline(struct Spline_Data *Data,double x)
{
  if(x<=Data->x1) return x*(Data->a1*x*x+Data->c1);
  else
    {
      x=x-1;
      return x*(Data->a2*x*x+Data->c2)+1;
    }
}

double bounce(double x)
{
  if(x<0.0) return 0.0;
  if(x>1.0) return 1.0;
  return x;
}

void fill_gradient(double x1,double y1,double *grad)
{
  int i;
  struct Spline_Data Spline;
  fill_spline_buffer(&Spline,x1,y1);
  for(i=0;i<256;i++,grad++) *grad=bounce(eval_spline(&Spline,i/255.0));
}

void swap_gradient(double *grad)
{
  int i;
  double d;
  for(i=0;i<128;i++)
    {
      d=grad[i];
      grad[i]=grad[255-i];
      grad[255-i]=d;
    }
}

void fill_G_palette(double *grad,struct RGB *pal)
{
  int i;
  for(i=0;i<256;i++,grad++,pal++) 
    {
      pal->r=pal->g=pal->b=bounce(*grad);
    }
}
/* Erzeugt einen Farbverlauf ueber das HSI Farbmodell  
void GEN_RGB(double H,struct RGB *P)
{
  H*=2.0;
  if(H<1)
    {
      P->b=0;
      P->r=bounce((1+cos(2*H/3*M_PI)/cos((1-2*H)*M_PI/3))/3);
      P->g=1-P->r;
    }
  else
    {
      H=H-1;
      P->r=0;
      P->g=bounce((1+cos(2*H/3*M_PI)/cos((1-2*H)*M_PI/3))/3);
      P->b=1-P->g;
    }
}
*/

/* Erzeugt einen Farbverlauf ueber verschobene sin^2(x) Funktionen  
void GEN_RGB(double x,struct RGB *P)
{
  double d;
  d=bounce(cos(x*M_PI)); 
  P->b=bounce(d*d);
  d=bounce(sin(x*M_PI));
  P->g=bounce(d*d);
  d=bounce(-cos(x*M_PI));
  P->r=bounce(d*d);
}
*/
/* Erzeugt einen Farbverlauf ueber stueckweise lineare Funktionen */

void GEN_RGB(double x,struct RGB *P)
{
  P->b=bounce(2-fabs(4*x));
  P->g=bounce(2-fabs(4*(x-0.5)));
  P->r=bounce(2-fabs(4*(x-1)));
}

void fill_C_palette(double *grad,struct RGB *pal)
{
  int i;
  for(i=0;i<256;i++,grad++,pal++) GEN_RGB(*grad,pal);
}

void output_pal(char * nam,struct RGB *pal)
{
  FILE *f;
  int i;

  f=fopen(nam,"w");
  if(f==NULL) {printf("Konnte Datei %s nicht oeffnen!\n",nam); return;}
  
  fprintf(f,"gmvcmap\n");
  for(i=0;i<256;i++,pal++) fprintf(f,"%f %f %f\n",pal->r,pal->g,pal->b);
  fclose(f);
}

void Anleitung(const char * nam)
{
  printf("Falsche Parameterzahl!\n Aufruf: %s template [x [y]]\n x aus (0,1), y aus [0,1]\n",nam);
}

int main(int argc,char **argv)
{
  double x1,y1;

  if((argc<2)||(argc>4)) {Anleitung(argv[0]); return EXIT_FAILURE;}
  if(argc>=3) x1=atof(argv[2]);
  else x1=0.5;
  if((x1<=0.0)||(x1>=1.0)){Anleitung(argv[0]); return EXIT_FAILURE;}
  if(argc==4) y1=atof(argv[3]);
  else y1=0.5;
  if((y1<0.0)||(y1>1.0)){Anleitung(argv[0]); return EXIT_FAILURE;}
  Templat=argv[1];
  Name=(char *)calloc(sizeof(char),strlen(Templat)+3+4+1);
  if(Name==NULL) {puts("Nicht genuegend Speicher frei!"); return EXIT_FAILURE;}

  fill_gradient(x1,y1,Gradient);
  fill_G_palette(Gradient,Palette);
  sprintf(Name,"%s_G.cmap",Templat);
  output_pal(Name,Palette);
  fill_C_palette(Gradient,Palette);
  sprintf(Name,"%s_C.cmap",Templat);
  output_pal(Name,Palette);
  swap_gradient(Gradient);
  fill_G_palette(Gradient,Palette);
  sprintf(Name,"%s_GI.cmap",Templat);
  output_pal(Name,Palette);
  fill_C_palette(Gradient,Palette);
  sprintf(Name,"%s_CI.cmap",Templat);
  output_pal(Name,Palette);

  free(Name);
  return EXIT_SUCCESS;
}

