# makefile fuer pp2d fuer sparc
#
OO=o
#
   FEATFLOW=/home/people/cbecker/tmp/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libgen
    SRCPP2D=$(FEATFLOW)/source/pp2d/src
#
OBJ= $(OO)/indat2d.o\
     $(OO)/parq2d.o\
     $(OO)/pp2d.o
#
COMOPT =  
ARFLAGS = rv
LDFLAGS = $(FEATFLOWLIB)/libpp2d.a \
$(FEATFLOWLIB)/libpp2dmg.a \
$(FEATFLOWLIB)/libfeat2d.a \
-lF77 $(FEATFLOWLIB)/libblas.a
#
pp2d :    $(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/indat2d.o: indat2d.f
	f77 -c $(COMOPT) indat2d.f -o $@
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/pp2d.o: $(SRCPP2D)/pp2d.f pp2d.inc
	f77 -c $(COMOPT) $(SRCPP2D)/pp2d.f -o $@
