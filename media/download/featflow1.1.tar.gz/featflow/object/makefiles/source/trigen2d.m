# makefile fuer trigen2d fuer sparc
#
OO=o
#
   FEATFLOW=XXFFXX
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libXXLIBXX
    SRCTRIGEN2D=$(FEATFLOW)/source/trigen2d/src
#
OBJ= $(OO)/parq2d.o\
     $(OO)/trigen2d.o
#
COMOPT = XXCOXX
ARFLAGS = XXARXX
LDFLAGS =  $(FEATFLOWLIB)/libtrigen2d.a \
$(FEATFLOWLIB)/libfeat2d.a \
XX77XX
#
trigen2d :$(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/trigen2d.o: $(SRCTRIGEN2D)/trigen2d.f trigen2d.inc
	f77 -c $(COMOPT) $(SRCTRIGEN2D)/trigen2d.f -o $@
