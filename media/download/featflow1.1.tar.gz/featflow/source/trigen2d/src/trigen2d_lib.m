      FEATFLOW=/home/people/cbecker/tmp/featflow

         LIB=$FEATFLOW/object/libraries/libgen/libtrigen2d.a
      COMOPT="" 

for i in  *.f
do
      f77 -c $COMOPT -o o/$i.o $i
      ar rv $LIB o/$i.o 
      rm o/$i.o
      echo
done
      ranlib $LIB
      
