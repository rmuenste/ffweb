# makefile fuer feat3dtest fuer sparc
#
OO=o
#
   FEATFLOW=/home/people/cbecker/tmp/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libgen
#
OBJ= $(OO)/feat3dtest.o\
     $(OO)/parq.o
#
COMOPT = 
ARFLAGS = rv
LDFLAGS =  $(FEATFLOWLIB)/libfeat3d.a \
$(FEATFLOWLIB)/libfeat2d.a \
-lF77 $(FEATFLOWLIB)/libblas.a
#
feat3dtest :$(OBJ)
	    f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/feat3dtest.o: feat3dtest.f
	f77 -c $(COMOPT) feat3dtest.f -o $@
$(OO)/parq.o: parq.f
	f77 -c $(COMOPT) parq.f -o $@
