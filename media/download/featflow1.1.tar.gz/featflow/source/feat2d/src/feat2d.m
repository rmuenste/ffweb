      FEATFLOW=/home/people/cbecker/tmp/featflow

         LIB=$FEATFLOW/object/libraries/libgen/libfeat2d.a
      COMOPT="" 

for i in  *.f
do
      f77 -c $COMOPT -o o/$i.o $i
      ar rv $LIB o/$i.o 
      rm o/$i.o
      echo
done

cc -c timewrap.c -o o/timewrap.o
      ar rv $LIB o/timewrap.o

      ranlib $LIB
