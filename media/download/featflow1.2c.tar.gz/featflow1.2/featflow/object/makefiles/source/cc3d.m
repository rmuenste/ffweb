# makefile fuer cc3d fuer sparc
#
OO=o
#
   FEATFLOW=XXFFXX
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libXXLIBXX
    SRCCC3D=$(FEATFLOW)/source/cc3d/src
#
OBJ= $(OO)/indat3d.o\
     $(OO)/parq3d.o\
     $(OO)/cc3d.o
#
COMOPT = XXCOXX
ARFLAGS = XXARXX
LDFLAGS = $(FEATFLOWLIB)/libcc3d.a \
$(FEATFLOWLIB)/libcc3dmg.a \
$(FEATFLOWLIB)/libfeat3d.a \
$(FEATFLOWLIB)/libfeat2d.a  \
XX77XX
#
cc3d :    $(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/indat3d.o: indat3d.f
	f77 -c $(COMOPT) indat3d.f -o $@
$(OO)/parq3d.o: parq3d.f
	f77 -c $(COMOPT) parq3d.f -o $@
$(OO)/cc3d.o: $(SRCCC3D)/cc3d.f cc3d.inc
	f77 -c $(COMOPT) $(SRCCC3D)/cc3d.f -o $@
