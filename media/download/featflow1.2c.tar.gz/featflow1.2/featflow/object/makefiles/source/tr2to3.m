# makefile fuer tr2to3 fuer sparc
#
OO=o
#
   FEATFLOW=XXFFXX
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libXXLIBXX
    SRCTR2TO3=$(FEATFLOW)/source/tr2to3/src
#
OBJ= $(OO)/parq2d.o\
     $(OO)/tr2to3.o
#
COMOPT = XXCOXX
ARFLAGS = XXARXX
LDFLAGS = $(FEATFLOWLIB)/libtr2to3.a \
$(FEATFLOWLIB)/libfeat2d.a \
 XX77XX
#
tr2to3 :$(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/tr2to3.o: $(SRCTR2TO3)/tr2to3.f tr2to3.inc
	f77 -c $(COMOPT) $(SRCTR2TO3)/tr2to3.f -o $@
