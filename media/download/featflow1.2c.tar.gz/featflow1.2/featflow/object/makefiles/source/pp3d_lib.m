      FEATFLOW=XXFFXX

         LIB=$FEATFLOW/object/libraries/libXXLIBXX/libpp3d.a
      COMOPT="XXCOXX" 

for i in  *.f
do
      f77 -c $COMOPT -o o/$i.o $i
      ar XXARXX $LIB o/$i.o 
      rm o/$i.o
      echo
done
      XXRLXX
      
