# makefile fuer trigen2d fuer sparc
#
OO=o
#
   FEATFLOW=/home/cerberus5/featflow/sources/featflow1.2_new/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
    SRCTRIGEN2D=$(FEATFLOW)/source/trigen2d/src
#
OBJ= $(OO)/parq2d.o\
     $(OO)/trigen2d.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:1024/64/1
ARFLAGS = rv
LDFLAGS =  $(FEATFLOWLIB)/libtrigen2d.a \
$(FEATFLOWLIB)/libfeat2d.a \
-lF77 -xlic_lib=sunperf
#
trigen2d :$(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/trigen2d.o: $(SRCTRIGEN2D)/trigen2d.f trigen2d.inc
	f77 -c $(COMOPT) $(SRCTRIGEN2D)/trigen2d.f -o $@
