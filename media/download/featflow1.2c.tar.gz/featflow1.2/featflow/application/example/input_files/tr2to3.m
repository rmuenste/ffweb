# makefile fuer tr2to3 fuer sparc
#
OO=o
#
   FEATFLOW=/home/cerberus5/featflow/sources/featflow1.2_new/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
    SRCTR2TO3=$(FEATFLOW)/source/tr2to3/src
#
OBJ= $(OO)/parq2d.o\
     $(OO)/tr2to3.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:1024/64/1
ARFLAGS = rv
LDFLAGS = $(FEATFLOWLIB)/libtr2to3.a \
$(FEATFLOWLIB)/libfeat2d.a \
 -lF77 -xlic_lib=sunperf
#
tr2to3 :$(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/tr2to3.o: $(SRCTR2TO3)/tr2to3.f tr2to3.inc
	f77 -c $(COMOPT) $(SRCTR2TO3)/tr2to3.f -o $@
