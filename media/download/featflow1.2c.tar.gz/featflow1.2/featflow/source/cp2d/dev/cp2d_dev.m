# makefile fuer pp2d fuer ultra
#
OO=o
#
   FEATFLOW=/home/cerberus5/featflow/sources/featflow1.2_new/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
#
OBJ= $(OO)/avs2d.o\
$(OO)/ab07.o\
$(OO)/bmul.o\
$(OO)/bndry.o\
$(OO)/coeff.o\
$(OO)/cp2d.o\
$(OO)/dfkt.o\
$(OO)/error.o\
$(OO)/fpost.o\
$(OO)/gupwd.o\
$(OO)/indat2d.o\
$(OO)/init1.o\
$(OO)/invert.o\
$(OO)/matmul.o\
$(OO)/mgrout.o\
$(OO)/mgstp.o\
$(OO)/nsdef.o\
$(OO)/optcnl.o\
$(OO)/oseen.o\
$(OO)/parq2d.o\
$(OO)/projma.o\
$(OO)/rdparm.o\
$(OO)/sblock.o\
$(OO)/spfile.o\
$(OO)/spfiles.o\
$(OO)/sprich.o\
$(OO)/supwdg.o\
$(OO)/trsort.o\
$(OO)/util.o\
$(OO)/vanca.o\
$(OO)/xmrout.o\
$(OO)/yrouta.o\
$(OO)/yroutp.o\
$(OO)/yrouts.o\
$(OO)/yroutu.o\
$(OO)/zvalue1.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:1024/64/1
ARFLAGS = rv
LDFLAGS = $(FEATFLOWLIB)/libfeat2d.a \
-lF77 -xlic_lib=sunperf
#
cp2d :$(OBJ)
	f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@
#
$(OO)/avs2d.o: avs2d.f common.inc dwork.inc
	f77 -c $(COMOPT) avs2d.f -o $@
$(OO)/ab07.o: ab07.f
	f77 -c $(COMOPT) ab07.f -o $@
$(OO)/bmul.o: bmul.f
	f77 -c $(COMOPT) bmul.f -o $@
$(OO)/bndry.o: bndry.f common.inc dwork.inc
	f77 -c $(COMOPT) bndry.f -o $@
$(OO)/coeff.o: coeff.f common.inc dwork.inc
	f77 -c $(COMOPT) coeff.f -o $@
$(OO)/cp2d.o: cp2d.f common.inc nnwork.inc
	f77 -c $(COMOPT) cp2d.f -o $@
$(OO)/dfkt.o: dfkt.f common.inc dwork.inc
	f77 -c $(COMOPT) dfkt.f -o $@
$(OO)/error.o: error.f
	f77 -c $(COMOPT) error.f -o $@
$(OO)/fpost.o: fpost.f common.inc dwork.inc
	f77 -c $(COMOPT) fpost.f -o $@
$(OO)/gupwd.o: gupwd.f common.inc dwork.inc
	f77 -c $(COMOPT) gupwd.f -o $@
$(OO)/indat2d.o: indat2d.f
	f77 -c $(COMOPT) indat2d.f -o $@
$(OO)/init1.o: init1.f common.inc dwork.inc
	f77 -c $(COMOPT) init1.f -o $@
$(OO)/invert.o: invert.f common.inc dwork.inc
	f77 -c $(COMOPT) invert.f -o $@
$(OO)/matmul.o: matmul.f common.inc dwork.inc
	f77 -c $(COMOPT) matmul.f -o $@
$(OO)/mgrout.o: mgrout.f common.inc dwork.inc
	f77 -c $(COMOPT) mgrout.f -o $@
$(OO)/mgstp.o: mgstp.f common.inc dwork.inc
	f77 -c $(COMOPT) mgstp.f -o $@
$(OO)/nsdef.o: nsdef.f common.inc dwork.inc
	f77 -c $(COMOPT) nsdef.f -o $@
$(OO)/optcnl.o: optcnl.f common.inc dwork.inc
	f77 -c $(COMOPT) optcnl.f -o $@
$(OO)/oseen.o: oseen.f common.inc dwork.inc
	f77 -c $(COMOPT) oseen.f -o $@
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/projma.o: projma.f common.inc dwork.inc
	f77 -c $(COMOPT) projma.f -o $@
$(OO)/rdparm.o: rdparm.f
	f77 -c $(COMOPT) rdparm.f -o $@
$(OO)/sblock.o: sblock.f common.inc dwork.inc
	f77 -c $(COMOPT) sblock.f -o $@
$(OO)/spfile.o: spfile.f common.inc dwork.inc
	f77 -c $(COMOPT) spfile.f -o $@
$(OO)/spfiles.o: spfiles.f common.inc dwork.inc
	f77 -c $(COMOPT) spfiles.f -o $@
$(OO)/sprich.o: sprich.f common.inc dwork.inc
	f77 -c $(COMOPT) sprich.f -o $@
$(OO)/supwdg.o: supwdg.f common.inc dwork.inc
	f77 -c $(COMOPT) supwdg.f -o $@
$(OO)/trsort.o: trsort.f
	f77 -c $(COMOPT) trsort.f -o $@
$(OO)/util.o: util.f common.inc dwork.inc
	f77 -c $(COMOPT) util.f -o $@
$(OO)/vanca.o: vanca.f common.inc dwork.inc
	f77 -c $(COMOPT) vanca.f -o $@
$(OO)/xmrout.o: xmrout.f
	f77 -c $(COMOPT) xmrout.f -o $@
$(OO)/yrouta.o: yrouta.f common.inc dwork.inc
	f77 -c $(COMOPT) yrouta.f -o $@
$(OO)/yroutp.o: yroutp.f common.inc dwork.inc
	f77 -c $(COMOPT) yroutp.f -o $@
$(OO)/yrouts.o: yrouts.f common.inc dwork.inc
	f77 -c $(COMOPT) yrouts.f -o $@
$(OO)/yroutu.o: yroutu.f common.inc dwork.inc
	f77 -c $(COMOPT) yroutu.f -o $@
$(OO)/zvalue1.o: zvalue1.f common.inc dwork.inc
	f77 -c $(COMOPT) zvalue1.f -o $@
