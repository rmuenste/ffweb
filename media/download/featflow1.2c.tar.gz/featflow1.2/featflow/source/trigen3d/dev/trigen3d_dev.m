# makefile fuer trigen3d fuer sparc
#
OO=o
#
   FEATFLOW=/home/cerberus5/featflow/sources/featflow1.2_new/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
#
OBJ= $(OO)/parq3d.o\
     $(OO)/trigen3d.o\
     $(OO)/util.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:1024/64/1
ARFLAGS = rv
LDFLAGS =  $(FEATFLOWLIB)/libfeat3d.a \
$(FEATFLOWLIB)/libfeat2d.a \
-lF77 -xlic_lib=sunperf
#
trigen3d :  $(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/parq3d.o: parq3d.f
	f77 -c $(COMOPT) parq3d.f -o $@
$(OO)/trigen3d.o: trigen3d.f
	f77 -c $(COMOPT) trigen3d.f -o $@
$(OO)/util.o: util.f
	f77 -c $(COMOPT) util.f -o $@
