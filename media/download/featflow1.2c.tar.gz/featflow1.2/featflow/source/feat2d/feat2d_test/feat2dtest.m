# makefile fuer feat2dtest fuer sparc
#
OO=o
#
   FEATFLOW=/home/cerberus5/featflow/sources/featflow1.2_new/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
#
OBJ= $(OO)/feat2dtest.o\
     $(OO)/ii010.o\
     $(OO)/ir010.o\
     $(OO)/is010.o\
     $(OO)/xii01.o\
     $(OO)/xir01.o\
     $(OO)/xis01.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:1024/64/1
ARFLAGS = rv
LDFLAGS =  $(FEATFLOWLIB)/libfeat2d.a  \
-lF77 -xlic_lib=sunperf
#
feat2dtest :$(OBJ)
	f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/feat2dtest.o: feat2dtest.f
	f77 -c $(COMOPT) feat2dtest.f -o $@
$(OO)/ii010.o: ii010.f
	f77 -c $(COMOPT) ii010.f -o $@
$(OO)/xii01.o: xii01.f
	f77 -c $(COMOPT) xii01.f -o $@
$(OO)/ir010.o: ir010.f
	f77 -c $(COMOPT) ir010.f -o $@
$(OO)/xir01.o: xir01.f
	f77 -c $(COMOPT) xir01.f -o $@
$(OO)/is010.o: is010.f
	f77 -c $(COMOPT) is010.f -o $@
$(OO)/xis01.o: xis01.f
	f77 -c $(COMOPT) xis01.f -o $@
