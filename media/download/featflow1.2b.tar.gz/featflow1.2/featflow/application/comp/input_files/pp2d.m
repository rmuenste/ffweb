# makefile fuer pp2d fuer sparc
#
OO=o
#
   FEATFLOW=/home/cerberus5/featflow/sources/featflow1.2_new/featflow
FEATFLOWLIB=$(FEATFLOW)/object/libraries/libultra2
    SRCPP2D=$(FEATFLOW)/source/pp2d/src
#
OBJ= $(OO)/indat2d.o\
     $(OO)/parq2d.o\
     $(OO)/pp2d.o
#
COMOPT = -xO5 -xtarget=ultra2 -dalign -xlibmil -fsimple=2 -Bstatic -depend -xlibmopt -lmvec -lcx -xarch=v8plusa -xsafe=mem -xcache=16/32/1:1024/64/1 
ARFLAGS = rv
LDFLAGS = $(FEATFLOWLIB)/libpp2d.a \
$(FEATFLOWLIB)/libpp2dmg.a \
$(FEATFLOWLIB)/libfeat2d.a \
-lF77 -xlic_lib=sunperf
#
pp2d :    $(OBJ)
	  f77 $(COMOPT) $(OBJ) $(LDFLAGS) -o $@ 
#			 
$(OO)/indat2d.o: indat2d.f
	f77 -c $(COMOPT) indat2d.f -o $@
$(OO)/parq2d.o: parq2d.f
	f77 -c $(COMOPT) parq2d.f -o $@
$(OO)/pp2d.o: $(SRCPP2D)/pp2d.f pp2d.inc
	f77 -c $(COMOPT) $(SRCPP2D)/pp2d.f -o $@
