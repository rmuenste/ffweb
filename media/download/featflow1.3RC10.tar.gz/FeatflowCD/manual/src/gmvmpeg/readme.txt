The documentation of GMVMPEG can be found in the subdirectory
utilities/graphics/gmvmpeg/ of the FeatFlow installation directory.