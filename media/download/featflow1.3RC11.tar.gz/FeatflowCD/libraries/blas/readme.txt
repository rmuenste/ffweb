This folder contains a basic implementation of the BLAS library.
The different subroutines provide only basic optimization
and are not intended to be used in an optimized build of FEAT(FLOW).
They are included either for compatibility as for debug reasons.

Source:      http://netlib.org/blas/blas.tgz
More info:   http://netlib.org/blas/index.html

Do make update to get the latest source.

WHENEVER POSSIBLE USE A HARDWARE OPTIMIZED BLAS LIBRARY INSTEAD!!!
