This folder contains the LAPACK library.
The different subroutines provide only basic optimization
and are not intended to be used in an optimized build of FEAT(FLOW).
They are included either for compatibility as for debug reasons.

Source:      http://netlib.org/lapack/lapack.tgz
More info:   http://netlib.org/lapack/index.html

Do make update to get the latest source.

WHENEVER POSSIBLE USE A HARDWARE OPTIMIZED LAPACK/BLAS LIBRARY INSTEAD!!!
